<?php
/**
 * Funciones del tema eBiopacking.
 *
 * Solo PHP: el CSS vive en assets/css (generado desde el sistema de diseño). Aquí solo se carga.
 *
 * @package ebiopacking
 */

add_theme_support( 'editor-styles' );

/**
 * Directorio de activos del tema (filtrable para las pruebas).
 *
 * @return string Ruta absoluta sin barra final.
 */
function ebio_theme_assets_dir(): string {
	return untrailingslashit( (string) apply_filters( 'ebio_theme_assets_dir', get_template_directory() . '/assets' ) );
}

/**
 * URL del directorio de activos (filtrable junto con la ruta).
 *
 * @return string URL sin barra final.
 */
function ebio_theme_assets_uri(): string {
	return untrailingslashit( (string) apply_filters( 'ebio_theme_assets_uri', get_template_directory_uri() . '/assets' ) );
}

/**
 * Hojas globales, en orden de carga.
 *
 * @return string[] Nombres de archivo en assets/css.
 */
function ebio_theme_global_styles(): array {
	return array( 'fonts.css', 'tokens.css', 'base.css', 'layout.css' );
}

/**
 * Handle de la última hoja global que existe (la cadena fonts → tokens → base → layout termina ahí).
 * Las hojas de bloque dependen de él para cargarse después de la base.
 *
 * @return string[] Handle en un arreglo (vacío si no hay hojas globales).
 */
function ebio_theme_base_handles(): array {
	$last = array();
	foreach ( ebio_theme_global_styles() as $file ) {
		if ( file_exists( ebio_theme_assets_dir() . '/css/' . $file ) ) {
			$last = array( 'ebio-' . basename( $file, '.css' ) );
		}
	}
	return $last;
}

/**
 * Encola fuentes, tokens, base y layout, en ese orden y si existen.
 */
function ebio_theme_enqueue_styles(): void {
	$dir  = ebio_theme_assets_dir() . '/css/';
	$uri  = ebio_theme_assets_uri() . '/css/';
	$prev = array();
	foreach ( ebio_theme_global_styles() as $file ) {
		if ( ! file_exists( $dir . $file ) ) {
			continue;
		}
		$handle = 'ebio-' . basename( $file, '.css' );
		wp_enqueue_style( $handle, $uri . $file, $prev, (string) filemtime( $dir . $file ) );
		$prev = array( $handle );
	}
}
add_action( 'wp_enqueue_scripts', 'ebio_theme_enqueue_styles' );
add_action( 'enqueue_block_assets', 'ebio_theme_enqueue_styles' );

/**
 * Los mismos archivos en el editor (add_editor_style).
 */
function ebio_theme_editor_styles(): void {
	$dir = ebio_theme_assets_dir() . '/css/';
	foreach ( ebio_theme_global_styles() as $file ) {
		if ( file_exists( $dir . $file ) ) {
			add_editor_style( 'assets/css/' . $file );
		}
	}
}
add_action( 'after_setup_theme', 'ebio_theme_editor_styles' );

/**
 * Precarga las fuentes que se pintan encima del pliegue: la regular (texto) y la media (titulares, botones). La
 * negrita (solo `strong`) se descubre al leer el CSS; precargar los tres pesos competiría con la imagen LCP.
 */
function ebio_theme_preload_font(): void {
	foreach ( array( '400', '500' ) as $weight ) {
		$name = 'roboto-latin-' . $weight . '-normal.woff2';
		if ( ! file_exists( ebio_theme_assets_dir() . '/fonts/' . $name ) ) {
			continue;
		}
		printf(
			'<link rel="preload" as="font" type="font/woff2" href="%s" crossorigin>' . "\n",
			esc_url( ebio_theme_assets_uri() . '/fonts/' . $name )
		);
	}
}
add_action( 'wp_head', 'ebio_theme_preload_font', 1 );

/**
 * Registra el CSS de cada bloque: solo se carga cuando el bloque se pinta.
 *
 * - core-<name>.css  → core/<name>
 * - product-card.css → ebio/product-grid y ebio/product-carousel
 * - <name>.css       → ebio/<name>
 */
function ebio_theme_register_block_styles(): void {
	$dir = ebio_theme_assets_dir() . '/css/blocks/';
	$uri = ebio_theme_assets_uri() . '/css/blocks/';
	$deps = ebio_theme_base_handles();
	foreach ( (array) glob( $dir . '*.css' ) as $path ) {
		$file = basename( $path, '.css' );
		if ( 0 === strpos( $file, 'core-' ) ) {
			$blocks = array( 'core/' . substr( $file, 5 ) );
			$handle = 'ebio-core-' . substr( $file, 5 );
		} elseif ( 'product-card' === $file ) {
			$blocks = array( 'ebio/product-grid', 'ebio/product-carousel' );
			$handle = 'ebio-block-product-card';
		} else {
			$blocks = array( 'ebio/' . $file );
			$handle = 'ebio-block-' . $file;
		}
		foreach ( $blocks as $i => $block ) {
			wp_enqueue_block_style(
				$block,
				array(
					// Un handle distinto por bloque si el archivo se comparte.
					'handle' => 0 === $i ? $handle : $handle . '-' . $i,
					'src'    => $uri . $file . '.css',
					'deps'   => $deps,
					'path'   => $path,
					'ver'    => (string) filemtime( $path ),
				)
			);
		}
	}
}
add_action( 'init', 'ebio_theme_register_block_styles' );

/**
 * H1 de la búsqueda: «Resultados para «consulta»» (C-M11) en lugar del texto de WordPress.
 *
 * @param string $content HTML del bloque `core/query-title`.
 * @param array  $block   Bloque analizado.
 * @return string
 */
function ebio_theme_search_title( $content, $block = array() ) {
	if ( ! is_search() || 'search' !== ( $block['attrs']['type'] ?? '' ) ) {
		return $content;
	}
	$level = (int) ( $block['attrs']['level'] ?? 1 );
	$level = ( $level >= 1 && $level <= 6 ) ? $level : 1;
	return sprintf(
		'<h%1$d class="wp-block-query-title">Resultados para «%2$s»</h%1$d>',
		$level,
		esc_html( get_search_query( false ) )
	);
}
add_filter( 'render_block_core/query-title', 'ebio_theme_search_title', 10, 2 );
