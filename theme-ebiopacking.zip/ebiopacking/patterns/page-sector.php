<?php
/**
 * Title: Página de sector
 * Slug: ebiopacking/page-sector
 * Description: Composición de catalog §5 con los textos de los fixtures default.
 * Inserter: true
 *
 * Provisional (vista previa): los datos que faltan del cliente no se publican; ver docs/content/pendientes.md.
 * Seed: cambia el H1, el sector del product-grid y las imágenes por sector.
 * Generado por tools/preview/build-home.mjs → build-site.mjs.
 *
 * @package ebiopacking
 */
?>
<!-- wp:ebio/breadcrumbs {"anchor":""} /-->

<!-- wp:ebio/hero-split {"variant":"sector","image":{"id":987100,"url":"/wp-content/uploads/preview/sector-floricultura.svg","alt":"Invernadero de flores para exportación","width":1600,"height":1200},"anchor":""} -->
<section class="ebio-hero-split ebio-hero-split--sector"><div class="ebio-hero-split__inner"><div class="ebio-hero-split__panel"><div class="ebio-hero-split__content">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Empaques para floricultura y exportación de flores</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cajas, láminas y separadores de cartón corrugado para cultivos de flores y exportadores, a la medida de tu producto.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#productos">Ver productos</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div></div><div class="ebio-hero-split__media"><img class="ebio-hero-split__image wp-image-987100" src="/wp-content/uploads/preview/sector-floricultura.svg" width="1600" height="1200" alt="Invernadero de flores para exportación" decoding="async" fetchpriority="high"/></div></div></section>
<!-- /wp:ebio/hero-split -->

<!-- wp:ebio/media-text-split {"heading":"Empaques pensados para tu operación","image":{"id":987100,"url":"/wp-content/uploads/preview/sector-operacion.svg","alt":"Empaque del sector","width":1200,"height":900},"anchor":""} -->
<section class="ebio-media-text-split"><div class="ebio-media-text-split__inner"><div class="ebio-media-text-split__media"><img class="ebio-media-text-split__image wp-image-987100" src="/wp-content/uploads/preview/sector-operacion.svg" width="1200" height="900" alt="Empaque del sector" decoding="async"/></div><div class="ebio-media-text-split__body"><h2 class="ebio-media-text-split__heading">Empaques pensados para tu operación</h2><div class="ebio-media-text-split__content">
<!-- wp:paragraph -->
<p>Diseñamos y fabricamos cajas, bandejas y láminas de cartón corrugado a la medida de tu producto. Cuéntanos qué empacas y te recomendamos la solución.</p>
<!-- /wp:paragraph -->
</div></div></div></section>
<!-- /wp:ebio/media-text-split -->

<!-- wp:ebio/product-grid {"variant":"plain","source":"sector","sector":"floricultura","anchor":"productos"} /-->

<!-- wp:ebio/faq {"heading":"Preguntas frecuentes del sector","items":[{"question":"¿Fabrican empaques en medidas especiales?","answer":"Sí. Cada caja se fabrica a la medida de tu producto. Cuéntanos las medidas que necesitas al cotizar."},{"question":"¿Cuál es el pedido mínimo?","answer":"Indícanos la cantidad que necesitas en tu solicitud de cotización y te confirmamos las condiciones del pedido."},{"question":"¿Pueden imprimir mi logo?","answer":"Sí. Fabricamos cajas impresas con tu marca; envíanos tu logo al solicitar la cotización."},{"question":"¿Despachan a todo el país y exportan?","answer":"Atendemos clientes de diferentes sectores, a nivel nacional e internacional. Dinos a dónde necesitas tu pedido al cotizar y te confirmamos la entrega."}],"uid":"faq-sector","anchor":""} -->
<section class="ebio-faq" aria-labelledby="ebio-faq-faq-sector-heading" data-wp-interactive="ebio/faq" data-wp-context="{&quot;hydrated&quot;:false}" data-wp-init="callbacks.hydrate" data-hydrated="false" data-wp-bind--data-hydrated="context.hydrated"><div class="ebio-faq__inner"><div class="ebio-faq__header"><h2 class="ebio-faq__heading" id="ebio-faq-faq-sector-heading">Preguntas frecuentes del sector</h2><p class="ebio-faq__intro">¿Otra duda? <a href="/cotizar/">Escríbenos</a></p></div><div class="ebio-faq__list"><div class="ebio-faq__item" data-open="true" data-wp-context="{&quot;index&quot;:0,&quot;open&quot;:true}" data-wp-init="callbacks.collapseInitial" data-wp-bind--data-open="context.open"><h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-sector-q0" aria-expanded="true" aria-controls="ebio-faq-faq-sector-a0" data-wp-bind--aria-expanded="context.open" data-wp-on--click="actions.toggle"><span class="ebio-faq__question-text">¿Fabrican empaques en medidas especiales?</span><span class="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span></button></h3><div class="ebio-faq__answer" id="ebio-faq-faq-sector-a0" data-wp-bind--hidden="!context.open"><p class="ebio-faq__answer-text">Sí. Cada caja se fabrica a la medida de tu producto. Cuéntanos las medidas que necesitas al cotizar.</p></div></div><div class="ebio-faq__item" data-open="true" data-wp-context="{&quot;index&quot;:1,&quot;open&quot;:true}" data-wp-init="callbacks.collapseInitial" data-wp-bind--data-open="context.open"><h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-sector-q1" aria-expanded="true" aria-controls="ebio-faq-faq-sector-a1" data-wp-bind--aria-expanded="context.open" data-wp-on--click="actions.toggle"><span class="ebio-faq__question-text">¿Cuál es el pedido mínimo?</span><span class="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span></button></h3><div class="ebio-faq__answer" id="ebio-faq-faq-sector-a1" data-wp-bind--hidden="!context.open"><p class="ebio-faq__answer-text">Indícanos la cantidad que necesitas en tu solicitud de cotización y te confirmamos las condiciones del pedido.</p></div></div><div class="ebio-faq__item" data-open="true" data-wp-context="{&quot;index&quot;:2,&quot;open&quot;:true}" data-wp-init="callbacks.collapseInitial" data-wp-bind--data-open="context.open"><h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-sector-q2" aria-expanded="true" aria-controls="ebio-faq-faq-sector-a2" data-wp-bind--aria-expanded="context.open" data-wp-on--click="actions.toggle"><span class="ebio-faq__question-text">¿Pueden imprimir mi logo?</span><span class="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span></button></h3><div class="ebio-faq__answer" id="ebio-faq-faq-sector-a2" data-wp-bind--hidden="!context.open"><p class="ebio-faq__answer-text">Sí. Fabricamos cajas impresas con tu marca; envíanos tu logo al solicitar la cotización.</p></div></div><div class="ebio-faq__item" data-open="true" data-wp-context="{&quot;index&quot;:3,&quot;open&quot;:true}" data-wp-init="callbacks.collapseInitial" data-wp-bind--data-open="context.open"><h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-sector-q3" aria-expanded="true" aria-controls="ebio-faq-faq-sector-a3" data-wp-bind--aria-expanded="context.open" data-wp-on--click="actions.toggle"><span class="ebio-faq__question-text">¿Despachan a todo el país y exportan?</span><span class="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span></button></h3><div class="ebio-faq__answer" id="ebio-faq-faq-sector-a3" data-wp-bind--hidden="!context.open"><p class="ebio-faq__answer-text">Atendemos clientes de diferentes sectores, a nivel nacional e internacional. Dinos a dónde necesitas tu pedido al cotizar y te confirmamos la entrega.</p></div></div></div></div></section>
<!-- /wp:ebio/faq -->

<!-- wp:ebio/sector-cards {"heading":"Otros sectores","intro":"Empaques pensados para cada sector: para empacar, exhibir y despachar tu producto.","items":[{"title":"Floricultura","text":"Cajas, láminas y separadores para exportar flor fresca.","url":"/sectores/floricultura/","image":{"id":51,"url":"/wp-content/uploads/preview/sector-floricultura.svg","alt":"Cultivo de flores en invernadero","width":900,"height":1200}},{"title":"Agro y frutas","text":"Bandejas y cajas para empacar y transportar fruta.","url":"/sectores/agro-frutas/","image":{"id":52,"url":"/wp-content/uploads/preview/sector-agro-frutas.svg","alt":"Bandejas de fruta en una planta de empaque","width":900,"height":1200}},{"title":"Industria","text":"Cajas telescópicas, láminas y particiones de gran formato.","url":"/sectores/industria/","image":{"id":53,"url":"/wp-content/uploads/preview/sector-industria.svg","alt":"Pallet con cajas de gran formato en bodega","width":900,"height":1200}},{"title":"Alimentos","text":"Cajas y bandejas para transportar y despachar alimentos.","url":"/sectores/alimentos/","image":{"id":54,"url":"/wp-content/uploads/preview/sector-alimentos.svg","alt":"Cajas para alimentos en una línea de despacho","width":900,"height":1200}},{"title":"Retail y e-commerce","text":"Cajas impresas, exhibidoras y ready to sell.","url":"/sectores/retail-ecommerce/","image":{"id":55,"url":"/wp-content/uploads/preview/sector-retail.svg","alt":"Cajas personalizadas listas para envío","width":900,"height":1200}}],"anchor":""} -->
<section class="ebio-sector-cards"><div class="ebio-sector-cards__inner"><div class="ebio-sector-cards__header"><h2 class="ebio-sector-cards__heading">Otros sectores</h2><p class="ebio-sector-cards__intro">Empaques pensados para cada sector: para empacar, exhibir y despachar tu producto.</p></div><ul class="ebio-sector-cards__list"><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/floricultura/"><img class="ebio-sector-cards__image wp-image-51" src="/wp-content/uploads/preview/sector-floricultura.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Floricultura</h3><p class="ebio-sector-cards__text">Cajas, láminas y separadores para exportar flor fresca.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/agro-frutas/"><img class="ebio-sector-cards__image wp-image-52" src="/wp-content/uploads/preview/sector-agro-frutas.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Agro y frutas</h3><p class="ebio-sector-cards__text">Bandejas y cajas para empacar y transportar fruta.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/industria/"><img class="ebio-sector-cards__image wp-image-53" src="/wp-content/uploads/preview/sector-industria.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Industria</h3><p class="ebio-sector-cards__text">Cajas telescópicas, láminas y particiones de gran formato.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/alimentos/"><img class="ebio-sector-cards__image wp-image-54" src="/wp-content/uploads/preview/sector-alimentos.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Alimentos</h3><p class="ebio-sector-cards__text">Cajas y bandejas para transportar y despachar alimentos.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/retail-ecommerce/"><img class="ebio-sector-cards__image wp-image-55" src="/wp-content/uploads/preview/sector-retail.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Retail y e-commerce</h3><p class="ebio-sector-cards__text">Cajas impresas, exhibidoras y ready to sell.</p></a></li></ul></div></section>
<!-- /wp:ebio/sector-cards -->

<!-- wp:ebio/cta-banner {"anchor":""} -->

<!-- wp:heading -->
<h2 class="wp-block-heading">¿No encuentras tu empaque? Lo fabricamos a tu medida.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cuéntanos qué vas a empacar, la cantidad y la medida aproximada. Te asesoramos en el diseño estructural.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- /wp:ebio/cta-banner -->
