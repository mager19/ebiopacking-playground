<?php
/**
 * Title: Sectores
 * Slug: ebiopacking/page-sectores
 * Description: Composición de catalog §5 con los textos de los fixtures default.
 * Inserter: false
 *
 * Provisional (vista previa): los datos que faltan del cliente no se publican; ver docs/content/pendientes.md.
 * Generado por tools/preview/build-home.mjs → build-site.mjs.
 *
 * @package ebiopacking
 */
?>
<!-- wp:ebio/breadcrumbs {"anchor":""} /-->

<!-- wp:group {"className":"ebio-layout-intro"} -->
<div class="wp-block-group ebio-layout-intro">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Empaques por sector</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Elige tu sector y encuentra los productos recomendados para empacar, exhibir y despachar tu mercancía.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:ebio/sector-cards {"intro":"Empaques pensados para cada sector: para empacar, exhibir y despachar tu producto.","items":[{"title":"Floricultura","text":"Cajas, láminas y separadores para exportar flor fresca.","url":"/sectores/floricultura/","image":{"id":51,"url":"/wp-content/uploads/preview/sector-floricultura.svg","alt":"Cultivo de flores en invernadero","width":900,"height":1200}},{"title":"Agro y frutas","text":"Bandejas y cajas para empacar y transportar fruta.","url":"/sectores/agro-frutas/","image":{"id":52,"url":"/wp-content/uploads/preview/sector-agro-frutas.svg","alt":"Bandejas de fruta en una planta de empaque","width":900,"height":1200}},{"title":"Industria","text":"Cajas telescópicas, láminas y particiones de gran formato.","url":"/sectores/industria/","image":{"id":53,"url":"/wp-content/uploads/preview/sector-industria.svg","alt":"Pallet con cajas de gran formato en bodega","width":900,"height":1200}},{"title":"Alimentos","text":"Cajas y bandejas para transportar y despachar alimentos.","url":"/sectores/alimentos/","image":{"id":54,"url":"/wp-content/uploads/preview/sector-alimentos.svg","alt":"Cajas para alimentos en una línea de despacho","width":900,"height":1200}},{"title":"Retail y e-commerce","text":"Cajas impresas, exhibidoras y ready to sell.","url":"/sectores/retail-ecommerce/","image":{"id":55,"url":"/wp-content/uploads/preview/sector-retail.svg","alt":"Cajas personalizadas listas para envío","width":900,"height":1200}}],"anchor":""} -->
<section class="ebio-sector-cards"><div class="ebio-sector-cards__inner"><div class="ebio-sector-cards__header"><h2 class="ebio-sector-cards__heading">Soluciones por sector</h2><p class="ebio-sector-cards__intro">Empaques pensados para cada sector: para empacar, exhibir y despachar tu producto.</p></div><ul class="ebio-sector-cards__list"><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/floricultura/"><img class="ebio-sector-cards__image wp-image-51" src="/wp-content/uploads/preview/sector-floricultura.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Floricultura</h3><p class="ebio-sector-cards__text">Cajas, láminas y separadores para exportar flor fresca.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/agro-frutas/"><img class="ebio-sector-cards__image wp-image-52" src="/wp-content/uploads/preview/sector-agro-frutas.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Agro y frutas</h3><p class="ebio-sector-cards__text">Bandejas y cajas para empacar y transportar fruta.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/industria/"><img class="ebio-sector-cards__image wp-image-53" src="/wp-content/uploads/preview/sector-industria.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Industria</h3><p class="ebio-sector-cards__text">Cajas telescópicas, láminas y particiones de gran formato.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/alimentos/"><img class="ebio-sector-cards__image wp-image-54" src="/wp-content/uploads/preview/sector-alimentos.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Alimentos</h3><p class="ebio-sector-cards__text">Cajas y bandejas para transportar y despachar alimentos.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/retail-ecommerce/"><img class="ebio-sector-cards__image wp-image-55" src="/wp-content/uploads/preview/sector-retail.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Retail y e-commerce</h3><p class="ebio-sector-cards__text">Cajas impresas, exhibidoras y ready to sell.</p></a></li></ul></div></section>
<!-- /wp:ebio/sector-cards -->

<!-- wp:ebio/cta-banner {"anchor":""} -->

<!-- wp:heading -->
<h2 class="wp-block-heading">¿No encuentras tu empaque? Lo fabricamos a tu medida.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cuéntanos qué vas a empacar, la cantidad y la medida aproximada. Te asesoramos en el diseño estructural.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- /wp:ebio/cta-banner -->
