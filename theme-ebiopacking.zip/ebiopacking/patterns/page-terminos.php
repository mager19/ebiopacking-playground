<?php
/**
 * Title: Términos y condiciones
 * Slug: ebiopacking/page-terminos
 * Description: Composición de catalog §5 con los textos de los fixtures default.
 * Inserter: false
 *
 * Provisional (vista previa): los datos que faltan del cliente no se publican; ver docs/content/pendientes.md.
 * Generado por tools/preview/build-home.mjs → build-site.mjs.
 *
 * @package ebiopacking
 */
?>
<!-- wp:ebio/breadcrumbs {"anchor":""} /-->

<!-- wp:columns {"className":"ebio-layout-legal"} -->
<div class="wp-block-columns ebio-layout-legal"><!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"tagName":"nav","className":"ebio-layout-legal-toc"} -->
<nav class="wp-block-group ebio-layout-legal-toc">
<!-- wp:paragraph -->
<p><strong>Contenido</strong></p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><a href="#uso">Uso del sitio</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#cotizaciones">Cotizaciones y pedidos</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#productos">Información de productos</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#propiedad">Propiedad intelectual</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#responsabilidad">Responsabilidad</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#datos">Datos personales</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#contacto">Ley aplicable y contacto</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</nav>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Términos y condiciones</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Estas condiciones regulan el uso del sitio ebiopacking.com y las solicitudes de cotización que envíes a eBiopacking a través de él. Al usar el sitio las aceptas. Última actualización: noviembre de 2026.</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading" id="uso">Uso del sitio</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Este sitio presenta el catálogo de eBiopacking y permite armar y enviar solicitudes de cotización. No es una tienda en línea: en el sitio no se compran productos ni se realizan pagos.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Al usar el sitio te comprometes a hacerlo de forma lícita y a no enviar información falsa, ni datos de terceros sin su autorización, ni intentar vulnerar la seguridad del sitio.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="cotizaciones">Cotizaciones y pedidos</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Enviar una solicitud de cotización no obliga a eBiopacking ni a ti a concretar una compra. Las condiciones comerciales (precio, cantidades, plazos y forma de pago) se acuerdan por escrito en la cotización o propuesta que te enviamos.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="productos">Información de productos</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Las imágenes, descripciones y medidas del sitio son de referencia. Cada empaque se fabrica a la medida de tu producto según lo acordado en la cotización. Podemos actualizar el catálogo y los contenidos del sitio sin previo aviso.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="propiedad">Propiedad intelectual</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Los textos, imágenes, logotipos y demás contenidos del sitio pertenecen a eBiopacking o a terceros que han autorizado su uso, y no pueden reproducirse con fines comerciales sin autorización escrita. Si nos envías tu logo o diseños para una cotización, declaras que tienes derecho a usarlos.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="responsabilidad">Responsabilidad</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Procuramos que la información del sitio sea exacta y que esté disponible, pero no garantizamos que no tenga errores o interrupciones. En la medida permitida por la ley, eBiopacking no responde por los daños derivados del uso del sitio, sin perjuicio de los derechos que la ley reconoce al consumidor. El sitio puede enlazar páginas de terceros, como redes sociales, sobre las cuales no tenemos control.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="datos">Datos personales</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Tratamos tus datos personales según nuestra <a href="/proteccion-de-datos/">política de protección de datos personales</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="contacto">Ley aplicable y contacto</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Estas condiciones se rigen por las leyes de la República de Colombia, y las controversias se someten a los jueces competentes de Colombia. Para cualquier consulta escríbenos a ventas@ebiopacking.com.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Podemos modificar estas condiciones; la versión vigente es la publicada en esta página, con su fecha de actualización.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:ebio/contact-channels {"variant":"compact","heading":"Canales de contacto","mapImage":{"id":91,"url":"/wp-content/uploads/preview/mapa-planta.svg","alt":"Mapa de la ubicación de la planta en el Parque Industrial San Jorge, Mosquera","width":1200,"height":900},"anchor":""} /-->
