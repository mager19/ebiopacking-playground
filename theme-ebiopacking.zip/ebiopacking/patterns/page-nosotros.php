<?php
/**
 * Title: Nosotros
 * Slug: ebiopacking/page-nosotros
 * Description: Composición de catalog §5 con los textos de los fixtures default.
 * Inserter: false
 *
 * Provisional (vista previa): los datos que faltan del cliente no se publican; ver docs/content/pendientes.md.
 * Generado por tools/preview/build-home.mjs → build-site.mjs.
 *
 * @package ebiopacking
 */
?>
<!-- wp:ebio/breadcrumbs {"anchor":""} /-->

<!-- wp:ebio/hero-split {"variant":"compact","sticker":"Fabricantes desde 2006","image":{"id":987100,"url":"/wp-content/uploads/preview/planta-bobina-papel.svg","alt":"Operario de eBiopacking con una bobina de papel en la planta","width":1600,"height":1200},"anchor":""} -->
<section class="ebio-hero-split ebio-hero-split--compact"><div class="ebio-hero-split__inner"><div class="ebio-hero-split__panel"><div class="ebio-hero-split__content">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Fabricantes de empaques de cartón corrugado desde 2006</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Somos fabricantes colombianos de empaques de cartón corrugado, en Mosquera. Conoce nuestra historia, nuestra maquinaria y nuestros valores.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/productos/">Ver productos</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div></div><div class="ebio-hero-split__media"><img class="ebio-hero-split__image wp-image-987100" src="/wp-content/uploads/preview/planta-bobina-papel.svg" width="1600" height="1200" alt="Operario de eBiopacking con una bobina de papel en la planta" decoding="async" fetchpriority="high"/></div></div></section>
<!-- /wp:ebio/hero-split -->

<!-- wp:ebio/media-text-split {"heading":"Fabricamos empaques a la medida de tu producto","image":{"id":987100,"url":"/wp-content/uploads/preview/producto-caja-telescopica.svg","alt":"Imagen de apoyo: Fabricamos empaques a la medida de tu producto","width":1200,"height":900},"anchor":""} -->
<section class="ebio-media-text-split"><div class="ebio-media-text-split__inner"><div class="ebio-media-text-split__media"><img class="ebio-media-text-split__image wp-image-987100" src="/wp-content/uploads/preview/producto-caja-telescopica.svg" width="1200" height="900" alt="Imagen de apoyo: Fabricamos empaques a la medida de tu producto" decoding="async"/></div><div class="ebio-media-text-split__body"><h2 class="ebio-media-text-split__heading">Fabricamos empaques a la medida de tu producto</h2><div class="ebio-media-text-split__content">
<!-- wp:paragraph -->
<p>eBiopacking es una empresa fundada en 2006 con el compromiso de ofrecer soluciones innovadoras en empaques de cartón corrugado. Desde el comienzo nos enfocamos en el diseño de láminas de cartón corrugado y en el desarrollo de empaques biodegradables.</p>
<!-- /wp:paragraph -->
</div></div></div></section>
<!-- /wp:ebio/media-text-split -->

<!-- wp:ebio/process-steps {"variant":"timeline","heading":"Nuestra historia como fabricantes de empaques","intro":"De una planta de corrugado en Mosquera a empaques de todas las escalas para cinco sectores.","showWhen":false,"items":[{"marker":"2006","when":"","title":"Fundación","text":"Inicia la fabricación de empaques de cartón corrugado."},{"marker":"Hoy","when":"","title":"Todas las escalas, cinco sectores","text":"Empaques de pequeño a gran formato para floricultura, agro, industria, alimentos y retail."}],"anchor":""} -->
<section class="ebio-process-steps ebio-process-steps--timeline"><div class="ebio-process-steps__inner"><div class="ebio-process-steps__header"><h2 class="ebio-process-steps__heading">Nuestra historia como fabricantes de empaques</h2><p class="ebio-process-steps__intro">De una planta de corrugado en Mosquera a empaques de todas las escalas para cinco sectores.</p></div><ol class="ebio-process-steps__list"><li class="ebio-process-steps__step"><span class="ebio-process-steps__marker">2006</span><h3 class="ebio-process-steps__title">Fundación</h3><p class="ebio-process-steps__text">Inicia la fabricación de empaques de cartón corrugado.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__marker">Hoy</span><h3 class="ebio-process-steps__title">Todas las escalas, cinco sectores</h3><p class="ebio-process-steps__text">Empaques de pequeño a gran formato para floricultura, agro, industria, alimentos y retail.</p></li></ol></div></section>
<!-- /wp:ebio/process-steps -->

<!-- wp:ebio/media-text-split {"heading":"Maquinaria pensada para resultados consistentes","image":{"id":987100,"url":"/wp-content/uploads/preview/producto-lamina-corrugada.svg","alt":"Imagen de apoyo: Maquinaria pensada para resultados consistentes","width":1200,"height":900},"mediaPosition":"end","anchor":""} -->
<section class="ebio-media-text-split ebio-media-text-split--media-end"><div class="ebio-media-text-split__inner"><div class="ebio-media-text-split__media"><img class="ebio-media-text-split__image wp-image-987100" src="/wp-content/uploads/preview/producto-lamina-corrugada.svg" width="1200" height="900" alt="Imagen de apoyo: Maquinaria pensada para resultados consistentes" decoding="async"/></div><div class="ebio-media-text-split__body"><h2 class="ebio-media-text-split__heading">Maquinaria pensada para resultados consistentes</h2><div class="ebio-media-text-split__content">
<!-- wp:paragraph -->
<p>Nuestra maquinaria está diseñada para garantizar procesos eficientes y resultados consistentes, con una producción responsable y optimizada.</p>
<!-- /wp:paragraph -->
</div></div></div></section>
<!-- /wp:ebio/media-text-split -->

<!-- wp:ebio/feature-pillars {"variant":"values","heading":"Nuestros valores","items":[{"icon":"shield","title":"Calidad","text":"Nuestro compromiso con la calidad y la excelencia nos ha permitido construir relaciones sólidas con clientes de diferentes sectores, en Colombia y en el exterior."},{"icon":"ruler","title":"Innovación","text":"Unimos la experiencia de los años con una visión de innovación constante para ofrecer empaques que protegen y realzan tu producto y cuidan el entorno."},{"icon":"phone","title":"Comunicación","text":"Mantenemos un diálogo abierto, transparente y continuo para comprender con precisión tus necesidades y expectativas."}],"anchor":""} -->
<section class="ebio-feature-pillars ebio-feature-pillars--values"><div class="ebio-feature-pillars__inner"><h2 class="ebio-feature-pillars__heading">Nuestros valores</h2><ul class="ebio-feature-pillars__list"><li class="ebio-feature-pillars__item"><span class="ebio-icon ebio-icon--shield ebio-feature-pillars__icon" aria-hidden="true"></span><h3 class="ebio-feature-pillars__title">Calidad</h3><p class="ebio-feature-pillars__text">Nuestro compromiso con la calidad y la excelencia nos ha permitido construir relaciones sólidas con clientes de diferentes sectores, en Colombia y en el exterior.</p></li><li class="ebio-feature-pillars__item"><span class="ebio-icon ebio-icon--ruler ebio-feature-pillars__icon" aria-hidden="true"></span><h3 class="ebio-feature-pillars__title">Innovación</h3><p class="ebio-feature-pillars__text">Unimos la experiencia de los años con una visión de innovación constante para ofrecer empaques que protegen y realzan tu producto y cuidan el entorno.</p></li><li class="ebio-feature-pillars__item"><span class="ebio-icon ebio-icon--phone ebio-feature-pillars__icon" aria-hidden="true"></span><h3 class="ebio-feature-pillars__title">Comunicación</h3><p class="ebio-feature-pillars__text">Mantenemos un diálogo abierto, transparente y continuo para comprender con precisión tus necesidades y expectativas.</p></li></ul></div></section>
<!-- /wp:ebio/feature-pillars -->

<!-- wp:ebio/cta-banner {"anchor":""} -->

<!-- wp:heading -->
<h2 class="wp-block-heading">¿No encuentras tu empaque? Lo fabricamos a tu medida.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cuéntanos qué vas a empacar, la cantidad y la medida aproximada. Te asesoramos en el diseño estructural.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- /wp:ebio/cta-banner -->
