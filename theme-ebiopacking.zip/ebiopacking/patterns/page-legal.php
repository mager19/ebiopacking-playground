<?php
/**
 * Title: Legal
 * Slug: ebiopacking/page-legal
 * Description: Composición de catalog §5 con los textos de los fixtures default.
 * Inserter: false
 *
 * Provisional (vista previa): los datos que faltan del cliente no se publican; ver docs/content/pendientes.md.
 * Generado por tools/preview/build-home.mjs → build-site.mjs.
 *
 * @package ebiopacking
 */
?>
<!-- wp:ebio/breadcrumbs {"anchor":""} /-->

<!-- wp:columns {"className":"ebio-layout-legal"} -->
<div class="wp-block-columns ebio-layout-legal"><!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"tagName":"nav","className":"ebio-layout-legal-toc"} -->
<nav class="wp-block-group ebio-layout-legal-toc">
<!-- wp:paragraph -->
<p><strong>Contenido</strong></p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><a href="#responsable">Responsable del tratamiento</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#alcance">Alcance</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#finalidades">Datos que recolectamos y finalidades</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#derechos">Derechos del titular</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#procedimiento">Procedimiento para consultas y reclamos</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#contacto">Canal de contacto</a></li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li><a href="#seguridad">Seguridad, conservación y cambios</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
</nav>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Política de protección de datos personales</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>En eBiopacking tratamos tus datos personales conforme a la Ley 1581 de 2012, el Decreto 1377 de 2013 y las normas que los complementan. Esta política explica quién es el responsable, para qué usamos tus datos y cómo puedes ejercer tus derechos. Última actualización: noviembre de 2026.</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading" id="responsable">Responsable del tratamiento</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>El responsable del tratamiento de los datos personales es eBiopacking, fabricante de empaques de cartón corrugado con planta en el Parque Industrial San Jorge, Mosquera, Cundinamarca (Colombia).</p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Sitio web: ebiopacking.com</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Correo electrónico: ventas@ebiopacking.com</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Teléfonos: +57 310 325 0267 y +57 310 451 4510</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="alcance">Alcance</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Esta política aplica a los datos personales que recibimos a través de este sitio web (solicitudes de cotización, formularios de contacto) y por los demás canales de atención: correo electrónico, teléfono y WhatsApp. No aplica a sitios de terceros a los que podamos enlazar, como las redes sociales.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="finalidades">Datos que recolectamos y finalidades</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Recolectamos los datos que nos entregas al solicitar una cotización o escribirnos: nombre, empresa, correo electrónico, teléfono y el detalle de tu solicitud (productos, cantidades y medidas). No solicitamos datos sensibles. Usamos tus datos para:</p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>responder tu solicitud y preparar tu cotización;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>contactarte por correo electrónico, teléfono o WhatsApp sobre tu solicitud;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>gestionar la relación comercial y el servicio al cliente;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>mejorar el funcionamiento de este sitio y de nuestros productos;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>cumplir obligaciones legales y atender requerimientos de las autoridades competentes.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
<!-- wp:paragraph -->
<p>Al enviar un formulario nos das tu autorización previa, expresa e informada para tratar tus datos con estas finalidades. No vendemos tus datos personales. Solo los compartimos con proveedores que nos prestan servicios necesarios para operar (por ejemplo, alojamiento del sitio y correo electrónico) o cuando una autoridad competente lo exige.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="derechos">Derechos del titular</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Como titular de los datos, de acuerdo con el artículo 8 de la Ley 1581 de 2012, tienes derecho a:</p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>conocer, actualizar y rectificar tus datos personales;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>solicitar prueba de la autorización que nos diste;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>ser informado, previa solicitud, sobre el uso que hemos dado a tus datos;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>presentar quejas ante la Superintendencia de Industria y Comercio por infracciones a la ley;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>revocar la autorización y solicitar la supresión de tus datos cuando no se respeten los principios, derechos y garantías legales;</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>acceder en forma gratuita a tus datos personales.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="procedimiento">Procedimiento para consultas y reclamos</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Consultas: respondemos tu consulta en un máximo de diez (10) días hábiles contados desde su recibo. Si no es posible, te informamos los motivos de la demora y la nueva fecha, que no superará cinco (5) días hábiles adicionales.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Reclamos: si consideras que tus datos deben corregirse, actualizarse o suprimirse, o que hemos incumplido la ley, envíanos un reclamo con tu identificación, la descripción de los hechos y un medio de contacto. Si el reclamo está incompleto, te pediremos corregirlo dentro de los cinco (5) días siguientes. Lo resolvemos en un máximo de quince (15) días hábiles contados desde su recibo completo; si no es posible, te informamos los motivos y la nueva fecha, que no superará ocho (8) días hábiles adicionales.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Solo puedes presentar una queja ante la Superintendencia de Industria y Comercio después de agotar este trámite con nosotros.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="contacto">Canal de contacto</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Para ejercer tus derechos escríbenos a ventas@ebiopacking.com con el asunto «Datos personales», o comunícate con nosotros por los teléfonos indicados arriba. Atendemos las consultas y los reclamos en los plazos de esta política.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading" id="seguridad">Seguridad, conservación y cambios</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Aplicamos medidas técnicas y administrativas razonables para proteger tus datos contra acceso, pérdida o uso no autorizados. Conservamos los datos mientras sean necesarios para las finalidades descritas o mientras la ley lo exija.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Podemos actualizar esta política. La versión vigente es la publicada en esta página, con su fecha de actualización.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:ebio/contact-channels {"variant":"compact","heading":"Canales de contacto","mapImage":{"id":91,"url":"/wp-content/uploads/preview/mapa-planta.svg","alt":"Mapa de la ubicación de la planta en el Parque Industrial San Jorge, Mosquera","width":1200,"height":900},"anchor":""} /-->
