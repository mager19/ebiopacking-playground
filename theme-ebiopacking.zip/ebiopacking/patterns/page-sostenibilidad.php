<?php
/**
 * Title: Sostenibilidad
 * Slug: ebiopacking/page-sostenibilidad
 * Description: Composición de catalog §5 con los textos de los fixtures default.
 * Inserter: false
 *
 * Provisional (vista previa): los datos que faltan del cliente no se publican; ver docs/content/pendientes.md.
 * Generado por tools/preview/build-home.mjs → build-site.mjs.
 *
 * @package ebiopacking
 */
?>
<!-- wp:ebio/breadcrumbs {"anchor":""} /-->

<!-- wp:ebio/hero-split {"variant":"compact","image":{"id":987100,"url":"/wp-content/uploads/preview/sostenibilidad-fibra.svg","alt":"Fibra de cartón reciclado y bobinas de papel en la planta","width":1600,"height":1200},"anchor":""} -->
<section class="ebio-hero-split ebio-hero-split--compact"><div class="ebio-hero-split__inner"><div class="ebio-hero-split__panel"><div class="ebio-hero-split__content">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Empaques sostenibles de cartón corrugado</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cartón corrugado reciclable y biodegradable, diseño con el material justo y fibra de origen responsable.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/productos/">Ver productos</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div></div><div class="ebio-hero-split__media"><img class="ebio-hero-split__image wp-image-987100" src="/wp-content/uploads/preview/sostenibilidad-fibra.svg" width="1600" height="1200" alt="Fibra de cartón reciclado y bobinas de papel en la planta" decoding="async" fetchpriority="high"/></div></div></section>
<!-- /wp:ebio/hero-split -->

<!-- wp:ebio/media-text-split {"heading":"Cartón reciclable y biodegradable","image":{"id":987100,"url":"/wp-content/uploads/preview/sostenibilidad-carton.svg","alt":"Imagen de apoyo: Cartón reciclable y biodegradable","width":1200,"height":900},"anchor":""} -->
<section class="ebio-media-text-split"><div class="ebio-media-text-split__inner"><div class="ebio-media-text-split__media"><img class="ebio-media-text-split__image wp-image-987100" src="/wp-content/uploads/preview/sostenibilidad-carton.svg" width="1200" height="900" alt="Imagen de apoyo: Cartón reciclable y biodegradable" decoding="async"/></div><div class="ebio-media-text-split__body"><h2 class="ebio-media-text-split__heading">Cartón reciclable y biodegradable</h2><div class="ebio-media-text-split__content">
<!-- wp:paragraph -->
<p>El cartón corrugado vuelve a ser fibra al final de su vida útil: es reciclable y biodegradable, y desarrollamos empaques que contribuyen a la sostenibilidad y al cuidado del medio ambiente.</p>
<!-- /wp:paragraph -->
</div></div></div></section>
<!-- /wp:ebio/media-text-split -->

<!-- wp:ebio/media-text-split {"heading":"El material justo para cada empaque","image":{"id":987100,"url":"/wp-content/uploads/preview/sostenibilidad-diseno.svg","alt":"Imagen de apoyo: El material justo para cada empaque","width":1200,"height":900},"mediaPosition":"end","anchor":""} -->
<section class="ebio-media-text-split ebio-media-text-split--media-end"><div class="ebio-media-text-split__inner"><div class="ebio-media-text-split__media"><img class="ebio-media-text-split__image wp-image-987100" src="/wp-content/uploads/preview/sostenibilidad-diseno.svg" width="1200" height="900" alt="Imagen de apoyo: El material justo para cada empaque" decoding="async"/></div><div class="ebio-media-text-split__body"><h2 class="ebio-media-text-split__heading">El material justo para cada empaque</h2><div class="ebio-media-text-split__content">
<!-- wp:paragraph -->
<p>Diseñamos cada caja para usar solo el cartón que necesita tu producto. Desde 2006 nos enfocamos en el diseño de láminas de cartón corrugado y en el desarrollo de empaques biodegradables.</p>
<!-- /wp:paragraph -->
</div></div></div></section>
<!-- /wp:ebio/media-text-split -->

<!-- wp:ebio/media-text-split {"heading":"Fibra de origen responsable","image":{"id":987100,"url":"/wp-content/uploads/preview/producto-caja-regular.svg","alt":"Imagen de apoyo: Fibra de origen responsable","width":1200,"height":900},"anchor":""} -->
<section class="ebio-media-text-split"><div class="ebio-media-text-split__inner"><div class="ebio-media-text-split__media"><img class="ebio-media-text-split__image wp-image-987100" src="/wp-content/uploads/preview/producto-caja-regular.svg" width="1200" height="900" alt="Imagen de apoyo: Fibra de origen responsable" decoding="async"/></div><div class="ebio-media-text-split__body"><h2 class="ebio-media-text-split__heading">Fibra de origen responsable</h2><div class="ebio-media-text-split__content">
<!-- wp:paragraph -->
<p>Trabajamos con papeles renovables, diseñados para reciclarse fácilmente, e incluimos alternativas con alto contenido de material reciclado. Nos comprometemos con la silvicultura responsable para que la fibra virgen, que es renovable, biodegradable y reciclable, esté disponible a largo plazo.</p>
<!-- /wp:paragraph -->
</div></div></div></section>
<!-- /wp:ebio/media-text-split -->

<!-- wp:ebio/process-steps {"heading":"El ciclo del cartón corrugado","intro":"Del material renovable al empaque, y de vuelta a fibra.","showWhen":false,"items":[{"marker":"","when":"","title":"Fibra renovable","text":"Papeles renovables, con silvicultura responsable y alto contenido de material reciclado."},{"marker":"","when":"","title":"Cartón corrugado","text":"Lo diseñamos con el material justo para tu producto."},{"marker":"","when":"","title":"Tu empaque","text":"Fabricamos en Mosquera, a la medida de lo que vas a empacar."},{"marker":"","when":"","title":"Vuelve a ser fibra","text":"Al final de su vida útil el cartón es reciclable y biodegradable."}],"anchor":""} -->
<section class="ebio-process-steps"><div class="ebio-process-steps__inner"><div class="ebio-process-steps__header"><h2 class="ebio-process-steps__heading">El ciclo del cartón corrugado</h2><p class="ebio-process-steps__intro">Del material renovable al empaque, y de vuelta a fibra.</p></div><ol class="ebio-process-steps__list"><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">1</span><h3 class="ebio-process-steps__title">Fibra renovable</h3><p class="ebio-process-steps__text">Papeles renovables, con silvicultura responsable y alto contenido de material reciclado.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">2</span><h3 class="ebio-process-steps__title">Cartón corrugado</h3><p class="ebio-process-steps__text">Lo diseñamos con el material justo para tu producto.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">3</span><h3 class="ebio-process-steps__title">Tu empaque</h3><p class="ebio-process-steps__text">Fabricamos en Mosquera, a la medida de lo que vas a empacar.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">4</span><h3 class="ebio-process-steps__title">Vuelve a ser fibra</h3><p class="ebio-process-steps__text">Al final de su vida útil el cartón es reciclable y biodegradable.</p></li></ol></div></section>
<!-- /wp:ebio/process-steps -->

<!-- wp:ebio/faq {"items":[{"question":"¿Fabrican empaques en medidas especiales?","answer":"Sí. Cada caja se fabrica a la medida de tu producto. Cuéntanos las medidas que necesitas al cotizar."},{"question":"¿Cuál es el pedido mínimo?","answer":"Indícanos la cantidad que necesitas en tu solicitud de cotización y te confirmamos las condiciones del pedido."},{"question":"¿Pueden imprimir mi logo?","answer":"Sí. Fabricamos cajas impresas con tu marca; envíanos tu logo al solicitar la cotización."},{"question":"¿Despachan a todo el país y exportan?","answer":"Atendemos clientes de diferentes sectores, a nivel nacional e internacional. Dinos a dónde necesitas tu pedido al cotizar y te confirmamos la entrega."}],"uid":"faq-sostenibilidad","anchor":""} -->
<section class="ebio-faq" aria-labelledby="ebio-faq-faq-sostenibilidad-heading" data-wp-interactive="ebio/faq" data-wp-context="{&quot;hydrated&quot;:false}" data-wp-init="callbacks.hydrate" data-hydrated="false" data-wp-bind--data-hydrated="context.hydrated"><div class="ebio-faq__inner"><div class="ebio-faq__header"><h2 class="ebio-faq__heading" id="ebio-faq-faq-sostenibilidad-heading">Preguntas frecuentes</h2><p class="ebio-faq__intro">¿Otra duda? <a href="/cotizar/">Escríbenos</a></p></div><div class="ebio-faq__list"><div class="ebio-faq__item" data-open="true" data-wp-context="{&quot;index&quot;:0,&quot;open&quot;:true}" data-wp-init="callbacks.collapseInitial" data-wp-bind--data-open="context.open"><h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-sostenibilidad-q0" aria-expanded="true" aria-controls="ebio-faq-faq-sostenibilidad-a0" data-wp-bind--aria-expanded="context.open" data-wp-on--click="actions.toggle"><span class="ebio-faq__question-text">¿Fabrican empaques en medidas especiales?</span><span class="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span></button></h3><div class="ebio-faq__answer" id="ebio-faq-faq-sostenibilidad-a0" data-wp-bind--hidden="!context.open"><p class="ebio-faq__answer-text">Sí. Cada caja se fabrica a la medida de tu producto. Cuéntanos las medidas que necesitas al cotizar.</p></div></div><div class="ebio-faq__item" data-open="true" data-wp-context="{&quot;index&quot;:1,&quot;open&quot;:true}" data-wp-init="callbacks.collapseInitial" data-wp-bind--data-open="context.open"><h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-sostenibilidad-q1" aria-expanded="true" aria-controls="ebio-faq-faq-sostenibilidad-a1" data-wp-bind--aria-expanded="context.open" data-wp-on--click="actions.toggle"><span class="ebio-faq__question-text">¿Cuál es el pedido mínimo?</span><span class="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span></button></h3><div class="ebio-faq__answer" id="ebio-faq-faq-sostenibilidad-a1" data-wp-bind--hidden="!context.open"><p class="ebio-faq__answer-text">Indícanos la cantidad que necesitas en tu solicitud de cotización y te confirmamos las condiciones del pedido.</p></div></div><div class="ebio-faq__item" data-open="true" data-wp-context="{&quot;index&quot;:2,&quot;open&quot;:true}" data-wp-init="callbacks.collapseInitial" data-wp-bind--data-open="context.open"><h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-sostenibilidad-q2" aria-expanded="true" aria-controls="ebio-faq-faq-sostenibilidad-a2" data-wp-bind--aria-expanded="context.open" data-wp-on--click="actions.toggle"><span class="ebio-faq__question-text">¿Pueden imprimir mi logo?</span><span class="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span></button></h3><div class="ebio-faq__answer" id="ebio-faq-faq-sostenibilidad-a2" data-wp-bind--hidden="!context.open"><p class="ebio-faq__answer-text">Sí. Fabricamos cajas impresas con tu marca; envíanos tu logo al solicitar la cotización.</p></div></div><div class="ebio-faq__item" data-open="true" data-wp-context="{&quot;index&quot;:3,&quot;open&quot;:true}" data-wp-init="callbacks.collapseInitial" data-wp-bind--data-open="context.open"><h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-sostenibilidad-q3" aria-expanded="true" aria-controls="ebio-faq-faq-sostenibilidad-a3" data-wp-bind--aria-expanded="context.open" data-wp-on--click="actions.toggle"><span class="ebio-faq__question-text">¿Despachan a todo el país y exportan?</span><span class="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span></button></h3><div class="ebio-faq__answer" id="ebio-faq-faq-sostenibilidad-a3" data-wp-bind--hidden="!context.open"><p class="ebio-faq__answer-text">Atendemos clientes de diferentes sectores, a nivel nacional e internacional. Dinos a dónde necesitas tu pedido al cotizar y te confirmamos la entrega.</p></div></div></div></div></section>
<!-- /wp:ebio/faq -->

<!-- wp:ebio/cta-banner {"anchor":""} -->

<!-- wp:heading -->
<h2 class="wp-block-heading">¿No encuentras tu empaque? Lo fabricamos a tu medida.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cuéntanos qué vas a empacar, la cantidad y la medida aproximada. Te asesoramos en el diseño estructural.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- /wp:ebio/cta-banner -->
