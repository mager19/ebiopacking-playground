<?php
/**
 * Title: Gracias
 * Slug: ebiopacking/page-gracias
 * Description: Composición de catalog §5 con los textos de los fixtures default.
 * Inserter: false
 *
 * Provisional (vista previa): los datos que faltan del cliente no se publican; ver docs/content/pendientes.md.
 * Generado por tools/preview/build-home.mjs → build-site.mjs.
 *
 * @package ebiopacking
 */
?>
<!-- wp:group {"className":"ebio-layout-confirm"} -->
<div class="wp-block-group ebio-layout-confirm">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Recibimos tu solicitud de cotización</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Nuestro equipo comercial revisará tu lista y te responderá con tu cotización lo antes posible.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Mientras tanto, puedes seguir explorando el catálogo.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/productos/">Ver productos</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/">Ir al inicio</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:ebio/process-steps {"heading":"Qué pasa ahora","showWhen":false,"items":[{"marker":"","when":"","title":"Confirmación por correo","text":"Recibes el resumen de tu solicitud."},{"marker":"","when":"","title":"Te contacta un asesor","text":"Confirma medidas, cantidades e impresión."},{"marker":"","when":"","title":"Recibes tu propuesta","text":"Precio y tiempos de producción."}],"anchor":""} -->
<section class="ebio-process-steps"><div class="ebio-process-steps__inner"><div class="ebio-process-steps__header"><h2 class="ebio-process-steps__heading">Qué pasa ahora</h2></div><ol class="ebio-process-steps__list"><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">1</span><h3 class="ebio-process-steps__title">Confirmación por correo</h3><p class="ebio-process-steps__text">Recibes el resumen de tu solicitud.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">2</span><h3 class="ebio-process-steps__title">Te contacta un asesor</h3><p class="ebio-process-steps__text">Confirma medidas, cantidades e impresión.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">3</span><h3 class="ebio-process-steps__title">Recibes tu propuesta</h3><p class="ebio-process-steps__text">Precio y tiempos de producción.</p></li></ol></div></section>
<!-- /wp:ebio/process-steps -->

<!-- wp:ebio/contact-channels {"variant":"compact","heading":"Otros canales","mapImage":{"id":91,"url":"/wp-content/uploads/preview/mapa-planta.svg","alt":"Mapa de la ubicación de la planta en el Parque Industrial San Jorge, Mosquera","width":1200,"height":900},"anchor":""} /-->

<!-- wp:ebio/collection-cards {"items":[{"title":"Empaques industriales","eyebrow":"Cajas, láminas y particiones","url":"/productos/empaques-industriales/","image":{"id":41,"url":"/wp-content/uploads/preview/coleccion-industriales.svg","alt":"Cajas industriales de gran formato apiladas en pallet","width":1200,"height":900}},{"title":"Empaques comerciales","eyebrow":"Exhibidoras, personalizadas y con tapa","url":"/productos/empaques-comerciales/","image":{"id":42,"url":"/wp-content/uploads/preview/coleccion-comerciales.svg","alt":"Cajas exhibidoras en un punto de venta","width":1200,"height":900}},{"title":"Empaques agro y flores","eyebrow":"Flores, frutas y hierbas","url":"/productos/empaques-agro-flores/","image":{"id":43,"url":"/wp-content/uploads/preview/coleccion-agro-flores.svg","alt":"Cajas para flores en un cultivo","width":1200,"height":900}}],"anchor":""} -->
<section class="ebio-collection-cards"><div class="ebio-collection-cards__inner"><div class="ebio-collection-cards__header"><h2 class="ebio-collection-cards__heading">Encuentra tu empaque por categoría</h2><a class="ebio-collection-cards__cta ebio-button ebio-button--secondary" href="/productos/">Ver todos los productos</a></div><ul class="ebio-collection-cards__list"><li class="ebio-collection-cards__item"><a class="ebio-collection-cards__card" href="/productos/empaques-industriales/"><img class="ebio-collection-cards__image wp-image-41" src="/wp-content/uploads/preview/coleccion-industriales.svg" width="1200" height="900" alt="" decoding="async"/><span class="ebio-collection-cards__label"><span class="ebio-collection-cards__eyebrow">Cajas, láminas y particiones</span><h3 class="ebio-collection-cards__title">Empaques industriales</h3></span><span class="ebio-icon ebio-icon--arrow-right ebio-collection-cards__arrow" aria-hidden="true"></span></a></li><li class="ebio-collection-cards__item"><a class="ebio-collection-cards__card" href="/productos/empaques-comerciales/"><img class="ebio-collection-cards__image wp-image-42" src="/wp-content/uploads/preview/coleccion-comerciales.svg" width="1200" height="900" alt="" decoding="async"/><span class="ebio-collection-cards__label"><span class="ebio-collection-cards__eyebrow">Exhibidoras, personalizadas y con tapa</span><h3 class="ebio-collection-cards__title">Empaques comerciales</h3></span><span class="ebio-icon ebio-icon--arrow-right ebio-collection-cards__arrow" aria-hidden="true"></span></a></li><li class="ebio-collection-cards__item"><a class="ebio-collection-cards__card" href="/productos/empaques-agro-flores/"><img class="ebio-collection-cards__image wp-image-43" src="/wp-content/uploads/preview/coleccion-agro-flores.svg" width="1200" height="900" alt="" decoding="async"/><span class="ebio-collection-cards__label"><span class="ebio-collection-cards__eyebrow">Flores, frutas y hierbas</span><h3 class="ebio-collection-cards__title">Empaques agro y flores</h3></span><span class="ebio-icon ebio-icon--arrow-right ebio-collection-cards__arrow" aria-hidden="true"></span></a></li></ul></div></section>
<!-- /wp:ebio/collection-cards -->
