<?php
/**
 * Title: Inicio
 * Slug: ebiopacking/page-inicio
 * Description: Composición de la página de inicio (catalog §5) con los textos de los fixtures default.
 * Inserter: false
 *
 * Provisional (vista previa): los datos que faltan del cliente no se publican; ver REWRITES en tools/preview/build-home.mjs.
 * product-carousel: sin productIds (los del fixture no existen); usa los primeros productos publicados.
 * Pendientes de la composición final de catalog §5:
 *  - ebio/testimonials va antes de ebio/cta-banner; se omite en la vista previa porque solo
 *    se muestra con `authorized: true` y no se inventan testimonios.
 * Generado por tools/preview/build-home.mjs.
 *
 * @package ebiopacking
 */
?>
<!-- wp:ebio/hero-split {"eyebrow":"Fabricantes directos · Mosquera, Colombia","sticker":"Fabricantes desde 2006","image":{"id":21,"url":"/wp-content/uploads/preview/hero-pallets-gran-formato.svg","alt":"Pallets de cajas de cartón de gran formato en bodega, con una caja pequeña en primer plano","width":1600,"height":1200},"anchor":""} -->
<section class="ebio-hero-split"><div class="ebio-hero-split__inner"><div class="ebio-hero-split__panel"><span class="ebio-hero-split__sticker" aria-hidden="true">Fabricantes desde 2006</span><p class="ebio-hero-split__eyebrow">Fabricantes directos · Mosquera, Colombia</p><div class="ebio-hero-split__content">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Empaques de cartón corrugado, de la caja pequeña al gran formato industrial</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Diseñamos y fabricamos cajas, bandejas, láminas y empaques a medida para industria, agro, flores, alimentos y retail. Arma tu lista de productos y recibe tu cotización lo antes posible.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/productos/">Ver productos</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div></div><div class="ebio-hero-split__media"><img class="ebio-hero-split__image wp-image-21" src="/wp-content/uploads/preview/hero-pallets-gran-formato.svg" width="1600" height="1200" alt="Pallets de cajas de cartón de gran formato en bodega, con una caja pequeña en primer plano" decoding="async" fetchpriority="high"/></div></div></section>
<!-- /wp:ebio/hero-split -->

<!-- wp:ebio/trust-strip {"items":[{"icon":"calendar","value":"Desde 2006","label":"fabricando empaques en Colombia"},{"icon":"factory","value":"Somos fabricantes","label":"de empaques de cartón corrugado en Mosquera"},{"icon":"pin","value":"Clientes en Colombia y el exterior","label":"de diferentes sectores"},{"icon":"recycle","value":"Cartón corrugado","label":"reciclable y biodegradable"}],"anchor":""} -->
<section class="ebio-trust-strip" aria-label="Por qué confiar en eBiopacking"><div class="ebio-trust-strip__inner"><ul class="ebio-trust-strip__list"><li class="ebio-trust-strip__item"><span class="ebio-icon ebio-icon--calendar ebio-trust-strip__icon" aria-hidden="true"></span><strong class="ebio-trust-strip__value">Desde 2006</strong><span class="ebio-trust-strip__label">fabricando empaques en Colombia</span></li><li class="ebio-trust-strip__item"><span class="ebio-icon ebio-icon--factory ebio-trust-strip__icon" aria-hidden="true"></span><strong class="ebio-trust-strip__value">Somos fabricantes</strong><span class="ebio-trust-strip__label">de empaques de cartón corrugado en Mosquera</span></li><li class="ebio-trust-strip__item"><span class="ebio-icon ebio-icon--pin ebio-trust-strip__icon" aria-hidden="true"></span><strong class="ebio-trust-strip__value">Clientes en Colombia y el exterior</strong><span class="ebio-trust-strip__label">de diferentes sectores</span></li><li class="ebio-trust-strip__item"><span class="ebio-icon ebio-icon--recycle ebio-trust-strip__icon" aria-hidden="true"></span><strong class="ebio-trust-strip__value">Cartón corrugado</strong><span class="ebio-trust-strip__label">reciclable y biodegradable</span></li></ul></div></section>
<!-- /wp:ebio/trust-strip -->

<!-- wp:ebio/scale-range {"intro":"Fabricamos en cualquier escala: desde el empaque de una sola unidad hasta cajas para maquinaria, pallets completos y contenedores de exportación.","ctaText":"Cotizar un empaque a medida","note":"Medidas de referencia a modo de ejemplo: fabricamos a la medida de tu producto.","anchor":""} /-->

<!-- wp:ebio/product-carousel {"intro":"Cada producto tiene ficha con medidas, especificaciones y botón de cotización.","anchor":""} /-->

<!-- wp:ebio/collection-cards {"items":[{"title":"Empaques industriales","eyebrow":"Cajas, láminas y particiones","url":"/productos/empaques-industriales/","image":{"id":41,"url":"/wp-content/uploads/preview/coleccion-industriales.svg","alt":"Cajas industriales de gran formato apiladas en pallet","width":1200,"height":900}},{"title":"Empaques comerciales","eyebrow":"Exhibidoras, personalizadas y con tapa","url":"/productos/empaques-comerciales/","image":{"id":42,"url":"/wp-content/uploads/preview/coleccion-comerciales.svg","alt":"Cajas exhibidoras en un punto de venta","width":1200,"height":900}},{"title":"Empaques agro y flores","eyebrow":"Flores, frutas y hierbas","url":"/productos/empaques-agro-flores/","image":{"id":43,"url":"/wp-content/uploads/preview/coleccion-agro-flores.svg","alt":"Cajas para flores en un cultivo","width":1200,"height":900}}],"anchor":""} -->
<section class="ebio-collection-cards"><div class="ebio-collection-cards__inner"><div class="ebio-collection-cards__header"><h2 class="ebio-collection-cards__heading">Encuentra tu empaque por categoría</h2><a class="ebio-collection-cards__cta ebio-button ebio-button--secondary" href="/productos/">Ver todos los productos</a></div><ul class="ebio-collection-cards__list"><li class="ebio-collection-cards__item"><a class="ebio-collection-cards__card" href="/productos/empaques-industriales/"><img class="ebio-collection-cards__image wp-image-41" src="/wp-content/uploads/preview/coleccion-industriales.svg" width="1200" height="900" alt="" decoding="async"/><span class="ebio-collection-cards__label"><span class="ebio-collection-cards__eyebrow">Cajas, láminas y particiones</span><h3 class="ebio-collection-cards__title">Empaques industriales</h3></span><span class="ebio-icon ebio-icon--arrow-right ebio-collection-cards__arrow" aria-hidden="true"></span></a></li><li class="ebio-collection-cards__item"><a class="ebio-collection-cards__card" href="/productos/empaques-comerciales/"><img class="ebio-collection-cards__image wp-image-42" src="/wp-content/uploads/preview/coleccion-comerciales.svg" width="1200" height="900" alt="" decoding="async"/><span class="ebio-collection-cards__label"><span class="ebio-collection-cards__eyebrow">Exhibidoras, personalizadas y con tapa</span><h3 class="ebio-collection-cards__title">Empaques comerciales</h3></span><span class="ebio-icon ebio-icon--arrow-right ebio-collection-cards__arrow" aria-hidden="true"></span></a></li><li class="ebio-collection-cards__item"><a class="ebio-collection-cards__card" href="/productos/empaques-agro-flores/"><img class="ebio-collection-cards__image wp-image-43" src="/wp-content/uploads/preview/coleccion-agro-flores.svg" width="1200" height="900" alt="" decoding="async"/><span class="ebio-collection-cards__label"><span class="ebio-collection-cards__eyebrow">Flores, frutas y hierbas</span><h3 class="ebio-collection-cards__title">Empaques agro y flores</h3></span><span class="ebio-icon ebio-icon--arrow-right ebio-collection-cards__arrow" aria-hidden="true"></span></a></li></ul></div></section>
<!-- /wp:ebio/collection-cards -->

<!-- wp:ebio/sector-cards {"intro":"Empaques pensados para cada sector: para empacar, exhibir y despachar tu producto.","items":[{"title":"Floricultura","text":"Cajas, láminas y separadores para exportar flor fresca.","url":"/sectores/floricultura/","image":{"id":51,"url":"/wp-content/uploads/preview/sector-floricultura.svg","alt":"Cultivo de flores en invernadero","width":900,"height":1200}},{"title":"Agro y frutas","text":"Bandejas y cajas para empacar y transportar fruta.","url":"/sectores/agro-frutas/","image":{"id":52,"url":"/wp-content/uploads/preview/sector-agro-frutas.svg","alt":"Bandejas de fruta en una planta de empaque","width":900,"height":1200}},{"title":"Industria","text":"Cajas telescópicas, láminas y particiones de gran formato.","url":"/sectores/industria/","image":{"id":53,"url":"/wp-content/uploads/preview/sector-industria.svg","alt":"Pallet con cajas de gran formato en bodega","width":900,"height":1200}},{"title":"Alimentos","text":"Cajas y bandejas para transportar y despachar alimentos.","url":"/sectores/alimentos/","image":{"id":54,"url":"/wp-content/uploads/preview/sector-alimentos.svg","alt":"Cajas para alimentos en una línea de despacho","width":900,"height":1200}},{"title":"Retail y e-commerce","text":"Cajas impresas, exhibidoras y ready to sell.","url":"/sectores/retail-ecommerce/","image":{"id":55,"url":"/wp-content/uploads/preview/sector-retail.svg","alt":"Cajas personalizadas listas para envío","width":900,"height":1200}}],"anchor":""} -->
<section class="ebio-sector-cards"><div class="ebio-sector-cards__inner"><div class="ebio-sector-cards__header"><h2 class="ebio-sector-cards__heading">Soluciones por sector</h2><p class="ebio-sector-cards__intro">Empaques pensados para cada sector: para empacar, exhibir y despachar tu producto.</p></div><ul class="ebio-sector-cards__list"><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/floricultura/"><img class="ebio-sector-cards__image wp-image-51" src="/wp-content/uploads/preview/sector-floricultura.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Floricultura</h3><p class="ebio-sector-cards__text">Cajas, láminas y separadores para exportar flor fresca.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/agro-frutas/"><img class="ebio-sector-cards__image wp-image-52" src="/wp-content/uploads/preview/sector-agro-frutas.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Agro y frutas</h3><p class="ebio-sector-cards__text">Bandejas y cajas para empacar y transportar fruta.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/industria/"><img class="ebio-sector-cards__image wp-image-53" src="/wp-content/uploads/preview/sector-industria.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Industria</h3><p class="ebio-sector-cards__text">Cajas telescópicas, láminas y particiones de gran formato.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/alimentos/"><img class="ebio-sector-cards__image wp-image-54" src="/wp-content/uploads/preview/sector-alimentos.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Alimentos</h3><p class="ebio-sector-cards__text">Cajas y bandejas para transportar y despachar alimentos.</p></a></li><li class="ebio-sector-cards__item"><a class="ebio-sector-cards__card" href="/sectores/retail-ecommerce/"><img class="ebio-sector-cards__image wp-image-55" src="/wp-content/uploads/preview/sector-retail.svg" width="900" height="1200" alt="" decoding="async"/><h3 class="ebio-sector-cards__title">Retail y e-commerce</h3><p class="ebio-sector-cards__text">Cajas impresas, exhibidoras y ready to sell.</p></a></li></ul></div></section>
<!-- /wp:ebio/sector-cards -->

<!-- wp:ebio/feature-pillars {"items":[{"icon":"factory","title":"Somos fabricantes","text":"Diseñamos y fabricamos tus empaques de cartón corrugado en Mosquera."},{"icon":"ruler","title":"Diseño estructural a medida","text":"Ajustamos medida, onda e impresión al producto que vas a empacar, de pequeño a gran formato."},{"icon":"leaf","title":"Material sostenible","text":"Cartón corrugado reciclable y biodegradable, con fibra de origen responsable."},{"icon":"phone","title":"Acompañamiento en tu pedido","text":"Un asesor revisa contigo medidas, cantidades e impresión."}],"anchor":""} -->
<section class="ebio-feature-pillars"><div class="ebio-feature-pillars__inner"><h2 class="ebio-feature-pillars__heading">Por qué eBiopacking</h2><ul class="ebio-feature-pillars__list"><li class="ebio-feature-pillars__item"><span class="ebio-icon ebio-icon--factory ebio-feature-pillars__icon" aria-hidden="true"></span><h3 class="ebio-feature-pillars__title">Somos fabricantes</h3><p class="ebio-feature-pillars__text">Diseñamos y fabricamos tus empaques de cartón corrugado en Mosquera.</p></li><li class="ebio-feature-pillars__item"><span class="ebio-icon ebio-icon--ruler ebio-feature-pillars__icon" aria-hidden="true"></span><h3 class="ebio-feature-pillars__title">Diseño estructural a medida</h3><p class="ebio-feature-pillars__text">Ajustamos medida, onda e impresión al producto que vas a empacar, de pequeño a gran formato.</p></li><li class="ebio-feature-pillars__item"><span class="ebio-icon ebio-icon--leaf ebio-feature-pillars__icon" aria-hidden="true"></span><h3 class="ebio-feature-pillars__title">Material sostenible</h3><p class="ebio-feature-pillars__text">Cartón corrugado reciclable y biodegradable, con fibra de origen responsable.</p></li><li class="ebio-feature-pillars__item"><span class="ebio-icon ebio-icon--phone ebio-feature-pillars__icon" aria-hidden="true"></span><h3 class="ebio-feature-pillars__title">Acompañamiento en tu pedido</h3><p class="ebio-feature-pillars__text">Un asesor revisa contigo medidas, cantidades e impresión.</p></li></ul></div></section>
<!-- /wp:ebio/feature-pillars -->

<!-- wp:ebio/process-steps {"intro":"Sin cuenta, sin carrito de compra: solo una lista de lo que necesitas cotizar.","ctaText":"Solicitar cotización","showWhen":false,"items":[{"marker":"","when":"Tú","title":"Arma tu lista","text":"Agrega productos con cantidad y medida aproximada, o describe lo que necesitas."},{"marker":"","when":"Inmediato","title":"Envía un solo formulario","text":"Tu lista y tus datos llegan a nuestro equipo comercial."},{"marker":"","when":"","title":"Asesoría y diseño estructural","text":"Revisamos medidas, onda e impresión contigo."},{"marker":"","when":"","title":"Propuesta","text":"Recibes precio y tiempos."},{"marker":"","when":"","title":"Producción y entrega","text":"Fabricamos en planta y despachamos a tu bodega."}],"anchor":""} -->
<section class="ebio-process-steps"><div class="ebio-process-steps__inner"><div class="ebio-process-steps__header"><h2 class="ebio-process-steps__heading">Así cotizas, en 5 pasos</h2><p class="ebio-process-steps__intro">Sin cuenta, sin carrito de compra: solo una lista de lo que necesitas cotizar.</p><a class="ebio-process-steps__cta ebio-button ebio-button--primary" href="/cotizar/">Solicitar cotización</a></div><ol class="ebio-process-steps__list"><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">1</span><h3 class="ebio-process-steps__title">Arma tu lista</h3><p class="ebio-process-steps__text">Agrega productos con cantidad y medida aproximada, o describe lo que necesitas.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">2</span><h3 class="ebio-process-steps__title">Envía un solo formulario</h3><p class="ebio-process-steps__text">Tu lista y tus datos llegan a nuestro equipo comercial.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">3</span><h3 class="ebio-process-steps__title">Asesoría y diseño estructural</h3><p class="ebio-process-steps__text">Revisamos medidas, onda e impresión contigo.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">4</span><h3 class="ebio-process-steps__title">Propuesta</h3><p class="ebio-process-steps__text">Recibes precio y tiempos.</p></li><li class="ebio-process-steps__step"><span class="ebio-process-steps__number" aria-hidden="true">5</span><h3 class="ebio-process-steps__title">Producción y entrega</h3><p class="ebio-process-steps__text">Fabricamos en planta y despachamos a tu bodega.</p></li></ol></div></section>
<!-- /wp:ebio/process-steps -->

<!-- wp:ebio/media-text-split {"heading":"Empaques reciclables y biodegradables","image":{"id":61,"url":"/wp-content/uploads/preview/sostenibilidad-fibra.svg","alt":"Fibra de cartón reciclado y bobinas de papel en la planta","width":1200,"height":900},"anchor":""} -->
<section class="ebio-media-text-split"><div class="ebio-media-text-split__inner"><div class="ebio-media-text-split__media"><img class="ebio-media-text-split__image wp-image-61" src="/wp-content/uploads/preview/sostenibilidad-fibra.svg" width="1200" height="900" alt="Fibra de cartón reciclado y bobinas de papel en la planta" decoding="async"/></div><div class="ebio-media-text-split__body"><h2 class="ebio-media-text-split__heading">Empaques reciclables y biodegradables</h2><div class="ebio-media-text-split__content">
<!-- wp:paragraph -->
<p>El cartón corrugado es reciclable y biodegradable. Diseñamos cada empaque para usar el material justo y volver a ser fibra al final de su vida útil.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/sostenibilidad/">Conoce nuestro compromiso</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div></div></div></section>
<!-- /wp:ebio/media-text-split -->

<!-- wp:ebio/cta-banner {"anchor":""} -->

<!-- wp:heading -->
<h2 class="wp-block-heading">¿No encuentras tu empaque? Lo fabricamos a tu medida.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Cuéntanos qué vas a empacar, la cantidad y la medida aproximada. Te asesoramos en el diseño estructural.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/cotizar/">Solicitar cotización</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- /wp:ebio/cta-banner -->
