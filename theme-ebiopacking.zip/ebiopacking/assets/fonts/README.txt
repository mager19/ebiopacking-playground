Roboto (latin, 400 / 500 / 700) · woff2 autoalojado

Origen:    paquete npm @fontsource/roboto 5.1.0, carpeta files/ (https://fontsource.org/fonts/roboto).
Archivos:  roboto-latin-400-normal.woff2, roboto-latin-500-normal.woff2, roboto-latin-700-normal.woff2
           (copiados sin modificar; los tres coinciden byte a byte con los del paquete).
Licencia:  Apache License 2.0. Texto completo en LICENSE-Apache-2.0.txt (copia del LICENSE del paquete,
           "Copyright 2011 Google Inc. All Rights Reserved.").

Verificación (Tarea 19): el package.json de @fontsource/roboto@5.1.0 declara "license": "Apache-2.0" y su
LICENSE es el texto de Apache 2.0. design/estilo/tipografia.md decía OFL 1.1, que es la licencia del Roboto
variable del repositorio google/fonts (no de estos woff2 estáticos). Para ESTOS archivos, que son los que se
sirven, la licencia es Apache-2.0. Si se cambian por otra distribución de Roboto, hay que revisar la licencia
de esa distribución y sustituir este texto y el LICENSE.

Uso: assets/css/fonts.css (font-display: swap). Máximo 3 pesos / 3 archivos (spec §13.7).
