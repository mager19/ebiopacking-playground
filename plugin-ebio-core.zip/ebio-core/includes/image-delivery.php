<?php
/**
 * Entrega de imágenes (E7, hallazgos 8 y 11): `sizes` realistas para las imágenes de los bloques estáticos y para el
 * logo, y una sola imagen con `fetchpriority="high"` por página.
 *
 * WordPress calcula `sizes` con el ancho del archivo (`(max-width: 2000px) 100vw, 2000px`), que en una tarjeta de
 * 220 px descarga la imagen completa. Aquí cada bloque declara el ancho con el que se pinta.
 *
 * @package ebio-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * `sizes` por bloque estático, para escritorio (≥ 1024 px) y móvil.
 *
 * @return array<string,string> Nombre de bloque → valor de `sizes`.
 */
function ebio_image_block_sizes(): array {
	return array(
		'ebio/hero-split'       => '(min-width: 1024px) 50vw, 100vw',
		'ebio/collection-cards' => '(min-width: 1024px) 30vw, 90vw',
		'ebio/sector-cards'     => '(min-width: 1024px) 25vw, 90vw',
		'ebio/media-text-split' => '(min-width: 1024px) 50vw, 100vw',
	);
}

/**
 * Añade `sizes` a las `<img>` de un bloque estático que aún no lo traen (WordPress agrega `srcset` después y
 * respeta el `sizes` existente).
 *
 * @param mixed $content HTML del bloque.
 * @param array $block   Bloque analizado.
 * @return mixed
 */
function ebio_image_block_add_sizes( $content, $block ) {
	$name  = is_array( $block ) ? (string) ( $block['blockName'] ?? '' ) : '';
	$sizes = ebio_image_block_sizes();
	if ( ! is_string( $content ) || ! isset( $sizes[ $name ] ) || false === strpos( $content, '<img' ) ) {
		return $content;
	}
	$tags = new WP_HTML_Tag_Processor( $content );
	while ( $tags->next_tag( 'img' ) ) {
		if ( null === $tags->get_attribute( 'sizes' ) ) {
			$tags->set_attribute( 'sizes', $sizes[ $name ] );
		}
	}
	return $tags->get_updated_html();
}
add_filter( 'render_block', 'ebio_image_block_add_sizes', 10, 2 );

/**
 * Sustituye `sizes` en una imagen de la vista de un bloque dinámico.
 *
 * @param array|null $image Imagen de `ebio_dynamic_image()` o `null`.
 * @param string     $sizes Valor de `sizes`.
 * @return array|null
 */
function ebio_image_with_sizes( ?array $image, string $sizes ): ?array {
	if ( null === $image ) {
		return null;
	}
	$image['sizes'] = $sizes;
	return $image;
}

/**
 * El logo no compite con la imagen principal: sin `fetchpriority` (queda solo la imagen LCP del contenido).
 * WordPress marca como `high` la primera imagen sin `loading="lazy"`, y esa es el logo de la cabecera.
 *
 * @param mixed $image HTML de la `<img>`.
 * @return mixed
 */
function ebio_image_logo_priority( $image ) {
	if ( ! is_string( $image ) || ! preg_match( '/class="[^"]*ebio-site-(?:header|footer)__logo-image/', $image ) ) {
		return $image;
	}
	return (string) preg_replace( '/ fetchpriority="high"/', '', $image );
}
add_filter( 'wp_content_img_tag', 'ebio_image_logo_priority' );
