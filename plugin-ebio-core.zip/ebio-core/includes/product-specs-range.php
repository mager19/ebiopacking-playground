<?php
/**
 * Fila "Rango habitual" de las especificaciones de la ficha (crítica Impeccable P1: mostrar el rango, no solo
 * afirmarlo).
 *
 * `ebio/product-specs` es estático y su plantilla es común a todas las fichas. Al renderizar una ficha se agrega
 * una fila "Rango habitual" con los formatos de tamaño del producto (términos `ebio_format` de la lista
 * `ebio_size_format_slugs()`, hoy solo "Gran formato"), marcada como referencia. Sin dato, no se agrega nada:
 * nunca se inventa una medida.
 *
 * @package ebio-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Slugs de `ebio_format` que describen un tamaño (los demás, como "Exportación", no son un rango).
 *
 * @return string[]
 */
function ebio_size_format_slugs(): array {
	/**
	 * Formatos que cuentan como tamaño en "Rango habitual".
	 *
	 * @param string[] $slugs Slugs de `ebio_format`.
	 */
	$slugs = apply_filters( 'ebio_size_format_slugs', array( 'gran-formato' ) );
	return array_values( array_filter( (array) $slugs, 'is_string' ) );
}

/**
 * Nombres de los formatos de tamaño de un producto, en orden de `term_id`.
 *
 * @param int $product_id Producto.
 * @return string[]
 */
function ebio_product_size_range( int $product_id ): array {
	$sizes = ebio_size_format_slugs();
	$names = array();
	foreach ( ebio_product_card_terms( $product_id, 'ebio_format' ) as $term ) {
		if ( in_array( $term->slug, $sizes, true ) ) {
			$names[] = ebio_product_card_text( $term->name );
		}
	}
	return array_values( array_filter( $names ) );
}

/**
 * Agrega la fila "Rango habitual" al HTML de `ebio/product-specs`: después de la fila "Medidas" o, sin ella, al
 * final de la tabla.
 *
 * @param string   $html  HTML del bloque.
 * @param string[] $range Nombres de los formatos de tamaño.
 * @return string HTML con la fila; sin cambios si `$range` está vacío o no hay tabla.
 */
function ebio_product_specs_add_range( string $html, array $range ): string {
	if ( ! $range || false === strpos( $html, '</tbody>' ) ) {
		return $html;
	}
	$row = '<tr class="ebio-product-specs__row ebio-product-specs__row--range"><th class="ebio-product-specs__label" scope="row">Rango habitual</th>'
		. '<td class="ebio-product-specs__value">' . esc_html( implode( ', ', $range ) ) . ' <span class="ebio-product-specs__reference">(referencia)</span></td></tr>';
	$out = (string) preg_replace( '#(<tr class="ebio-product-specs__row"><th class="ebio-product-specs__label" scope="row">Medidas</th>.*?</tr>)#s', '$1' . str_replace( '$', '\\$', $row ), $html, 1, $count );
	if ( $count > 0 ) {
		return $out;
	}
	$at = strrpos( $html, '</tbody>' );
	return substr( $html, 0, $at ) . $row . substr( $html, $at );
}

/**
 * Filtro de `render_block` para `ebio/product-specs` dentro de una ficha de producto.
 *
 * @param mixed $content HTML del bloque.
 * @param array $block   Bloque analizado.
 * @return mixed
 */
function ebio_product_specs_range_render( $content, $block ) {
	if ( ! is_string( $content ) || ! is_array( $block ) || 'ebio/product-specs' !== ( $block['blockName'] ?? '' ) || ! is_singular( 'ebio_product' ) ) {
		return $content;
	}
	return ebio_product_specs_add_range( $content, ebio_product_size_range( (int) get_queried_object_id() ) );
}
add_filter( 'render_block', 'ebio_product_specs_range_render', 10, 2 );
