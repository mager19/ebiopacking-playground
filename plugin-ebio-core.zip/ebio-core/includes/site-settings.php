<?php
/**
 * Ajustes del sitio (opción `ebio_site_settings`), pantalla "Ajustes › eBiopacking" y enlaces de WhatsApp.
 *
 * Claves cerradas: ver docs/blocks/catalog.md §2.14.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Valores iniciales (los de los fixtures `default` de contact-channels, site-footer y scale-range).
 *
 * @return array
 */
function ebio_site_settings_defaults(): array {
	return array(
		'phones'         => array( '+57 310 325 0267', '+57 310 451 4510' ),
		'whatsapp'       => '573103250267',
		'whatsappNote'   => '[PENDIENTE CLIENTE: cuál número es el WhatsApp comercial]',
		'email'          => 'ventas@ebiopacking.com',
		'address'        => 'Parque Industrial San Jorge, Mosquera, Cundinamarca',
		'mapsUrl'        => 'https://maps.google.com/?q=Parque+Industrial+San+Jorge+Mosquera',
		'hours'          => '[PENDIENTE CLIENTE: horarios de atención, p. ej. lunes a viernes 7:00 a. m. – 5:00 p. m.]',
		'social'         => array(),
		'plantRange'     => array(
			array(
				'name'     => 'Pequeño',
				'size'     => '≈ 20 × 15 × 10 cm',
				'uses'     => 'Hierbas, retail, e-commerce',
				'linkText' => 'Ver productos',
				'linkUrl'  => '/productos/',
				'scale'    => 1,
				'imageId'  => 0,
			),
			array(
				'name'     => 'Mediano',
				'size'     => '≈ 40 × 30 × 30 cm',
				'uses'     => 'Flores, frutas, alimentos',
				'linkText' => 'Ver productos',
				'linkUrl'  => '/productos/',
				'scale'    => 2,
				'imageId'  => 0,
			),
			array(
				'name'     => 'Grande',
				'size'     => '≈ 80 × 60 × 60 cm',
				'uses'     => 'Industria, electrodomésticos',
				'linkText' => 'Ver productos',
				'linkUrl'  => '/productos/',
				'scale'    => 3,
				'imageId'  => 0,
			),
			array(
				'name'     => 'Gran formato',
				'size'     => '≥ 120 × 100 × 100 cm',
				'uses'     => 'Pallets, maquinaria, exportación',
				'linkText' => 'Ver productos de gran formato',
				'linkUrl'  => '/productos/?formato=gran-formato',
				'scale'    => 4,
				'imageId'  => 0,
			),
		),
		'plantRangeNote' => 'Medidas de referencia. [PENDIENTE CLIENTE: confirmar rango real de medidas mínimo y máximo de planta]',
		'headerNavId'    => 0,
		'logoId'         => 0,
		'footerColumns'  => array(
			array(
				'title' => 'Productos',
				'links' => array(
					array( 'label' => 'Empaques industriales', 'url' => '/productos/empaques-industriales/' ),
					array( 'label' => 'Empaques comerciales', 'url' => '/productos/empaques-comerciales/' ),
					array( 'label' => 'Empaques agro y flores', 'url' => '/productos/empaques-agro-flores/' ),
					array( 'label' => 'Todo el catálogo', 'url' => '/productos/' ),
				),
			),
			array(
				'title' => 'Empresa',
				'links' => array(
					array( 'label' => 'Nosotros', 'url' => '/nosotros/' ),
					array( 'label' => 'Sostenibilidad', 'url' => '/sostenibilidad/' ),
					array( 'label' => 'Cotizar / Contacto', 'url' => '/cotizar/' ),
				),
			),
		),
	);
}

/**
 * Ajustes vigentes: la opción guardada sobre los valores iniciales.
 *
 * @return array
 */
function ebio_site_settings(): array {
	$defaults = ebio_site_settings_defaults();
	$stored   = get_option( 'ebio_site_settings', array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	return array_merge( $defaults, array_intersect_key( $stored, $defaults ) );
}

/**
 * Normaliza una URL: relativa, `#ancla`, http(s), mailto o tel; cualquier otro esquema (p. ej. `javascript:`) se vacía.
 *
 * @param mixed $url URL de entrada.
 * @return string
 */
function ebio_sanitize_setting_url( $url ): string {
	if ( ! is_string( $url ) ) {
		return '';
	}
	return esc_url_raw( trim( $url ), array( 'http', 'https', 'mailto', 'tel' ) );
}

/**
 * Entero no negativo estricto: "15" y 15 valen; "abc" y "12.5" dan 0.
 *
 * @param mixed $value Entrada.
 * @return int
 */
function ebio_sanitize_setting_id( $value ): int {
	if ( is_int( $value ) ) {
		return max( 0, $value );
	}
	if ( is_string( $value ) && preg_match( '/^\d+$/', trim( $value ) ) ) {
		return (int) trim( $value );
	}
	return 0;
}

/**
 * Lista de líneas: acepta un array o un texto con una entrada por línea.
 *
 * @param mixed $value Entrada.
 * @return array
 */
function ebio_setting_lines( $value ): array {
	if ( is_string( $value ) ) {
		$value = preg_split( '/\R/', $value ) ?: array();
	}
	return is_array( $value ) ? array_values( $value ) : array();
}

/**
 * Sanea la opción completa: solo claves conocidas; las ausentes toman su valor inicial.
 *
 * Es el `sanitize_callback` de la opción: una llamada parcial a `update_option( 'ebio_site_settings', … )`
 * restablece a sus valores iniciales todas las claves que no incluya. Quien escriba desde fuera de la pantalla
 * (WP-CLI, importador; no corre `admin_init`, así que el callback puede no estar registrado) debe fusionar sus
 * claves sobre `ebio_site_settings()` y pasar el resultado por `ebio_sanitize_site_settings()` antes de guardar.
 * Un `footerColumns` en JSON inválido conserva el valor guardado y avisa con `add_settings_error`.
 *
 * @param mixed $input Entrada (formulario, importador o prueba).
 * @return array
 */
function ebio_sanitize_site_settings( $input ): array {
	$defaults = ebio_site_settings_defaults();
	$input    = is_array( $input ) ? $input : array();
	$out      = $defaults;
	$text     = static function ( $value ): string {
		return is_scalar( $value ) ? trim( sanitize_text_field( (string) $value ) ) : '';
	};

	if ( array_key_exists( 'phones', $input ) ) {
		$out['phones'] = array_values( array_filter( array_map( $text, ebio_setting_lines( $input['phones'] ) ), 'strlen' ) );
	}
	if ( array_key_exists( 'whatsapp', $input ) ) {
		$out['whatsapp'] = is_scalar( $input['whatsapp'] ) ? (string) preg_replace( '/\D+/', '', (string) $input['whatsapp'] ) : '';
	}
	foreach ( array( 'whatsappNote', 'address', 'hours', 'plantRangeNote' ) as $key ) {
		if ( array_key_exists( $key, $input ) ) {
			$out[ $key ] = $text( $input[ $key ] );
		}
	}
	if ( array_key_exists( 'email', $input ) ) {
		$out['email'] = is_string( $input['email'] ) ? (string) sanitize_email( $input['email'] ) : '';
	}
	if ( array_key_exists( 'mapsUrl', $input ) ) {
		$out['mapsUrl'] = ebio_sanitize_setting_url( $input['mapsUrl'] );
	}

	if ( array_key_exists( 'social', $input ) ) {
		$social = array();
		foreach ( ebio_setting_lines( $input['social'] ) as $item ) {
			if ( is_string( $item ) && false !== strpos( $item, '|' ) ) { // Línea "red | url".
				list( $network, $url ) = array_map( 'trim', explode( '|', $item, 2 ) );
				$item                  = array( 'network' => $network, 'url' => $url );
			}
			if ( ! is_array( $item ) ) {
				continue;
			}
			$network = $text( $item['network'] ?? '' );
			if ( '' === $network ) {
				continue;
			}
			$social[] = array( 'network' => $network, 'url' => ebio_sanitize_setting_url( $item['url'] ?? '' ) );
		}
		$out['social'] = $social;
	}

	if ( array_key_exists( 'plantRange', $input ) && is_array( $input['plantRange'] ) ) {
		$steps = array_values( $input['plantRange'] );
		foreach ( $defaults['plantRange'] as $i => $default_step ) {
			$step = isset( $steps[ $i ] ) && is_array( $steps[ $i ] ) ? $steps[ $i ] : array();
			$scale = isset( $step['scale'] ) ? (int) $step['scale'] : $default_step['scale'];
			$out['plantRange'][ $i ] = array(
				'name'     => array_key_exists( 'name', $step ) ? $text( $step['name'] ) : $default_step['name'],
				'size'     => array_key_exists( 'size', $step ) ? $text( $step['size'] ) : $default_step['size'],
				'uses'     => array_key_exists( 'uses', $step ) ? $text( $step['uses'] ) : $default_step['uses'],
				'linkText' => array_key_exists( 'linkText', $step ) ? $text( $step['linkText'] ) : $default_step['linkText'],
				'linkUrl'  => array_key_exists( 'linkUrl', $step ) ? ebio_sanitize_setting_url( $step['linkUrl'] ) : $default_step['linkUrl'],
				'scale'    => ( $scale >= 1 && $scale <= 4 ) ? $scale : $default_step['scale'],
				'imageId'  => array_key_exists( 'imageId', $step ) ? absint( $step['imageId'] ) : $default_step['imageId'],
			);
		}
	}

	foreach ( array( 'headerNavId', 'logoId' ) as $key ) {
		if ( array_key_exists( $key, $input ) ) {
			$out[ $key ] = ebio_sanitize_setting_id( $input[ $key ] );
		}
	}

	if ( array_key_exists( 'footerColumns', $input ) ) {
		$columns = $input['footerColumns'];
		if ( is_string( $columns ) ) {
			$columns = json_decode( $columns, true );
		}
		if ( ! is_array( $columns ) ) {
			// JSON inválido: se conservan las columnas guardadas en vez de borrarlas.
			$out['footerColumns'] = ebio_site_settings()['footerColumns'];
			if ( function_exists( 'add_settings_error' ) ) {
				add_settings_error( 'ebio_site_settings', 'ebio_footer_columns_json', 'Las columnas del pie no son JSON válido; se conservaron las anteriores.' );
			}
			return $out;
		}
		$clean = array();
		foreach ( array_slice( array_values( $columns ), 0, 4 ) as $column ) {
			if ( ! is_array( $column ) ) {
				continue;
			}
			$links = array();
			foreach ( is_array( $column['links'] ?? null ) ? $column['links'] : array() as $link ) {
				if ( is_array( $link ) && '' !== $text( $link['label'] ?? '' ) ) {
					$links[] = array( 'label' => $text( $link['label'] ), 'url' => ebio_sanitize_setting_url( $link['url'] ?? '' ) );
				}
			}
			$clean[] = array( 'title' => $text( $column['title'] ?? '' ), 'links' => $links );
		}
		$out['footerColumns'] = $clean;
	}

	return $out;
}

/**
 * Mensaje precargado de WhatsApp (catalog §2.14): `general` o `product` (`{producto}`, `{url}`).
 *
 * @param string $key  Clave del mensaje.
 * @param array  $vars Variables: `producto`, `url`.
 * @return string
 */
function ebio_whatsapp_message( string $key, array $vars = array() ): string {
	$templates = array(
		'general' => 'Hola, quiero cotizar empaques de cartón. Los vi en ebiopacking.com',
		'product' => 'Hola, quiero cotizar: {producto} ({url})',
	);
	if ( ! isset( $templates[ $key ] ) ) {
		return '';
	}
	return strtr(
		$templates[ $key ],
		array(
			'{producto}' => (string) ( $vars['producto'] ?? '' ),
			'{url}'      => (string) ( $vars['url'] ?? '' ),
		)
	);
}

/**
 * Enlace `wa.me` con el mensaje codificado; cadena vacía si no hay número configurado.
 *
 * @param string $message Mensaje precargado.
 * @return string
 */
function ebio_whatsapp_url( string $message ): string {
	$number = preg_replace( '/\D+/', '', (string) ebio_site_settings()['whatsapp'] );
	if ( '' === $number ) {
		return '';
	}
	return 'https://wa.me/' . $number . '?text=' . rawurlencode( $message );
}

/**
 * Registra la opción y la pantalla "Ajustes › eBiopacking".
 */
function ebio_site_settings_register(): void {
	register_setting(
		'ebio_site_settings_group',
		'ebio_site_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'ebio_sanitize_site_settings',
			'default'           => ebio_site_settings_defaults(),
			'show_in_rest'      => false,
		)
	);
}
add_action( 'admin_init', 'ebio_site_settings_register' );

/**
 * Añade la pantalla bajo Ajustes.
 */
function ebio_site_settings_menu(): void {
	add_options_page( __( 'eBiopacking', 'ebio-core' ), __( 'eBiopacking', 'ebio-core' ), 'manage_options', 'ebio-settings', 'ebio_site_settings_render_page' );
}
add_action( 'admin_menu', 'ebio_site_settings_menu' );

/**
 * Dibuja una fila de texto.
 *
 * @param string $label Etiqueta.
 * @param string $name  Nombre del campo dentro de la opción.
 * @param string $value Valor.
 * @param string $type  Tipo de input.
 */
function ebio_site_settings_field( string $label, string $name, string $value, string $type = 'text' ): void {
	$id = 'ebio-' . $name;
	echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label></th><td>';
	echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="' . esc_attr( $id ) . '" name="ebio_site_settings[' . esc_attr( $name ) . ']" value="' . esc_attr( $value ) . '">';
	echo '</td></tr>';
}

/**
 * Dibuja una fila de área de texto.
 *
 * @param string $label Etiqueta.
 * @param string $name  Nombre del campo.
 * @param string $value Valor.
 * @param string $hint  Ayuda.
 */
function ebio_site_settings_textarea( string $label, string $name, string $value, string $hint = '' ): void {
	$id = 'ebio-' . $name;
	echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label></th><td>';
	echo '<textarea class="large-text code" rows="5" id="' . esc_attr( $id ) . '" name="ebio_site_settings[' . esc_attr( $name ) . ']">' . esc_textarea( $value ) . '</textarea>';
	if ( '' !== $hint ) {
		echo '<p class="description">' . esc_html( $hint ) . '</p>';
	}
	echo '</td></tr>';
}

/**
 * Pantalla de ajustes.
 */
function ebio_site_settings_render_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s      = ebio_site_settings();
	$social = array();
	foreach ( $s['social'] as $item ) {
		$social[] = $item['network'] . ' | ' . $item['url'];
	}

	echo '<div class="wrap"><h1>' . esc_html__( 'Ajustes de eBiopacking', 'ebio-core' ) . '</h1>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'ebio_site_settings_group' );
	echo '<h2>' . esc_html__( 'Contacto', 'ebio-core' ) . '</h2><table class="form-table" role="presentation">';
	ebio_site_settings_textarea( __( 'Teléfonos', 'ebio-core' ), 'phones', implode( "\n", $s['phones'] ), __( 'Uno por línea.', 'ebio-core' ) );
	ebio_site_settings_field( __( 'WhatsApp (solo dígitos, con indicativo)', 'ebio-core' ), 'whatsapp', $s['whatsapp'] );
	ebio_site_settings_field( __( 'Nota de WhatsApp', 'ebio-core' ), 'whatsappNote', $s['whatsappNote'] );
	ebio_site_settings_field( __( 'Correo', 'ebio-core' ), 'email', $s['email'], 'email' );
	ebio_site_settings_field( __( 'Dirección', 'ebio-core' ), 'address', $s['address'] );
	ebio_site_settings_field( __( 'Enlace del mapa', 'ebio-core' ), 'mapsUrl', $s['mapsUrl'], 'url' );
	ebio_site_settings_field( __( 'Horarios', 'ebio-core' ), 'hours', $s['hours'] );
	ebio_site_settings_textarea( __( 'Redes sociales', 'ebio-core' ), 'social', implode( "\n", $social ), __( 'Una por línea: red | url.', 'ebio-core' ) );
	echo '</table><h2>' . esc_html__( 'Rango de planta', 'ebio-core' ) . '</h2><table class="form-table" role="presentation">';
	foreach ( $s['plantRange'] as $i => $step ) {
		foreach ( array( 'name', 'size', 'uses', 'linkText', 'linkUrl', 'scale', 'imageId' ) as $field ) {
			$id = 'ebio-plantRange-' . $i . '-' . $field;
			echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( sprintf( 'Escalón %d: %s', $i + 1, $field ) ) . '</label></th><td>';
			echo '<input class="regular-text" type="text" id="' . esc_attr( $id ) . '" name="ebio_site_settings[plantRange][' . (int) $i . '][' . esc_attr( $field ) . ']" value="' . esc_attr( (string) ( $step[ $field ] ?? '' ) ) . '"></td></tr>';
		}
	}
	ebio_site_settings_field( __( 'Nota del rango de planta', 'ebio-core' ), 'plantRangeNote', $s['plantRangeNote'] );
	echo '</table><h2>' . esc_html__( 'Cabecera y pie', 'ebio-core' ) . '</h2><table class="form-table" role="presentation">';
	ebio_site_settings_field( __( 'ID del menú de cabecera (wp_navigation)', 'ebio-core' ), 'headerNavId', (string) $s['headerNavId'], 'number' );
	ebio_site_settings_field( __( 'ID del logo (adjunto)', 'ebio-core' ), 'logoId', (string) $s['logoId'], 'number' );
	ebio_site_settings_textarea( __( 'Columnas del pie (JSON)', 'ebio-core' ), 'footerColumns', (string) wp_json_encode( $s['footerColumns'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ), __( 'Hasta 4 columnas: [{ "title": "…", "links": [{ "label": "…", "url": "…" }] }].', 'ebio-core' ) );
	echo '</table>';
	submit_button();
	echo '</form></div>';
}
