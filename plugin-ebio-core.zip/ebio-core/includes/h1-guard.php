<?php
/**
 * Un solo H1 por página (catalog §2.4, C-B2): donde la plantilla o el contenido ya emite el H1, el editor
 * no ofrece `ebio/hero-split` (que también lo emite).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Clases de layout cuyo `core/heading` de nivel 1 es el H1 de la página (catalog §2.4).
 *
 * @return string[] Sufijos tras `ebio-layout-`.
 */
function ebio_h1_layout_classes(): array {
	return array( 'intro', 'confirm', '404', 'search-head', 'legal' );
}

/**
 * El contenido ya trae un grupo de layout que emite el H1.
 *
 * @param string $content Contenido (HTML con comentarios de bloque).
 * @return bool
 */
function ebio_content_has_layout_h1( string $content ): bool {
	$suffixes = implode( '|', array_map( 'preg_quote', ebio_h1_layout_classes() ) );
	return 1 === preg_match( '/\bebio-layout-(?:' . $suffixes . ')(?![a-z0-9-])/', $content );
}

/**
 * `allowed_block_types_all`: quita `ebio/hero-split` en las fichas de producto (el H1 lo pone
 * `ebio/product-summary`) y en los posts cuyo contenido ya trae un grupo de layout con H1.
 *
 * @param bool|string[]            $allowed Bloques permitidos (`true` = todos).
 * @param WP_Block_Editor_Context  $context Contexto del editor.
 * @return bool|string[]
 */
function ebio_h1_allowed_blocks( $allowed, $context ) {
	if ( false === $allowed || ! is_object( $context ) || ! ( $context->post ?? null ) instanceof WP_Post ) {
		return $allowed;
	}
	$post = $context->post;
	if ( 'ebio_product' !== $post->post_type && ! ebio_content_has_layout_h1( (string) $post->post_content ) ) {
		return $allowed;
	}
	if ( true === $allowed ) {
		$allowed = array_keys( WP_Block_Type_Registry::get_instance()->get_all_registered() );
	}
	if ( ! is_array( $allowed ) ) {
		return $allowed;
	}
	return array_values( array_diff( $allowed, array( 'ebio/hero-split' ) ) );
}
add_filter( 'allowed_block_types_all', 'ebio_h1_allowed_blocks', 10, 2 );
