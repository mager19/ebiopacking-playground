<?php
/**
 * Modelo de contenido: productos, categorías, sectores y solicitudes de cotización.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Plantilla de bloques del CPT `ebio_product` (FU10, catalog §5 y D16): solo se aplica a productos nuevos.
 * Las filas de especificaciones salen de los valores por defecto de `ebio/product-specs`; los textos
 * pendientes del cliente llevan su marcador `[PENDIENTE CLIENTE: …]`.
 *
 * @return array[] Plantilla en el formato de `register_post_type( 'template' )`.
 */
function ebio_product_template(): array {
	$step  = static function ( string $name, string $size, int $scale ): array {
		return array(
			'name'     => $name,
			'size'     => $size,
			'uses'     => '[PENDIENTE CLIENTE: usos]',
			'linkText' => '',
			'linkUrl'  => '',
			'scale'    => $scale,
		);
	};
	$image = array(
		'id'     => 0,
		'url'    => '',
		'alt'    => '',
		'width'  => 0,
		'height' => 0,
	);
	$sector = static function ( string $title, string $url ) use ( $image ): array {
		return array(
			'title' => $title,
			'text'  => '[PENDIENTE CLIENTE: uso de este producto en el sector]',
			'url'   => $url,
			'image' => $image,
		);
	};
	return array(
		array(
			'core/columns',
			array( 'className' => 'ebio-layout-product-top' ),
			array(
				array( 'core/column', array(), array( array( 'ebio/product-gallery' ) ) ),
				array( 'core/column', array(), array( array( 'ebio/product-summary' ), array( 'ebio/add-to-quote' ) ) ),
			),
		),
		array(
			'ebio/scale-range',
			array(
				'variant' => 'product',
				'compact' => true,
				'heading' => 'Esta caja, en todas las escalas',
				'steps'   => array(
					$step( 'Mínimo', '[PENDIENTE CLIENTE: medida mínima]', 1 ),
					$step( 'Estándar', '[PENDIENTE CLIENTE: medida estándar]', 2 ),
					$step( 'Grande', '[PENDIENTE CLIENTE: medida grande]', 3 ),
					$step( 'Gran formato', '[PENDIENTE CLIENTE: medida máxima]', 4 ),
				),
			),
		),
		array( 'ebio/product-specs' ),
		array(
			'ebio/sector-cards',
			array(
				'heading' => 'Sectores recomendados',
				'intro'   => '[PENDIENTE CLIENTE: sectores donde se usa este producto]',
				'items'   => array(
					// Los cinco sectores: al mostrar la ficha solo quedan los del producto (includes/product-sectors.php).
					$sector( 'Floricultura', '/sectores/floricultura/' ),
					$sector( 'Agro y frutas', '/sectores/agro-frutas/' ),
					$sector( 'Industria', '/sectores/industria/' ),
					$sector( 'Alimentos', '/sectores/alimentos/' ),
					$sector( 'Retail y e-commerce', '/sectores/retail-ecommerce/' ),
				),
			),
		),
		array(
			'ebio/faq',
			array(
				'heading' => 'Preguntas frecuentes',
				'items'   => array(
					array(
						'question' => '¿Fabrican este producto en medidas especiales?',
						'answer'   => 'Sí. Cada caja se fabrica a la medida de tu producto, dentro de su rango de medidas [PENDIENTE CLIENTE: rango de medidas de este producto].',
					),
					array(
						'question' => '¿Cuál es el pedido mínimo?',
						'answer'   => '[PENDIENTE CLIENTE: pedido mínimo]',
					),
					array(
						'question' => '¿Pueden imprimir mi logo?',
						'answer'   => 'Sí, en flexografía de 1 a [PENDIENTE CLIENTE: n.º de tintas] tintas.',
					),
					array(
						'question' => '¿Despachan a todo el país y exportan?',
						'answer'   => '[PENDIENTE CLIENTE: cobertura de despacho y países de exportación]',
					),
				),
			),
		),
	);
}

/**
 * Registra el CPT de productos.
 */
function ebio_register_product_post_type() {
	register_post_type(
		'ebio_product',
		array(
			'labels'       => array(
				'name'               => __( 'Productos', 'ebio-core' ),
				'singular_name'      => __( 'Producto', 'ebio-core' ),
				'add_new'            => __( 'Añadir nuevo', 'ebio-core' ),
				'add_new_item'       => __( 'Añadir nuevo producto', 'ebio-core' ),
				'edit_item'          => __( 'Editar producto', 'ebio-core' ),
				'new_item'           => __( 'Nuevo producto', 'ebio-core' ),
				'view_item'          => __( 'Ver producto', 'ebio-core' ),
				'search_items'       => __( 'Buscar productos', 'ebio-core' ),
				'not_found'          => __( 'No se encontraron productos', 'ebio-core' ),
				'not_found_in_trash' => __( 'No hay productos en la papelera', 'ebio-core' ),
				'all_items'          => __( 'Todos los productos', 'ebio-core' ),
				'menu_name'          => __( 'Productos', 'ebio-core' ),
			),
			'public'       => true,
			'show_in_rest' => true,
			'has_archive'  => 'productos',
			'menu_icon'    => 'dashicons-archive',
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields' ),
			'taxonomies'   => array( 'ebio_product_category', 'ebio_sector', 'ebio_format' ),
				'template'     => ebio_product_template(),
			'rewrite'      => array(
				'slug'       => 'productos/%ebio_product_category%',
				'with_front' => false,
			),
		)
	);

	register_post_meta(
		'ebio_product',
		'ebio_tags',
		array(
			'type'         => 'array',
			'single'       => true,
			'default'      => array(),
			'show_in_rest' => array(
				'schema' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
			),
		)
	);

	register_post_meta(
		'ebio_product',
		'ebio_min_order',
		array(
			'type'         => 'string',
			'single'       => true,
			'default'      => '',
			'show_in_rest' => true,
		)
	);
}

/**
 * Registra las taxonomías de productos.
 */
function ebio_register_taxonomies() {
	register_taxonomy(
		'ebio_product_category',
		'ebio_product',
		array(
			'labels'       => array(
				'name'          => __( 'Categorías de producto', 'ebio-core' ),
				'singular_name' => __( 'Categoría de producto', 'ebio-core' ),
				'search_items'  => __( 'Buscar categorías', 'ebio-core' ),
				'all_items'     => __( 'Todas las categorías', 'ebio-core' ),
				'parent_item'   => __( 'Categoría superior', 'ebio-core' ),
				'edit_item'     => __( 'Editar categoría', 'ebio-core' ),
				'add_new_item'  => __( 'Añadir nueva categoría', 'ebio-core' ),
				'menu_name'     => __( 'Categorías', 'ebio-core' ),
			),
			'hierarchical' => true,
			'public'       => true,
			'show_in_rest' => true,
			'rewrite'      => array(
				'slug'         => 'productos',
				'with_front'   => false,
				// Las 3 categorías son planas; con true la regla productos/(.+?)/ se traga las URLs de producto.
				'hierarchical' => false,
			),
		)
	);

	register_taxonomy(
		'ebio_sector',
		'ebio_product',
		array(
			'labels'             => array(
				'name'          => __( 'Sectores', 'ebio-core' ),
				'singular_name' => __( 'Sector', 'ebio-core' ),
				'search_items'  => __( 'Buscar sectores', 'ebio-core' ),
				'all_items'     => __( 'Todos los sectores', 'ebio-core' ),
				'edit_item'     => __( 'Editar sector', 'ebio-core' ),
				'add_new_item'  => __( 'Añadir nuevo sector', 'ebio-core' ),
				'menu_name'     => __( 'Sectores', 'ebio-core' ),
			),
			'hierarchical'       => false,
			'public'             => true,
			'publicly_queryable' => false,
			'show_in_rest'       => true,
			'rewrite'            => false,
		)
	);

	register_taxonomy(
		'ebio_format',
		'ebio_product',
		array(
			'labels'             => array(
				'name'          => __( 'Formatos', 'ebio-core' ),
				'singular_name' => __( 'Formato', 'ebio-core' ),
				'search_items'  => __( 'Buscar formatos', 'ebio-core' ),
				'all_items'     => __( 'Todos los formatos', 'ebio-core' ),
				'edit_item'     => __( 'Editar formato', 'ebio-core' ),
				'add_new_item'  => __( 'Añadir nuevo formato', 'ebio-core' ),
				'menu_name'     => __( 'Formatos', 'ebio-core' ),
			),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_rest'       => true,
			'show_admin_column'  => true,
			// Casillas en el editor; los términos no tienen padre.
			'hierarchical'       => true,
			'rewrite'            => false,
			'query_var'          => false,
		)
	);
}

/**
 * Registra el CPT privado de solicitudes de cotización.
 */
function ebio_register_quote_post_type() {
	register_post_type(
		'ebio_quote',
		array(
			'labels'              => array(
				'name'               => __( 'Cotizaciones', 'ebio-core' ),
				'singular_name'      => __( 'Cotización', 'ebio-core' ),
				'add_new'            => __( 'Añadir nueva', 'ebio-core' ),
				'add_new_item'       => __( 'Añadir nueva cotización', 'ebio-core' ),
				'edit_item'          => __( 'Ver cotización', 'ebio-core' ),
				'new_item'           => __( 'Nueva cotización', 'ebio-core' ),
				'view_item'          => __( 'Ver cotización', 'ebio-core' ),
				'search_items'       => __( 'Buscar cotizaciones', 'ebio-core' ),
				'not_found'          => __( 'No se encontraron cotizaciones', 'ebio-core' ),
				'not_found_in_trash' => __( 'No hay cotizaciones en la papelera', 'ebio-core' ),
				'all_items'          => __( 'Todas las cotizaciones', 'ebio-core' ),
				'menu_name'          => __( 'Cotizaciones', 'ebio-core' ),
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => false,
			'show_in_nav_menus'   => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'has_archive'         => false,
			'rewrite'             => false,
			// Las cotizaciones contienen datos personales: capacidades propias, solo administradores.
			'capability_type'     => array( 'ebio_quote', 'ebio_quotes' ),
			'map_meta_cap'        => true,
			'capabilities'        => array( 'create_posts' => 'do_not_allow' ),
			'menu_icon'           => 'dashicons-clipboard',
			'supports'            => array( 'title' ),
		)
	);
}

/**
 * Registra tipos de contenido y taxonomías.
 */
function ebio_register_content_model() {
	ebio_register_taxonomies();
	ebio_register_product_post_type();
	ebio_register_quote_post_type();
}
add_action( 'init', 'ebio_register_content_model' );

/**
 * Reemplaza %ebio_product_category% por el slug de la primera categoría.
 *
 * @param string  $post_link Enlace.
 * @param WP_Post $post      Entrada.
 * @return string
 */
function ebio_product_permalink( $post_link, $post ) {
	if ( ! $post instanceof WP_Post || 'ebio_product' !== $post->post_type || false === strpos( $post_link, '%ebio_product_category%' ) ) {
		return $post_link;
	}
	$slug  = 'sin-categoria';
	$terms = get_the_terms( $post->ID, 'ebio_product_category' );
	if ( is_array( $terms ) && ! empty( $terms ) ) {
		usort(
			$terms,
			function ( $a, $b ) {
				return $a->term_id <=> $b->term_id;
			}
		);
		$slug = $terms[0]->slug;
	}
	return str_replace( '%ebio_product_category%', $slug, $post_link );
}
add_filter( 'post_type_link', 'ebio_product_permalink', 10, 2 );

/**
 * Devuelve la URL canónica si la ruta solicitada no corresponde al permalink del producto.
 *
 * @param WP_Post $post           Producto.
 * @param string  $requested_path Ruta solicitada (sin query string).
 * @return string|null
 */
function ebio_product_canonical_redirect_url( WP_Post $post, string $requested_path ): ?string {
	$canonical = get_permalink( $post );
	if ( ! $canonical ) {
		return null;
	}
	$canonical_path = trailingslashit( (string) wp_parse_url( $canonical, PHP_URL_PATH ) );
	$requested      = trailingslashit( '/' . ltrim( $requested_path, '/' ) );
	// Las rutas no distinguen mayúsculas: /Productos/Cat/Slug/ es la misma página.
	if ( 0 === strpos( strtolower( $requested ), strtolower( $canonical_path ) ) ) {
		return null;
	}
	return $canonical;
}

/**
 * Calcula la URL a la que redirigir, o null si no corresponde.
 *
 * Solo GET/HEAD y nunca en vista previa.
 *
 * @param WP_Post $post        Producto.
 * @param string  $request_uri URI solicitada (con query string).
 * @param string  $method      Método HTTP.
 * @param bool    $is_preview  Si es una vista previa.
 * @return string|null
 */
function ebio_product_canonical_redirect_target( WP_Post $post, string $request_uri, string $method, bool $is_preview ): ?string {
	if ( $is_preview || ! in_array( strtoupper( $method ), array( 'GET', 'HEAD' ), true ) ) {
		return null;
	}
	$path   = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
	$target = ebio_product_canonical_redirect_url( $post, $path );
	if ( ! $target ) {
		return null;
	}
	$query = (string) wp_parse_url( $request_uri, PHP_URL_QUERY );
	if ( '' !== $query ) {
		$target .= '?' . $query;
	}
	return $target;
}

/**
 * Redirige 301 los productos pedidos bajo una categoría que no es la canónica.
 */
function ebio_product_canonical_redirect() {
	if ( ! is_singular( 'ebio_product' ) ) {
		return;
	}
	$post = get_queried_object();
	if ( ! $post instanceof WP_Post || empty( $_SERVER['REQUEST_URI'] ) ) {
		return;
	}
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : 'GET';
	$target = ebio_product_canonical_redirect_target( $post, wp_unslash( $_SERVER['REQUEST_URI'] ), $method, is_preview() );
	if ( $target ) {
		wp_safe_redirect( $target, 301 );
		exit;
	}
}
add_action( 'template_redirect', 'ebio_product_canonical_redirect' );

/**
 * Concede a administradores las capacidades de cotizaciones.
 */
function ebio_grant_quote_caps(): void {
	$role = get_role( 'administrator' );
	if ( ! $role ) {
		return;
	}
	foreach ( array( 'edit_ebio_quotes', 'edit_others_ebio_quotes', 'read_private_ebio_quotes', 'delete_ebio_quotes', 'delete_others_ebio_quotes', 'publish_ebio_quotes', 'edit_published_ebio_quotes', 'delete_published_ebio_quotes', 'edit_private_ebio_quotes', 'delete_private_ebio_quotes' ) as $cap ) {
		$role->add_cap( $cap );
	}
}

/**
 * Concede las capacidades si faltan (sitios ya activos o un reinicio de roles las quitó).
 */
function ebio_maybe_grant_quote_caps() {
	$role = get_role( 'administrator' );
	if ( $role && $role->has_cap( 'edit_ebio_quotes' ) ) {
		return;
	}
	ebio_grant_quote_caps();
	update_option( 'ebio_caps_v1', 1 );
}
add_action( 'init', 'ebio_maybe_grant_quote_caps', 20 );

/**
 * Siembra categorías y sectores. Idempotente.
 */
function ebio_seed_terms(): void {
	$sets = array(
		'ebio_product_category' => array(
			'empaques-industriales' => 'Empaques industriales',
			'empaques-comerciales'  => 'Empaques comerciales',
			'empaques-agro-flores'  => 'Empaques agro y flores',
		),
		'ebio_sector'           => array(
			'floricultura'     => 'Floricultura',
			'agro-frutas'      => 'Agro y frutas',
			'industria'        => 'Industria',
			'alimentos'        => 'Alimentos',
			'retail-ecommerce' => 'Retail y e-commerce',
		),
		'ebio_format'           => array(
			'gran-formato' => 'Gran formato',
			'a-medida'     => 'A medida',
			'exportacion'  => 'Exportación',
		),
	);
	foreach ( $sets as $taxonomy => $terms ) {
		foreach ( $terms as $slug => $name ) {
			if ( ! get_term_by( 'slug', $slug, $taxonomy ) ) {
				wp_insert_term( $name, $taxonomy, array( 'slug' => $slug ) );
			}
		}
	}
}

/**
 * Siembra los términos en sitios donde el plugin ya estaba activo.
 */
function ebio_maybe_seed_terms() {
	// v2: añade los formatos en sitios que ya tenían la siembra v1.
	if ( get_option( 'ebio_terms_seeded_v2' ) ) {
		return;
	}
	ebio_seed_terms();
	update_option( 'ebio_terms_seeded_v1', 1 );
	update_option( 'ebio_terms_seeded_v2', 1 );
}
add_action( 'init', 'ebio_maybe_seed_terms', 20 );

/**
 * Activación: registra, siembra y refresca reglas de reescritura.
 */
function ebio_core_activate(): void {
	ebio_register_content_model();
	ebio_seed_terms();
	update_option( 'ebio_terms_seeded_v1', 1 );
	update_option( 'ebio_terms_seeded_v2', 1 );
	ebio_grant_quote_caps();
	update_option( 'ebio_caps_v1', 1 );
	flush_rewrite_rules();
}
