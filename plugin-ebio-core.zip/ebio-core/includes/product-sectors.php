<?php
/**
 * "Sectores recomendados" de la ficha (E7, O3): las tarjetas salen de los sectores del producto.
 *
 * La plantilla del producto lista las tarjetas de todos los sectores (`ebio/sector-cards`, estático). Al
 * renderizar una ficha se dejan solo las tarjetas cuyo enlace es `/sectores/<slug>/` de un término `ebio_sector`
 * del producto; sin ninguno, el bloque no se emite (sin sección vacía).
 *
 * @package ebio-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Deja en el HTML de `ebio/sector-cards` solo las tarjetas de los sectores indicados.
 *
 * @param string   $html  HTML del bloque.
 * @param string[] $slugs Slugs de los sectores del producto.
 * @return string HTML filtrado; `''` si no queda ninguna tarjeta.
 */
function ebio_product_sectors_filter_html( string $html, array $slugs ): string {
	$kept = 0;
	$out  = (string) preg_replace_callback(
		'#<li class="ebio-sector-cards__item">.*?</li>#s',
		static function ( array $match ) use ( $slugs, &$kept ): string {
			if ( ! preg_match( '#href="(?:https?://[^/"]+)?/sectores/([a-z0-9-]+)/?"#', $match[0], $href ) || ! in_array( $href[1], $slugs, true ) ) {
				return '';
			}
			++$kept;
			return $match[0];
		},
		$html
	);
	return $kept > 0 ? $out : '';
}

/**
 * Filtro de `render_block` para `ebio/sector-cards` dentro de una ficha de producto.
 *
 * @param mixed $content HTML del bloque.
 * @param array $block   Bloque analizado.
 * @return mixed
 */
function ebio_product_sectors_render( $content, $block ) {
	if ( ! is_string( $content ) || ! is_array( $block ) || 'ebio/sector-cards' !== ( $block['blockName'] ?? '' ) || ! is_singular( 'ebio_product' ) ) {
		return $content;
	}
	$slugs = wp_get_post_terms( (int) get_queried_object_id(), 'ebio_sector', array( 'fields' => 'slugs' ) );
	return ebio_product_sectors_filter_html( $content, is_array( $slugs ) ? $slugs : array() );
}
add_filter( 'render_block', 'ebio_product_sectors_render', 10, 2 );

/**
 * Quita del HTML de `ebio/sector-cards` la tarjeta que enlaza a `/sectores/<slug>/`.
 *
 * @param string $html HTML del bloque.
 * @param string $slug Sector a quitar.
 * @return string HTML filtrado; `''` si no queda ninguna tarjeta.
 */
function ebio_sector_cards_exclude_html( string $html, string $slug ): string {
	$all = array();
	if ( preg_match_all( '#href="(?:https?://[^/"]+)?/sectores/([a-z0-9-]+)/?"#', $html, $found ) ) {
		$all = array_unique( $found[1] );
	}
	return ebio_product_sectors_filter_html( $html, array_values( array_diff( $all, array( $slug ) ) ) );
}

/**
 * Sector de la página actual: `<slug>` si la petición es `/sectores/<slug>/` de un término `ebio_sector`.
 *
 * @return string Slug o `''`.
 */
function ebio_current_sector_page(): string {
	if ( ! is_page() ) {
		return '';
	}
	$path = ebio_site_path( (string) ( ebio_current_request()['path'] ?? '' ) );
	if ( ! preg_match( '#^/sectores/([a-z0-9-]+)/$#', $path, $match ) || ! term_exists( $match[1], 'ebio_sector' ) ) {
		return '';
	}
	return $match[1];
}

/**
 * "Otros sectores" (crítica P2): en la página de un sector, `ebio/sector-cards` no repite la tarjeta de ese sector.
 *
 * @param mixed $content HTML del bloque.
 * @param array $block   Bloque analizado.
 * @return mixed
 */
function ebio_sector_page_cards_render( $content, $block ) {
	if ( ! is_string( $content ) || ! is_array( $block ) || 'ebio/sector-cards' !== ( $block['blockName'] ?? '' ) ) {
		return $content;
	}
	$slug = ebio_current_sector_page();
	return '' === $slug ? $content : ebio_sector_cards_exclude_html( $content, $slug );
}
add_filter( 'render_block', 'ebio_sector_page_cards_render', 10, 2 );
