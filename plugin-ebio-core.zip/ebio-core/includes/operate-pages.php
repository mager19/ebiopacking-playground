<?php
/**
 * Páginas en modo Operate (`.impeccable/surfaces/themes-ebiopacking-patterns-page-cotizar-php.md`): `/cotizar/` y
 * `/cotizar/gracias/` sirven para completar la solicitud, no para promocionar.
 *
 * - En esas dos páginas no se emiten la marquesina de marcas (`ebio/brand-marquee`, en la parte del pie) ni el
 *   banner de cotización (`ebio/cta-banner`).
 * - En cualquier página, el botón "Solicitar cotización" del header y del pie no se emite si enlaza a la propia
 *   página (en `/cotizar/` era un enlace a sí misma).
 *
 * Los bloques son compartidos por todas las páginas, así que esto se resuelve al renderizar, como
 * `includes/product-sectors.php`.
 *
 * @package ebio-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ruta normalizada de la petición actual (`/cotizar/`).
 */
function ebio_operate_current_path(): string {
	return ebio_site_path( (string) ( ebio_current_request()['path'] ?? '' ) );
}

/**
 * La petición actual es `/cotizar/` o `/cotizar/gracias/`.
 */
function ebio_is_operate_page(): bool {
	$path = ebio_operate_current_path();
	return in_array( $path, array( '/cotizar/', ebio_site_path( ebio_quote_thanks_path() ) ), true );
}

/**
 * Quita de un HTML los enlaces `<a class="…$class…" href="…">…</a>` que apuntan a `$path`.
 *
 * @param string $html  HTML.
 * @param string $class Clase BEM del enlace (`ebio-site-header__cta`).
 * @param string $path  Ruta normalizada de la página actual.
 * @return string HTML sin esos enlaces.
 */
function ebio_operate_strip_self_link( string $html, string $class, string $path ): string {
	return (string) preg_replace_callback(
		'#<a class="' . preg_quote( $class, '#' ) . '[^"]*" href="([^"]*)"[^>]*>.*?</a>#s',
		static function ( array $match ) use ( $path ): string {
			$target = (string) wp_parse_url( html_entity_decode( $match[1], ENT_QUOTES ), PHP_URL_PATH );
			return '' !== $target && ebio_site_path( $target ) === $path ? '' : $match[0];
		},
		$html
	);
}

/**
 * Filtro de `render_block`.
 *
 * @param mixed $content HTML del bloque.
 * @param array $block   Bloque analizado.
 * @return mixed
 */
function ebio_operate_pages_render( $content, $block ) {
	if ( ! is_string( $content ) || ! is_array( $block ) ) {
		return $content;
	}
	$name = (string) ( $block['blockName'] ?? '' );
	if ( in_array( $name, array( 'ebio/brand-marquee', 'ebio/cta-banner' ), true ) && ebio_is_operate_page() ) {
		return '';
	}
	$links = array(
		'ebio/site-header' => 'ebio-site-header__cta',
		'ebio/site-footer' => 'ebio-site-footer__cta',
	);
	if ( isset( $links[ $name ] ) ) {
		return ebio_operate_strip_self_link( $content, $links[ $name ], ebio_operate_current_path() );
	}
	return $content;
}
add_filter( 'render_block', 'ebio_operate_pages_render', 10, 2 );
