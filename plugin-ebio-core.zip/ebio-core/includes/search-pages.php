<?php
/**
 * Búsqueda (FU12): el `core/query` "Páginas" de la plantilla `search` lista páginas que coinciden con la
 * búsqueda en curso, no las últimas páginas publicadas.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * IDs de las páginas que no deben aparecer como resultado de búsqueda (la confirmación de la cotización).
 * Las rutas salen del filtro `ebio_search_excluded_paths`.
 *
 * @return int[]
 */
function ebio_search_excluded_ids(): array {
	$ids = array();
	foreach ( (array) apply_filters( 'ebio_search_excluded_paths', array( 'cotizar/gracias' ) ) as $path ) {
		$page = get_page_by_path( (string) $path );
		if ( $page ) {
			$ids[] = (int) $page->ID;
		}
	}
	return $ids;
}

/**
 * La búsqueda principal tampoco devuelve las páginas excluidas.
 *
 * @param WP_Query $query Consulta.
 */
function ebio_search_exclude_pages( $query ): void {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
		return;
	}
	$excluded = ebio_search_excluded_ids();
	if ( $excluded ) {
		$query->set( 'post__not_in', array_values( array_unique( array_merge( array_filter( (array) $query->get( 'post__not_in' ) ), $excluded ) ) ) );
	}
}
add_action( 'pre_get_posts', 'ebio_search_exclude_pages' );

/**
 * `query_loop_block_query_vars`: dentro de `ebio-layout-search-pages` (o con la clase propia de la consulta)
 * la consulta pide `post_type` `page` y la búsqueda `s` de la petición.
 *
 * @param array    $query Argumentos de `WP_Query`.
 * @param WP_Block $block Bloque `core/query`.
 * @return array
 */
function ebio_search_pages_query_vars( array $query, $block ): array {
	$class = is_object( $block ) ? (string) ( $block->attributes['className'] ?? '' ) : '';
	$match = 1 === preg_match( '/(?:^|\s)(?:ebio-layout-search-pages|ebio-search-pages-query)(?:\s|$)/', $class );
	if ( ! $match && is_object( $block ) && is_search() ) {
		// El filtro recibe el `core/post-template` hijo, que no ve la clase del `core/query`; el contexto sí
		// trae su consulta: en la búsqueda, la lista de páginas es la única consulta de `post_type` `page`.
		$context = is_array( $block->context ?? null ) ? $block->context : array();
		$match   = 'page' === ( $context['query']['postType'] ?? '' );
	}
	if ( ! $match ) {
		return $query;
	}
	$query['post_type'] = 'page';
	$excluded           = ebio_search_excluded_ids();
	if ( $excluded ) {
		$query['post__not_in'] = array_values( array_unique( array_merge( (array) ( $query['post__not_in'] ?? array() ), $excluded ) ) );
	}
	$search             = trim( (string) get_search_query( false ) );
	if ( '' !== $search ) {
		$query['s'] = $search;
	}
	return $query;
}
add_filter( 'query_loop_block_query_vars', 'ebio_search_pages_query_vars', 10, 2 );
