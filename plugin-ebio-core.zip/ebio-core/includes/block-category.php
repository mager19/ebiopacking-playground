<?php
/**
 * Categoría de bloques "eBiopacking", primera en el insertador.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Antepone la categoría `ebio`.
 *
 * @param array $categories Categorías existentes.
 * @return array
 */
function ebio_block_categories( $categories ) {
	$categories = is_array( $categories ) ? $categories : array();
	$categories = array_values(
		array_filter(
			$categories,
			static function ( $category ) {
				return ! isset( $category['slug'] ) || 'ebio' !== $category['slug'];
			}
		)
	);
	array_unshift(
		$categories,
		array(
			'slug'  => 'ebio',
			'title' => __( 'eBiopacking', 'ebio-core' ),
			'icon'  => null,
		)
	);
	return $categories;
}
add_filter( 'block_categories_all', 'ebio_block_categories' );
