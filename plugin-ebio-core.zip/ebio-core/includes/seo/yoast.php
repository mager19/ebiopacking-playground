<?php
/**
 * Integración con Yoast SEO (catalog D12, FU5): migas, `FAQPage`, `Product`, organización y canonical del
 * catálogo. Todo se engancha a los filtros de Yoast; sin Yoast no se ejecuta nada.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Texto plano de un fragmento HTML (sin etiquetas, entidades decodificadas, espacios colapsados).
 *
 * @param string $html HTML.
 * @return string
 */
function ebio_seo_plain_text( string $html ): string {
	$text = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	return trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
}

/**
 * El texto lleva un marcador `[PENDIENTE CLIENTE: …]` (contenido provisional que no se publica en datos estructurados).
 *
 * @param string $text Texto.
 * @return bool
 */
function ebio_seo_has_pending_marker( string $text ): bool {
	return false !== strpos( $text, '[PENDIENTE CLIENTE:' );
}

/**
 * Migas de Yoast (`wpseo_breadcrumb_links`) a partir de `ebio_breadcrumb_trail()`: cada ítem pasa de
 * `label` a `text`; la página actual va al final con su URL (Yoast la quita del grafo). Sin ruta (Inicio)
 * devuelve las migas de Yoast sin cambios.
 *
 * @param array $links Migas de Yoast.
 * @return array<int,array{text:string,url:string}>
 */
function ebio_yoast_breadcrumb_links( array $links ): array {
	$trail = ebio_breadcrumb_trail();
	if ( '' === $trail['current'] ) {
		return $links;
	}
	$out = array();
	foreach ( $trail['items'] as $item ) {
		$out[] = array(
			'text' => $item['label'],
			'url'  => $item['url'],
		);
	}
	$request = ebio_current_request();
	$object  = $request['object'] ?? null;
	$url     = $object instanceof WP_Post ? get_permalink( $object ) : '';
	if ( $object instanceof WP_Term ) {
		$url = get_term_link( $object );
	}
	if ( ! is_string( $url ) || '' === $url ) {
		$url = home_url( ebio_site_path( (string) ( $request['path'] ?? '/' ) ) );
	}
	$out[] = array(
		'text' => $trail['current'],
		'url'  => $url,
	);
	return $out;
}
add_filter( 'wpseo_breadcrumb_links', 'ebio_yoast_breadcrumb_links' );

/**
 * Nodo `FAQPage` único con las preguntas de todos los `ebio/faq` de la página: texto plano, sin repetidas y
 * sin las que lleven `[PENDIENTE CLIENTE: …]` en la pregunta o la respuesta (C-M3).
 *
 * @param string $page_url URL de la página (base del `@id`).
 * @return array|null Nodo o `null` si no queda ninguna pregunta.
 */
function ebio_seo_faq_node( string $page_url ): ?array {
	$entities = array();
	$seen     = array();
	foreach ( ebio_faq_collected() as $faq ) {
		if ( ebio_seo_has_pending_marker( $faq['question'] ) || ebio_seo_has_pending_marker( $faq['answer'] ) ) {
			continue;
		}
		$question = ebio_seo_plain_text( $faq['question'] );
		$answer   = ebio_seo_plain_text( $faq['answer'] );
		$key      = function_exists( 'mb_strtolower' ) ? mb_strtolower( $question ) : strtolower( $question );
		if ( '' === $question || '' === $answer || isset( $seen[ $key ] ) ) {
			continue;
		}
		$seen[ $key ] = true;
		$entities[]   = array(
			'@type'          => 'Question',
			'name'           => $question,
			'acceptedAnswer' => array(
				'@type' => 'Answer',
				'text'  => $answer,
			),
		);
	}
	if ( ! $entities ) {
		return null;
	}
	return array(
		'@type'      => 'FAQPage',
		'@id'        => $page_url . '#faq',
		'mainEntity' => $entities,
	);
}

/**
 * Nodo `Product` de la ficha (sin `offers`: el catálogo no publica precios). `description` es el extracto
 * salvo que lleve un marcador `[PENDIENTE CLIENTE: …]`.
 *
 * @param WP_Post $post Ficha.
 * @return array
 */
function ebio_seo_product_node( WP_Post $post ): array {
	$url  = (string) get_permalink( $post );
	$node = array(
		'@type' => 'Product',
		'@id'   => $url . '#product',
		'name'  => ebio_seo_plain_text( get_the_title( $post ) ),
		'url'   => $url,
		'brand' => array(
			'@type' => 'Brand',
			'name'  => 'eBiopacking',
		),
	);

	$excerpt = ebio_seo_plain_text( (string) $post->post_excerpt );
	if ( '' !== $excerpt && ! ebio_seo_has_pending_marker( $excerpt ) ) {
		$node['description'] = $excerpt;
	}
	$image = get_the_post_thumbnail_url( $post, 'full' );
	if ( is_string( $image ) && '' !== $image ) {
		$node['image'] = $image;
	}
	$terms = get_the_terms( $post, 'ebio_product_category' );
	$term  = is_array( $terms ) && $terms ? reset( $terms ) : null;
	if ( $term instanceof WP_Term ) {
		$node['category'] = ebio_seo_plain_text( $term->name );
	}
	return $node;
}

/**
 * Grafo de Yoast (`wpseo_schema_graph`): añade un único `FAQPage` (si la página tiene preguntas
 * publicables) y, en la ficha de producto, un `Product`.
 *
 * @param array $graph   Nodos del grafo.
 * @param mixed $context Contexto de Yoast (`canonical`).
 * @return array
 */
function ebio_yoast_schema_graph( array $graph, $context ): array {
	$request = ebio_current_request();
	$object  = $request['object'] ?? null;
	$url     = is_object( $context ) && ! empty( $context->canonical ) ? (string) $context->canonical : '';
	if ( '' === $url && $object instanceof WP_Post ) {
		$url = (string) get_permalink( $object );
	}

	$has = static function ( string $type ) use ( $graph ): bool {
		foreach ( $graph as $node ) {
			$types = is_array( $node ) ? (array) ( $node['@type'] ?? array() ) : array();
			if ( in_array( $type, $types, true ) ) {
				return true;
			}
		}
		return false;
	};

	$faq = $has( 'FAQPage' ) ? null : ebio_seo_faq_node( $url );
	if ( null !== $faq ) {
		$graph[] = $faq;
	}
	if ( ! empty( $request['is_product'] ) && $object instanceof WP_Post && ! $has( 'Product' ) ) {
		$graph[] = ebio_seo_product_node( $object );
	}
	return $graph;
}
add_filter( 'wpseo_schema_graph', 'ebio_yoast_schema_graph', 10, 2 );

/**
 * Organización de Yoast (`wpseo_schema_organization`): `Organization` + `LocalBusiness` con dirección,
 * primer celular y correo de Ajustes › eBiopacking.
 *
 * @param array $data Nodo de organización.
 * @return array
 */
function ebio_yoast_organization( array $data ): array {
	$settings = ebio_site_settings();
	$phones   = ebio_site_contact_phones();
	$email    = ebio_site_contact_email();
	$address  = trim( (string) $settings['address'] );

	$data['@type'] = array( 'Organization', 'LocalBusiness' );
	if ( '' !== $address ) {
		$data['address'] = array(
			'@type'          => 'PostalAddress',
			'streetAddress'  => $address,
			'addressCountry' => 'CO',
		);
	}
	if ( $phones ) {
		$data['telephone'] = $phones[0]['label'];
	}
	if ( null !== $email ) {
		$data['email'] = $email['label'];
	}
	return $data;
}
add_filter( 'wpseo_schema_organization', 'ebio_yoast_organization' );

/**
 * Canonical del archivo de productos (`wpseo_canonical`): con `categoria`, `sector` o `formato` en la URL
 * (válidos o no) apunta siempre a `/productos/`; los filtros no son páginas. Solo mira la presencia de las
 * claves, nunca su valor.
 *
 * @param mixed $canonical Canonical de Yoast (texto; Yoast puede pasar otro tipo si no hay canonical).
 * @return string
 */
function ebio_yoast_catalog_canonical( $canonical ): string {
	$canonical = is_string( $canonical ) ? $canonical : '';
	$request   = ebio_current_request();
	if ( '/productos/' !== ebio_site_path( (string) ( $request['path'] ?? '' ) ) || ! is_array( $request['query'] ?? null ) ) {
		return $canonical;
	}
	foreach ( array( 'categoria', 'sector', 'formato' ) as $key ) {
		if ( array_key_exists( $key, $request['query'] ) ) {
			return home_url( '/productos/' );
		}
	}
	return $canonical;
}
add_filter( 'wpseo_canonical', 'ebio_yoast_catalog_canonical' );

/**
 * Quita el `BreadcrumbList` de Yoast en el Inicio (`wpseo_schema_graph_pieces`): con una sola miga ("Inicio", sin URL)
 * no aporta nada y Search Console lo marca (E7, O9).
 *
 * @param mixed $pieces  Piezas del grafo.
 * @param mixed $context Contexto de Yoast.
 * @return mixed
 */
function ebio_yoast_front_page_pieces( $pieces, $context = null ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	if ( ! is_array( $pieces ) || ! is_front_page() ) {
		return $pieces;
	}
	return array_values(
		array_filter(
			$pieces,
			static function ( $piece ): bool {
				return ! is_object( $piece ) || 'Yoast\WP\SEO\Generators\Schema\Breadcrumb' !== get_class( $piece );
			}
		)
	);
}
add_filter( 'wpseo_schema_graph_pieces', 'ebio_yoast_front_page_pieces', 20, 2 );
