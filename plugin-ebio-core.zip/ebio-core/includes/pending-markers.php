<?php
/**
 * Marcadores `[PENDIENTE CLIENTE: …]`: se envuelven en `<span class="ebio-pending">` solo en nodos de texto.
 *
 * Se recorre el HTML por tokens con WP_HTML_Tag_Processor (contrato §2.8 / C-M4), sin regex sobre el HTML completo.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Ebio_Pending_Marker_Processor' ) ) {
	/**
	 * Recorre tokens `#text` y calcula los envoltorios con desplazamientos de marcadores (bookmarks).
	 */
	class Ebio_Pending_Marker_Processor extends WP_HTML_Tag_Processor {
		/**
		 * HTML original (los desplazamientos de los marcadores son sobre este texto).
		 *
		 * @var string
		 */
		private $source;

		/**
		 * @param string $html HTML a procesar.
		 */
		public function __construct( $html ) {
			parent::__construct( $html );
			$this->source = $html;
		}

		/**
		 * Devuelve el HTML con cada marcador de nodo de texto envuelto.
		 *
		 * @return string
		 */
		public function wrap(): string {
			$edits       = array();
			$raw_element = null; // TEXTAREA, SCRIPT, STYLE o TITLE abierto.
			$span_depth  = 0;    // > 0 dentro de un `.ebio-pending` existente.

			while ( $this->next_token() ) {
				$type = $this->get_token_type();

				if ( '#tag' === $type ) {
					$name   = $this->get_tag();
					$closer = $this->is_tag_closer();
					if ( null !== $raw_element ) {
						if ( $closer && $name === $raw_element ) {
							$raw_element = null;
						}
						continue;
					}
					if ( ! $closer && in_array( $name, array( 'TEXTAREA', 'SCRIPT', 'STYLE', 'TITLE' ), true ) ) {
						$raw_element = $name;
						continue;
					}
					if ( 'SPAN' === $name ) {
						if ( $span_depth > 0 ) {
							$span_depth += $closer ? -1 : 1;
						} elseif ( ! $closer && $this->has_class( 'ebio-pending' ) ) {
							$span_depth = 1;
						}
					}
					continue;
				}

				if ( '#text' !== $type || null !== $raw_element || $span_depth > 0 ) {
					continue;
				}

				if ( ! $this->set_bookmark( 'ebio_text' ) ) {
					continue;
				}
				$span = $this->bookmarks['ebio_text'];
				$this->release_bookmark( 'ebio_text' );

				$raw = substr( $this->source, $span->start, $span->length );
				if ( false === strpos( $raw, '[PENDIENTE CLIENTE:' ) ) {
					continue;
				}
				$wrapped = preg_replace( '/\[PENDIENTE CLIENTE:[^\]]*\]/u', '<span class="ebio-pending">$0</span>', $raw );
				if ( null !== $wrapped && $wrapped !== $raw ) {
					$edits[] = array( $span->start, $span->length, $wrapped );
				}
			}

			$html = $this->source;
			foreach ( array_reverse( $edits ) as $edit ) {
				$html = substr_replace( $html, $edit[2], $edit[0], $edit[1] );
			}
			return $html;
		}
	}
}

/**
 * Envuelve cada marcador `[PENDIENTE CLIENTE: …]` de los nodos de texto.
 *
 * Nunca toca atributos, `<textarea>`, `<script>`, `<style>`, `<title>` ni un `.ebio-pending` existente.
 *
 * @param string $html HTML.
 * @return string
 */
function ebio_wrap_pending_markers( string $html ): string {
	if ( false === strpos( $html, '[PENDIENTE CLIENTE:' ) ) {
		return $html;
	}
	return ( new Ebio_Pending_Marker_Processor( $html ) )->wrap();
}

/**
 * Filtro `render_block`: bloques `ebio/*` y los core de texto.
 *
 * @param string $content Salida del bloque.
 * @param array  $block   Bloque parseado.
 * @return string
 */
function ebio_render_block_pending_markers( $content, $block ) {
	$name = is_array( $block ) ? (string) ( $block['blockName'] ?? '' ) : '';
	if ( ! is_string( $content ) || '' === $name ) {
		return $content;
	}
	$core = array( 'core/paragraph', 'core/heading', 'core/list-item', 'core/button', 'core/table' );
	if ( 0 === strpos( $name, 'ebio/' ) || in_array( $name, $core, true ) ) {
		return ebio_wrap_pending_markers( $content );
	}
	return $content;
}
add_filter( 'render_block', 'ebio_render_block_pending_markers', 10, 2 );

/**
 * Con sesión iniciada los marcadores se muestran resaltados (`ebio-show-pending`).
 *
 * @param string[] $classes Clases del body.
 * @return string[]
 */
function ebio_pending_body_class( $classes ) {
	if ( is_user_logged_in() ) {
		$classes[] = 'ebio-show-pending';
	}
	return $classes;
}
add_filter( 'body_class', 'ebio_pending_body_class' );
