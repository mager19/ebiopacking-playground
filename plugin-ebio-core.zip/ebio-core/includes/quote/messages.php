<?php
/**
 * Mensajes de la cotización: fuente única para validación, servicio, REST, formulario sin JS y JS.
 *
 * Los textos son los de docs/blocks/quote-form.md (tablas de campos y de errores).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Todos los textos de la cotización.
 *
 * @return array<string,string>
 */
function ebio_quote_messages(): array {
	return array(
		// Errores de formulario.
		'bad_nonce_nojs'   => 'Tu sesión del formulario expiró. Vuelve a escribir tus datos y envía el formulario.',
		'bad_nonce_js'     => 'Tu sesión del formulario expiró. Recarga la página y envía de nuevo: tu lista de productos se conserva.',
		'rate_limited'     => 'Has enviado varias solicitudes seguidas. Intenta de nuevo en unos minutos.',
		'spam'             => 'No pudimos enviar tu solicitud. Intenta de nuevo.',
		'save_failed'      => 'No pudimos guardar tu solicitud. Intenta de nuevo.',
		'invalid'          => 'Revisa los campos del formulario.',
		'network'          => 'No pudimos conectar. Revisa tu conexión e intenta de nuevo.',
		'items_prefix'     => 'Tu lista:',
		// Errores de campo.
		'company_required' => 'Escribe el nombre de tu empresa.',
		'company_long'     => 'El nombre de la empresa es demasiado largo.',
		'name_required'    => 'Escribe tu nombre.',
		'name_long'        => 'Tu nombre es demasiado largo.',
		'email'            => 'Escribe un correo válido.',
		'phone'            => 'Escribe un número de celular o WhatsApp válido.',
		'city_long'        => 'La ciudad es demasiado larga.',
		'sector'           => 'Selecciona un sector de la lista.',
		'message_long'     => 'El mensaje es demasiado largo.',
		'consent'          => 'Debes aceptar el tratamiento de datos.',
		'items'            => 'Revisa los productos de tu lista.',
	);
}

/**
 * Texto de un mensaje por clave.
 *
 * @param string $key Clave de ebio_quote_messages().
 */
function ebio_quote_message( string $key ): string {
	$messages = ebio_quote_messages();
	return $messages[ $key ] ?? $messages['invalid'];
}

/**
 * Texto de un código de error de la cotización según el canal.
 *
 * @param string $code    Código del WP_Error (`ebio_bad_nonce`, `ebio_rate_limited`…).
 * @param string $channel `js` o `nojs`.
 */
function ebio_quote_error_message( string $code, string $channel ): string {
	switch ( $code ) {
		case 'ebio_bad_nonce':
			return ebio_quote_message( 'js' === $channel ? 'bad_nonce_js' : 'bad_nonce_nojs' );
		case 'ebio_rate_limited':
			return ebio_quote_message( 'rate_limited' );
		case 'ebio_spam':
			return ebio_quote_message( 'spam' );
		case 'ebio_save_failed':
			return ebio_quote_message( 'save_failed' );
		default:
			return ebio_quote_message( 'invalid' );
	}
}
