<?php
/**
 * Pantallas de administración de cotizaciones.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Columnas de la lista.
 *
 * @param array $columns Columnas actuales.
 */
function ebio_quote_admin_columns( array $columns ): array {
	return array(
		'cb'               => $columns['cb'] ?? '',
		'ebio_date'        => 'Fecha',
		'title'            => 'Empresa',
		'ebio_contact'     => 'Contacto',
		'ebio_items_count' => 'Productos',
		'ebio_status'      => 'Estado',
	);
}
add_filter( 'manage_ebio_quote_posts_columns', 'ebio_quote_admin_columns' );

/**
 * Contenido de las columnas.
 *
 * @param string $column  Columna.
 * @param int    $post_id ID.
 */
function ebio_quote_admin_column_content( string $column, int $post_id ): void {
	$data = get_post_meta( $post_id, 'ebio_quote_data', true );
	$data = is_array( $data ) ? $data : array();
	switch ( $column ) {
		case 'ebio_date':
			echo esc_html( get_the_date( 'Y-m-d H:i', $post_id ) );
			break;
		case 'ebio_contact':
			echo esc_html( ( $data['name'] ?? '' ) . ' · ' . ( $data['email'] ?? '' ) . ' · ' . ( $data['phone'] ?? '' ) );
			break;
		case 'ebio_items_count':
			echo esc_html( (string) count( $data['items'] ?? array() ) );
			break;
		case 'ebio_status':
			echo esc_html( ebio_quote_status_label( ebio_quote_get_status( $post_id ) ) );
			break;
	}
}
add_action( 'manage_ebio_quote_posts_custom_column', 'ebio_quote_admin_column_content', 10, 2 );

/**
 * Estado actual (`nueva` o `atendida`).
 */
function ebio_quote_get_status( int $post_id ): string {
	$status = get_post_meta( $post_id, 'ebio_quote_status', true );
	return 'atendida' === $status ? 'atendida' : 'nueva';
}

/**
 * Etiqueta de un estado.
 */
function ebio_quote_status_label( string $status ): string {
	return 'atendida' === $status ? 'Atendida' : 'Nueva';
}

/**
 * Cajas de la pantalla de edición.
 */
function ebio_quote_add_meta_boxes(): void {
	add_meta_box( 'ebio_quote_data', 'Datos de la solicitud', 'ebio_quote_render_data_box', 'ebio_quote', 'normal', 'high' );
	add_meta_box( 'ebio_quote_status', 'Estado', 'ebio_quote_render_status_box', 'ebio_quote', 'side', 'high' );
}
add_action( 'add_meta_boxes_ebio_quote', 'ebio_quote_add_meta_boxes' );

/**
 * Caja de solo lectura con los datos.
 *
 * @param WP_Post $post Cotización.
 */
function ebio_quote_render_data_box( WP_Post $post ): void {
	$data = get_post_meta( $post->ID, 'ebio_quote_data', true );
	if ( ! is_array( $data ) ) {
		echo '<p>' . esc_html( 'Sin datos.' ) . '</p>';
		return;
	}
	$labels = array(
		'company' => 'Empresa',
		'name'    => 'Nombre',
		'email'   => 'Correo',
		'phone'   => 'Celular / WhatsApp',
		'city'    => 'Ciudad',
		'sector'  => 'Sector',
		'message' => 'Mensaje',
	);
	echo '<table class="widefat striped"><tbody>';
	foreach ( $labels as $key => $label ) {
		printf(
			'<tr><th scope="row">%s</th><td>%s</td></tr>',
			esc_html( $label ),
			nl2br( esc_html( (string) ( $data[ $key ] ?? '' ) ) )
		);
	}
	echo '</tbody></table>';

	echo '<h4>' . esc_html( 'Productos' ) . '</h4>';
	$items = $data['items'] ?? array();
	if ( ! $items ) {
		echo '<p>' . esc_html( 'Solicitud libre, sin productos.' ) . '</p>';
		return;
	}
	echo '<table class="widefat striped"><thead><tr><th>' . esc_html( 'Producto' ) . '</th><th>' . esc_html( 'Cantidad' ) . '</th><th>' . esc_html( 'Medidas' ) . '</th><th>' . esc_html( 'Notas' ) . '</th></tr></thead><tbody>';
	foreach ( $items as $item ) {
		$product_id = (int) ( $item['product_id'] ?? 0 );
		$product    = $product_id ? get_post( $product_id ) : null;
		if ( $product && 'ebio_product' === $product->post_type ) {
			$edit = get_edit_post_link( $product_id );
			$name = $edit
				? '<a href="' . esc_url( $edit ) . '">' . esc_html( get_the_title( $product_id ) ) . '</a>'
				: esc_html( get_the_title( $product_id ) );
		} else {
			$name = esc_html( (string) $product_id . ' (producto eliminado)' );
		}
		// `quantity` y `dimensions` ya son texto legible ("500 pallets", "60 × 40 × 40 cm (largo × ancho × alto)").
		$or_none = static function ( $value ): string {
			$value = trim( (string) $value );
			return '' !== $value ? $value : 'sin indicar';
		};
		printf(
			'<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>',
			$name, // Ya escapado arriba.
			esc_html( $or_none( $item['quantity'] ?? '' ) ),
			esc_html( $or_none( $item['dimensions'] ?? '' ) ),
			nl2br( esc_html( (string) ( $item['notes'] ?? '' ) ) )
		);
	}
	echo '</tbody></table>';
}

/**
 * Selector de estado.
 *
 * @param WP_Post $post Cotización.
 */
function ebio_quote_render_status_box( WP_Post $post ): void {
	wp_nonce_field( 'ebio_quote_status_' . $post->ID, 'ebio_quote_status_nonce' );
	$current = ebio_quote_get_status( $post->ID );
	echo '<select name="ebio_quote_status">';
	foreach ( array( 'nueva', 'atendida' ) as $status ) {
		printf(
			'<option value="%s"%s>%s</option>',
			esc_attr( $status ),
			selected( $current, $status, false ),
			esc_html( ebio_quote_status_label( $status ) )
		);
	}
	echo '</select>';
}

/**
 * Guarda el estado desde la caja.
 *
 * @param int $post_id ID.
 */
function ebio_quote_save_status( int $post_id ): void {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	$nonce = isset( $_POST['ebio_quote_status_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ebio_quote_status_nonce'] ) ) : '';
	if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'ebio_quote_status_' . $post_id ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$status = isset( $_POST['ebio_quote_status'] ) ? sanitize_key( wp_unslash( $_POST['ebio_quote_status'] ) ) : '';
	if ( in_array( $status, array( 'nueva', 'atendida' ), true ) ) {
		update_post_meta( $post_id, 'ebio_quote_status', $status );
	}
}
add_action( 'save_post_ebio_quote', 'ebio_quote_save_status' );
