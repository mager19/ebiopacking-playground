<?php
/**
 * Envío del formulario de cotización sin JavaScript (admin-post.php).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Procesa un POST de formulario y devuelve la URL de destino. No redirige.
 *
 * @param array  $post Datos del formulario (sin slashes).
 * @param string $ip   IP del cliente.
 * @return string URL absoluta de destino.
 */
function ebio_quote_handle_form( array $post, string $ip ): string {
	$error_url = function ( string $code, array $args = array() ): string {
		return add_query_arg( array_merge( array( 'ebio_error' => $code ), $args ), home_url( '/cotizar/' ) ) . '#ebio-quote-form';
	};

	if ( ! ebio_quote_verify_nonce( $post['_ebio_nonce'] ?? null ) ) {
		return $error_url( 'ebio_bad_nonce' );
	}

	$result = ebio_quote_submit( $post, $ip );
	if ( ! is_wp_error( $result ) ) {
		return home_url( '/cotizar/gracias/' );
	}

	$args = array();
	if ( 'ebio_invalid' === $result->get_error_code() ) {
		// Valores conservados 10 minutos para rellenar el formulario; la referencia no es adivinable.
		$ref  = wp_generate_password( 16, false );
		$keep   = array();
		$limits = array( 'company' => 120, 'name' => 120, 'email' => 254, 'phone' => 30, 'city' => 80, 'sector' => 40, 'message' => 2000 );
		foreach ( $limits as $field => $max ) {
			$value          = ebio_quote_clean_text( $post[ $field ] ?? '', 'message' === $field );
			$keep[ $field ] = mb_substr( $value ?? '', 0, $max );
		}
		$keep['items'] = array();
		$raw_items     = isset( $post['items'] ) && is_array( $post['items'] ) ? array_slice( $post['items'], 0, EBIO_QUOTE_MAX_ITEMS ) : array();
		foreach ( $raw_items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$pid  = $item['product_id'] ?? '';
			$kept = array(
				'product_id' => is_scalar( $pid ) ? mb_substr( (string) $pid, 0, 12 ) : '',
				'quantity'   => mb_substr( ebio_quote_clean_text( $item['quantity'] ?? '' ) ?? '', 0, 40 ),
				'dimensions' => mb_substr( ebio_quote_clean_text( $item['dimensions'] ?? '' ) ?? '', 0, 120 ),
				'notes'      => mb_substr( ebio_quote_clean_text( $item['notes'] ?? '', true ) ?? '', 0, 500 ),
			);
			// Campos estructurados (cantidad, unidades y medidas), recortados igual que en la validación.
			foreach ( array( 'quantity_unit' => 10, 'length' => 9, 'width' => 9, 'height' => 9, 'dimension_unit' => 10 ) as $key => $max ) {
				if ( array_key_exists( $key, $item ) ) {
					$kept[ $key ] = mb_substr( ebio_quote_clean_text( $item[ $key ] ) ?? '', 0, $max );
				}
			}
			$keep['items'][] = $kept;
		}
		$keep['fields'] = $result->get_error_data()['fields'] ?? array();
		set_transient( 'ebio_quote_form_' . $ref, $keep, 10 * MINUTE_IN_SECONDS );
		$args['ebio_ref'] = $ref;
	}
	return $error_url( $result->get_error_code(), $args );
}

/**
 * Hook de admin-post: redirige a la URL calculada.
 */
function ebio_quote_admin_post(): void {
	$post = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Se verifica en ebio_quote_handle_form().
	$url  = ebio_quote_handle_form( is_array( $post ) ? $post : array(), ebio_quote_client_ip() );
	nocache_headers();
	wp_safe_redirect( $url, 303 );
	exit;
}
add_action( 'admin_post_nopriv_ebio_quote', 'ebio_quote_admin_post' );
add_action( 'admin_post_ebio_quote', 'ebio_quote_admin_post' );
