<?php
/**
 * Validación y saneamiento de solicitudes de cotización.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

const EBIO_QUOTE_MAX_ITEMS = 30;

/**
 * Sectores válidos del formulario.
 *
 * @return string[]
 */
function ebio_quote_sectors(): array {
	return array( 'floricultura', 'agro-frutas', 'industria', 'alimentos', 'retail-ecommerce', 'otro' );
}

/**
 * Convierte un valor de entrada en texto limpio. Devuelve null si no es un escalar.
 *
 * @param mixed $value    Valor recibido.
 * @param bool  $textarea Conserva saltos de línea.
 * @return string|null
 */
function ebio_quote_clean_text( $value, bool $textarea = false ): ?string {
	if ( null === $value ) {
		return '';
	}
	if ( ! is_scalar( $value ) ) {
		return null;
	}
	$value = (string) $value;
	return $textarea ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
}

/**
 * Valida y limpia los productos de la solicitud.
 *
 * @param mixed $raw Valor recibido en `items`.
 * @return array|null Lista limpia o null si hay algún error.
 */
function ebio_quote_clean_items( $raw ): ?array {
	if ( null === $raw || '' === $raw || array() === $raw ) {
		return array();
	}
	if ( ! is_array( $raw ) || count( $raw ) > EBIO_QUOTE_MAX_ITEMS ) {
		return null;
	}
	$items = array();
	foreach ( $raw as $item ) {
		if ( ! is_array( $item ) ) {
			return null;
		}
		$product_id = $item['product_id'] ?? null;
		if ( is_string( $product_id ) && ctype_digit( $product_id ) && strlen( $product_id ) <= 9 ) {
			$product_id = (int) $product_id;
		}
		if ( ! is_int( $product_id ) || $product_id < 1 ) {
			return null;
		}
		$product = get_post( $product_id );
		if ( ! $product || 'ebio_product' !== $product->post_type || 'publish' !== $product->post_status ) {
			return null;
		}
		$clean = ebio_quote_is_structured_item( $item ) ? ebio_quote_clean_structured_item( $item ) : ebio_quote_clean_legacy_item( $item );
		if ( null === $clean ) {
			return null;
		}
		if ( isset( $items[ $product_id ] ) ) {
			continue; // Duplicado: se conserva el primero.
		}
		$items[ $product_id ] = array_merge( array( 'product_id' => $product_id ), $clean );
	}
	return array_values( $items );
}

/**
 * Unidades válidas de cantidad (la primera es la de por defecto).
 *
 * @return string[]
 */
function ebio_quote_quantity_units(): array {
	return array( 'unidades', 'pallets' );
}

/**
 * Unidades válidas de medida (la primera es la de por defecto).
 *
 * @return string[]
 */
function ebio_quote_dimension_units(): array {
	return array( 'cm', 'mm' );
}

/**
 * Un ítem es estructurado (JS actual) si trae alguno de los campos nuevos; si no, es del formato anterior
 * (`quantity` y `dimensions` de texto libre), que se sigue aceptando.
 *
 * @param array $item Ítem recibido.
 */
function ebio_quote_is_structured_item( array $item ): bool {
	foreach ( array( 'quantity_unit', 'length', 'width', 'height', 'dimension_unit' ) as $key ) {
		if ( array_key_exists( $key, $item ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Ítem del formato anterior: texto libre limitado (40, 120 y 500 caracteres). Los campos estructurados quedan vacíos.
 *
 * @param array $item Ítem recibido.
 * @return array|null Campos limpios (sin `product_id`) o null si hay algún error.
 */
function ebio_quote_clean_legacy_item( array $item ): ?array {
	$quantity   = ebio_quote_clean_text( $item['quantity'] ?? '' );
	$dimensions = ebio_quote_clean_text( $item['dimensions'] ?? '' );
	$notes      = ebio_quote_clean_text( $item['notes'] ?? '', true );
	if ( null === $quantity || null === $dimensions || null === $notes
		|| mb_strlen( $quantity ) > 40 || mb_strlen( $dimensions ) > 120 || mb_strlen( $notes ) > 500 ) {
		return null;
	}
	return array(
		'quantity'       => $quantity,
		'dimensions'     => $dimensions,
		'notes'          => $notes,
		'quantity_value' => '',
		'quantity_unit'  => '',
		'length'         => '',
		'width'          => '',
		'height'         => '',
		'dimension_unit' => '',
	);
}

/**
 * Ítem estructurado: cantidad entera (hasta 9 dígitos), largo/ancho/alto con hasta 2 decimales y unidades de la
 * lista (vacías → la de por defecto). `quantity` y `dimensions` guardan además el texto legible que usan el
 * correo y la pantalla de administración.
 *
 * @param array $item Ítem recibido.
 * @return array|null Campos limpios (sin `product_id`) o null si hay algún error.
 */
function ebio_quote_clean_structured_item( array $item ): ?array {
	$text = static function ( string $key ) use ( $item ): ?string {
		$value = ebio_quote_clean_text( $item[ $key ] ?? '' );
		return null === $value ? null : trim( $value );
	};
	$quantity = $text( 'quantity' );
	$q_unit   = $text( 'quantity_unit' );
	$d_unit   = $text( 'dimension_unit' );
	$notes    = ebio_quote_clean_text( $item['notes'] ?? '', true );
	$sizes    = array();
	foreach ( array( 'length', 'width', 'height' ) as $key ) {
		$sizes[ $key ] = $text( $key );
		if ( null === $sizes[ $key ] || ( '' !== $sizes[ $key ] && ! preg_match( '/^\d{1,6}(\.\d{1,2})?$/', $sizes[ $key ] ) ) ) {
			return null;
		}
	}
	if ( null === $quantity || null === $q_unit || null === $d_unit || null === $notes || mb_strlen( $notes ) > 500
		|| ( '' !== $quantity && ! preg_match( '/^\d{1,9}$/', $quantity ) ) ) {
		return null;
	}
	$q_unit = '' === $q_unit ? ebio_quote_quantity_units()[0] : $q_unit;
	$d_unit = '' === $d_unit ? ebio_quote_dimension_units()[0] : $d_unit;
	if ( ! in_array( $q_unit, ebio_quote_quantity_units(), true ) || ! in_array( $d_unit, ebio_quote_dimension_units(), true ) ) {
		return null;
	}
	return array(
		'quantity'       => ebio_quote_quantity_text( $quantity, $q_unit ),
		'dimensions'     => ebio_quote_dimensions_text( $sizes['length'], $sizes['width'], $sizes['height'], $d_unit ),
		'notes'          => $notes,
		'quantity_value' => $quantity,
		'quantity_unit'  => $q_unit,
		'length'         => $sizes['length'],
		'width'          => $sizes['width'],
		'height'         => $sizes['height'],
		'dimension_unit' => $d_unit,
	);
}

/**
 * Cantidad legible: "500 unidades", "1 pallet"; vacía sin número.
 *
 * @param string $quantity Número.
 * @param string $unit     `unidades` o `pallets`.
 */
function ebio_quote_quantity_text( string $quantity, string $unit ): string {
	if ( '' === $quantity ) {
		return '';
	}
	$singular = array(
		'unidades' => 'unidad',
		'pallets'  => 'pallet',
	);
	return $quantity . ' ' . ( '1' === ltrim( $quantity, '0' ) ? ( $singular[ $unit ] ?? $unit ) : $unit );
}

/**
 * Medidas legibles: "60 × 40 × 40 cm (largo × ancho × alto)" con las tres; con algunas, "largo 60 · alto 40 cm";
 * vacías sin ninguna.
 *
 * @param string $length Largo.
 * @param string $width  Ancho.
 * @param string $height Alto.
 * @param string $unit   `cm` o `mm`.
 */
function ebio_quote_dimensions_text( string $length, string $width, string $height, string $unit ): string {
	if ( '' !== $length && '' !== $width && '' !== $height ) {
		return $length . ' × ' . $width . ' × ' . $height . ' ' . $unit . ' (largo × ancho × alto)';
	}
	$parts = array();
	foreach ( array( 'largo' => $length, 'ancho' => $width, 'alto' => $height ) as $label => $value ) {
		if ( '' !== $value ) {
			$parts[] = $label . ' ' . $value;
		}
	}
	return $parts ? implode( ' · ', $parts ) . ' ' . $unit : '';
}

/**
 * Valida y limpia una solicitud de cotización.
 *
 * @param array $input Datos recibidos.
 * @return array|WP_Error Datos limpios o error `ebio_invalid` / `ebio_spam`.
 */
function ebio_quote_validate( array $input ) {
	if ( isset( $input['website'] ) && '' !== trim( is_scalar( $input['website'] ) ? (string) $input['website'] : 'x' ) ) {
		return new WP_Error( 'ebio_spam', ebio_quote_error_message( 'ebio_spam', 'js' ), array( 'status' => 400 ) );
	}

	$errors = array();
	$clean  = array();

	$m     = ebio_quote_messages();
	$rules = array(
		'company' => array( 'max' => 120, 'required' => $m['company_required'], 'long' => $m['company_long'] ),
		'name'    => array( 'max' => 120, 'required' => $m['name_required'], 'long' => $m['name_long'] ),
		'email'   => array( 'max' => 254, 'required' => $m['email'], 'long' => $m['email'] ),
		'phone'   => array( 'max' => 30, 'required' => $m['phone'], 'long' => $m['phone'] ),
		'city'    => array( 'max' => 80, 'long' => $m['city_long'] ),
		'sector'  => array( 'max' => 40, 'long' => $m['sector'] ),
		'message' => array( 'max' => 2000, 'long' => $m['message_long'], 'textarea' => true ),
	);

	foreach ( $rules as $field => $rule ) {
		$value = ebio_quote_clean_text( $input[ $field ] ?? '', ! empty( $rule['textarea'] ) );
		if ( null === $value ) {
			$errors[ $field ] = $rule['required'] ?? $rule['long'];
			$value            = '';
		} elseif ( isset( $rule['required'] ) && '' === $value ) {
			$errors[ $field ] = $rule['required'];
		} elseif ( mb_strlen( $value ) > $rule['max'] ) {
			$errors[ $field ] = $rule['long'];
		}
		$clean[ $field ] = $value;
	}

	if ( ! isset( $errors['email'] ) && ! is_email( $clean['email'] ) ) {
		$errors['email'] = $m['email'];
	}
	if ( ! isset( $errors['phone'] ) && ( ! preg_match( '/^[0-9 +()\-]+$/', $clean['phone'] ) || preg_match_all( '/\d/', $clean['phone'] ) < 7 ) ) {
		$errors['phone'] = $m['phone'];
	}
	if ( '' !== $clean['sector'] && ! in_array( $clean['sector'], ebio_quote_sectors(), true ) ) {
		$errors['sector'] = $m['sector'];
	}

	$consent = $input['consent'] ?? false;
	if ( true !== $consent && '1' !== $consent && 1 !== $consent ) {
		$errors['consent'] = $m['consent'];
	}
	$clean['consent'] = true;

	$items = ebio_quote_clean_items( $input['items'] ?? array() );
	if ( null === $items ) {
		$errors['items'] = $m['items'];
		$items           = array();
	}
	$clean['items'] = $items;

	if ( $errors ) {
		return new WP_Error(
			'ebio_invalid',
			$m['invalid'],
			array(
				'status' => 400,
				'fields' => $errors,
			)
		);
	}
	return $clean;
}
