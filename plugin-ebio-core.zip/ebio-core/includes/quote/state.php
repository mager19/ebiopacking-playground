<?php
/**
 * Estado inicial del store compartido `ebio/quote` (catalog §4, FU13).
 *
 * El contador y la lista viven en el navegador: el servidor solo publica los valores iniciales que ya
 * están escritos en el markup (contador en 0, aviso oculto, `cardState` "idle"), para que procesar
 * las directivas en el servidor no cambie el HTML (catalog §2.12), más las URL y los mensajes que usa
 * el JS. Es idempotente: los bloques que usan `ebio/quote` lo llaman también desde su render, porque
 * en un tema de bloques la plantilla se renderiza antes de `wp_enqueue_scripts`.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Nombre accesible del contador del header: empieza por su texto visible `quoteLabel` (WCAG 2.5.3).
 * Gemelo de `counterLabel()` (src/stores/quote/lib.js).
 *
 * @param int    $count Productos en la lista.
 * @param string $label `quoteLabel` del header; vacío → "Mi cotización".
 * @return string "<label>, N productos".
 */
function ebio_quote_counter_label( int $count, string $label ): string {
	$label = trim( $label );
	return ( '' !== $label ? $label : 'Mi cotización' ) . ', ' . $count . ( 1 === $count ? ' producto' : ' productos' );
}

/**
 * Publica el estado inicial de `ebio/quote`. Conserva el `quoteLabel` que ya publicó el header (la
 * llamada de `wp_enqueue_scripts` llega después de renderizar la cabecera en un tema de bloques).
 */
function ebio_quote_init_state(): void {
	$current = wp_interactivity_state( 'ebio/quote' );
	$label   = is_string( $current['quoteLabel'] ?? null ) && '' !== trim( $current['quoteLabel'] ) ? $current['quoteLabel'] : 'Mi cotización';
	wp_interactivity_state(
		'ebio/quote',
		array(
			'count'        => 0,
			'quoteLabel'   => $label,
			'counterLabel' => ebio_quote_counter_label( 0, $label ),
			'cardState'    => 'idle',
			// `null`, nunca `false`: un `aria-*` con `false` se imprimiría como "false" (D8).
			'cardDisabled' => null,
			'toastVisible' => false,
			'toastText'    => '',
			'max'          => EBIO_QUOTE_MAX_ITEMS,
			'quoteUrl'     => home_url( '/cotizar/' ),
			'restUrl'      => rest_url( 'ebio/v1/quote' ),
			'messages'     => ebio_quote_messages(),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'ebio_quote_init_state' );
