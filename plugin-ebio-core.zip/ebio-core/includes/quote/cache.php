<?php
/**
 * La página con el formulario de cotización no se cachea (nonce por visitante, repoblado de errores) y
 * mantenimiento de las filas del límite de frecuencia.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Indica si una página contiene el formulario de cotización.
 *
 * @param WP_Post|null $post Entrada.
 */
function ebio_quote_page_needs_nocache( ?WP_Post $post ): bool {
	return $post instanceof WP_Post && has_block( 'ebio/quote-form', $post );
}

/**
 * Desactiva la caché de página y envía cabeceras no-cache en la página del formulario.
 */
function ebio_quote_maybe_nocache(): void {
	if ( ! is_singular() || ! ebio_quote_page_needs_nocache( get_queried_object() instanceof WP_Post ? get_queried_object() : null ) ) {
		return;
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	nocache_headers();
}
add_action( 'template_redirect', 'ebio_quote_maybe_nocache' );

/**
 * Borra las filas de contador de buckets anteriores al actual (de cualquier IP).
 *
 * @return int Filas borradas.
 */
function ebio_quote_purge_rate_limits(): int {
	global $wpdb;
	$bucket = (int) floor( ebio_quote_now() / EBIO_QUOTE_RATE_WINDOW );
	// Nombre: `_ebio_rl_` + hash hexadecimal (sin `_`) + `_` + bucket; el bucket es lo que sigue al último `_`.
	$deleted = $wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(SUBSTRING_INDEX(option_name, '_', -1) AS UNSIGNED) < %d",
			$wpdb->esc_like( '_ebio_rl_' ) . '%',
			$bucket
		)
	);
	return (int) $deleted;
}
add_action( 'ebio_quote_purge_rl', 'ebio_quote_purge_rate_limits' );

/**
 * Programa la purga diaria (activación del plugin).
 */
function ebio_quote_schedule_purge(): void {
	if ( ! wp_next_scheduled( 'ebio_quote_purge_rl' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ebio_quote_purge_rl' );
	}
}

// También en `init`: el evento se programa aunque el plugin ya estuviera activo antes de añadirlo.
add_action( 'init', 'ebio_quote_schedule_purge' );

/**
 * Desprograma la purga diaria (desactivación del plugin).
 */
function ebio_quote_unschedule_purge(): void {
	wp_clear_scheduled_hook( 'ebio_quote_purge_rl' );
}
