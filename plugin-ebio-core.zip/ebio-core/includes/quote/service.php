<?php
/**
 * Servicio de cotización: límite de frecuencia, almacenamiento y envío.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

const EBIO_QUOTE_RATE_MAX    = 5;
const EBIO_QUOTE_RATE_WINDOW = 600;

/**
 * IP del cliente. Solo REMOTE_ADDR: las cabeceras X-Forwarded-For o Client-IP las controla el cliente.
 */
function ebio_quote_client_ip(): string {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$ip = false !== filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	/**
	 * Permite a un despliegue detrás de proxy/CDN resolver la IP real. El resultado se revalida.
	 *
	 * @param string $ip REMOTE_ADDR validada.
	 */
	$filtered = apply_filters( 'ebio_quote_client_ip', $ip );
	return ( is_string( $filtered ) && false !== filter_var( $filtered, FILTER_VALIDATE_IP ) ) ? $filtered : $ip;
}

/**
 * Destinatario de las solicitudes.
 */
function ebio_quote_recipient(): string {
	$option = get_option( 'ebio_quote_recipient' );
	return ( is_string( $option ) && is_email( $option ) ) ? $option : 'ventas@ebiopacking.com';
}

/**
 * Prefijo de las filas de contador de una IP.
 */
function ebio_quote_rate_limit_prefix( string $ip ): string {
	return '_ebio_rl_' . substr( wp_hash( $ip ), 0, 32 ) . '_';
}

/**
 * Borra los contadores de una IP.
 */
function ebio_quote_reset_rate_limit( string $ip ): void {
	global $wpdb;
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( ebio_quote_rate_limit_prefix( $ip ) ) . '%' ) );
}

/**
 * Hora actual (Unix) del límite de frecuencia. El filtro `ebio_quote_now` permite fijarla en pruebas.
 */
function ebio_quote_now(): int {
	return (int) apply_filters( 'ebio_quote_now', time() );
}

/**
 * Registra un intento y dice si la IP superó el límite.
 *
 * Decisión: ventanas de reloj fijas y alineadas de 10 minutos (bucket = floor(ebio_quote_now()/600)), no una
 * ventana deslizante desde el primer intento. El contador es una fila de wp_options incrementada con
 * un único INSERT ... ON DUPLICATE KEY UPDATE, atómico entre peticiones concurrentes.
 */
function ebio_quote_rate_limited( string $ip ): bool {
	global $wpdb;
	$bucket = (int) floor( ebio_quote_now() / EBIO_QUOTE_RATE_WINDOW );
	$prefix = ebio_quote_rate_limit_prefix( $ip );
	$name   = $prefix . $bucket;

	$wpdb->query( $wpdb->prepare( "INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, '1', 'off') ON DUPLICATE KEY UPDATE option_value = option_value + 1", $name ) );
	$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) );

	if ( 1 === $count ) {
		// Primer intento del bucket: purga los de buckets anteriores de esta IP.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name <> %s", $wpdb->esc_like( $prefix ) . '%', $name ) );
	}
	return $count > EBIO_QUOTE_RATE_MAX;
}

/**
 * Procesa una solicitud: límite, validación, guardado y correos.
 *
 * @param array  $input Datos recibidos.
 * @param string $ip    IP del cliente.
 * @return int|WP_Error ID de la cotización.
 */
function ebio_quote_submit( array $input, string $ip ) {
	if ( ebio_quote_rate_limited( $ip ) ) {
		return new WP_Error( 'ebio_rate_limited', ebio_quote_error_message( 'ebio_rate_limited', 'js' ), array( 'status' => 429 ) );
	}

	$clean = ebio_quote_validate( $input );
	if ( is_wp_error( $clean ) ) {
		return $clean;
	}

	$id = wp_insert_post(
		array(
			'post_type'   => 'ebio_quote',
			'post_status' => 'publish',
			'post_author' => 0,
			'post_title'  => wp_slash( $clean['company'] . ' — ' . current_time( 'Y-m-d H:i' ) ),
		),
		true
	);
	if ( is_wp_error( $id ) || ! $id ) {
		return new WP_Error( 'ebio_save_failed', ebio_quote_error_message( 'ebio_save_failed', 'js' ), array( 'status' => 500 ) );
	}

	update_post_meta( $id, 'ebio_quote_data', wp_slash( $clean ) );
	update_post_meta( $id, 'ebio_quote_status', 'nueva' );
	update_post_meta( $id, 'ebio_quote_ip_hash', wp_hash( $ip ) );

	ebio_quote_send_mails( $id );
	return (int) $id;
}

/**
 * Ejecuta un callback como usuario 0 (el nonce de cotización no depende de la sesión).
 *
 * @param callable $fn Callback.
 * @return mixed
 */
function ebio_quote_as_anonymous( callable $fn ) {
	$previous = get_current_user_id();
	wp_set_current_user( 0 );
	try {
		return $fn();
	} finally {
		wp_set_current_user( $previous );
	}
}

/**
 * Crea el nonce de cotización, siempre como usuario 0.
 */
function ebio_quote_create_nonce(): string {
	return (string) ebio_quote_as_anonymous(
		function () {
			return wp_create_nonce( 'ebio_quote' );
		}
	);
}

/**
 * Verifica el nonce de cotización, siempre como usuario 0.
 *
 * @param mixed $nonce Valor recibido.
 */
function ebio_quote_verify_nonce( $nonce ): bool {
	if ( ! is_string( $nonce ) || '' === $nonce ) {
		return false;
	}
	return (bool) ebio_quote_as_anonymous(
		function () use ( $nonce ) {
			return wp_verify_nonce( $nonce, 'ebio_quote' );
		}
	);
}

/**
 * Hidden input con el nonce del formulario de cotización.
 */
function ebio_quote_nonce_field(): string {
	return '<input type="hidden" name="_ebio_nonce" value="' . esc_attr( ebio_quote_create_nonce() ) . '" />';
}

/**
 * Ruta relativa de la página de gracias.
 */
function ebio_quote_thanks_path(): string {
	return (string) wp_parse_url( home_url( '/cotizar/gracias/' ), PHP_URL_PATH );
}
