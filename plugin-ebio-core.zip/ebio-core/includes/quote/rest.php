<?php
/**
 * Endpoint REST de cotización.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registra POST /ebio/v1/quote.
 */
function ebio_quote_register_rest_route(): void {
	register_rest_route(
		'ebio/v1',
		'/quote',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => 'ebio_quote_rest_callback',
			'permission_callback' => '__return_true', // Público; protegido por nonce, honeypot y límite de frecuencia.
		)
	);
}
add_action( 'rest_api_init', 'ebio_quote_register_rest_route' );

/**
 * Crea una cotización desde una petición REST.
 *
 * @param WP_REST_Request $request Petición.
 * @return WP_REST_Response|WP_Error
 */
function ebio_quote_rest_callback( WP_REST_Request $request ) {
	$params = $request->get_json_params();
	if ( ! is_array( $params ) ) {
		$params = $request->get_body_params();
	}

	if ( ! ebio_quote_verify_nonce( $params['_ebio_nonce'] ?? null ) ) {
		return new WP_Error( 'ebio_bad_nonce', ebio_quote_error_message( 'ebio_bad_nonce', 'js' ), array( 'status' => 403 ) );
	}

	$id = ebio_quote_submit( $params, ebio_quote_client_ip() );
	if ( is_wp_error( $id ) ) {
		return $id;
	}

	$response = new WP_REST_Response(
		array( 'redirect' => ebio_quote_thanks_path() ),
		201
	);
	$response->header( 'Cache-Control', 'no-store' );
	return $response;
}
