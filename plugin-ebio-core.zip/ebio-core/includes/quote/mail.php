<?php
/**
 * Correos de cotización (texto plano).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Elimina CR/LF y controles de un valor que irá en una cabecera o asunto.
 */
function ebio_quote_header_value( string $value ): string {
	return trim( preg_replace( '/[\x00-\x1F\x7F]+/', ' ', $value ) );
}

/**
 * Texto para salida en texto plano: decodifica entidades HTML (nombradas y numéricas).
 */
function ebio_quote_plain( string $value ): string {
	return html_entity_decode( $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
}

/**
 * Arma el cuerpo en texto plano de una solicitud.
 *
 * @param array $data Datos limpios.
 */
function ebio_quote_mail_body( array $data, bool $include_free_text = true ): string {
	$lines   = array();
	$lines[] = 'Empresa: ' . $data['company'];
	$lines[] = 'Nombre: ' . $data['name'];
	$lines[] = 'Correo: ' . $data['email'];
	$lines[] = 'Celular / WhatsApp: ' . $data['phone'];
	$lines[] = 'Ciudad: ' . $data['city'];
	$lines[] = 'Sector: ' . $data['sector'];
	if ( $include_free_text ) {
		$lines[] = 'Mensaje: ' . $data['message'];
	}
	$lines[] = '';
	$lines[] = 'Productos (' . count( $data['items'] ) . '):';
	if ( ! $data['items'] ) {
		$lines[] = '- Solicitud libre, sin productos.';
	}
	// `quantity` y `dimensions` ya son texto legible ("500 unidades", "60 × 40 × 40 cm (largo × ancho × alto)").
	$or_none = static function ( $value ): string {
		$value = trim( (string) $value );
		return '' !== $value ? $value : 'sin indicar';
	};
	foreach ( $data['items'] as $item ) {
		$title   = (string) get_post_field( 'post_title', $item['product_id'], 'raw' );
		$lines[] = sprintf(
			$include_free_text ? '- %s (ID %d) | Cantidad: %s | Medidas: %s | Notas: %s' : '- %s (ID %d) | Cantidad: %s | Medidas: %s%s',
			'' !== $title ? wp_strip_all_tags( $title ) : 'producto eliminado',
			$item['product_id'],
			$or_none( $item['quantity'] ?? '' ),
			$or_none( $item['dimensions'] ?? '' ),
			$include_free_text ? $item['notes'] : ''
		);
	}
	return ebio_quote_plain( implode( "\n", $lines ) );
}

/**
 * Envía el correo a ventas y la confirmación al cliente.
 *
 * @param int $quote_id ID de la cotización.
 */
function ebio_quote_send_mails( int $quote_id ): void {
	$data = get_post_meta( $quote_id, 'ebio_quote_data', true );
	if ( ! is_array( $data ) || empty( $data['email'] ) ) {
		return;
	}
	$company = ebio_quote_header_value( ebio_quote_plain( $data['company'] ) );
	$email   = ebio_quote_header_value( $data['email'] );
	$body    = ebio_quote_mail_body( $data );
	$plain   = 'Content-Type: text/plain; charset=UTF-8';

	wp_mail(
		ebio_quote_recipient(),
		'Nueva solicitud de cotización — ' . $company,
		"Solicitud #{$quote_id}\n\n" . $body,
		array( $plain, 'Reply-To: ' . $email )
	);

	if ( is_email( $email ) ) {
		wp_mail(
			$email,
			'Recibimos tu solicitud de cotización — eBiopacking',
			'Hola ' . ebio_quote_plain( $data['name'] ) . ",\n\nRecibimos tu solicitud de cotización. Este es el resumen:\n\n" . ebio_quote_mail_body( $data, false )
				. "\n\nTe responderemos con tu cotización lo antes posible.\n\neBiopacking",
			array( $plain )
		);
	}
}
