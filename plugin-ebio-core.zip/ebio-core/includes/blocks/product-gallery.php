<?php
/**
 * `ebio/product-gallery`: estado inicial del store de la Interactivity API.
 *
 * El diálogo de ampliación enlaza `src` y `alt` a `state.activeSrc` y `state.activeAlt`; el servidor
 * los define con el mismo valor que ya está en el markup (`null` → sin `src`, `""` → `alt=""`), de
 * modo que procesar las directivas no cambia el HTML (catalog §2.12, "SSR sin efecto").
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Publica el estado inicial de `ebio/product-gallery`.
 */
function ebio_product_gallery_init_state(): void {
	wp_interactivity_state(
		'ebio/product-gallery',
		array(
			'activeSrc' => null,
			'activeAlt' => '',
		)
	);
}

/**
 * Filtro `render_block_data`: antes de renderizar una galería (el procesado de directivas va después).
 *
 * @param array $parsed_block Bloque analizado.
 * @return array Bloque sin cambios.
 */
function ebio_product_gallery_prepare_state( $parsed_block ) {
	if ( 'ebio/product-gallery' === ( $parsed_block['blockName'] ?? '' ) ) {
		ebio_product_gallery_init_state();
	}
	return $parsed_block;
}
add_filter( 'render_block_data', 'ebio_product_gallery_prepare_state' );
