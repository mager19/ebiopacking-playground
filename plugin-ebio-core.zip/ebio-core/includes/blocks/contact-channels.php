<?php
/**
 * `ebio/contact-channels`: vista dinámica (docs/blocks/contact-channels.md). Teléfonos, WhatsApp,
 * correo, dirección y horarios salen de `ebio_site_settings()` al renderizar; el mapa, de `mapImage`.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Vista de `ebio/contact-channels` (orden de claves fijo).
 *
 * `whatsapp` es `null` sin número; `map` es `null` sin `mapImage`, en `compact` o si el alt de la
 * imagen está vacío (C-B3). Un canal sin dato queda vacío (`null`, `''` o `[]`) y no se emite.
 *
 * @param array         $attributes Atributos del bloque.
 * @param WP_Block|null $block      Bloque.
 * @return array{phones:array,whatsapp:array|null,email:array|null,address:string,mapsUrl:string,hours:string,map:array|null}
 */
function ebio_contact_channels_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$settings = ebio_site_settings();

	$whatsapp_url = ebio_whatsapp_link( 'general' );

	$map   = null;
	$image = is_array( $attributes['mapImage'] ?? null ) ? $attributes['mapImage'] : array();
	$alt   = trim( (string) ( $image['alt'] ?? '' ) );
	if ( 'compact' !== ( $attributes['variant'] ?? 'default' ) && '' !== $alt ) {
		$map = ebio_dynamic_image( (int) ( $image['id'] ?? 0 ), 'full', $alt, 'lazy' );
	}

	return array(
		'phones'   => ebio_site_contact_phones(),
		'whatsapp' => '' !== $whatsapp_url ? array(
			'url'  => $whatsapp_url,
			'note' => (string) $settings['whatsappNote'],
		) : null,
		'email'    => ebio_site_contact_email(),
		'address'  => trim( (string) $settings['address'] ),
		'mapsUrl'  => esc_url_raw( (string) $settings['mapsUrl'] ),
		'hours'    => trim( (string) $settings['hours'] ),
		'map'      => $map,
	);
}
ebio_register_block_view( 'ebio/contact-channels', 'ebio_contact_channels_view' );
