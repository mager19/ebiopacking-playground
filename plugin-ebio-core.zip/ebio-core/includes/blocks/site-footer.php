<?php
/**
 * `ebio/site-footer`: vista dinámica (docs/blocks/site-footer.md). Contacto, logo (`logoId`) y
 * columnas de enlaces (`footerColumns`) se leen de `ebio_site_settings()` al renderizar.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Columnas del pie tal como las guardan los ajustes; se descartan los enlaces sin etiqueta o URL y
 * las columnas sin título ni enlaces.
 *
 * @param mixed $columns `footerColumns` de los ajustes.
 * @return array<int, array{title:string,links:array<int, array{label:string,url:string}>}>
 */
function ebio_site_footer_columns( $columns ): array {
	$out = array();
	foreach ( is_array( $columns ) ? $columns : array() as $column ) {
		if ( ! is_array( $column ) ) {
			continue;
		}
		$links = array();
		foreach ( is_array( $column['links'] ?? null ) ? $column['links'] : array() as $link ) {
			$label = is_array( $link ) ? trim( (string) ( $link['label'] ?? '' ) ) : '';
			$url   = is_array( $link ) ? trim( (string) ( $link['url'] ?? '' ) ) : '';
			if ( '' !== $label && '' !== $url ) {
				$links[] = array(
					'label' => $label,
					'url'   => $url,
				);
			}
		}
		$title = trim( (string) ( $column['title'] ?? '' ) );
		if ( '' !== $title || $links ) {
			$out[] = array(
				'title' => $title,
				'links' => $links,
			);
		}
	}
	return $out;
}

/**
 * Vista de `ebio/site-footer`: `year`, `address`, `phones`, `email`, `hours`, `logo` y `columns`, en ese orden.
 *
 * @param array         $attributes Atributos del bloque (no intervienen: contacto, logo y columnas son ajustes del sitio).
 * @param WP_Block|null $block      Bloque.
 * @return array
 */
function ebio_site_footer_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$settings = ebio_site_settings();

	return array(
		'year'    => wp_date( 'Y' ),
		'address' => trim( (string) $settings['address'] ),
		'phones'  => ebio_site_contact_phones(),
		'email'   => ebio_site_contact_email(),
		'hours'   => trim( (string) $settings['hours'] ),
		'logo'    => ebio_image_with_sizes( ebio_dynamic_image( (int) $settings['logoId'], 'full', '', 'lazy' ), '(min-width: 1024px) 160px, 120px' ),
		'columns' => ebio_site_footer_columns( $settings['footerColumns'] ),
	);
}
ebio_register_block_view( 'ebio/site-footer', 'ebio_site_footer_view' );
