<?php
/**
 * Endpoint REST que entrega al editor la vista de un bloque dinámico.
 *
 * GET /wp-json/ebio/v1/view/<bloque>?attributes={…}&postId=<id>
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registra la ruta de vistas.
 */
function ebio_register_view_route(): void {
	register_rest_route(
		'ebio/v1',
		'/view/(?P<block>[a-z0-9-]+)',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'ebio_view_endpoint_callback',
			'permission_callback' => static function () {
				return current_user_can( 'edit_posts' );
			},
			'args'                => array(
				'postId' => array(
					'type'              => 'integer',
					'default'           => 0,
					'sanitize_callback' => 'absint',
				),
			),
		)
	);
}
add_action( 'rest_api_init', 'ebio_register_view_route' );

/**
 * Ejecuta el constructor de vista del bloque pedido.
 *
 * @param WP_REST_Request $request Petición.
 * @return array|WP_Error
 */
function ebio_view_endpoint_callback( WP_REST_Request $request ) {
	$name    = 'ebio/' . $request['block'];
	$builder = ebio_block_view_builder( $name );
	if ( null === $builder ) {
		return new WP_Error( 'ebio_unknown_block', 'Bloque sin vista de servidor.', array( 'status' => 404 ) );
	}

	$attributes = $request->get_param( 'attributes' );
	if ( is_string( $attributes ) ) {
		$attributes = json_decode( $attributes, true );
	}
	if ( ! is_array( $attributes ) ) {
		$attributes = array();
	}

	$type = WP_Block_Type_Registry::get_instance()->get_registered( $name );
	if ( $type instanceof WP_Block_Type ) {
		$attributes = $type->prepare_attributes_for_render( $attributes );
	}

	$post_id = (int) $request->get_param( 'postId' );
	if ( $post_id && ! current_user_can( 'read_post', $post_id ) ) {
		return new WP_Error( 'ebio_forbidden_post', 'No puedes leer ese contenido.', array( 'status' => 403 ) );
	}
	$block   = (object) array(
		'context'    => array(
			'postId'   => $post_id,
			'postType' => $post_id ? (string) get_post_type( $post_id ) : '',
		),
		'attributes' => $attributes,
	);

	return rest_ensure_response( $builder( $attributes, $block ) );
}
