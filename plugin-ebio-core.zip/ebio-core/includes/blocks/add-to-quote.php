<?php
/**
 * `ebio/add-to-quote` (docs/blocks/add-to-quote.md): producto del contexto y enlace de WhatsApp.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Vista de `ebio/add-to-quote` (orden de claves fijo). Fuera de un producto publicado devuelve `array()`
 * y el bloque no emite nada.
 *
 * @param array                $attributes Atributos del bloque (no intervienen).
 * @param WP_Block|object|null $block      Bloque (`context.postId`).
 * @return array{productId?:int,productName?:string,quoteUrl?:string,howUrl?:string,whatsappUrl?:string}
 */
function ebio_add_to_quote_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$post = ebio_block_context_product( $block, true );
	if ( null === $post ) {
		return array();
	}
	return array(
		'productId'   => (int) $post->ID,
		'productName' => ebio_product_card_text( get_the_title( $post ) ),
		'quoteUrl'    => '/cotizar/',
		'howUrl'      => '/cotizar/#como-funciona',
		'whatsappUrl' => ebio_whatsapp_link( 'product', $post ),
	);
}
ebio_register_block_view( 'ebio/add-to-quote', 'ebio_add_to_quote_view' );

/**
 * Valores iniciales de los getters de `ebio/quote` que usa `add-to-quote` (catalog §2.12, SSR sin efecto).
 * El JS (`view.js`) los reemplaza por getters al hidratar.
 */
function ebio_add_to_quote_init_state(): void {
	ebio_quote_init_state();
	wp_interactivity_state(
		'ebio/quote',
		array(
			'isConfirmationVisible' => false,
			'isFullVisible'         => false,
			'isErrorVisible'        => false,
			'confirmationText'      => '',
		)
	);
}
