<?php
/**
 * `ebio/product-summary` (docs/blocks/product-summary.md) y el producto del contexto que comparte con
 * `ebio/add-to-quote`.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Producto de la página: `postId` del contexto del bloque o, sin él, el de la petición.
 *
 * @param WP_Block|object|null $block   Bloque.
 * @param bool                 $publish Exige que esté publicado.
 * @return WP_Post|null `null` fuera de un `ebio_product` (o no publicado si `$publish`).
 */
function ebio_block_context_product( $block, bool $publish = false ): ?WP_Post {
	$context = is_object( $block ) && isset( $block->context ) && is_array( $block->context ) ? $block->context : array();
	$post_id = (int) ( $context['postId'] ?? 0 );
	if ( $post_id <= 0 ) {
		$request = ebio_current_request();
		$object  = $request['object'] ?? null;
		$post_id = ! empty( $request['is_product'] ) && $object instanceof WP_Post ? (int) $object->ID : 0;
	}
	$post = $post_id > 0 ? get_post( $post_id ) : null;
	if ( ! $post instanceof WP_Post || 'ebio_product' !== $post->post_type ) {
		return null;
	}
	if ( $publish && 'publish' !== $post->post_status ) {
		return null;
	}
	return $post;
}

/**
 * Etiquetas de la ficha: todos los términos `ebio_format` y luego `ebio_tags`, sin duplicados ni recorte.
 *
 * @param int $post_id Producto.
 * @return array<int,array{label:string,format:string}>
 */
function ebio_product_summary_tags( int $post_id ): array {
	$tags = array();
	$seen = array();
	$add  = static function ( string $label, string $format ) use ( &$tags, &$seen ): void {
		$key = sanitize_title( $label );
		if ( '' === $label || '' === $key || isset( $seen[ $key ] ) ) {
			return;
		}
		$seen[ $key ] = true;
		$tags[]       = array(
			'label'  => $label,
			'format' => $format,
		);
	};
	foreach ( ebio_product_card_terms( $post_id, 'ebio_format' ) as $term ) {
		$add( ebio_product_card_text( $term->name ), $term->slug );
	}
	$meta = get_post_meta( $post_id, 'ebio_tags', true );
	foreach ( is_array( $meta ) ? $meta : array() as $label ) {
		if ( is_string( $label ) ) {
			$add( ebio_product_card_text( $label ), '' );
		}
	}
	return $tags;
}

/**
 * Vista de `ebio/product-summary` (orden de claves fijo). Fuera de un producto devuelve `array()` y el
 * bloque no emite nada.
 *
 * @param array                $attributes Atributos del bloque (no intervienen: los datos salen del post).
 * @param WP_Block|object|null $block      Bloque (`context.postId`).
 * @return array{title?:string,category?:array|null,tags?:array,description?:string,minOrder?:string}
 */
function ebio_product_summary_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$post = ebio_block_context_product( $block );
	if ( null === $post ) {
		return array();
	}
	$terms    = ebio_product_card_terms( $post->ID, 'ebio_product_category' );
	$category = null;
	if ( $terms ) {
		$link     = get_term_link( $terms[0] );
		$category = array(
			'name' => ebio_product_card_text( $terms[0]->name ),
			'url'  => is_string( $link ) ? esc_url_raw( $link ) : '',
		);
	}
	$min_order = get_post_meta( $post->ID, 'ebio_min_order', true );
	return array(
		'title'       => ebio_product_card_text( get_the_title( $post ) ),
		'category'    => $category,
		'tags'        => ebio_product_summary_tags( $post->ID ),
		'description' => ebio_product_card_text( (string) $post->post_excerpt ),
		'minOrder'    => is_string( $min_order ) ? trim( $min_order ) : '',
	);
}
ebio_register_block_view( 'ebio/product-summary', 'ebio_product_summary_view' );
