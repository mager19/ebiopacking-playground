<?php
/**
 * Componente compartido `ebio-product-card` (docs/blocks/product-card.md; no es un bloque).
 *
 * `ebio_product_card_view()` arma el `ProductCardView` de un producto publicado y
 * `ebio_render_product_card()` lo pinta: gemelo de `src/components/ProductCard.jsx`. Lo usan
 * `ebio/product-carousel` y `ebio/product-grid` desde sus constructores de vista y su `render.php`.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Texto plano de un título o nombre de término (sin etiquetas ni entidades).
 *
 * @param string $text Texto de WordPress.
 * @return string
 */
function ebio_product_card_text( string $text ): string {
	return trim( html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
}

/**
 * Términos de un producto ordenados por `term_id` (el mismo criterio que el permalink).
 *
 * @param int    $post_id  Producto.
 * @param string $taxonomy Taxonomía.
 * @return WP_Term[]
 */
function ebio_product_card_terms( int $post_id, string $taxonomy ): array {
	$terms = get_the_terms( $post_id, $taxonomy );
	if ( ! is_array( $terms ) ) {
		return array();
	}
	usort(
		$terms,
		static function ( $a, $b ) {
			return $a->term_id <=> $b->term_id;
		}
	);
	return $terms;
}

/**
 * Vista de la tarjeta de un producto publicado (`ProductCardView`, orden de claves fijo).
 *
 * @param int $product_id ID de un `ebio_product`.
 * @return array|null `null` si no existe, no es un producto o no está publicado.
 */
function ebio_product_card_view( int $product_id ): ?array {
	$post = $product_id > 0 ? get_post( $product_id ) : null;
	if ( ! $post instanceof WP_Post || 'ebio_product' !== $post->post_type || 'publish' !== $post->post_status ) {
		return null;
	}
	$name       = ebio_product_card_text( get_the_title( $post ) );
	$categories = ebio_product_card_terms( $post->ID, 'ebio_product_category' );
	$formats    = ebio_product_card_terms( $post->ID, 'ebio_format' );
	$sectors    = ebio_product_card_terms( $post->ID, 'ebio_sector' );

	// Línea de formato: los términos `ebio_format` del producto (el mismo dato que el filtro "Formato").
	$format_line = array();
	$seen        = array();
	foreach ( $formats as $term ) {
		$label = ebio_product_card_text( $term->name );
		if ( '' !== $label ) {
			$format_line[]                   = array(
				'label' => $label,
				'slug'  => $term->slug,
			);
			$seen[ sanitize_title( $label ) ] = true;
			$seen[ $term->slug ]              = true;
		}
	}

	// Etiqueta: `ebio_tags` que no repiten un formato (ni otro formato existente), sin duplicados; máx. 1.
	$tags      = array();
	$meta_tags = get_post_meta( $post->ID, 'ebio_tags', true );
	foreach ( is_array( $meta_tags ) ? $meta_tags : array() as $label ) {
		$label = is_string( $label ) ? ebio_product_card_text( $label ) : '';
		$key   = sanitize_title( $label );
		if ( '' === $label || '' === $key || isset( $seen[ $key ] ) || get_term_by( 'slug', $key, 'ebio_format' ) ) {
			continue;
		}
		$seen[ $key ] = true;
		$tags[]       = array(
			'label'  => $label,
			'format' => '',
		);
	}

	$thumbnail = (int) get_post_thumbnail_id( $post );
	$alt       = $thumbnail ? trim( (string) get_post_meta( $thumbnail, '_wp_attachment_image_alt', true ) ) : '';
	$slugs     = static function ( array $terms ): array {
		return array_values( wp_list_pluck( $terms, 'slug' ) );
	};

	return array(
		'id'       => $post->ID,
		'name'     => $name,
		'url'      => esc_url_raw( (string) get_permalink( $post ) ),
		'category' => $categories ? ebio_product_card_text( $categories[0]->name ) : '',
		'tags'     => array_slice( $tags, 0, 1 ),
		'formats'  => $format_line,
		'image'    => ebio_dynamic_image( $thumbnail, 'medium_large', '' !== $alt ? $alt : $name, 'lazy' ),
		'facets'   => array(
			'categories' => $slugs( $categories ),
			'sectors'    => $slugs( $sectors ),
			'formats'    => $slugs( $formats ),
		),
	);
}

/**
 * Opciones del contenedor con sus valores por defecto; gemelo de `productCardOptions()`.
 *
 * @param array $options `headingLevel` (3|4), `quoteUrl`, `showAddToQuote`.
 * @return array{headingLevel:int,quoteUrl:string,showAddToQuote:bool}
 */
function ebio_product_card_options( array $options ): array {
	return array(
		'headingLevel'   => 4 === (int) ( $options['headingLevel'] ?? 3 ) ? 4 : 3,
		'quoteUrl'       => is_string( $options['quoteUrl'] ?? null ) ? $options['quoteUrl'] : '/cotizar/',
		'showAddToQuote' => false !== ( $options['showAddToQuote'] ?? true ),
	);
}

/**
 * HTML de una tarjeta de producto; gemelo de `<ProductCard card options />`.
 *
 * Con `showAddToQuote`, publica también el estado inicial de `ebio/quote` (idempotente), del que
 * dependen las directivas del botón.
 *
 * @param array $card    `ProductCardView`.
 * @param array $options Opciones del contenedor.
 * @return string HTML.
 */
function ebio_render_product_card( array $card, array $options = array() ): string {
	$options  = ebio_product_card_options( $options );
	$id       = (int) ( $card['id'] ?? 0 );
	$name     = (string) ( $card['name'] ?? '' );
	$url      = (string) ( $card['url'] ?? '' );
	$category = (string) ( $card['category'] ?? '' );
	$tags     = array_slice( array_values( is_array( $card['tags'] ?? null ) ? $card['tags'] : array() ), 0, 1 );
	$formats  = array_values( is_array( $card['formats'] ?? null ) ? $card['formats'] : array() );
	$image    = is_array( $card['image'] ?? null ) ? $card['image'] : null;
	$heading  = 'h' . $options['headingLevel'];

	if ( $options['showAddToQuote'] ) {
		ebio_quote_init_state();
	}

	// Cada elemento en su línea: el contenido en línea va pegado a sus etiquetas (catalog §2.9).
	$lines   = array();
	$lines[] = '<article class="ebio-product-card" data-product-id="' . esc_attr( (string) $id ) . '">';
	$lines[] = '<div class="ebio-product-card__media">';
	if ( null !== $image ) {
		$lines[] = ebio_dynamic_image_html( 'ebio-product-card__image', $image );
	}
	if ( $tags ) {
		$lines[] = '<ul class="ebio-product-card__tags" aria-label="Etiquetas">';
		foreach ( $tags as $tag ) {
			$lines[] = '<li class="ebio-product-card__tag" data-format="' . esc_attr( (string) ( $tag['format'] ?? '' ) ) . '">' . esc_html( (string) ( $tag['label'] ?? '' ) ) . '</li>';
		}
		$lines[] = '</ul>';
	}
	$lines[] = '</div>';
	if ( '' !== $category ) {
		$lines[] = '<p class="ebio-product-card__category">' . esc_html( $category ) . '</p>';
	}
	$lines[] = '<' . $heading . ' class="ebio-product-card__title"><a class="ebio-product-card__link" href="' . esc_url( $url ) . '">' . esc_html( $name ) . '</a></' . $heading . '>';
	if ( $formats ) {
		$lines[] = '<ul class="ebio-product-card__formats" aria-label="Formato">';
		foreach ( $formats as $format ) {
			$lines[] = '<li class="ebio-product-card__format" data-format="' . esc_attr( (string) ( $format['slug'] ?? '' ) ) . '">' . esc_html( (string) ( $format['label'] ?? '' ) ) . '</li>';
		}
		$lines[] = '</ul>';
	}
	$lines[] = '<div class="ebio-product-card__actions">';
	if ( $options['showAddToQuote'] ) {
		$lines[] = '<form class="ebio-product-card__add-form" action="' . esc_url( $options['quoteUrl'] ) . '" method="get" data-wp-interactive="ebio/quote" '
			. wp_interactivity_data_wp_context( array( 'productId' => $id, 'inList' => false ) )
			. ' data-wp-watch="callbacks.syncCard" data-wp-on--submit="actions.addFromCard">';
		$lines[] = '<input type="hidden" name="producto" value="' . esc_attr( (string) $id ) . '">'
			. '<button type="submit" class="ebio-product-card__add ebio-button ebio-button--small" data-state="idle" aria-pressed="false" data-wp-bind--data-state="state.cardState" data-wp-bind--aria-pressed="context.inList" data-wp-bind--aria-disabled="state.cardDisabled">'
			. '<span class="ebio-icon ebio-icon--plus" aria-hidden="true"></span>'
			. '<span class="ebio-product-card__add-text">Agregar a cotización</span>'
			. '<span class="ebio-product-card__added-text" hidden data-wp-bind--hidden="!context.inList">En tu cotización</span>'
			. '<span class="ebio-visually-hidden">: ' . esc_html( $name ) . '</span>'
			. '</button>';
		$lines[] = '</form>';
	}
	$lines[] = '<a class="ebio-product-card__more" href="' . esc_url( $url ) . '">Ver ficha<span class="ebio-visually-hidden">: ' . esc_html( $name ) . '</span></a>';
	$lines[] = '</div>';
	$lines[] = '</article>';
	return implode( "\n", $lines ) . "\n";
}
