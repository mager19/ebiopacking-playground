<?php
/**
 * `ebio/cta-banner`: vista dinámica (docs/blocks/cta-banner.md). El enlace de WhatsApp sale de
 * `ebio_site_settings()`; con `whatsappMessage: product` usa el producto del contexto del bloque (o,
 * sin contexto, el de la petición si es una ficha).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Producto del contexto del bloque (`postId`, `postType`) o, sin él, el de la ficha actual.
 *
 * @param WP_Block|object|null $block Bloque en renderizado.
 * @return WP_Post|null
 */
function ebio_cta_banner_product( $block ) {
	$context = is_object( $block ) && isset( $block->context ) && is_array( $block->context ) ? $block->context : array();
	$post_id = (int) ( $context['postId'] ?? 0 );
	if ( $post_id > 0 && 'ebio_product' === ( $context['postType'] ?? '' ) ) {
		$post = get_post( $post_id );
		if ( $post instanceof WP_Post && 'ebio_product' === $post->post_type && 'publish' === $post->post_status ) {
			return $post;
		}
	}
	$request = ebio_current_request();
	return ! empty( $request['is_product'] ) && $request['object'] instanceof WP_Post ? $request['object'] : null;
}

/**
 * Vista de `ebio/cta-banner`: `whatsappUrl` (`''` sin número o con `showWhatsapp` en `false`).
 *
 * @param array         $attributes Atributos del bloque.
 * @param WP_Block|null $block      Bloque.
 * @return array{whatsappUrl:string}
 */
function ebio_cta_banner_view( array $attributes, $block ): array {
	if ( empty( $attributes['showWhatsapp'] ) ) {
		return array( 'whatsappUrl' => '' );
	}
	$kind = 'product' === ( $attributes['whatsappMessage'] ?? 'general' ) ? 'product' : 'general';
	return array( 'whatsappUrl' => ebio_whatsapp_link( $kind, 'product' === $kind ? ebio_cta_banner_product( $block ) : null ) );
}
ebio_register_block_view( 'ebio/cta-banner', 'ebio_cta_banner_view' );
