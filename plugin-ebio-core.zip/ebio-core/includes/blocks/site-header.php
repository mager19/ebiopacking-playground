<?php
/**
 * `ebio/site-header`: vista dinámica (docs/blocks/site-header.md). El logo y el menú se leen de
 * `ebio_site_settings()` al renderizar (`logoId`, `headerNavId`).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Ruta normalizada con barra final (`/productos` → `/productos/`).
 *
 * @param string $path Ruta.
 * @return string
 */
function ebio_site_header_path( string $path ): string {
	return '/' . ltrim( trailingslashit( $path ), '/' );
}

/**
 * El enlace apunta a la página de la petición: misma ruta y, si es absoluto, mismo host del sitio.
 *
 * @param string $url          URL del enlace.
 * @param string $current_path Ruta de la petición.
 * @return bool
 */
function ebio_site_header_is_current( string $url, string $current_path ): bool {
	$parts = wp_parse_url( $url );
	// Un enlace con fragmento apunta a una sección, no a la página actual.
	if ( ! is_array( $parts ) || '' === $current_path || isset( $parts['fragment'] ) || false !== strpos( $url, '#' ) ) {
		return false;
	}
	if ( isset( $parts['host'] ) && wp_parse_url( home_url(), PHP_URL_HOST ) !== $parts['host'] ) {
		return false;
	}
	return ebio_site_header_path( (string) ( $parts['path'] ?? '/' ) ) === ebio_site_header_path( $current_path );
}

/**
 * URL de un ítem del menú: un `core/navigation-link` de tipo post (`kind: post-type` con `id` de un post
 * publicado) usa su permalink actual; si no, la `url` guardada.
 *
 * @param array $attrs Atributos del bloque.
 * @return string URL segura o vacía.
 */
function ebio_site_header_link_url( array $attrs ): string {
	$id = (int) ( $attrs['id'] ?? 0 );
	if ( 'post-type' === ( $attrs['kind'] ?? '' ) && $id > 0 && 'publish' === get_post_status( $id ) ) {
		$permalink = get_permalink( $id );
		if ( is_string( $permalink ) && '' !== $permalink ) {
			return esc_url_raw( $permalink );
		}
	}
	return esc_url_raw( (string) ( $attrs['url'] ?? '' ) );
}

/**
 * Ítems del menú: bloques de primer nivel `core/navigation-link` (y la etiqueta y URL de cada
 * `core/navigation-submenu`, sin sus hijos) del `wp_navigation` publicado `$nav_id`. Solo el primer
 * ítem que coincide con la petición es `current`.
 *
 * @param int    $nav_id       ID del post `wp_navigation`.
 * @param string $current_path Ruta de la petición.
 * @return array<int, array{label:string,url:string,current:string}>
 */
function ebio_site_header_nav( int $nav_id, string $current_path ): array {
	$post = $nav_id > 0 ? get_post( $nav_id ) : null;
	if ( ! $post instanceof WP_Post || 'wp_navigation' !== $post->post_type || 'publish' !== $post->post_status ) {
		return array();
	}
	$items = array();
	$found = false;
	foreach ( parse_blocks( $post->post_content ) as $block ) {
		if ( ! in_array( $block['blockName'] ?? '', array( 'core/navigation-link', 'core/navigation-submenu' ), true ) ) {
			continue;
		}
		$label = trim( html_entity_decode( wp_strip_all_tags( (string) ( $block['attrs']['label'] ?? '' ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		$url   = ebio_site_header_link_url( is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array() );
		if ( '' === $label || '' === $url ) {
			continue;
		}
		$current = ! $found && ebio_site_header_is_current( $url, $current_path );
		$found   = $found || $current;
		$items[] = array(
			'label'   => $label,
			'url'     => $url,
			'current' => $current ? 'page' : '',
		);
	}
	return $items;
}

/**
 * Vista de `ebio/site-header`: `logo` (imagen dinámica o `null`) y `nav`, en ese orden.
 *
 * @param array         $attributes Atributos del bloque (no intervienen: logo y menú son ajustes del sitio).
 * @param WP_Block|null $block      Bloque.
 * @return array{logo:array|null,nav:array}
 */
function ebio_site_header_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$settings = ebio_site_settings();
	return array(
		'logo' => ebio_image_with_sizes( ebio_dynamic_image( (int) $settings['logoId'], 'full', '', 'eager' ), '(min-width: 1024px) 96px, 80px' ),
		'nav'  => ebio_site_header_nav( (int) $settings['headerNavId'], (string) ebio_current_request()['path'] ),
	);
}
ebio_register_block_view( 'ebio/site-header', 'ebio_site_header_view' );
