<?php
/**
 * Estado inicial del store compartido `ebio/carousel` (`ebio/product-carousel` y `ebio/testimonials`).
 *
 * `state.isFirst` y `state.isLast` son estado derivado del contexto de cada carrusel (`index`, `count`):
 * el servidor los evalúa con el mismo valor que ya está escrito en el markup (`__prev[disabled]`;
 * `__next[disabled]` solo con una tarjeta), de modo que procesar las directivas no cambia el HTML
 * (catalog §2.12, "SSR sin efecto"). En el navegador los reemplazan los getters de
 * `src/stores/carousel/store.js`, que además miden cuántas tarjetas caben.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Publica el estado inicial de `ebio/carousel`. Idempotente.
 */
function ebio_carousel_init_state(): void {
	wp_interactivity_state(
		'ebio/carousel',
		array(
			'isFirst' => static function (): bool {
				$context = wp_interactivity_get_context( 'ebio/carousel' );
				return (int) ( $context['index'] ?? 0 ) <= 0;
			},
			'isLast'  => static function (): bool {
				$context = wp_interactivity_get_context( 'ebio/carousel' );
				return (int) ( $context['index'] ?? 0 ) >= (int) ( $context['count'] ?? 0 ) - 1;
			},
		)
	);
}
