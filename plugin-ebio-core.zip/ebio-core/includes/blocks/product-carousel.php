<?php
/**
 * `ebio/product-carousel`: vista dinámica (docs/blocks/product-carousel.md).
 *
 * Las tarjetas salen del componente compartido `ebio_product_card_view()` / `ebio_render_product_card()`
 * (product-card.php); aquí solo se decide qué productos van y en qué orden.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * IDs de producto publicados, en orden de menú y título.
 *
 * @param array $tax_query Condiciones de taxonomía (vacío = todos).
 * @param int   $exclude   Producto a excluir (0 = ninguno).
 * @param int   $limit     Máximo.
 * @return int[]
 */
function ebio_product_carousel_query( array $tax_query, int $exclude, int $limit ): array {
	$args = array(
		'post_type'        => 'ebio_product',
		'post_status'      => 'publish',
		'posts_per_page'   => $limit,
		'orderby'          => array(
			'menu_order' => 'ASC',
			'title'      => 'ASC',
		),
		'fields'           => 'ids',
		'no_found_rows'    => true,
		'suppress_filters' => true,
	);
	if ( $tax_query ) {
		$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
	}
	if ( $exclude > 0 ) {
		$args['post__not_in'] = array( $exclude ); // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in
	}
	return array_map( 'intval', get_posts( $args ) );
}

/**
 * Producto de la página actual para `related`: `postId` del contexto o, sin él, la petición.
 *
 * @param WP_Block|object|null $block Bloque.
 * @return int ID (0 si no hay).
 */
function ebio_product_carousel_current_id( $block ): int {
	$context = is_object( $block ) && isset( $block->context ) && is_array( $block->context ) ? $block->context : array();
	$post_id = (int) ( $context['postId'] ?? 0 );
	if ( $post_id > 0 ) {
		return $post_id;
	}
	$request = ebio_current_request();
	return $request['is_product'] && $request['object'] instanceof WP_Post ? (int) $request['object']->ID : 0;
}

/**
 * Vista de `ebio/product-carousel` (orden de claves fijo).
 *
 * - `featured`: `productIds` en ese orden; los no publicados se omiten sin dejar hueco (C-M8). Sin
 *   `productIds`, los primeros por `menu_order` y título.
 * - `related`: misma categoría principal (la de menor `term_id`, como la tarjeta) que el producto del
 *   contexto, sin él. Con menos de 2 productos, `products` queda vacío (sección delgada).
 * - `category`: productos del slug de `category`.
 * Sin productos, `products` queda vacío y el bloque no emite nada.
 *
 * @param array                $attributes Atributos del bloque.
 * @param WP_Block|object|null $block      Bloque (`context.postId`).
 * @return array{uid:string,quoteUrl:string,products:array}
 */
function ebio_product_carousel_view( array $attributes, $block ): array {
	$source = is_string( $attributes['source'] ?? null ) ? $attributes['source'] : 'featured';
	$limit  = max( 1, min( 12, (int) ( $attributes['limit'] ?? 8 ) ) );
	$ids    = array();

	if ( 'related' === $source ) {
		$current = ebio_product_carousel_current_id( $block );
		$terms   = $current > 0 ? ebio_product_card_terms( $current, 'ebio_product_category' ) : array();
		if ( $terms ) {
			$ids = ebio_product_carousel_query(
				array(
					array(
						'taxonomy' => 'ebio_product_category',
						'field'    => 'term_id',
						'terms'    => array( $terms[0]->term_id ),
					),
				),
				$current,
				$limit
			);
		}
	} elseif ( 'category' === $source ) {
		$slug = is_string( $attributes['category'] ?? null ) ? sanitize_title( $attributes['category'] ) : '';
		if ( '' !== $slug ) {
			$ids = ebio_product_carousel_query(
				array(
					array(
						'taxonomy' => 'ebio_product_category',
						'field'    => 'slug',
						'terms'    => array( $slug ),
					),
				),
				0,
				$limit
			);
		}
	} else {
		$chosen = array_slice( array_values( array_unique( array_filter( array_map( 'intval', (array) ( $attributes['productIds'] ?? array() ) ), static fn( $id ) => $id > 0 ) ) ), 0, 12 );
		$ids    = $chosen ? $chosen : ebio_product_carousel_query( array(), 0, $limit );
	}

	$products = array();
	foreach ( $ids as $id ) {
		$card = ebio_product_card_view( (int) $id );
		if ( null !== $card ) {
			$products[] = $card;
		}
		if ( count( $products ) >= $limit ) {
			break;
		}
	}
	// "Productos relacionados" con un solo producto se ve vacío: con menos de 2 no se emite (crítica P2).
	if ( 'related' === $source && count( $products ) < 2 ) {
		$products = array();
	}

	return array(
		'uid'      => wp_unique_id( 'carousel-' ),
		'quoteUrl' => '/cotizar/',
		'products' => $products,
	);
}

ebio_register_block_view( 'ebio/product-carousel', 'ebio_product_carousel_view' );
