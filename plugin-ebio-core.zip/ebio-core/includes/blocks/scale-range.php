<?php
/**
 * `ebio/scale-range` (docs/blocks/scale-range.md): rango de planta global o escalones propios.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Escalones propios de la instancia, normalizados (máx. 4); lo que no es un escalón se descarta.
 *
 * @param mixed $steps `attributes.steps`.
 * @return array<int,array{name:string,size:string,uses:string,linkText:string,linkUrl:string,scale:int,imageId:int}>
 */
function ebio_scale_range_instance_steps( $steps ): array {
	$out = array();
	foreach ( array_slice( is_array( $steps ) ? array_values( $steps ) : array(), 0, 4 ) as $step ) {
		if ( ! is_array( $step ) ) {
			continue;
		}
		$text    = static function ( string $key ) use ( $step ): string {
			return is_string( $step[ $key ] ?? null ) ? $step[ $key ] : '';
		};
		$scale   = (int) ( $step['scale'] ?? 0 );
		$out[]   = array(
			'name'     => $text( 'name' ),
			'size'     => $text( 'size' ),
			'uses'     => $text( 'uses' ),
			'linkText' => $text( 'linkText' ),
			'linkUrl'  => $text( 'linkUrl' ),
			'scale'    => ( $scale >= 1 && $scale <= 4 ) ? $scale : count( $out ) + 1,
			'imageId'  => absint( $step['imageId'] ?? 0 ),
		);
	}
	return $out;
}

/**
 * Foto de un escalón como imagen dinámica de la vista (catalog §2.5): el alt sale de la biblioteca de
 * medios y `sizes` refleja el ancho real (4 columnas en escritorio, 2×2 en móvil). `imageId` vacío o un
 * adjunto que ya no existe → `null` (se dibuja la caja de respaldo).
 *
 * @param array<int,mixed> $steps Escalones con `imageId`.
 * @return array<int,array<string,mixed>> Escalones con `image` (imagen o `null`) en lugar de `imageId`.
 */
function ebio_scale_range_resolve_images( array $steps ): array {
	$out = array();
	foreach ( $steps as $step ) {
		$step     = is_array( $step ) ? $step : array();
		$image_id = absint( $step['imageId'] ?? 0 );
		unset( $step['imageId'] );
		$alt           = $image_id > 0 ? trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) : '';
		$step['image'] = ebio_image_with_sizes( ebio_dynamic_image( $image_id, 'large', $alt, 'lazy' ), '(min-width: 1024px) 22vw, 45vw' );
		$out[]         = $step;
	}
	return $out;
}

/**
 * Vista de `ebio/scale-range` (orden de claves fijo).
 *
 * - Con `steps` en la instancia: esos escalones y `attributes.note` (C-B1).
 * - `plant` sin `steps`: el rango y la nota de `ebio_site_settings()`; con la nota vacía, el valor inicial.
 * - `product` sin `steps`: `steps` vacío y el bloque no emite nada.
 *
 * @param array                $attributes Atributos del bloque.
 * @param WP_Block|object|null $block      Bloque (no interviene).
 * @return array{steps:array,note:string}
 */
function ebio_scale_range_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$own = ebio_scale_range_instance_steps( $attributes['steps'] ?? array() );
	if ( $own ) {
		return array(
			'steps' => ebio_scale_range_resolve_images( $own ),
			'note'  => is_string( $attributes['note'] ?? null ) ? trim( $attributes['note'] ) : '',
		);
	}
	if ( 'product' === ( $attributes['variant'] ?? 'plant' ) ) {
		return array(
			'steps' => array(),
			'note'  => '',
		);
	}
	$settings = ebio_site_settings();
	$note     = is_string( $settings['plantRangeNote'] ?? null ) ? trim( $settings['plantRangeNote'] ) : '';
	if ( '' === $note ) {
		$note = (string) ebio_site_settings_defaults()['plantRangeNote'];
	}
	return array(
		'steps' => ebio_scale_range_resolve_images( array_values( (array) $settings['plantRange'] ) ),
		'note'  => $note,
	);
}
ebio_register_block_view( 'ebio/scale-range', 'ebio_scale_range_view' );
