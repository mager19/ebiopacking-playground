<?php
/**
 * `ebio/quote-list`: vista dinámica (docs/blocks/quote-list.md) y estado del catálogo de productos publicados.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Vista de `ebio/quote-list` (orden de claves fijo): enlace al catálogo, ancla del formulario y categorías
 * de producto de primer nivel para el estado vacío.
 *
 * @param array                $attributes Atributos del bloque (no intervienen).
 * @param WP_Block|object|null $block      Bloque (no interviene).
 * @return array{catalogUrl:string,formAnchor:string,categories:array<int,array{label:string,url:string}>}
 */
function ebio_quote_list_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$categories = array();
	$terms      = get_terms(
		array(
			'taxonomy'   => 'ebio_product_category',
			'parent'     => 0,
			'hide_empty' => false,
			'orderby'    => 'term_id',
			'order'      => 'ASC',
		)
	);
	foreach ( is_array( $terms ) ? $terms : array() as $term ) {
		$link = get_term_link( $term );
		if ( is_wp_error( $link ) ) {
			continue;
		}
		$categories[] = array(
			'label' => ebio_product_card_text( $term->name ),
			'url'   => ebio_site_path( (string) wp_parse_url( $link, PHP_URL_PATH ) ),
		);
	}
	return array(
		'catalogUrl' => '/productos/',
		'formAnchor' => '#ebio-quote-form',
		'categories' => $categories,
	);
}
ebio_register_block_view( 'ebio/quote-list', 'ebio_quote_list_view' );

/**
 * Productos publicados para cruzar con la lista del navegador (`{ "<id>": { name, url, category, image } }`).
 * La miniatura no lleva `alt`: el `<img>` es decorativo (`alt=""`, C-M13). Nunca viaja un nombre desde el cliente.
 *
 * @return array<int,array{name:string,url:string,category:string,image:array|null}>
 */
function ebio_quote_list_catalog(): array {
	$ids     = get_posts(
		array(
			'post_type'      => 'ebio_product',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		)
	);
	$catalog = array();
	foreach ( $ids as $id ) {
		$id         = (int) $id;
		$categories = ebio_product_card_terms( $id, 'ebio_product_category' );
		$image      = ebio_dynamic_image( (int) get_post_thumbnail_id( $id ), 'thumbnail', '', 'lazy' );
		$catalog[ $id ] = array(
			'name'     => ebio_product_card_text( get_the_title( $id ) ),
			'url'      => esc_url_raw( (string) get_permalink( $id ) ),
			'category' => $categories ? ebio_product_card_text( $categories[0]->name ) : '',
			'image'    => $image ? array(
				'src'    => $image['src'],
				'width'  => $image['width'],
				'height' => $image['height'],
			) : null,
		);
	}
	return $catalog;
}

/**
 * Estado inicial de `ebio/quote` para la lista (catalog §2.12, SSR sin efecto): los valores que ya están en
 * el markup. El JS (`stores/quote/list.js`) los reemplaza por getters al hidratar.
 */
function ebio_quote_list_init_state(): void {
	ebio_quote_init_state();
	wp_interactivity_state(
		'ebio/quote',
		array(
			'catalog'    => ebio_quote_list_catalog(),
			'listStatus' => 'loading',
			'isLoading'  => true,
			'hasItems'   => false,
			'isEmpty'    => false,
			'countText'  => '',
			'canUndo'    => false,
			'undoText'   => '',
			'listItems'  => array(),
		)
	);
}
