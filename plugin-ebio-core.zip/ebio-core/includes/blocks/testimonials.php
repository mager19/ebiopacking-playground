<?php
/**
 * `ebio/testimonials`: vista dinámica (docs/blocks/testimonials.md).
 *
 * Solo salen las citas con `authorized: true` (D22) y las fotos con imagen y alt no vacío en la
 * biblioteca (C-B3). Sin ninguna cita autorizada, `items` queda vacío y el bloque no emite nada.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Texto de un campo del ítem, sin etiquetas y sin espacios en los extremos.
 *
 * @param mixed $value Valor guardado.
 * @return string
 */
function ebio_testimonials_text( $value ): string {
	return is_string( $value ) ? trim( wp_strip_all_tags( $value ) ) : '';
}

/**
 * Vista de `ebio/testimonials` (orden de claves fijo).
 *
 * - `default`: hasta 8 ítems, en el orden guardado.
 * - `single`: la primera cita autorizada y, si hay, la primera foto con alt.
 *
 * @param array                $attributes Atributos del bloque.
 * @param WP_Block|object|null $block      Bloque (sin uso).
 * @return array{uid:string,items:array}
 */
function ebio_testimonials_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$single = 'single' === ( $attributes['variant'] ?? 'default' );
	$items  = array();

	foreach ( array_slice( array_values( (array) ( $attributes['items'] ?? array() ) ), 0, 8 ) as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}
		if ( 'quote' === ( $item['type'] ?? '' ) ) {
			$quote = ebio_testimonials_text( $item['quote'] ?? '' );
			if ( true !== ( $item['authorized'] ?? false ) || '' === $quote ) {
				continue;
			}
			$items[] = array(
				'type'    => 'quote',
				'quote'   => $quote,
				'name'    => ebio_testimonials_text( $item['name'] ?? '' ),
				'role'    => ebio_testimonials_text( $item['role'] ?? '' ),
				'company' => ebio_testimonials_text( $item['company'] ?? '' ),
			);
		} elseif ( 'photo' === ( $item['type'] ?? '' ) ) {
			$image_id = (int) ( $item['imageId'] ?? 0 );
			$alt      = $image_id > 0 ? trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) : '';
			$image    = '' !== $alt ? ebio_dynamic_image( $image_id, 'large', $alt, 'lazy' ) : null;
			if ( null !== $image ) {
				$items[] = array(
					'type'  => 'photo',
					'image' => $image,
				);
			}
		}
	}

	$has_quote = (bool) array_filter(
		$items,
		static function ( array $item ): bool {
			return 'quote' === $item['type'];
		}
	);
	if ( ! $has_quote ) {
		$items = array();
	} elseif ( $single ) {
		$first = array();
		foreach ( $items as $item ) {
			if ( ! isset( $first[ $item['type'] ] ) ) {
				$first[ $item['type'] ] = $item;
			}
		}
		$items = array();
		foreach ( $first as $item ) {
			$items[] = $item;
		}
	}

	return array(
		'uid'   => wp_unique_id( 'testimonials-' ),
		'items' => $items,
	);
}

ebio_register_block_view( 'ebio/testimonials', 'ebio_testimonials_view' );
