<?php
/**
 * `ebio/product-grid`: vista dinámica (docs/blocks/product-grid.md).
 *
 * Las tarjetas salen del componente compartido `ebio_product_card_view()` / `ebio_render_product_card()`
 * (product-card.php). Aquí se decide qué productos van, qué filtros vienen de la URL y cuáles se ven
 * (todo el conjunto de la fuente se emite; lo que no cumple va con `hidden`, D4).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Taxonomía de cada grupo de filtro y clave de las facetas de la tarjeta.
 *
 * @return array<string,array{taxonomy:string,legend:string,facet:string}>
 */
function ebio_product_grid_groups_map(): array {
	return array(
		'categoria' => array(
			'taxonomy' => 'ebio_product_category',
			'legend'   => 'Categoría',
			'facet'    => 'categories',
		),
		'sector'    => array(
			'taxonomy' => 'ebio_sector',
			'legend'   => 'Sector',
			'facet'    => 'sectors',
		),
		'formato'   => array(
			'taxonomy' => 'ebio_format',
			'legend'   => 'Formato',
			'facet'    => 'formats',
		),
	);
}

/**
 * Términos de un grupo de filtro, en el orden de creación (el de la siembra).
 *
 * @param string $key Grupo (`categoria`, `sector`, `formato`).
 * @return WP_Term[]
 */
function ebio_product_grid_terms( string $key ): array {
	$map   = ebio_product_grid_groups_map();
	$terms = isset( $map[ $key ] ) ? get_terms(
		array(
			'taxonomy'   => $map[ $key ]['taxonomy'],
			'hide_empty' => false,
			'orderby'    => 'term_id',
			'order'      => 'ASC',
		)
	) : array();
	return is_array( $terms ) ? array_values( array_filter( $terms, static fn( $term ) => $term instanceof WP_Term ) ) : array();
}

/**
 * Selección de filtros de la consulta de la URL: acepta `a,b` y `a[]=`, aplica `sanitize_key` y una lista
 * blanca de términos existentes. Si una clave aparece como texto y como arreglo, vale lo que PHP dejó en
 * `$_GET` (la última forma). Gemelo de `parseSelection()` (src/blocks/product-grid/filter.js).
 *
 * @param array $query `$_GET` o la consulta de un enlace.
 * @return array{categoria:string[],sector:string[],formato:string[]}
 */
function ebio_product_grid_selection( array $query ): array {
	$selection = array(
		'categoria' => array(),
		'sector'    => array(),
		'formato'   => array(),
	);
	foreach ( array_keys( $selection ) as $key ) {
		$raw = $query[ $key ] ?? null;
		if ( is_string( $raw ) ) {
			$raw = array( $raw );
		}
		if ( ! is_array( $raw ) ) {
			continue;
		}
		$allowed = wp_list_pluck( ebio_product_grid_terms( $key ), 'slug' );
		$found   = array();
		foreach ( $raw as $value ) {
			if ( ! is_string( $value ) ) {
				continue;
			}
			foreach ( explode( ',', $value ) as $piece ) {
				$slug = sanitize_key( $piece );
				if ( '' !== $slug && in_array( $slug, $allowed, true ) ) {
					$found[ $slug ] = $slug;
				}
			}
		}
		$found            = array_values( $found );
		$selection[ $key ] = $found;
		sort( $selection[ $key ] );
	}
	return $selection;
}

/**
 * ¿El producto cumple la selección? O dentro de un grupo, Y entre grupos; un grupo vacío no filtra.
 * Gemelo de `matches()` (filter.js).
 *
 * @param array $facets    `categories`, `sectors`, `formats` de la tarjeta.
 * @param array $selection Selección de `ebio_product_grid_selection()`.
 * @return bool
 */
function ebio_product_grid_matches( array $facets, array $selection ): bool {
	foreach ( ebio_product_grid_groups_map() as $key => $group ) {
		$wanted = is_array( $selection[ $key ] ?? null ) ? $selection[ $key ] : array();
		if ( ! $wanted ) {
			continue;
		}
		$own = is_array( $facets[ $group['facet'] ] ?? null ) ? $facets[ $group['facet'] ] : array();
		if ( ! array_intersect( $wanted, $own ) ) {
			return false;
		}
	}
	return true;
}

/**
 * Término de la categoría o del sector de la grilla: el del atributo o, sin él, el de la consulta actual.
 *
 * @param array $attributes Atributos del bloque.
 * @param array $request    Petición de `ebio_current_request()`.
 * @return WP_Term|null
 */
function ebio_product_grid_source_term( array $attributes, array $request ): ?WP_Term {
	$source   = is_string( $attributes['source'] ?? null ) ? $attributes['source'] : 'all';
	$taxonomy = 'category' === $source ? 'ebio_product_category' : ( 'sector' === $source ? 'ebio_sector' : '' );
	if ( '' === $taxonomy ) {
		return null;
	}
	$slug = is_string( $attributes[ $source ] ?? null ) ? sanitize_title( $attributes[ $source ] ) : '';
	if ( '' !== $slug ) {
		$term = get_term_by( 'slug', $slug, $taxonomy );
		return $term instanceof WP_Term ? $term : null;
	}
	$object = $request['object'] ?? null;
	return $object instanceof WP_Term && $object->taxonomy === $taxonomy ? $object : null;
}

/**
 * Nombre en minúscula inicial ("empaques industriales").
 *
 * @param string $name Nombre del término.
 * @return string
 */
function ebio_product_grid_lcfirst( string $name ): string {
	return mb_strtolower( mb_substr( $name, 0, 1 ) ) . mb_substr( $name, 1 );
}

/**
 * "producto" o "productos" según la cantidad.
 *
 * @param int $count Cantidad.
 * @return string
 */
function ebio_product_grid_noun( int $count ): string {
	return 1 === $count ? 'producto' : 'productos';
}

/**
 * Plantilla de texto con `{term}` y `{query}` resueltos y `{count}`/`{products}` sin tocar (los recalcula el JS).
 *
 * @param string $template Texto con marcadores.
 * @param string $term     Nombre del término en minúscula inicial.
 * @param string $query    Búsqueda.
 * @return string
 */
function ebio_product_grid_partial_text( string $template, string $term, string $query ): string {
	return str_replace( array( '{term}', '{query}' ), array( $term, $query ), $template );
}

/**
 * Resuelve `{count}` y `{products}` de una plantilla parcial.
 *
 * @param string $template Plantilla de `ebio_product_grid_partial_text()`.
 * @param int    $count    Cantidad visible.
 * @return string
 */
function ebio_product_grid_count_text( string $template, int $count ): string {
	return str_replace( array( '{count}', '{products}' ), array( (string) $count, ebio_product_grid_noun( $count ) ), $template );
}

/**
 * Búsqueda y nombre de término de la petición actual, para los textos de la grilla.
 *
 * @param array $attributes Atributos del bloque.
 * @return array{term:string,query:string}
 */
function ebio_product_grid_text_parts( array $attributes ): array {
	$request = ebio_current_request();
	$term    = ebio_product_grid_source_term( $attributes, $request );
	$query   = '';
	if ( 'search' === ( $attributes['source'] ?? '' ) && is_string( $request['query']['s'] ?? null ) ) {
		$query = trim( sanitize_text_field( $request['query']['s'] ) );
	}
	return array(
		'term'  => $term ? ebio_product_grid_lcfirst( ebio_product_card_text( $term->name ) ) : '',
		'query' => $query,
	);
}

/**
 * IDs de los productos de la fuente, en orden de menú y título (máx. `perPage`).
 *
 * @param array $attributes Atributos del bloque.
 * @param array $request    Petición.
 * @param string $query     Búsqueda (`source: search`).
 * @return int[]
 */
function ebio_product_grid_ids( array $attributes, array $request, string $query ): array {
	$source = is_string( $attributes['source'] ?? null ) ? $attributes['source'] : 'all';
	$limit  = max( 1, min( 100, (int) ( $attributes['perPage'] ?? 60 ) ) );
	$args   = array(
		'post_type'        => 'ebio_product',
		'post_status'      => 'publish',
		'posts_per_page'   => $limit,
		'orderby'          => array(
			'menu_order' => 'ASC',
			'title'      => 'ASC',
		),
		'fields'           => 'ids',
		'no_found_rows'    => true,
		'suppress_filters' => true,
	);
	if ( 'category' === $source || 'sector' === $source ) {
		$term = ebio_product_grid_source_term( $attributes, $request );
		if ( ! $term ) {
			return array();
		}
		$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			array(
				'taxonomy' => $term->taxonomy,
				'field'    => 'term_id',
				'terms'    => array( $term->term_id ),
			),
		);
	} elseif ( 'search' === $source ) {
		if ( '' === $query ) {
			return array();
		}
		$args['s'] = $query;
	}
	return array_map( 'intval', get_posts( $args ) );
}

/**
 * Vista de `ebio/product-grid` (orden de claves fijo).
 *
 * - `status`: `results`, `empty` (filtros sin coincidencias o búsqueda sin nada en el sitio, D23) o `hidden`
 *   (búsqueda sin productos pero con páginas: el bloque no emite nada).
 * - `groups` según `variant`; `checked` desde la URL. `visible`: IDs que cumplen los filtros.
 *
 * @param array                 $attributes Atributos del bloque.
 * @param WP_Block|object|null  $block      Bloque.
 * @return array{uid:string,status:string,headingText:string,countText:string,emptyTitle:string,formAction:string,quoteUrl:string,groups:array,products:array,visible:int[]}
 */
function ebio_product_grid_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$request = ebio_current_request();
	$variant = is_string( $attributes['variant'] ?? null ) ? $attributes['variant'] : 'full-filters';
	$source  = is_string( $attributes['source'] ?? null ) ? $attributes['source'] : 'all';
	$parts   = ebio_product_grid_text_parts( $attributes );

	$keys = 'full-filters' === $variant ? array( 'categoria', 'sector', 'formato' ) : ( 'sector-format' === $variant ? array( 'sector', 'formato' ) : array() );
	$all  = ebio_product_grid_selection( is_array( $request['query'] ?? null ) ? $request['query'] : array() );
	$map  = ebio_product_grid_groups_map();

	$selection = array(
		'categoria' => array(),
		'sector'    => array(),
		'formato'   => array(),
	);
	$groups    = array();
	foreach ( $keys as $key ) {
		$selection[ $key ] = $all[ $key ];
		$options           = array();
		foreach ( ebio_product_grid_terms( $key ) as $term ) {
			$options[] = array(
				'value'   => $term->slug,
				'label'   => ebio_product_card_text( $term->name ),
				'checked' => in_array( $term->slug, $selection[ $key ], true ),
			);
		}
		$groups[] = array(
			'key'     => $key,
			'legend'  => $map[ $key ]['legend'],
			'options' => $options,
		);
	}

	$products = array();
	foreach ( ebio_product_grid_ids( $attributes, $request, $parts['query'] ) as $id ) {
		$card = ebio_product_card_view( $id );
		if ( null !== $card ) {
			$products[] = $card;
		}
	}
	$visible = array();
	foreach ( $products as $card ) {
		if ( ebio_product_grid_matches( $card['facets'], $selection ) ) {
			$visible[] = $card['id'];
		}
	}

	$status = $visible ? 'results' : 'empty';
	if ( 'search' === $source && ! $products && '' !== $parts['query'] ) {
		$pages = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => 'publish',
				's'                => $parts['query'],
				'posts_per_page'   => 1,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => true,
			)
		);
		if ( $pages ) {
			$status = 'hidden';
		}
	}

	$count    = count( $visible );
	$template = is_string( $attributes['heading'] ?? null ) ? $attributes['heading'] : '{count} {products}';
	$empty    = is_string( $attributes['emptyTitle'] ?? null ) ? $attributes['emptyTitle'] : '';
	$path     = ebio_site_path( (string) ( $request['path'] ?? '' ) );

	return array(
		'uid'         => wp_unique_id( 'grid-' ),
		'status'      => $status,
		'headingText' => ebio_product_grid_count_text( ebio_product_grid_partial_text( $template, $parts['term'], $parts['query'] ), $count ),
		'countText'   => ebio_product_grid_count_text( '{count} {products}', $count ),
		'emptyTitle'  => ebio_product_grid_partial_text( $empty, $parts['term'], $parts['query'] ),
		'formAction'  => wp_make_link_relative( home_url( $path ) ),
		'quoteUrl'    => '/cotizar/',
		'groups'      => $groups,
		'products'    => $products,
		'visible'     => $visible,
	);
}

/**
 * Estado inicial de `ebio/product-grid` a partir de la vista (solo valores planos: lo que se pinta en el
 * servidor es lo que el JS recalcula, D8).
 *
 * @param array $attributes Atributos del bloque.
 * @param array $view       Vista.
 */
function ebio_product_grid_init_state( array $attributes, array $view ): void {
	$parts    = ebio_product_grid_text_parts( $attributes );
	$template = is_string( $attributes['heading'] ?? null ) ? $attributes['heading'] : '{count} {products}';
	$count    = count( is_array( $view['visible'] ?? null ) ? $view['visible'] : array() );
	wp_interactivity_state(
		'ebio/product-grid',
		array(
			'headingTemplate' => ebio_product_grid_partial_text( $template, $parts['term'], $parts['query'] ),
			'headingText'     => (string) ( $view['headingText'] ?? '' ),
			'countText'       => (string) ( $view['countText'] ?? '' ),
			'emptyTitle'      => (string) ( $view['emptyTitle'] ?? '' ),
			'liveText'        => '',
			'isEmpty'         => 'empty' === ( $view['status'] ?? '' ),
			'resultCount'     => $count,
			'isFew'           => $count > 0 && $count <= 3,
		)
	);
}

ebio_register_block_view( 'ebio/product-grid', 'ebio_product_grid_view' );
