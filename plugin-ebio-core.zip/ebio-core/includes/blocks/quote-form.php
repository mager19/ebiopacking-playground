<?php
/**
 * `ebio/quote-form`: vista dinámica (docs/blocks/quote-form.md): nonce, repoblado de errores sin JS y
 * precarga de `?producto=`.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Campos del formulario, en el orden del formulario y del resumen de errores (`items` no tiene campo).
 *
 * @return string[]
 */
function ebio_quote_form_fields(): array {
	return array( 'company', 'name', 'email', 'phone', 'city', 'sector', 'message', 'consent', 'items' );
}

/**
 * Valor escalar de la petición como texto (los arreglos y demás se ignoran).
 *
 * @param mixed  $query Consulta de la petición.
 * @param string $key   Clave.
 */
function ebio_quote_form_query_text( $query, string $key ): string {
	$value = is_array( $query ) ? ( $query[ $key ] ?? '' ) : '';
	return is_string( $value ) ? $value : '';
}

/**
 * Texto de precarga de la solicitud (FU9): "Quiero cotizar: <nombre> · Cantidad: <c> · Medidas: <m>".
 * Solo con un `ebio_product` publicado; las partes vacías se omiten.
 *
 * @param mixed $query Consulta de la petición.
 */
function ebio_quote_form_prefill( $query ): string {
	$raw = ebio_quote_form_query_text( $query, 'producto' );
	if ( '' === $raw || ! ctype_digit( $raw ) || strlen( $raw ) > 9 ) {
		return '';
	}
	$post = get_post( (int) $raw );
	if ( ! $post instanceof WP_Post || 'ebio_product' !== $post->post_type || 'publish' !== $post->post_status ) {
		return '';
	}
	$name = ebio_product_card_text( get_the_title( $post ) );
	if ( '' === $name ) {
		return '';
	}
	$parts    = array( 'Quiero cotizar: ' . $name );
	$quantity = mb_substr( (string) sanitize_text_field( ebio_quote_form_query_text( $query, 'cantidad' ) ), 0, 40 );
	$sizes    = mb_substr( (string) sanitize_text_field( ebio_quote_form_query_text( $query, 'medidas' ) ), 0, 120 );
	if ( '' !== $quantity ) {
		$parts[] = 'Cantidad: ' . $quantity;
	}
	if ( '' !== $sizes ) {
		$parts[] = 'Medidas: ' . $sizes;
	}
	return implode( ' · ', $parts );
}

/**
 * Vista de `ebio/quote-form` (orden de claves fijo). Sin JS, un envío rechazado vuelve a `/cotizar/` con
 * `?ebio_error=…`: la lista blanca de códigos decide el texto; `ebio_invalid` + `ebio_ref` repuebla el
 * formulario desde el transient `ebio_quote_form_<ref>`, que se **borra al leerlo** (FU8).
 *
 * @param array                $attributes Atributos del bloque (no intervienen).
 * @param WP_Block|object|null $block      Bloque (no interviene).
 * @return array{nonce:string,actionUrl:string,values:array,errors:array,errorCount:int,summaryTitle:string,formError:string}
 */
function ebio_quote_form_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$request = ebio_current_request();
	$query   = is_array( $request['query'] ?? null ) ? $request['query'] : array();

	$values = array(
		'company' => '',
		'name'    => '',
		'email'   => '',
		'phone'   => '',
		'city'    => '',
		'sector'  => '',
		'message' => '',
	);
	$errors = array_fill_keys( ebio_quote_form_fields(), '' );
	$form_error = '';

	$allowed = array( 'ebio_invalid', 'ebio_bad_nonce', 'ebio_rate_limited', 'ebio_spam', 'ebio_save_failed' );
	$code    = ebio_quote_form_query_text( $query, 'ebio_error' );

	if ( in_array( $code, $allowed, true ) ) {
		$form_error = ebio_quote_error_message( $code, 'nojs' );
		if ( 'ebio_invalid' === $code ) {
			$ref  = ebio_quote_form_query_text( $query, 'ebio_ref' );
			$kept = preg_match( '/^[A-Za-z0-9]{16}$/', $ref ) ? get_transient( 'ebio_quote_form_' . $ref ) : false;
			if ( is_array( $kept ) ) {
				delete_transient( 'ebio_quote_form_' . $ref );
				foreach ( array_keys( $values ) as $field ) {
					$values[ $field ] = is_string( $kept[ $field ] ?? null ) ? $kept[ $field ] : '';
				}
				foreach ( is_array( $kept['fields'] ?? null ) ? $kept['fields'] : array() as $field => $message ) {
					if ( array_key_exists( $field, $errors ) && is_string( $message ) ) {
						$errors[ $field ] = $message;
					}
				}
				$form_error = '';
			}
		}
	} else {
		$values['message'] = ebio_quote_form_prefill( $query );
	}

	$count = count( array_filter( $errors, 'strlen' ) );
	return array(
		'nonce'        => ebio_quote_create_nonce(),
		'actionUrl'    => admin_url( 'admin-post.php?action=ebio_quote' ),
		'values'       => $values,
		'errors'       => $errors,
		'errorCount'   => $count,
		'summaryTitle' => $count > 0 ? 'Revisa ' . $count . ( 1 === $count ? ' campo' : ' campos' ) . ' para enviar tu solicitud:' : '',
		'formError'    => $form_error,
	);
}
ebio_register_block_view( 'ebio/quote-form', 'ebio_quote_form_view' );

/**
 * `data-state` de la raíz según la vista: `error` (error de formulario), `invalid` (campos) o `idle`.
 *
 * @param array $view Vista.
 */
function ebio_quote_form_status( array $view ): string {
	if ( ! empty( $view['formError'] ) ) {
		return 'error';
	}
	return (int) ( $view['errorCount'] ?? 0 ) > 0 ? 'invalid' : 'idle';
}

/**
 * Estado inicial de `ebio/quote` para el formulario (catalog §2.12): lo mismo que ya está en el markup, para
 * que procesar las directivas en el servidor no cambie nada. El JS lo actualiza al enviar.
 *
 * @param array $view Vista.
 */
function ebio_quote_form_init_state( array $view ): void {
	ebio_quote_init_state();
	$errors  = array_fill_keys( ebio_quote_form_fields(), '' );
	$invalid = array_fill_keys( ebio_quote_form_fields(), false );
	foreach ( is_array( $view['errors'] ?? null ) ? $view['errors'] : array() as $field => $message ) {
		if ( array_key_exists( $field, $errors ) && is_string( $message ) ) {
			$errors[ $field ]  = $message;
			$invalid[ $field ] = '' !== $message;
		}
	}
	$values = array();
	foreach ( array( 'company', 'name', 'email', 'phone', 'city', 'sector', 'message' ) as $field ) {
		$values[ $field ] = is_string( $view['values'][ $field ] ?? null ) ? $view['values'][ $field ] : '';
	}
	$count = (int) ( $view['errorCount'] ?? 0 );
	wp_interactivity_state(
		'ebio/quote',
		array(
			'form'            => array(
				'status'       => ebio_quote_form_status( $view ),
				'isSubmitting' => false,
				'hasErrors'    => $count > 0,
				'errorCount'   => $count,
				'summaryTitle' => (string) ( $view['summaryTitle'] ?? '' ),
				'values'       => $values,
				'errors'       => $errors,
				'invalid'      => $invalid,
				'formError'    => (string) ( $view['formError'] ?? '' ),
			),
			'hasItems'        => false,
			'submitCountText' => '',
		)
	);
}
