<?php
/**
 * `ebio/category-nav`: vista dinámica (docs/blocks/category-nav.md). Marca el ítem actual (`page`) o
 * ancestro (`true`) según la petición, incluidos los filtros del catálogo (`?formato=`).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Rutas de los ancestros de la página actual: la categoría de la Ficha o los padres de una página
 * (p. ej. `/sectores/` en una página de sector).
 *
 * @param array $request Petición de `ebio_current_request()`.
 * @return string[] Rutas normalizadas (`/productos/empaques-agro-flores/`).
 */
function ebio_category_nav_ancestor_paths( array $request ): array {
	$object = $request['object'] ?? null;
	$urls   = array();
	if ( ! empty( $request['is_product'] ) && $object instanceof WP_Post ) {
		$terms = get_the_terms( $object, 'ebio_product_category' );
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$urls[] = get_term_link( $term );
		}
	} elseif ( $object instanceof WP_Post && 'page' === $object->post_type ) {
		foreach ( get_post_ancestors( $object ) as $ancestor_id ) {
			$urls[] = get_permalink( $ancestor_id );
		}
	}
	$paths = array();
	foreach ( $urls as $url ) {
		if ( is_string( $url ) && '' !== $url ) {
			$paths[] = ebio_site_path( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		}
	}
	return $paths;
}

/**
 * Vista de `ebio/category-nav`: `items` con `label`, `url` (relativas resueltas con `home_url()`), `icon` y `current`.
 *
 * `current` es `page` si la ruta y los filtros del catálogo del ítem coinciden con la petición (solo el
 * primero), `true` si el ítem es ancestro de la página y `''` en otro caso.
 *
 * @param array         $attributes Atributos del bloque (`items`).
 * @param WP_Block|null $block      Bloque.
 * @return array{items:array<int,array{label:string,url:string,icon:string,current:string}>}
 */
function ebio_category_nav_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$request   = ebio_current_request();
	$path      = ebio_site_path( (string) ( $request['path'] ?? '' ) );
	$filters   = ebio_request_catalog_filters( $request['query'] ?? array() );
	$ancestors = ebio_category_nav_ancestor_paths( $request );
	$home_host = wp_parse_url( home_url(), PHP_URL_HOST );

	$items = array();
	$found = false;
	foreach ( is_array( $attributes['items'] ?? null ) ? array_slice( $attributes['items'], 0, 8 ) : array() as $item ) {
		if ( ! is_array( $item ) || ! is_string( $item['label'] ?? null ) || ! is_string( $item['url'] ?? null ) ) {
			continue;
		}
		$label = trim( $item['label'] );
		$url   = trim( $item['url'] );
		if ( '' === $label || '' === $url ) {
			continue;
		}
		$is_absolute = (bool) preg_match( '#^https?://#i', $url );
		$resolved    = $is_absolute ? esc_url_raw( $url ) : home_url( $url );
		$parts       = wp_parse_url( $resolved );
		$same_site   = is_array( $parts ) && ( ! isset( $parts['host'] ) || $parts['host'] === $home_host );
		$query       = array();
		parse_str( is_array( $parts ) ? (string) ( $parts['query'] ?? '' ) : '', $query );
		$item_path    = ebio_site_path( is_array( $parts ) ? (string) ( $parts['path'] ?? '/' ) : '/' );
		$item_filters = ebio_request_catalog_filters( $query );

		$current = '';
		if ( $same_site && ! $found && $item_path === $path && $item_filters === $filters ) {
			$current = 'page';
			$found   = true;
		} elseif ( $same_site && array() === $item_filters && in_array( $item_path, $ancestors, true ) ) {
			$current = 'true';
		}
		$items[] = array(
			'label'   => $label,
			'url'     => $resolved,
			'icon'    => is_string( $item['icon'] ?? null ) ? sanitize_key( $item['icon'] ) : '',
			'current' => $current,
		);
	}
	return array( 'items' => $items );
}
ebio_register_block_view( 'ebio/category-nav', 'ebio_category_nav_view' );
