<?php
/**
 * `ebio/faq`: recolector de preguntas para el `FAQPage` de la página (catalog D12).
 *
 * El bloque es estático; cada vez que WordPress renderiza un `ebio/faq`, el filtro
 * `render_block_ebio/faq` anota sus `items` aquí. La Tarea 10 (SEO) lee el conjunto con
 * `ebio_faq_collected()` y arma el único nodo `FAQPage` del grafo de Yoast (reglas de exclusión
 * incluidas: respuestas con `[PENDIENTE CLIENTE: …]`).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Almacén de las preguntas recogidas durante la petición.
 *
 * @param array<int, array{question:string, answer:string}>|null $replace Si no es null, reemplaza el almacén.
 * @return array<int, array{question:string, answer:string}> Preguntas recogidas, en orden de render.
 */
function ebio_faq_store( ?array $replace = null ): array {
	static $store = array();
	if ( null !== $replace ) {
		$store = $replace;
	}
	return $store;
}

/**
 * Añade las preguntas de un bloque `ebio/faq`. Se omiten ítems sin pregunta o sin respuesta y
 * cualquier entrada que no sea una lista de textos; el orden se conserva y no se deduplica.
 *
 * @param array $items Ítems `{ question, answer }` del atributo `items`.
 */
function ebio_faq_collect( array $items ): void {
	$collected = ebio_faq_store();
	foreach ( $items as $item ) {
		if ( ! is_array( $item ) || ! is_string( $item['question'] ?? null ) || ! is_string( $item['answer'] ?? null ) ) {
			continue;
		}
		$question = trim( $item['question'] );
		$answer   = trim( $item['answer'] );
		if ( '' === $question || '' === $answer ) {
			continue;
		}
		$collected[] = array(
			'question' => $question,
			'answer'   => $answer,
		);
	}
	ebio_faq_store( $collected );
}

/**
 * Preguntas recogidas hasta ahora en esta petición (respuestas con su HTML en línea).
 *
 * @return array<int, array{question:string, answer:string}>
 */
function ebio_faq_collected(): array {
	return ebio_faq_store();
}

/**
 * Vacía el recolector (pruebas y renders aislados).
 */
function ebio_faq_reset(): void {
	ebio_faq_store( array() );
}

/**
 * Filtro `render_block_ebio/faq`: anota los ítems y devuelve el HTML sin cambios.
 *
 * @param string $block_content HTML del bloque.
 * @param array  $parsed_block  Bloque analizado (`attrs.items`).
 * @return string HTML sin cambios.
 */
function ebio_faq_render_block( $block_content, $parsed_block = array() ) {
	$items = $parsed_block['attrs']['items'] ?? array();
	if ( is_array( $items ) ) {
		ebio_faq_collect( $items );
	}
	return $block_content;
}
add_filter( 'render_block_ebio/faq', 'ebio_faq_render_block', 10, 2 );
