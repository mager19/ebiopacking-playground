<?php
/**
 * `ebio/breadcrumbs`: ruta de la página actual (docs/blocks/breadcrumbs.md). `ebio_breadcrumb_trail()` también
 * alimenta el `BreadcrumbList` de Yoast (includes/seo/yoast.php).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Texto plano de un título (sin etiquetas ni entidades).
 *
 * @param string $title Título.
 * @return string
 */
function ebio_breadcrumb_text( string $title ): string {
	return trim( html_entity_decode( wp_strip_all_tags( $title ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
}

/**
 * Ruta de migas de la petición actual: `items` (ancestros con enlace, empezando por "Inicio") y `current`.
 *
 * Catálogo → Productos; Categoría → Productos / {categoría}; Ficha → Productos / {categoría principal} /
 * {producto}; Cotizar → "Cotizar" (M3); página → sus padres / {título de la página} (el título es el
 * título corto de la miga, C-M1; filtrable con `ebio_breadcrumb_label`). Sin ruta (Inicio, 404…) `current` es `''`.
 *
 * @return array{items:array<int,array{label:string,url:string}>,current:string}
 */
function ebio_breadcrumb_trail(): array {
	$request = ebio_current_request();
	$object  = $request['object'] ?? null;
	$path    = ebio_site_path( (string) ( $request['path'] ?? '' ) );
	$items   = array(
		array(
			'label' => 'Inicio',
			'url'   => home_url( '/' ),
		),
	);
	$current = '';
	$catalog = array(
		'label' => 'Productos',
		'url'   => home_url( '/productos/' ),
	);

	if ( ! empty( $request['is_product'] ) && $object instanceof WP_Post ) {
		$items[] = $catalog;
		$terms   = get_the_terms( $object, 'ebio_product_category' );
		$term    = is_array( $terms ) && $terms ? reset( $terms ) : null;
		$link    = $term instanceof WP_Term ? get_term_link( $term ) : null;
		if ( $term instanceof WP_Term && is_string( $link ) ) {
			$items[] = array(
				'label' => ebio_breadcrumb_text( $term->name ),
				'url'   => $link,
			);
		}
		$current = ebio_breadcrumb_text( get_the_title( $object ) );
	} elseif ( $object instanceof WP_Term && 'ebio_product_category' === $object->taxonomy ) {
		$items[] = $catalog;
		$current = ebio_breadcrumb_text( $object->name );
	} elseif ( '/productos/' === $path ) {
		$current = $catalog['label'];
	} elseif ( '/cotizar/' === $path ) {
		$current = 'Cotizar';
	} elseif ( $object instanceof WP_Post && 'page' === $object->post_type && (int) get_option( 'page_on_front' ) !== $object->ID ) {
		foreach ( array_reverse( get_post_ancestors( $object ) ) as $ancestor_id ) {
			$items[] = array(
				'label' => ebio_breadcrumb_text( (string) apply_filters( 'ebio_breadcrumb_label', get_the_title( $ancestor_id ), get_post( $ancestor_id ) ) ),
				'url'   => (string) get_permalink( $ancestor_id ),
			);
		}
		$current = ebio_breadcrumb_text( (string) apply_filters( 'ebio_breadcrumb_label', get_the_title( $object ), $object ) );
	}

	return array(
		'items'   => $items,
		'current' => $current,
	);
}

/**
 * Vista de `ebio/breadcrumbs`: `items` y `current` de `ebio_breadcrumb_trail()`; la etiqueta del primer
 * ítem es `homeLabel`.
 *
 * @param array         $attributes Atributos del bloque (`homeLabel`).
 * @param WP_Block|null $block      Bloque.
 * @return array{items:array<int,array{label:string,url:string}>,current:string}
 */
function ebio_breadcrumbs_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$trail = ebio_breadcrumb_trail();
	$home  = is_string( $attributes['homeLabel'] ?? null ) ? trim( $attributes['homeLabel'] ) : '';
	if ( '' !== $home && isset( $trail['items'][0] ) ) {
		$trail['items'][0]['label'] = $home;
	}
	return $trail;
}
ebio_register_block_view( 'ebio/breadcrumbs', 'ebio_breadcrumbs_view' );
