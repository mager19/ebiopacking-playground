<?php
/**
 * `ebio/whatsapp-float` (docs/blocks/whatsapp-float.md) y el enlace de WhatsApp compartido por
 * `ebio/cta-banner` y `ebio/contact-channels`. El número y los mensajes salen de
 * `ebio_site_settings()` y `ebio_whatsapp_message()`; la página, de `ebio_current_request()`.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enlace de WhatsApp para un mensaje `general` o `product` (catalog §2.14).
 *
 * El mensaje `product` usa el producto dado; sin producto publicado o sin tipo `ebio_product` cae
 * en el mensaje `general`. Cadena vacía si no hay número configurado.
 *
 * @param string          $kind    `general` o `product`.
 * @param WP_Post|null    $product Producto de la ficha.
 * @return string URL `wa.me` o `''`.
 */
function ebio_whatsapp_link( string $kind, $product = null ): string {
	if ( 'product' === $kind && $product instanceof WP_Post && 'ebio_product' === $product->post_type ) {
		$permalink = get_permalink( $product );
		return ebio_whatsapp_url(
			ebio_whatsapp_message(
				'product',
				array(
					'producto' => ebio_product_card_text( get_the_title( $product ) ),
					'url'      => is_string( $permalink ) ? $permalink : '',
				)
			)
		);
	}
	return ebio_whatsapp_url( ebio_whatsapp_message( 'general' ) );
}

/**
 * Vista de `ebio/whatsapp-float`: `url` (`''` sin número) y `raised` (ficha de producto), en ese orden.
 *
 * @param array         $attributes Atributos del bloque (no intervienen: el botón no tiene datos propios).
 * @param WP_Block|null $block      Bloque.
 * @return array{url:string,raised:bool}
 */
function ebio_whatsapp_float_view( array $attributes, $block ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
	$request = ebio_current_request();
	$object  = $request['object'] ?? null;
	$product = $object instanceof WP_Post && 'ebio_product' === $object->post_type && ! empty( $request['is_product'] ) ? $object : null;
	return array(
		'url'    => ebio_whatsapp_link( null !== $product ? 'product' : 'general', $product ),
		'raised' => ! empty( $request['is_product'] ),
	);
}
ebio_register_block_view( 'ebio/whatsapp-float', 'ebio_whatsapp_float_view' );
