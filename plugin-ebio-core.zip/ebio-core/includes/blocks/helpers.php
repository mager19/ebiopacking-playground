<?php
/**
 * Helpers compartidos por los bloques dinámicos (constructores de vista, atributos de la raíz, petición actual).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Devuelve la vista de un bloque: la del contexto `ebio/view` (fixtures, paridad) o la que arma `$build`.
 *
 * @param WP_Block|object|null $block Bloque en renderizado.
 * @param callable             $build Constructor de la vista real.
 * @return array
 */
function ebio_block_view( $block, callable $build ): array {
	if ( is_object( $block ) && isset( $block->context ) && is_array( $block->context ) && isset( $block->context['ebio/view'] ) && is_array( $block->context['ebio/view'] ) ) {
		return $block->context['ebio/view'];
	}
	return $build();
}

/**
 * Atributos HTML de la raíz de un bloque: clase BEM, modificadores y ancla.
 *
 * @param string $base       Clase base (p. ej. `ebio-faq`).
 * @param array  $modifiers  Modificadores; se omiten los vacíos y `false`.
 * @param array  $attributes Atributos del bloque (usa `anchor`).
 * @return string `class="…"` y, si hay ancla, ` id="…"`.
 */
function ebio_root_attributes( string $base, array $modifiers, array $attributes ): string {
	$classes = array( $base );
	foreach ( $modifiers as $modifier ) {
		if ( is_string( $modifier ) && '' !== $modifier ) {
			$classes[] = $base . '--' . $modifier;
		}
	}
	$html = 'class="' . esc_attr( implode( ' ', $classes ) ) . '"';
	if ( ! empty( $attributes['anchor'] ) && is_string( $attributes['anchor'] ) ) {
		$html .= ' id="' . esc_attr( $attributes['anchor'] ) . '"';
	}
	return $html;
}

/**
 * Registro de constructores de vista por nombre de bloque.
 *
 * @param string        $name    Nombre del bloque (p. ej. `ebio/faq`).
 * @param callable|null $builder Constructor; `null` solo consulta.
 * @param bool          $remove  Retira `$name` del registro.
 * @return array<string,callable>
 */
function ebio_block_view_registry( string $name = '', ?callable $builder = null, bool $remove = false ): array {
	static $registry = array();
	if ( $remove ) {
		unset( $registry[ $name ] );
	}
	if ( '' !== $name && null !== $builder ) {
		$registry[ $name ] = $builder;
	}
	return $registry;
}

/**
 * Registra el constructor de vista de un bloque (lo usa el endpoint REST del editor).
 *
 * @param string   $name    Nombre del bloque (p. ej. `ebio/faq`).
 * @param callable $builder `fn( array $attributes, $block ): array`.
 */
function ebio_register_block_view( string $name, callable $builder ): void {
	ebio_block_view_registry( $name, $builder );
}

/**
 * Retira el constructor de vista de un bloque (pruebas).
 *
 * @param string $name Nombre del bloque.
 */
function ebio_unregister_block_view( string $name ): void {
	ebio_block_view_registry( $name, null, true );
}

/**
 * Constructor de vista registrado para un bloque.
 *
 * @param string $name Nombre del bloque.
 * @return callable|null
 */
function ebio_block_view_builder( string $name ): ?callable {
	$registry = ebio_block_view_registry();
	return $registry[ $name ] ?? null;
}

/**
 * Petición actual vista por los constructores de vista (única vía de lectura; filtrable en pruebas).
 *
 * @return array{path:string,query:array,object:WP_Post|WP_Term|null,is_product:bool}
 */
function ebio_current_request(): array {
	$uri    = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( (string) $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$path   = (string) wp_parse_url( $uri, PHP_URL_PATH );
	$object = function_exists( 'get_queried_object' ) ? get_queried_object() : null;
	if ( ! ( $object instanceof WP_Post ) && ! ( $object instanceof WP_Term ) ) {
		$object = null;
	}
	$request = array(
		'path'       => $path,
		'query'      => wp_unslash( $_GET ), // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput
		'object'     => $object,
		'is_product' => function_exists( 'is_singular' ) && is_singular( 'ebio_product' ),
	);
	/**
	 * Permite sustituir la petición actual (las pruebas lo usan).
	 *
	 * @param array $request Petición normalizada.
	 */
	return apply_filters( 'ebio_current_request', $request );
}

/**
 * Imagen dinámica de la vista (catalog §2.5) a partir de un adjunto.
 *
 * @param int    $attachment_id Adjunto.
 * @param string $size          Tamaño registrado (`full`, `medium_large`…).
 * @param string $alt           Texto alternativo ya resuelto.
 * @param string $loading       `lazy` o `eager`.
 * @return array{src:string,srcset:string,sizes:string,width:int,height:int,alt:string,loading:string}|null
 *         `null` si el adjunto no existe o no es una imagen.
 */
function ebio_dynamic_image( int $attachment_id, string $size, string $alt, string $loading ): ?array {
	if ( $attachment_id <= 0 || ! wp_attachment_is_image( $attachment_id ) ) {
		return null;
	}
	$src = wp_get_attachment_image_src( $attachment_id, $size );
	if ( ! is_array( $src ) || empty( $src[0] ) ) {
		return null;
	}
	return array(
		'src'     => esc_url_raw( $src[0] ),
		'srcset'  => (string) wp_get_attachment_image_srcset( $attachment_id, $size ),
		'sizes'   => (string) wp_get_attachment_image_sizes( $attachment_id, $size ),
		'width'   => (int) $src[1],
		'height'  => (int) $src[2],
		'alt'     => $alt,
		'loading' => $loading,
	);
}

/**
 * `<img>` de una imagen dinámica de la vista; gemelo de `DynamicImage.jsx`. `srcset` y `sizes`
 * vacíos se omiten; siempre `decoding="async"`.
 *
 * @param string     $class_name Clase BEM del elemento.
 * @param array|null $image      Imagen de la vista o `null` (no emite nada).
 * @return string HTML.
 */
function ebio_dynamic_image_html( string $class_name, ?array $image ): string {
	if ( null === $image ) {
		return '';
	}
	$html = '<img class="' . esc_attr( $class_name ) . '" src="' . esc_url( (string) ( $image['src'] ?? '' ) ) . '"';
	foreach ( array( 'srcset', 'sizes' ) as $key ) {
		if ( ! empty( $image[ $key ] ) ) {
			$html .= ' ' . $key . '="' . esc_attr( (string) $image[ $key ] ) . '"';
		}
	}
	$html .= ' width="' . (int) ( $image['width'] ?? 0 ) . '" height="' . (int) ( $image['height'] ?? 0 ) . '"';
	$html .= ' alt="' . esc_attr( (string) ( $image['alt'] ?? '' ) ) . '"';
	$html .= ' loading="' . esc_attr( (string) ( $image['loading'] ?? '' ) ) . '" decoding="async">';
	return $html;
}

/**
 * Enlace `tel:` en formato internacional a partir de la etiqueta de un celular.
 *
 * @param string $label Teléfono como se muestra (`+57 310 325 0267`).
 * @return string `tel:+573103250267` o `''` si no hay dígitos.
 */
function ebio_contact_channels_tel_href( string $label ): string {
	$digits = (string) preg_replace( '/\D+/', '', $label );
	if ( '' === $digits ) {
		return '';
	}
	return 'tel:' . ( 0 === strpos( ltrim( $label ), '+' ) ? '+' : '' ) . $digits;
}

/**
 * Celulares de los ajustes como `{ label, href }` (los que no tienen dígitos se descartan).
 *
 * @return array<int, array{label:string,href:string}>
 */
function ebio_site_contact_phones(): array {
	$phones = array();
	foreach ( (array) ebio_site_settings()['phones'] as $label ) {
		$label = is_string( $label ) ? trim( $label ) : '';
		$href  = '' !== $label ? ebio_contact_channels_tel_href( $label ) : '';
		if ( '' !== $href ) {
			$phones[] = array(
				'label' => $label,
				'href'  => $href,
			);
		}
	}
	return $phones;
}

/**
 * Correo de los ajustes como `{ label, href }` o `null` si está vacío.
 *
 * @return array{label:string,href:string}|null
 */
function ebio_site_contact_email(): ?array {
	$email = trim( (string) ebio_site_settings()['email'] );
	return '' !== $email ? array(
		'label' => $email,
		'href'  => 'mailto:' . $email,
	) : null;
}

/**
 * Ruta normalizada para comparar enlaces del sitio: sin el prefijo de `home_url()`, con barra inicial y final.
 *
 * @param string $path Ruta (`/productos`, `/sub/productos/`).
 * @return string `/productos/`.
 */
function ebio_site_path( string $path ): string {
	$base = rtrim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
	if ( '' !== $base && 0 === strpos( $path, $base . '/' ) ) {
		$path = substr( $path, strlen( $base ) );
	}
	$trimmed = trim( $path, '/' );
	return '' === $trimmed ? '/' : '/' . $trimmed . '/';
}

/**
 * Filtros de catálogo de la petición (`categoria`, `sector`, `formato`) normalizados: solo valores de texto,
 * en minúsculas, separados por coma, con slugs válidos, sin repetidos y ordenados. Todo lo demás (arreglos,
 * vacíos, claves ajenas) se ignora y nunca lanza avisos.
 *
 * @param mixed $query `$_GET` o la consulta de un enlace.
 * @return array<string,string> Solo los filtros no vacíos, en el orden `categoria`, `sector`, `formato`.
 */
function ebio_request_catalog_filters( $query ): array {
	$filters = array();
	if ( ! is_array( $query ) ) {
		return $filters;
	}
	foreach ( array( 'categoria', 'sector', 'formato' ) as $key ) {
		if ( ! isset( $query[ $key ] ) || ! is_string( $query[ $key ] ) ) {
			continue;
		}
		$slugs = array();
		foreach ( explode( ',', strtolower( $query[ $key ] ) ) as $slug ) {
			$slug = sanitize_key( $slug );
			if ( '' !== $slug ) {
				$slugs[ $slug ] = $slug;
			}
		}
		sort( $slugs );
		if ( $slugs ) {
			$filters[ $key ] = implode( ',', $slugs );
		}
	}
	return $filters;
}
