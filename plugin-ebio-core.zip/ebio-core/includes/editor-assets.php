<?php
/**
 * Script del editor de bloques (panel "Datos del producto"), solo para `ebio_product`.
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

/**
 * Encola `build/editor/index.js` en el editor de un producto.
 */
function ebio_enqueue_editor_assets(): void {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'ebio_product' !== $screen->post_type ) {
		return;
	}
	$asset_file = EBIO_CORE_PATH . 'build/editor/index.asset.php';
	if ( ! is_readable( $asset_file ) ) {
		return;
	}
	$asset = include $asset_file;
	wp_enqueue_script(
		'ebio-core-editor',
		plugins_url( 'build/editor/index.js', EBIO_CORE_PATH . 'ebio-core.php' ),
		is_array( $asset['dependencies'] ?? null ) ? $asset['dependencies'] : array(),
		is_string( $asset['version'] ?? null ) ? $asset['version'] : false,
		true
	);
}
add_action( 'enqueue_block_editor_assets', 'ebio_enqueue_editor_assets' );
