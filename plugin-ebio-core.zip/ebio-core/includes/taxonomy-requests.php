<?php
/**
 * Peticiones a taxonomías sin página propia (E7, O2).
 *
 * `ebio_sector` y `ebio_format` no tienen URL pública: WordPress ignora `/?taxonomy=ebio_sector&term=x` y
 * `/?ebio_sector=x` y responde 200 con el Inicio (con canonical `/`). Un sector con página en `/sectores/<slug>/`
 * redirige (301) a ella; cualquier otro caso responde 404.
 *
 * @package ebio-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Qué hacer con una petición a una taxonomía sin página propia.
 *
 * @param array $query Parámetros de la URL (`$_GET`).
 * @return array{action:string,url:string} `action`: `none` (no es una de estas peticiones), `redirect` (con `url`)
 *                                          o `not_found`.
 */
function ebio_taxonomy_request_target( array $query ): array {
	$none     = array(
		'action' => 'none',
		'url'    => '',
	);
	$taxonomy = '';
	$term     = '';
	if ( isset( $query['taxonomy'] ) && is_string( $query['taxonomy'] ) && in_array( $query['taxonomy'], array( 'ebio_sector', 'ebio_format' ), true ) ) {
		$taxonomy = $query['taxonomy'];
		$term     = isset( $query['term'] ) && is_string( $query['term'] ) ? $query['term'] : '';
	} else {
		foreach ( array( 'ebio_sector', 'ebio_format' ) as $name ) {
			if ( isset( $query[ $name ] ) ) {
				$taxonomy = $name;
				$term     = is_string( $query[ $name ] ) ? $query[ $name ] : '';
				break;
			}
		}
	}
	if ( '' === $taxonomy ) {
		return $none;
	}

	$slug = sanitize_title( $term );
	if ( 'ebio_sector' === $taxonomy && '' !== $slug && get_term_by( 'slug', $slug, 'ebio_sector' ) instanceof WP_Term ) {
		$page = get_page_by_path( 'sectores/' . $slug, OBJECT, 'page' );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			return array(
				'action' => 'redirect',
				'url'    => (string) get_permalink( $page ),
			);
		}
	}
	return array(
		'action' => 'not_found',
		'url'    => '',
	);
}

/**
 * Aplica `ebio_taxonomy_request_target()` antes de elegir plantilla.
 */
function ebio_taxonomy_request_guard(): void {
	if ( is_admin() || ! is_front_page() && ! is_home() ) {
		return;
	}
	$target = ebio_taxonomy_request_target( wp_unslash( $_GET ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo lectura de la URL.
	if ( 'redirect' === $target['action'] ) {
		wp_safe_redirect( $target['url'], 301 );
		exit;
	}
	if ( 'not_found' === $target['action'] ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}
}
add_action( 'template_redirect', 'ebio_taxonomy_request_guard', 1 );
