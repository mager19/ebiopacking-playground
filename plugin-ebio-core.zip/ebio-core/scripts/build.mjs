// Build de bloques. Sin bloques en <src>/*/block.json limpia la salida y termina con código 0
// (wp-scripts falla cuando no hay entradas). Salida: <out>/<name>/block.json.
//
// Uso: node scripts/build.mjs [start] [--src=<dir relativo al plugin>] [--out=<dir>]
// Por defecto --src=src/blocks y --out=build/blocks; en ese caso se borra build/ completo antes.
//
// --experimental-modules: @wordpress/scripts solo compila las entradas `viewScriptModule`
// con este flag. Con él, webpack deja de limpiar la salida (dos compilaciones comparten el
// directorio), así que este script la limpia antes de compilar.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const argv = process.argv.slice(2);
const option = (name, fallback) => {
	const hit = argv.find((a) => a.startsWith(`--${name}=`));
	return hit ? hit.slice(name.length + 3) : fallback;
};
const cmd = argv[0] === 'start' ? 'start' : 'build';
const srcDir = option('src', 'src/blocks');
const outDir = option('out', 'build/blocks');
// Con la salida por defecto se limpia build/ entero; con --out, solo ese directorio.
const cleanDir = path.resolve(root, argv.some((a) => a.startsWith('--out=')) ? outDir : 'build');

// La salida se limpia siempre, también cuando no hay bloques (queda sin restos).
fs.rmSync(cleanDir, { recursive: true, force: true });

const blocksDir = path.resolve(root, srcDir);
const hasBlocks =
	fs.existsSync(blocksDir) &&
	fs.readdirSync(blocksDir, { withFileTypes: true }).some((d) => d.isDirectory() && fs.existsSync(path.join(blocksDir, d.name, 'block.json')));

if (!hasBlocks) {
	console.log(`ebio-core: sin bloques en ${srcDir}, nada que compilar.`);
	process.exit(0);
}

const res = spawnSync(
	'npx',
	['wp-scripts', cmd, `--webpack-src-dir=${srcDir}`, `--output-path=${path.resolve(root, outDir)}`, '--blocks-manifest', '--experimental-modules'],
	{ cwd: root, stdio: 'inherit' }
);
if ((res.status ?? 1) !== 0) {
	process.exit(res.status ?? 1);
}

// Segunda compilación (solo con la salida por defecto): el script del editor (panel "Datos del producto")
// va en build/editor/. Corre después de la de bloques, que limpia build/ entero; wp-scripts, sin
// --experimental-modules, limpia solo build/editor/.
const editorEntry = path.resolve(root, 'src/editor/index.js');
const isDefaultRun = !argv.some((a) => a.startsWith('--src=') || a.startsWith('--out='));
if (cmd === 'build' && isDefaultRun && fs.existsSync(editorEntry)) {
	const editor = spawnSync('npx', ['wp-scripts', 'build', 'index.js', '--webpack-src-dir=src/editor', `--output-path=${path.resolve(root, 'build/editor')}`], { cwd: root, stdio: 'inherit' });
	process.exit(editor.status ?? 1);
}
process.exit(0);
