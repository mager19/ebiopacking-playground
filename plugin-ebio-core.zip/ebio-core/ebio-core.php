<?php
/**
 * Plugin Name: eBio Core
 * Description: Bloques personalizados y funcionalidad del sitio eBiopacking.
 * Version: 0.1.0
 * Requires at least: 6.6
 * Requires PHP: 8.0
 * Text Domain: ebio-core
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

define( 'EBIO_CORE_VERSION', '0.1.0' );
define( 'EBIO_CORE_PATH', plugin_dir_path( __FILE__ ) );

foreach ( glob( EBIO_CORE_PATH . 'includes/*.php' ) ?: array() as $ebio_core_file ) {
	require_once $ebio_core_file;
}
unset( $ebio_core_file );

// Cotización: el orden de carga importa (mensajes primero, caché al final).
foreach ( array( 'messages', 'validate', 'service', 'mail', 'rest', 'admin-post', 'admin', 'cache', 'state' ) as $ebio_core_quote_file ) {
	require_once EBIO_CORE_PATH . 'includes/quote/' . $ebio_core_quote_file . '.php';
}
unset( $ebio_core_quote_file );

// Infraestructura de bloques y SEO: los helpers van primero: los bloques los llaman al cargarse (p. ej. ebio_register_block_view()); el resto se carga en orden alfabético.
require_once EBIO_CORE_PATH . 'includes/blocks/helpers.php';
foreach ( array( 'blocks', 'seo' ) as $ebio_core_dir ) {
	foreach ( glob( EBIO_CORE_PATH . 'includes/' . $ebio_core_dir . '/*.php' ) ?: array() as $ebio_core_file ) {
		require_once $ebio_core_file;
	}
}
unset( $ebio_core_dir, $ebio_core_file );

register_activation_hook( __FILE__, 'ebio_core_activate' );
register_activation_hook( __FILE__, 'ebio_quote_schedule_purge' );
register_deactivation_hook( __FILE__, 'ebio_quote_unschedule_purge' );

/**
 * Registra todo bloque compilado.
 *
 * `wp-scripts build --webpack-src-dir=src/blocks --output-path=build/blocks`
 * deja cada bloque en `build/blocks/<nombre>/block.json`; ese es el patrón que se busca.
 */
function ebio_core_register_blocks() {
	foreach ( glob( EBIO_CORE_PATH . 'build/blocks/*/block.json' ) ?: array() as $block_json ) {
		register_block_type( dirname( $block_json ) );
	}
}
add_action( 'init', 'ebio_core_register_blocks' );
