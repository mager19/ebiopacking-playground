// Foco al cerrar la barra de anuncio (WCAG 2.4.3): siguiente enfocable fuera de la barra.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { nextFocusTarget } from '../../src/blocks/announcement-bar/focus-target.js';

function mount(html) {
	document.body.innerHTML = html;
	return document.querySelector('.ebio-announcement-bar');
}

test('focus moves to the next focusable after the bar', () => {
	const bar = mount(
		'<div class="ebio-announcement-bar"><a href="/oferta/" id="in-bar">Oferta</a><button class="ebio-announcement-bar__close" id="close">x</button></div>' +
			'<header><a href="/" id="logo">Logo</a><button id="menu">Menú</button></header>'
	);
	assert.equal(nextFocusTarget(bar)?.id, 'logo');
});

test('skips hidden, inert, disabled and aria-hidden candidates', () => {
	const bar = mount(
		'<div class="ebio-announcement-bar"><button id="close">x</button></div>' +
			'<a href="/a" hidden id="a">a</a>' +
			'<div hidden><a href="/b" id="b">b</a></div>' +
			'<div inert><a href="/c" id="c">c</a></div>' +
			'<button disabled id="d">d</button>' +
			'<a href="/e" aria-hidden="true" id="e">e</a>' +
			'<input type="hidden" id="f">' +
			'<a href="/g" id="g">g</a>'
	);
	assert.equal(nextFocusTarget(bar)?.id, 'g');
});

test('ignores focusables before the bar and returns null when none follows', () => {
	const bar = mount('<a href="/antes" id="antes">antes</a><div class="ebio-announcement-bar"><button id="close">x</button></div>');
	assert.equal(nextFocusTarget(bar), null);
});

test('null-safe without a bar', () => {
	assert.equal(nextFocusTarget(null), null);
	assert.equal(nextFocusTarget(undefined), null);
});
