// Bloques estáticos con imagen (Tarea 6): hero-split, media-text-split, collection-cards, sector-cards.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { loadBlock, loadHarness, readBlockJson, readFixtures } from './load-block.mjs';
import { hasOtherH1 } from '../../src/blocks/hero-split/h1.js';

async function render(block, attributes, children) {
	const { Component } = await loadBlock(block);
	return renderToStaticMarkup(React.createElement(Component, { attributes, context: {} }, children));
}
const fixture = (block, name) => readFixtures(block).find((fx) => fx.name === name).attributes;
const count = (html, needle) => html.split(needle).length - 1;
const many = (n, make) => Array.from({ length: n }, (_, i) => make(i));
const photo = { id: 9, url: '/x.webp', alt: 'Foto', width: 10, height: 10 };

test('hero-split is unique', () => {
	assert.equal(readBlockJson('hero-split').supports.multiple, false);
	for (const other of [ 'media-text-split', 'collection-cards', 'sector-cards' ]) {
		assert.equal(readBlockJson(other).supports.multiple, undefined);
	}
});

test('media-text-split media end modifier', async () => {
	const base = fixture('media-text-split', 'default');
	const end = await render('media-text-split', { ...base, mediaPosition: 'end' });
	assert.ok(end.includes('ebio-media-text-split--media-end'));
	assert.ok(end.includes('class="ebio-media-text-split ebio-media-text-split--stat ebio-media-text-split--media-end"'));
	const start = await render('media-text-split', base);
	assert.ok(!start.includes('--media-end'));
	const plain = await render('media-text-split', { ...fixture('media-text-split', 'minimal'), mediaPosition: 'end' });
	assert.ok(plain.includes('class="ebio-media-text-split ebio-media-text-split--media-end"'));
});

test('card images have empty alt', async () => {
	for (const [ block, key ] of [ [ 'collection-cards', 'items' ], [ 'sector-cards', 'items' ] ]) {
		const base = fixture(block, 'default');
		const html = await render(block, { ...base, [ key ]: [ { ...base[ key ][ 0 ], image: photo } ] });
		assert.ok(html.includes(`<img class="ebio-${ block }__image wp-image-9"`));
		assert.match(html, /<img [^>]*alt=""/);
		assert.ok(!html.includes('alt="Foto"'));
	}
});

test('hero image keeps alt and wp-image class', async () => {
	const html = await render('hero-split', fixture('hero-split', 'default'));
	assert.match(html, /<img [^>]*class="ebio-hero-split__image wp-image-21"/);
	assert.match(html, /alt="Pallets de cajas de cartón de gran formato en bodega, con una caja pequeña en primer plano"/);
	assert.match(html, /fetchpriority="high"/);
	assert.ok(!html.includes('loading="lazy"'));
});

test('hero-split markup follows the contract', async () => {
	const full = await render('hero-split', fixture('hero-split', 'default'), React.createElement('p', null, 'x'));
	assert.ok(full.startsWith('<section class="ebio-hero-split">'));
	assert.ok(full.includes('<span class="ebio-hero-split__sticker" aria-hidden="true">Fabricantes desde 2006</span>'));
	assert.ok(full.includes('<p class="ebio-hero-split__eyebrow">'));
	assert.ok(full.includes('<div class="ebio-hero-split__content"><p>x</p></div>'));
	// El sticker es solo de la variante por defecto; sin imagen no hay __media.
	const sector = await render('hero-split', fixture('hero-split', 'long-content'));
	assert.ok(sector.includes('ebio-hero-split--sector'));
	assert.ok(!sector.includes('__sticker'));
	const minimal = await render('hero-split', fixture('hero-split', 'minimal'));
	assert.ok(minimal.includes('ebio-hero-split--compact'));
	assert.ok(!minimal.includes('__media'));
	assert.ok(!minimal.includes('__eyebrow'));
	const stuck = await render('hero-split', { ...fixture('hero-split', 'long-content'), variant: 'compact', sticker: 'No' });
	assert.ok(!stuck.includes('__sticker'));
});

test('media-text-split stats only in the stat variant, around the content', async () => {
	const before = await render('media-text-split', fixture('media-text-split', 'default'));
	assert.ok(before.indexOf('__stats') > -1 && before.indexOf('__stats') < before.indexOf('__content'));
	const after = await render('media-text-split', fixture('media-text-split', 'long-content'));
	assert.ok(after.indexOf('__stats') > after.indexOf('__content'));
	assert.equal(count(after, 'class="ebio-media-text-split__stat"'), 4);
	assert.equal(count(after, 'ebio-media-text-split__stat-label'), 4);
	// Etiqueta vacía: sin __stat-label (fixture default).
	assert.ok(!before.includes('__stat-label'));
	const plain = await render('media-text-split', { ...fixture('media-text-split', 'default'), variant: 'default' });
	assert.ok(!plain.includes('__stats'));
	assert.ok(!plain.includes('ebio-media-text-split--'));
	const none = await render('media-text-split', { ...fixture('media-text-split', 'default'), stats: [] });
	assert.ok(!none.includes('__stats'));
	const clamped = await render('media-text-split', { ...fixture('media-text-split', 'long-content'), stats: many(6, (i) => ({ value: `v${ i }`, label: '' })) });
	assert.equal(count(clamped, 'class="ebio-media-text-split__stat"'), 4);
});

test('media-text-split uses headingLevel, omits eyebrow and media when empty', async () => {
	const html = await render('media-text-split', fixture('media-text-split', 'minimal'));
	assert.ok(html.includes('<h2 class="ebio-media-text-split__heading">Quiénes somos</h2>'));
	assert.ok(!html.includes('__media'));
	assert.ok(!html.includes('__eyebrow'));
	const full = await render('media-text-split', fixture('media-text-split', 'default'));
	assert.ok(full.includes('class="ebio-media-text-split__image wp-image-61"'));
	assert.ok(full.includes('<p class="ebio-media-text-split__eyebrow">Sostenibilidad</p>'));
});

test('collection-cards markup, clamping and optional parts', async () => {
	const html = await render('collection-cards', fixture('collection-cards', 'default'));
	assert.ok(html.includes('<a class="ebio-collection-cards__cta ebio-button ebio-button--secondary" href="/productos/">Ver todos los productos</a>'));
	assert.ok(html.includes('<a class="ebio-collection-cards__card" href="/productos/empaques-industriales/">'));
	assert.ok(html.includes('<h3 class="ebio-collection-cards__title">Empaques industriales</h3>'));
	assert.ok(html.includes('class="ebio-icon ebio-icon--arrow-right ebio-collection-cards__arrow" aria-hidden="true"'));
	const minimal = await render('collection-cards', fixture('collection-cards', 'minimal'));
	assert.ok(!minimal.includes('__cta'));
	assert.ok(!minimal.includes('__eyebrow'));
	assert.ok(!minimal.includes('<img'));
	const clamped = await render('collection-cards', { ...fixture('collection-cards', 'default'), items: many(6, (i) => ({ title: `t${ i }`, eyebrow: '', url: '/x/', image: photo })) });
	assert.equal(count(clamped, 'class="ebio-collection-cards__item"'), 4);
	const level = await render('collection-cards', { ...fixture('collection-cards', 'default'), headingLevel: 3 });
	assert.ok(level.includes('<h3 class="ebio-collection-cards__heading">'));
	assert.ok(level.includes('<h4 class="ebio-collection-cards__title">'));
	await render('collection-cards', { ...fixture('collection-cards', 'default'), items: [ null, undefined ] });
});

test('sector-cards markup, clamping and optional parts', async () => {
	const html = await render('sector-cards', fixture('sector-cards', 'default'));
	assert.ok(html.includes('<p class="ebio-sector-cards__intro">'));
	assert.ok(html.includes('<a class="ebio-sector-cards__card" href="/sectores/floricultura/">'));
	assert.ok(html.includes('<h3 class="ebio-sector-cards__title">Floricultura</h3>'));
	assert.ok(html.includes('<p class="ebio-sector-cards__text">Cajas, láminas y separadores para exportar flor fresca.</p>'));
	const minimal = await render('sector-cards', fixture('sector-cards', 'minimal'));
	assert.ok(!minimal.includes('__intro'));
	assert.ok(!minimal.includes('__text'));
	assert.ok(!minimal.includes('<img'));
	const clamped = await render('sector-cards', { ...fixture('sector-cards', 'default'), items: many(9, (i) => ({ title: `t${ i }`, text: '', url: '/x/', image: photo })) });
	assert.equal(count(clamped, 'class="ebio-sector-cards__item"'), 6);
	await render('sector-cards', { ...fixture('sector-cards', 'default'), items: [ null, undefined ] });
});

test('ImageControl warns on missing alt', async () => {
	const { lib } = await loadHarness();
	const html = renderToStaticMarkup(React.createElement(lib.ImageControl, { label: 'Imagen', value: { id: 5, url: '/a.webp', alt: '', width: 1, height: 1 }, onChange() {}, required: true }));
	assert.ok(html.includes('Falta el texto alternativo (obligatorio)'));
	assert.ok(html.includes('Texto alternativo (obligatorio)'));
	const fine = renderToStaticMarkup(React.createElement(lib.ImageControl, { label: 'Imagen', value: { id: 5, url: '/a.webp', alt: 'Algo', width: 1, height: 1 }, onChange() {}, required: true }));
	assert.ok(!fine.includes('Falta el texto alternativo'));
});

const heading = (clientId, level = 1, innerBlocks = []) => ({ clientId, name: 'core/heading', attributes: { level }, innerBlocks });
const hero = (clientId, innerBlocks = []) => ({ clientId, name: 'ebio/hero-split', attributes: {}, innerBlocks });

test('hasOtherH1 detects a level-1 heading outside the block', () => {
	assert.equal(hasOtherH1([ hero('hero'), heading('h1') ], 'hero'), true);
	assert.equal(hasOtherH1([ hero('hero', [ heading('own') ]) ], 'hero'), false);
	assert.equal(hasOtherH1([ hero('hero', [ heading('own') ]), heading('h2', 2) ], 'hero'), false);
	assert.equal(hasOtherH1([ hero('hero') ], 'hero'), false);
	// Anidado en otro bloque (p. ej. un core/group): también cuenta.
	assert.equal(hasOtherH1([ { clientId: 'g', name: 'core/group', attributes: {}, innerBlocks: [ heading('deep') ] }, hero('hero') ], 'hero'), true);
	// Otro bloque con el mismo nivel pero que no es un encabezado no cuenta.
	assert.equal(hasOtherH1([ { clientId: 'p', name: 'core/paragraph', attributes: { level: 1 }, innerBlocks: [] }, hero('hero') ], 'hero'), false);
	assert.equal(hasOtherH1(undefined, 'hero'), false);
});

test('hero-split edit shows the H1 notice', async () => {
	const { wp } = await loadHarness();
	const { settings } = await loadBlock('hero-split');
	const dispatch = wp.data.dispatch('core/block-editor');
	const attributes = fixture('hero-split', 'default');
	const view = () => renderToStaticMarkup(React.createElement(settings.edit, { attributes, setAttributes() {}, clientId: 'hero', isSelected: false }));

	dispatch.resetBlocks([ hero('hero'), heading('other') ]);
	assert.ok(view().includes('Esta página ya tiene un H1'));

	dispatch.resetBlocks([ hero('hero', [ heading('own') ]) ]);
	assert.ok(!view().includes('Esta página ya tiene un H1'));

	dispatch.resetBlocks([ hero('hero') ]);
	assert.ok(!view().includes('Esta página ya tiene un H1'));
	dispatch.resetBlocks([]);
});

test('cards render a div instead of a link inside the editor canvas only', async () => {
	const { lib, blockModules } = await loadHarness();
	const attributes = fixture('sector-cards', 'default');
	const { Component } = blockModules[ 'sector-cards' ];
	const view = renderToStaticMarkup(React.createElement(Component, { attributes }));
	assert.ok(view.includes('<a class="ebio-sector-cards__card" href="/sectores/floricultura/">'));
	const editing = renderToStaticMarkup(React.createElement(lib.EditContext.Provider, { value: { onChange() {} } }, React.createElement(Component, { attributes })));
	assert.ok(editing.includes('<div class="ebio-sector-cards__card">'));
	assert.ok(!editing.includes('<a '));
});

test('editor cards without an image show the selector; saved markup is unchanged', async () => {
	const { lib, blockModules, wp } = await loadHarness();
	for (const block of [ 'collection-cards', 'sector-cards' ]) {
		const base = fixture(block, 'minimal');
		const attributes = { ...base, items: [ { ...base.items[ 0 ], image: { id: 0, url: '', alt: '', width: 0, height: 0 } } ] };
		const { Component, settings, metadata } = blockModules[ block ];
		const paths = [];
		const ctx = { onChange() {}, imagePicker: ( path ) => (paths.push(path), React.createElement('button', null, 'Elegir imagen')) };
		const editing = renderToStaticMarkup(React.createElement(lib.EditContext.Provider, { value: ctx }, React.createElement(Component, { attributes })));
		assert.ok(editing.includes('Elegir imagen'), block);
		assert.deepEqual(paths, [ [ 'items', 0, 'image' ] ]);
		// Vista y save(): ni selector ni cambios de HTML.
		const view = renderToStaticMarkup(React.createElement(Component, { attributes }));
		assert.ok(!view.includes('Elegir imagen') && !view.includes('<button'));
		if (!wp.blocks.getBlockType(metadata.name)) wp.blocks.registerBlockType(metadata, settings);
		const saved = wp.blocks.serialize(wp.blocks.createBlock(metadata.name, attributes, []));
		assert.ok(!saved.includes('Elegir imagen') && !saved.includes('<button'));
	}
});

test('edit warns about a missing image alt in the canvas', async () => {
	const { wp } = await loadHarness();
	for (const [ block, name ] of [ [ 'hero-split', 'default' ], [ 'media-text-split', 'default' ] ]) {
		const { settings } = await loadBlock(block);
		const attributes = { ...fixture(block, name), image: { ...fixture(block, name).image, alt: '' } };
		wp.data.dispatch('core/block-editor').resetBlocks([]);
		const html = renderToStaticMarkup(React.createElement(settings.edit, { attributes, setAttributes() {}, clientId: 'c1', isSelected: false }));
		assert.ok(html.includes('Falta el texto alternativo (obligatorio)'), block);
	}
});
