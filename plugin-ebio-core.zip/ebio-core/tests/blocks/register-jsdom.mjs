// Registro de jsdom para las pruebas de bloques: igual que `global-jsdom/register`, pero sin el ruido
// "Could not parse CSS stylesheet" (jsdom no entiende CSS moderno de los componentes y lo avisa en cada
// prueba). Cualquier otro error de jsdom sigue llegando a la consola.
import globalJsdom from 'global-jsdom';
import { VirtualConsole } from 'jsdom';

const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', (error) => {
	if (/Could not parse CSS stylesheet/.test(String(error?.message ?? error))) return;
	console.error(error);
});
for (const method of ['log', 'info', 'warn', 'error', 'debug']) {
	virtualConsole.on(method, (...args) => console[method](...args));
}

globalJsdom(undefined, { virtualConsole });
