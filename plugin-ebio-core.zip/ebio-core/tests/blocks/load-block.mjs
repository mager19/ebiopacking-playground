// Carga los bloques de src/blocks para las pruebas de Node (node --import global-jsdom/register).
//
// Los paquetes @wordpress/* no se pueden importar directamente en Node (importan JSON sin
// atributos de importación), así que se empaquetan con esbuild en un módulo temporal fuera del
// repositorio. Un solo paquete por proceso contiene @wordpress/*, los helpers de src/ y todos los
// bloques: así comparten el mismo registro de @wordpress/data, el mismo store `core/blocks` y el
// mismo contexto `SaveMode`. React queda externo (una sola copia, la del workspace), de modo que
// `react-dom/server` y `react` importados por las pruebas son los mismos que usan los bloques.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url));
export const PLUGIN_DIR = path.resolve(here, '../..');
export const SRC_DIR = path.join(PLUGIN_DIR, 'src');
export const BLOCKS_DIR = path.join(SRC_DIR, 'blocks');
export const COMPONENTS_DIR = path.join(SRC_DIR, 'components');
export const DOCS_DIR = path.resolve(PLUGIN_DIR, '../../docs/blocks');

/** `brand-marquee` → `BrandMarquee`. */
export const pascalCase = (name) =>
	name
		.replace(/^ebio\//, '')
		.split('-')
		.map((p) => p.charAt(0).toUpperCase() + p.slice(1))
		.join('');

/** Bloques de src/blocks (directorios con block.json), en orden alfabético. */
export function blockNames() {
	if (!fs.existsSync(BLOCKS_DIR)) return [];
	return fs
		.readdirSync(BLOCKS_DIR, { withFileTypes: true })
		.filter((d) => d.isDirectory() && fs.existsSync(path.join(BLOCKS_DIR, d.name, 'block.json')))
		.map((d) => d.name)
		.sort();
}

export const readBlockJson = (name) => JSON.parse(fs.readFileSync(path.join(BLOCKS_DIR, name, 'block.json'), 'utf8'));

export function readFixtures(name) {
	const file = path.join(BLOCKS_DIR, name, 'fixtures.json');
	if (!fs.existsSync(file)) throw new Error(`${name} :: falta fixtures.json`);
	return JSON.parse(fs.readFileSync(file, 'utf8'));
}

const LIB = {
	rootProps: ['components/lib/root-props.js', 'rootProps'],
	SaveMode: ['components/lib/save-mode.js', 'SaveMode'],
	RichField: ['components/lib/RichField.jsx', 'default'],
	BlockImage: ['components/lib/BlockImage.jsx', 'default'],
	DynamicImage: ['components/lib/DynamicImage.jsx', 'default'],
	useUid: ['editor/use-uid.js', 'default'],
	EditContext: ['components/lib/edit-context.js', 'EditContext'],
	makeEditContext: ['editor/edit-context.js', 'makeEditContext'],
	isEditing: ['components/lib/edit-context.js', 'isEditing'],
	setIn: ['editor/edit-context.js', 'setIn'],
	createUid: ['editor/use-uid.js', 'createUid'],
	useBlockView: ['editor/use-block-view.js', 'default'],
	ImageControl: ['editor/ImageControl.jsx', 'default'],
};

function entrySource() {
	const lines = [
		"import * as blocks from '@wordpress/blocks';",
		"import * as blockEditor from '@wordpress/block-editor';",
		"import * as data from '@wordpress/data';",
		"import * as element from '@wordpress/element';",
		'export const wp = { blocks, blockEditor, data, element };',
	];
	const lib = [];
	for (const [key, [file, exported]] of Object.entries(LIB)) {
		lines.push(`import { ${exported} as lib_${key} } from ${JSON.stringify(path.join(SRC_DIR, file))};`);
		lib.push(`${key}: lib_${key}`);
	}
	lines.push(`export const lib = { ${lib.join(', ')} };`);

	const modules = [];
	blockNames().forEach((name, i) => {
		const dir = path.join(BLOCKS_DIR, name);
		const hasSave = fs.existsSync(path.join(dir, 'save.jsx'));
		lines.push(`import metadata_${i} from ${JSON.stringify(path.join(dir, 'block.json'))};`);
		lines.push(`import edit_${i} from ${JSON.stringify(path.join(dir, 'edit.jsx'))};`);
		if (hasSave) lines.push(`import save_${i} from ${JSON.stringify(path.join(dir, 'save.jsx'))};`);
		lines.push(`import Component_${i} from ${JSON.stringify(path.join(COMPONENTS_DIR, `${pascalCase(name)}.jsx`))};`);
		const settings = hasSave ? `{ edit: edit_${i}, save: save_${i} }` : `{ edit: edit_${i} }`;
		modules.push(`${JSON.stringify(name)}: { metadata: metadata_${i}, settings: ${settings}, Component: Component_${i} }`);
	});
	lines.push(`export const blockModules = { ${modules.join(', ')} };`);
	return lines.join('\n') + '\n';
}

// react, react-dom y sus subrutas: externos, resueltos a la copia del workspace por ruta absoluta.
const externalReact = {
	name: 'external-react',
	setup(b) {
		b.onResolve({ filter: /^react(-dom)?(\/.*)?$/ }, (args) => ({ path: fileURLToPath(import.meta.resolve(args.path)), external: true }));
	},
};

async function buildHarness() {
	const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-blocks-'));
	try {
		const out = path.join(dir, 'harness.mjs');
		await build({
			// La entrada resuelve los paquetes desde el plugin; solo la salida vive fuera del repositorio.
			stdin: { contents: entrySource(), resolveDir: PLUGIN_DIR, sourcefile: 'ebio-blocks-harness.js', loader: 'js' },
			outfile: out,
			bundle: true,
			format: 'esm',
			platform: 'node',
			jsx: 'automatic',
			loader: { '.js': 'jsx' },
			logLevel: 'error',
			plugins: [externalReact],
			// Los módulos CommonJS empaquetados llaman a require('react'): que resuelva desde aquí.
			banner: { js: `import { createRequire as __ebioCreateRequire } from 'node:module';\nconst require = __ebioCreateRequire(${JSON.stringify(import.meta.url)});` },
		});
		return await import(pathToFileURL(out).href);
	} finally {
		fs.rmSync(dir, { recursive: true, force: true });
	}
}

let harness;
/** @returns {Promise<{ wp: { blocks, blockEditor, data, element }, lib: object, blockModules: object }>} */
export function loadHarness() {
	harness ??= buildHarness();
	return harness;
}

/**
 * Módulo de un bloque de src/blocks.
 *
 * @param {string} name `brand-marquee` o `ebio/brand-marquee`.
 * @returns {Promise<{ metadata: object, settings: { edit: Function, save?: Function }, Component: Function }>}
 */
export async function loadBlock(name) {
	const short = name.replace(/^ebio\//, '');
	const { blockModules } = await loadHarness();
	if (!blockModules[short]) throw new Error(`loadBlock: no existe src/blocks/${short}/block.json`);
	return blockModules[short];
}
