// Bloques con save(): validación del editor (serialize → parse) y mismo HTML en save() y en el componente.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { blockNames, loadBlock, loadHarness, readFixtures } from './load-block.mjs';
import { checkSsr, normalizeHtml } from '../parity/parity.mjs';

const { wp } = await loadHarness();
const { blocks } = wp;
const stripBlockComments = (html) => html.replace(/<!-- \/?wp:[\s\S]*?-->/g, '');

for (const name of blockNames()) {
	const { metadata, settings, Component } = await loadBlock(name);
	if (!settings.save) continue;
	if (!blocks.getBlockType(metadata.name)) blocks.registerBlockType(metadata, settings);

	for (const fx of readFixtures(name)) {
		test(`${name} :: ${fx.name}: serialize → parse is valid and keeps the attributes`, () => {
			const inner = fx.innerHTML ? blocks.parse(fx.innerHTML) : [];
			const html = blocks.serialize(blocks.createBlock(metadata.name, fx.attributes, inner));
			const parsed = blocks.parse(html);
			assert.equal(parsed.length, 1);
			assert.equal(parsed[0].isValid, true, `bloque inválido:\n${html}`);
			// Sin defaults implícitos: el fixture trae todos los atributos (anchor incluido).
			assert.deepEqual(parsed[0].attributes, fx.attributes);
		});

		// Dinámico (block.json `render`): el marco lo pinta el servidor y save() solo guarda InnerBlocks.Content;
		// su paridad la cubre tests/parity.
		if (metadata.render) continue;

		test(`${name} :: ${fx.name}: component markup equals save() markup`, async () => {
			const saved = stripBlockComments(blocks.serialize(blocks.createBlock(metadata.name, fx.attributes, [])));
			const rendered = renderToStaticMarkup(React.createElement(Component, { attributes: fx.attributes, context: {} }));
			assert.equal(normalizeHtml(rendered), normalizeHtml(saved));
			if (metadata.viewScriptModule) {
				const ssr = await checkSsr(saved);
				assert.ok(ssr.ok, `SSR con efecto:\n${ssr.diff}`);
			}
		});
	}
}
