// Bloques estáticos de listas (Tarea 5): trust-strip, feature-pillars, process-steps, product-specs.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { loadBlock, readFixtures } from './load-block.mjs';

async function render(block, attributes) {
	const { Component } = await loadBlock(block);
	return renderToStaticMarkup(React.createElement(Component, { attributes, context: {} }));
}
const fixture = (block, name) => readFixtures(block).find((fx) => fx.name === name).attributes;

test('process-steps timeline emits marker', async () => {
	const timeline = await render('process-steps', fixture('process-steps', 'long-content'));
	assert.equal(fixture('process-steps', 'long-content').variant, 'timeline');
	assert.ok(timeline.includes('ebio-process-steps--timeline'));
	assert.ok(timeline.includes('ebio-process-steps__marker'));
	assert.ok(!timeline.includes('ebio-process-steps__number'));
	assert.ok(!timeline.includes('ebio-process-steps__when'));

	const plain = await render('process-steps', fixture('process-steps', 'default'));
	assert.ok(!plain.includes('__marker'));
	assert.ok(!plain.includes('ebio-process-steps--'));
	assert.ok(plain.includes('ebio-process-steps__number'));
	assert.ok(plain.includes('ebio-process-steps__when'));
});

test('process-steps optional parts follow intro, ctaText, showWhen and anchor', async () => {
	const full = await render('process-steps', fixture('process-steps', 'default'));
	assert.ok(full.includes('ebio-process-steps__intro'));
	assert.ok(full.includes('<a class="ebio-process-steps__cta ebio-button ebio-button--primary" href="/cotizar/">Solicitar cotización</a>'));
	const minimal = await render('process-steps', fixture('process-steps', 'minimal'));
	assert.ok(!minimal.includes('__intro'));
	assert.ok(!minimal.includes('__cta'));
	assert.ok(!minimal.includes('__when'));
	assert.ok(minimal.includes('id="como-funciona"'));
});

test('feature-pillars items use headingLevel + 1', async () => {
	const html = await render('feature-pillars', { ...fixture('feature-pillars', 'default'), headingLevel: 3 });
	assert.ok(html.includes('<h3 class="ebio-feature-pillars__heading">'));
	assert.ok(html.includes('<h4 class="ebio-feature-pillars__title">'));
	assert.ok(!html.includes('<h3 class="ebio-feature-pillars__title">'));
});

test('feature-pillars omits the icon when empty and the text when empty', async () => {
	const html = await render('feature-pillars', fixture('feature-pillars', 'minimal'));
	assert.ok(!html.includes('ebio-icon'));
	assert.ok(!html.includes('__text'));
	assert.ok(html.includes('ebio-feature-pillars__title'));
	const values = await render('feature-pillars', fixture('feature-pillars', 'long-content'));
	assert.ok(values.includes('ebio-feature-pillars--values'));
	assert.ok(values.includes('ebio-icon ebio-icon--shield ebio-feature-pillars__icon'));
});

test('product-specs omits empty rows', async () => {
	const attributes = { ...fixture('product-specs', 'minimal'), rows: [ { label: 'Peso', value: '' }, { label: 'Material', value: 'Cartón' }, { label: 'Medidas', value: 'A medida' }, { label: 'Impresión', value: 'Opcional' } ] };
	const html = await render('product-specs', attributes);
	assert.ok(!html.includes('Peso'));
	assert.ok(html.includes('Material'));
	assert.ok(html.includes('<th class="ebio-product-specs__label" scope="row">Material</th>'));
});

test('product-specs labels the table with the heading id built from uid', async () => {
	const html = await render('product-specs', fixture('product-specs', 'default'));
	assert.ok(html.includes('id="ebio-product-specs-specs-a1-heading"'));
	assert.ok(html.includes('aria-labelledby="ebio-product-specs-specs-a1-heading"'));
});

test('trust-strip default variant has no modifier', async () => {
	const html = await render('trust-strip', fixture('trust-strip', 'default'));
	assert.ok(html.startsWith('<section class="ebio-trust-strip" '));
	assert.ok(!html.includes('ebio-trust-strip--'));
	const figures = await render('trust-strip', fixture('trust-strip', 'long-content'));
	assert.ok(figures.includes('class="ebio-trust-strip ebio-trust-strip--figures"'));
});

test('trust-strip omits an empty label and keeps the aria-label', async () => {
	const html = await render('trust-strip', fixture('trust-strip', 'minimal'));
	assert.ok(!html.includes('__label'));
	assert.ok(html.includes('aria-label="Por qué confiar en eBiopacking"'));
	assert.ok(html.includes('class="ebio-trust-strip ebio-trust-strip--compact"'));
});

test('trust-strip renders the optional icon only on items that set one', async () => {
	const html = await render('trust-strip', fixture('trust-strip', 'default'));
	assert.ok(html.includes('<span class="ebio-icon ebio-icon--calendar ebio-trust-strip__icon" aria-hidden="true"></span><strong'));
	assert.equal(html.split('ebio-trust-strip__icon').length - 1, 4);
	const minimal = await render('trust-strip', fixture('trust-strip', 'minimal'));
	assert.ok(!minimal.includes('ebio-icon'));
});

const count = (html, needle) => html.split(needle).length - 1;
const many = (n, make) => Array.from({ length: n }, (_, i) => make(i));

test('over-max items are clamped (limits are not in the contract fixtures)', async () => {
	const trust = await render('trust-strip', { ...fixture('trust-strip', 'default'), items: many(7, (i) => ({ value: `v${i}`, label: 'l' })) });
	assert.equal(count(trust, 'class="ebio-trust-strip__item"'), 5);
	const pillars = await render('feature-pillars', { ...fixture('feature-pillars', 'default'), items: many(6, (i) => ({ icon: '', title: `t${i}`, text: '' })) });
	assert.equal(count(pillars, 'class="ebio-feature-pillars__item"'), 4);
	const steps = await render('process-steps', { ...fixture('process-steps', 'default'), items: many(8, (i) => ({ marker: '', when: '', title: `t${i}`, text: '' })) });
	assert.equal(count(steps, 'class="ebio-process-steps__step"'), 6);
	const specs = await render('product-specs', { ...fixture('product-specs', 'default'), rows: many(18, (i) => ({ label: `l${i}`, value: `v${i}` })) });
	assert.equal(count(specs, 'class="ebio-product-specs__row"'), 15);
});

test('product-specs filters empty rows before clamping to 15', async () => {
	const rows = [ ...many(15, (i) => ({ label: `e${i}`, value: '' })), { label: 'Visible', value: 'sí' } ];
	const html = await render('product-specs', { ...fixture('product-specs', 'default'), rows });
	assert.equal(count(html, 'class="ebio-product-specs__row"'), 1);
	assert.ok(html.includes('Visible'));
});

test('process-steps omits the CTA without a url', async () => {
	const html = await render('process-steps', { ...fixture('process-steps', 'default'), ctaUrl: '' });
	assert.ok(!html.includes('__cta'));
	assert.ok(!html.includes('href=""'));
});

test('components tolerate missing items and null entries', async () => {
	for (const [block, key] of [ ['trust-strip', 'items'], ['feature-pillars', 'items'], ['process-steps', 'items'], ['product-specs', 'rows'] ]) {
		const base = fixture(block, 'default');
		await render(block, { ...base, [key]: undefined });
		await render(block, { ...base, [key]: [ null, undefined ] });
	}
});
