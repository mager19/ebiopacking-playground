// Bloques estáticos con Interactivity API (Tarea 7): announcement-bar, faq, product-gallery.
// Mejora progresiva (D9): el servidor entrega todo desplegado y los controles solo-JS con `hidden`.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { loadBlock, loadHarness, readFixtures } from './load-block.mjs';
import { checkSsr } from '../parity/parity.mjs';

const { wp } = await loadHarness();
const BLOCKS = [ 'announcement-bar', 'faq', 'product-gallery' ];

async function render( block, attributes, state ) {
	const { Component } = await loadBlock( block );
	const context = state ? { 'ebio/state': state } : {};
	return renderToStaticMarkup( React.createElement( Component, { attributes, context } ) );
}
async function saved( block, attributes ) {
	const { metadata, settings } = await loadBlock( block );
	if ( ! wp.blocks.getBlockType( metadata.name ) ) wp.blocks.registerBlockType( metadata, settings );
	return wp.blocks.serialize( wp.blocks.createBlock( metadata.name, attributes, [] ) ).replace( /<!-- \/?wp:[\s\S]*?-->/g, '' ).trim();
}
const fixture = ( block, name ) => readFixtures( block ).find( ( fx ) => fx.name === name ).attributes;
const count = ( html, needle ) => html.split( needle ).length - 1;

test( 'faq server markup is expanded', async () => {
	const html = await render( 'faq', fixture( 'faq', 'default' ) );
	assert.ok( html.includes( 'data-hydrated="false"' ) );
	assert.ok( html.includes( 'data-wp-bind--data-hydrated="context.hydrated"' ) );
	assert.ok( html.includes( 'data-wp-context="{&quot;hydrated&quot;:false}"' ) );
	assert.ok( ! /\shidden(=|\s|>)/.test( html ), 'ninguna respuesta con hidden en el servidor' );
	assert.equal( count( html, 'data-open="true"' ), 4 );
	assert.equal( count( html, 'aria-expanded="true"' ), 4 );
	assert.ok( html.includes( 'data-wp-context="{&quot;index&quot;:2,&quot;open&quot;:true}"' ) );
});

test( 'faq ids come from uid and the question heading is headingLevel + 1', async () => {
	const html = await render( 'faq', fixture( 'faq', 'default' ) );
	assert.ok( html.includes( 'aria-labelledby="ebio-faq-faq-a1-heading"' ) );
	assert.ok( html.includes( '<h2 class="ebio-faq__heading" id="ebio-faq-faq-a1-heading">' ) );
	assert.ok( html.includes( '<h3 class="ebio-faq__question"><button type="button" class="ebio-faq__toggle" id="ebio-faq-faq-a1-q0" aria-expanded="true" aria-controls="ebio-faq-faq-a1-a0"' ) );
	assert.ok( html.includes( 'class="ebio-faq__answer" id="ebio-faq-faq-a1-a0"' ) );
	const deeper = await render( 'faq', { ...fixture( 'faq', 'default' ), headingLevel: 3 } );
	assert.ok( deeper.includes( '<h4 class="ebio-faq__question">' ) );
});

test( 'faq hydrated states fold the answers like the Interactivity store', async () => {
	const attributes = fixture( 'faq', 'default' );
	const first = await render( 'faq', attributes, { hydrated: true, open: [ 0 ] } );
	assert.ok( first.includes( 'data-hydrated="true"' ) );
	assert.equal( count( first, 'data-open="true"' ), 1 );
	assert.equal( count( first, 'data-open="false"' ), 3 );
	assert.equal( count( first, 'aria-expanded="false"' ), 3 );
	assert.equal( count( first, ' hidden=""' ), 3 );
	const none = await render( 'faq', attributes, { hydrated: true, open: [] } );
	assert.equal( count( none, ' hidden=""' ), 4 );
	const second = await render( 'faq', attributes, { hydrated: true, open: [ 1 ] } );
	assert.ok( /data-open="true"[^>]*data-wp-context="\{&quot;index&quot;:1/.test( second ) );
});

test( 'faq omits the intro when empty and clamps to 8 items', async () => {
	const minimal = await render( 'faq', fixture( 'faq', 'minimal' ) );
	assert.ok( ! minimal.includes( 'ebio-faq__intro' ) );
	const many = await render( 'faq', { ...fixture( 'faq', 'minimal' ), items: Array.from( { length: 11 }, ( _, i ) => ( { question: `q${ i }`, answer: 'a' } ) ) } );
	assert.equal( count( many, 'class="ebio-faq__item"' ), 8 );
});

test( 'gallery js-only controls hidden', async () => {
	const html = await render( 'product-gallery', fixture( 'product-gallery', 'default' ) );
	assert.ok( html.includes( '<ul class="ebio-product-gallery__thumbs" hidden="" data-wp-bind--hidden="!context.hydrated">' ) );
	assert.ok( /class="ebio-product-gallery__zoom ebio-button ebio-button--icon"[^>]*\shidden=""/.test( html ) );
	assert.ok( html.includes( 'data-hydrated="false"' ) );
	assert.equal( count( html, 'class="ebio-product-gallery__slide"' ), 4, 'las cuatro fotos desplegadas' );
	assert.ok( ! /class="ebio-product-gallery__slide"[^>]*\shidden/.test( html ), 'ninguna foto con hidden en el servidor' );
	assert.equal( count( html, 'fetchpriority="high"' ), 1 );
	assert.ok( html.includes( 'Ver foto 1 de 4' ) && html.includes( 'Ver foto 4 de 4' ) );
	assert.equal( count( html, 'class="ebio-product-gallery__thumb-image wp-image-81" src="/wp-content/uploads/2026/11/telescopica-principal.webp" width="1200" height="1200" alt=""' ), 1 );
	assert.ok( html.includes( 'role="group" aria-label="Fotos del producto"' ) );
	assert.ok( html.includes( '<dialog class="ebio-product-gallery__dialog" aria-label="Foto ampliada"' ) );
});

test( 'gallery with one photo has no thumbnails and keeps the zoom button', async () => {
	const html = await render( 'product-gallery', fixture( 'product-gallery', 'minimal' ) );
	assert.ok( ! html.includes( '__thumbs' ) );
	assert.ok( ! html.includes( ' de 1' ) );
	assert.ok( html.includes( 'ebio-product-gallery__zoom' ) );
	assert.ok( html.includes( 'data-wp-context="{&quot;active&quot;:0,&quot;count&quot;:1,&quot;hydrated&quot;:false}"' ) );
});

test( 'gallery hydrated states follow the active photo and the zoom dialog', async () => {
	const attributes = fixture( 'product-gallery', 'default' );
	const third = await render( 'product-gallery', attributes, { hydrated: true, active: 2 } );
	assert.ok( third.includes( 'data-hydrated="true"' ) );
	assert.equal( count( third, 'aria-pressed="true"' ), 1 );
	assert.equal( count( third, 'aria-pressed="false"' ), 3 );
	assert.ok( ! third.includes( 'class="ebio-product-gallery__thumbs" hidden' ) );
	const slides = third.match( /<li class="ebio-product-gallery__slide"[^>]*>/g );
	assert.deepEqual( slides.map( ( tag ) => / hidden=""/.test( tag ) ), [ true, true, false, true ] );
	const zoom = await render( 'product-gallery', attributes, { hydrated: true, zoom: true } );
	assert.ok( /<dialog[^>]*\sopen=""/.test( zoom ) );
	assert.ok( zoom.includes( 'class="ebio-product-gallery__dialog-image" src="/wp-content/uploads/2026/11/telescopica-principal.webp"' ) );
});

test( 'announcement-bar context key is the dismissKey and the markup follows the attributes', async () => {
	const html = await render( 'announcement-bar', fixture( 'announcement-bar', 'long-content' ) );
	assert.ok( html.includes( 'data-wp-context="{&quot;key&quot;:&quot;v2&quot;,&quot;dismissed&quot;:false}"' ) );
	assert.ok( html.includes( 'data-wp-init="callbacks.restore"' ) );
	assert.ok( html.includes( 'data-wp-bind--hidden="context.dismissed"' ) );
	assert.ok( html.includes( 'data-wp-on--click="actions.dismiss"' ) );
	assert.ok( html.includes( '</span> <a class="ebio-announcement-bar__link" href="/cotizar/">' ), 'espacio entre mensaje y enlace' );
	const minimal = await render( 'announcement-bar', fixture( 'announcement-bar', 'minimal' ) );
	assert.ok( ! minimal.includes( '__close' ) );
	assert.ok( ! minimal.includes( '__link' ) );
	const bad = await render( 'announcement-bar', { ...fixture( 'announcement-bar', 'default' ), dismissKey: 'Año Nuevo!' } );
	assert.ok( bad.includes( 'data-wp-context="{&quot;key&quot;:&quot;v1&quot;,&quot;dismissed&quot;:false}"' ), 'clave inválida cae en v1 (D8: solo ASCII)' );
	const dismissed = await render( 'announcement-bar', fixture( 'announcement-bar', 'default' ), { dismissed: true } );
	assert.ok( /^<div class="ebio-announcement-bar"[^>]*\shidden=""/.test( dismissed ) );
});

for ( const block of BLOCKS ) {
	test( `${ block }: data-wp-context values are ASCII-safe (D8)`, async () => {
		for ( const fx of readFixtures( block ) ) {
			const html = await render( block, fx.attributes );
			for ( const [ , raw ] of html.matchAll( /data-wp-context="([^"]*)"/g ) ) {
				const ctx = JSON.parse( raw.replaceAll( '&quot;', '"' ) );
				for ( const value of Object.values( ctx ) ) {
					const ok = value === null || typeof value === 'boolean' || Number.isInteger( value ) || ( typeof value === 'string' && /^[a-z0-9-]*$/.test( value ) );
					assert.ok( ok, `${ block } :: ${ fx.name }: valor de contexto no permitido ${ JSON.stringify( value ) }` );
				}
			}
		}
	});

	test( `interactive statics ssr no-effect :: ${ block }`, async () => {
		for ( const fx of readFixtures( block ) ) {
			const result = await checkSsr( await saved( block, fx.attributes ) );
			assert.ok( result.ok, `${ block } :: ${ fx.name }: SSR con efecto\n${ result.diff }` );
		}
	});
}
