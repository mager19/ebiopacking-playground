// block.json y fixtures.json de cada bloque frente al contrato (docs/blocks/catalog.md y docs/blocks/<b>.md).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { blockNames, BLOCKS_DIR, COMPONENTS_DIR, DOCS_DIR, pascalCase, readBlockJson, readFixtures } from './load-block.mjs';

const catalog = fs.readFileSync(path.join(DOCS_DIR, 'catalog.md'), 'utf8');

// supports común: el bloque ```json de catalog §2.3.
const section23 = catalog.slice(catalog.indexOf('### 2.3'));
const COMMON = JSON.parse(/```json\n([\s\S]*?)```/.exec(section23)[1]);

// Tabla §1: tipo (estático/dinámico) e Interactivity API (sí/no) por bloque.
const table = {};
for (const m of catalog.matchAll(/^\|\s*\[`ebio\/([a-z-]+)`\]\([^)]*\)[^|]*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|/gm)) {
	table[m[1]] = { dynamic: m[2].startsWith('dinámico'), interactive: m[3].startsWith('sí') };
}

const contractFixtures = (name) => {
	const md = fs.readFileSync(path.join(DOCS_DIR, `${name}.md`), 'utf8');
	const section = md.slice(md.indexOf('## Fixtures'));
	return JSON.parse(/```json\n([\s\S]*?)```/.exec(section)[1]);
};

test('catalog §2.3 and §1 are readable', () => {
	assert.equal(COMMON.apiVersion, 3);
	assert.equal(typeof COMMON.supports, 'object');
	assert.ok(Object.keys(table).length >= 27, `tabla §1 con ${Object.keys(table).length} bloques`);
});

for (const name of blockNames()) {
	test(`${name}: block.json follows catalog §2.3`, () => {
		const bj = readBlockJson(name);
		assert.equal(bj.name, `ebio/${name}`);
		assert.equal(bj.apiVersion, 3);
		assert.equal(bj.category, 'ebio');
		assert.equal(bj.textdomain, 'ebio-core');
		const { multiple, interactivity, ...supports } = bj.supports ?? {};
		assert.deepEqual(supports, COMMON.supports);
		const md = fs.readFileSync(path.join(DOCS_DIR, `${name}.md`), 'utf8');
		assert.equal(multiple === false, /"multiple": false/.test(md), 'supports.multiple === false solo si el contrato lo pide');
		assert.ok(multiple === undefined || multiple === false);

		const row = table[name];
		assert.ok(row, `ebio/${name} en la tabla §1 del catálogo`);
		assert.equal(Boolean(bj.render), row.dynamic, 'dinámico ⇔ "render"');
		assert.equal(fs.existsSync(path.join(BLOCKS_DIR, name, 'render.php')), row.dynamic, 'render.php solo en dinámicos');
		if (!row.dynamic) assert.ok(fs.existsSync(path.join(BLOCKS_DIR, name, 'save.jsx')), 'estático con save.jsx');
		const savePath = path.join(BLOCKS_DIR, name, 'save.jsx');
		if (row.dynamic && fs.existsSync(savePath)) {
			assert.match(fs.readFileSync(savePath, 'utf8'), /<InnerBlocks\.Content \/>/, 'dinámico con save.jsx: solo InnerBlocks.Content');
		}
		assert.equal(Boolean(bj.viewScriptModule), row.interactive, 'Interactivity API ⇔ viewScriptModule');
		if (bj.viewScriptModule) assert.deepEqual(interactivity, { clientNavigation: false });
		else assert.equal(interactivity, undefined);
		assert.ok(fs.existsSync(path.join(COMPONENTS_DIR, `${pascalCase(name)}.jsx`)), `src/components/${pascalCase(name)}.jsx`);
	});

	test(`${name}: fixtures.json is the contract's and covers every attribute`, () => {
		const bj = readBlockJson(name);
		const fixtures = readFixtures(name);
		assert.deepEqual(fixtures, contractFixtures(name), `fixtures.json igual a docs/blocks/${name}.md › Fixtures`);
		const names = fixtures.map((f) => f.name);
		for (const required of ['default', 'long-content', 'minimal']) assert.ok(names.includes(required), `fixture ${required}`);
		const keys = [...Object.keys(bj.attributes ?? {}), 'anchor'].sort();
		for (const fx of fixtures) {
			assert.deepEqual(Object.keys(fx.attributes ?? {}).sort(), keys, `fixture ${fx.name}: atributos de block.json ∪ anchor`);
			if (bj.render) assert.equal(typeof fx.context?.['ebio/view'], 'object', `fixture ${fx.name}: context['ebio/view']`);
		}
	});
}
