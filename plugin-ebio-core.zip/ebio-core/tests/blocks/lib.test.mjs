// Helpers JS compartidos por los bloques (src/components/lib, src/editor).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import React, { act } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { createRoot } from 'react-dom/client';
import { loadHarness, SRC_DIR } from './load-block.mjs';

const { lib, wp } = await loadHarness();
const h = React.createElement;
const html = (el) => renderToStaticMarkup(el);

test('rootProps builds the BEM root like ebio_root_attributes()', () => {
	assert.deepEqual(lib.rootProps('ebio-x', ['compact', false], { anchor: 'faq' }), { className: 'ebio-x ebio-x--compact', id: 'faq' });
	assert.deepEqual(lib.rootProps('ebio-x', [null, '', false], { anchor: '' }), { className: 'ebio-x' });
	assert.deepEqual(lib.rootProps('ebio-x', [], {}), { className: 'ebio-x' });
});

test('BlockImage prints nothing without id and the static image otherwise', () => {
	assert.equal(html(h(lib.BlockImage, { className: 'ebio-x__image', image: { id: 0, url: '', alt: '', width: 0, height: 0 } })), '');
	const out = html(h(lib.BlockImage, { className: 'ebio-x__image', image: { id: 12, url: 'https://e.test/a.jpg', alt: 'Caja', width: 800, height: 600 } }));
	assert.match(out, /class="ebio-x__image wp-image-12"/);
	assert.match(out, /decoding="async"/);
	assert.match(out, /width="800"/);
	assert.match(out, /height="600"/);
	assert.match(out, /alt="Caja"/);
	assert.match(out, /src="https:\/\/e\.test\/a\.jpg"/);
});

test('DynamicImage prints the view image as is and omits empty srcset/sizes', () => {
	assert.equal(html(h(lib.DynamicImage, { className: 'ebio-x__image', image: null })), '');
	const full = html(
		h(lib.DynamicImage, {
			className: 'ebio-x__image',
			image: { src: 'a.jpg', srcset: 'a.jpg 800w', sizes: '100vw', width: 800, height: 600, alt: 'Caja', loading: 'lazy' },
		})
	);
	assert.equal(full, '<img class="ebio-x__image" src="a.jpg" srcSet="a.jpg 800w" sizes="100vw" width="800" height="600" alt="Caja" loading="lazy" decoding="async"/>');
	const bare = html(h(lib.DynamicImage, { className: 'ebio-x__image', image: { src: 'a.jpg', srcset: '', sizes: '', width: 1, height: 1, alt: '', loading: 'lazy' } }));
	assert.doesNotMatch(bare, /srcSet|sizes/);
	assert.match(bare, /alt=""/);
});

test('RichField same html in save and render', () => {
	const field = h(lib.RichField, { tagName: 'p', className: 'ebio-x__text', value: 'Hola <strong>x</strong>' });
	const expected = '<p class="ebio-x__text">Hola <strong>x</strong></p>';
	// save(): WordPress serializa con @wordpress/element (RichText.Content); componente: react-dom.
	assert.equal(wp.element.renderToString(h(lib.SaveMode.Provider, { value: true }, field)), expected);
	assert.equal(html(h(lib.SaveMode.Provider, { value: false }, field)), expected);
	assert.equal(html(field), expected, 'SaveMode es false por defecto');
	const empty = h(lib.RichField, { tagName: 'p', className: 'ebio-x__text', value: '' });
	assert.equal(html(empty), '');
	assert.equal(wp.element.renderToString(h(lib.SaveMode.Provider, { value: true }, empty)), '');
});

test('no file under src/ uses RawHTML', () => {
	const walk = (dir) =>
		fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => (d.isDirectory() ? walk(path.join(dir, d.name)) : [path.join(dir, d.name)]));
	const offenders = walk(SRC_DIR).filter((f) => /\.(m?js|jsx)$/.test(f) && /\bRawHTML\b/.test(fs.readFileSync(f, 'utf8')));
	assert.deepEqual(offenders, []);
});

test('relative imports under src/ carry their extension (webpack + "type": "module")', () => {
	const walk = (dir) =>
		fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => (d.isDirectory() ? walk(path.join(dir, d.name)) : [path.join(dir, d.name)]));
	const bad = walk(SRC_DIR)
		.filter((f) => /\.(m?js|jsx)$/.test(f))
		.flatMap((f) =>
			[...fs.readFileSync(f, 'utf8').matchAll(/\bfrom\s+['"](\.{1,2}\/[^'"]+)['"]/g)]
				.filter((m) => !/\.(m?js|jsx|json)$/.test(m[1]))
				.map((m) => `${path.relative(SRC_DIR, f)}: ${m[1]}`)
		);
	assert.deepEqual(bad, []);
});

test('useUid regenerates duplicated uid', async () => {
	globalThis.IS_REACT_ACT_ENVIRONMENT = true;
	const { blocks, blockEditor, data } = wp;
	if (!blocks.getBlockType('ebio-test/uid')) {
		blocks.registerBlockType('ebio-test/uid', {
			apiVersion: 3,
			title: 'uid',
			category: 'text',
			attributes: { uid: { type: 'string', default: '' } },
			save: () => null,
		});
	}
	const first = blocks.createBlock('ebio-test/uid', { uid: 'faq-a1' });
	const copy = blocks.createBlock('ebio-test/uid', { uid: 'faq-a1' });
	const unique = blocks.createBlock('ebio-test/uid', { uid: 'faq-zz9' });
	const missing = blocks.createBlock('ebio-test/uid', { uid: '' });
	data.dispatch(blockEditor.store).resetBlocks([first, copy, unique, missing]);

	const seen = {};
	function Probe({ clientId }) {
		const attributes = data.useSelect((select) => select(blockEditor.store).getBlockAttributes(clientId), [clientId]);
		const { updateBlockAttributes } = data.useDispatch(blockEditor.store);
		seen[clientId] = lib.useUid(clientId, attributes, (next) => updateBlockAttributes(clientId, next), 'faq');
		return null;
	}
	const container = document.createElement('div');
	const root = createRoot(container);
	await act(async () => {
		root.render(h(React.Fragment, null, ...[first, copy, unique, missing].map((b) => h(Probe, { key: b.clientId, clientId: b.clientId }))));
	});
	const uid = (b) => data.select(blockEditor.store).getBlockAttributes(b.clientId).uid;
	const UID = /^[a-z0-9-]{1,32}$/;
	assert.equal(uid(first), 'faq-a1', 'el primero conserva su uid');
	assert.notEqual(uid(copy), 'faq-a1', 'el duplicado recibe otro uid');
	assert.match(uid(copy), UID);
	assert.match(uid(copy), /^faq-[a-z0-9]{6}$/);
	assert.equal(uid(unique), 'faq-zz9', 'un uid único no cambia');
	assert.match(uid(missing), /^faq-[a-z0-9]{6}$/, 'sin uid se genera uno');
	assert.equal(new Set([first, copy, unique, missing].map(uid)).size, 4);
	assert.equal(seen[copy.clientId], uid(copy), 'el hook devuelve el uid vigente');
	await act(async () => root.unmount());
});

test('ImageControl warns when a required image has no alt text', async () => {
	globalThis.IS_REACT_ACT_ENVIRONMENT = true;
	const text = async (value) => {
		const container = document.createElement('div');
		const root = createRoot(container);
		await act(async () => root.render(h(lib.ImageControl, { label: 'Imagen', value, onChange() {}, required: true })));
		const out = container.textContent;
		await act(async () => root.unmount());
		return out;
	};
	const withoutAlt = await text({ id: 3, url: 'a.jpg', alt: '', width: 1, height: 1 });
	assert.match(withoutAlt, /Texto alternativo \(obligatorio\)/);
	assert.match(withoutAlt, /Falta el texto alternativo \(obligatorio\)/);
	assert.doesNotMatch(await text({ id: 3, url: 'a.jpg', alt: 'Caja', width: 1, height: 1 }), /Falta el texto alternativo/);
	assert.doesNotMatch(await text({ id: 0, url: '', alt: '', width: 0, height: 0 }), /Falta el texto alternativo/);
});
