// El rol `wp` no escribe CSS ni estilos en línea, y solo emite clases del contrato (spec §10, catalog §2.1).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { blockNames, loadBlock, readFixtures, SRC_DIR } from './load-block.mjs';

const ALLOWED_CLASS = /^(ebio-|wp-image-|wp-block-|is-style-)/;

const walk = (dir) =>
	fs.existsSync(dir)
		? fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => (d.isDirectory() ? walk(path.join(dir, d.name)) : [path.join(dir, d.name)]))
		: [];
const files = walk(SRC_DIR);
const sources = files.filter((f) => /\.(m?js|jsx|php)$/.test(f));
const rel = (f) => path.relative(SRC_DIR, f);

/** Clases literales de un archivo: className="…", className={ '…' }, class="…" (sin expresiones). */
function literalClasses(source) {
	const found = [];
	const patterns = [/className=\{?\s*(["'])([^"'{}$]*)\1/g, /className=\{\s*`([^`$]*)`\s*\}/g, /\bclass=(["'])([^"'<$]*)\1/g];
	for (const re of patterns) {
		for (const m of source.matchAll(re)) found.push(...(m[2] ?? m[1]).split(/\s+/).filter(Boolean));
	}
	return found;
}

test('no .css or .scss under src/', () => {
	assert.deepEqual(files.filter((f) => /\.s?css$/.test(f)).map(rel), []);
});

test('no inline style in src/**/*.{js,jsx,php}', () => {
	assert.deepEqual(sources.filter((f) => /\bstyle=\{?/.test(fs.readFileSync(f, 'utf8'))).map(rel), []);
});

test('literal class names only use ebio-, wp-image-, wp-block- or is-style-', () => {
	const bad = sources.flatMap((f) => literalClasses(fs.readFileSync(f, 'utf8')).filter((c) => !ALLOWED_CLASS.test(c)).map((c) => `${rel(f)}: ${c}`));
	assert.deepEqual(bad, []);
});

test('literalClasses finds the class literals it guards', () => {
	assert.deepEqual(literalClasses('<p className="ebio-x__a foo">'), ['ebio-x__a', 'foo']);
	assert.deepEqual(literalClasses("<p className={ 'bar' }>"), ['bar']);
	assert.deepEqual(literalClasses('<p className={`baz qux`}>'), ['baz', 'qux']);
	assert.deepEqual(literalClasses('<span class="ebio-icon">'), ['ebio-icon']);
	assert.deepEqual(literalClasses('<div <?php echo ebio_root_attributes(); ?>>'), []);
});

for (const name of blockNames()) {
	test(`${name}: rendered fixtures only carry contract classes`, async () => {
		const { Component } = await loadBlock(name);
		for (const fx of readFixtures(name)) {
			const html = renderToStaticMarkup(React.createElement(Component, { attributes: fx.attributes, context: fx.context ?? {} }));
			assert.doesNotMatch(html, /\sstyle=/, `${fx.name}: atributo style`);
			const classes = [...html.matchAll(/\sclass="([^"]*)"/g)].flatMap((m) => m[1].split(/\s+/).filter(Boolean));
			assert.deepEqual(classes.filter((c) => !ALLOWED_CLASS.test(c)), [], `${fx.name}: clases fuera del contrato`);
		}
	});
}
