// EditContext + RichField: edición en línea sin cambiar el HTML guardado.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { loadHarness } from './load-block.mjs';

const { lib } = await loadHarness();
const { RichField, SaveMode, EditContext, makeEditContext, setIn } = lib;
const field = ( props ) => React.createElement( RichField, { tagName: 'p', className: 'x', ...props } );

test( 'RichField without edit context emits the plain view HTML (save() is covered by roundtrip.test)', () => {
	const view = renderToStaticMarkup( field( { value: 'a &lt; b', path: [ 'items', 0, 'text' ] } ) );
		assert.equal( view, '<p class="x">a &lt; b</p>' );
	assert.equal( renderToStaticMarkup( field( { value: '', path: 'text' } ) ), '' );
});

test( 'RichField with edit context renders an editable RichText, even when empty', () => {
	const ctx = { onChange() {} };
	for ( const value of [ 'hola', '' ] ) {
		const html = renderToStaticMarkup( React.createElement( EditContext.Provider, { value: ctx }, field( { value, path: 'text' } ) ) );
		assert.match( html, /contenteditable="true"/ );
		assert.match( html, /class="[^"]*\bx\b/ );
	}
});

test( 'makeEditContext writes nested paths without mutating', () => {
	const attributes = { heading: 'h', items: [ { value: 'a' }, { value: 'b' } ] };
	let saved;
	makeEditContext( attributes, ( patch ) => ( saved = patch ) ).onChange( [ 'items', 1, 'value' ], '5 &lt; 10' );
	assert.deepEqual( saved, { items: [ { value: 'a' }, { value: '5 &lt; 10' } ] } );
	assert.equal( attributes.items[ 1 ].value, 'b' );
	makeEditContext( attributes, ( patch ) => ( saved = patch ) ).onChange( 'heading', 'x' );
	assert.deepEqual( saved, { heading: 'x' } );
	assert.deepEqual( setIn( undefined, [ 'a', 'b' ], 1 ), { a: { b: 1 } } );
});
