// Filtros de `ebio/product-grid` (src/blocks/product-grid/filter.js) contra los casos compartidos con PHP.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { matches, parseSelection, toSearch } from '../../src/blocks/product-grid/filter.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const cases = JSON.parse(fs.readFileSync(path.join(here, 'product-grid-cases.json'), 'utf8'));

test('parseSelection gives the shared selections', () => {
	for (const c of cases.selection) {
		assert.deepEqual(parseSelection(c.query, cases.allowed), c.selection, `query "${c.query}"`);
	}
});

test('matches gives the shared results', () => {
	for (const c of cases.matches) {
		assert.equal(matches(c.facets, c.selection), c.matches, JSON.stringify(c));
	}
});

test('toSearch writes the ?formato=a,b form and round-trips', () => {
	assert.equal(toSearch({ categoria: [], sector: [], formato: [] }), '');
	assert.equal(toSearch({ categoria: [], sector: [], formato: ['gran-formato'] }), '?formato=gran-formato');
	assert.equal(toSearch({ categoria: ['a'], sector: [], formato: ['b', 'c'] }), '?categoria=a&formato=b,c');
	const selection = { categoria: [], sector: ['industria'], formato: ['a-medida', 'gran-formato'] };
	assert.deepEqual(parseSelection(toSearch(selection)), selection);
});

test('parseSelection without allow-list still strips unsafe characters', () => {
	assert.deepEqual(parseSelection('?formato=%3Cscript%3E').formato, ['script']);
});
