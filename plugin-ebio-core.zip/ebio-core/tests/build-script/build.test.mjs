import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const pluginRoot = path.resolve(here, '../..');
const script = path.join(pluginRoot, 'scripts/build.mjs');

test('build compila viewScriptModule y editorScript, y limpia la salida antes', { timeout: 240_000 }, () => {
	const out = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-build-'));
	try {
		fs.writeFileSync(path.join(out, 'stale.txt'), 'de una compilación anterior');
		const res = spawnSync('node', [script, '--src=tests/build-fixture', `--out=${out}`], {
			cwd: pluginRoot,
			encoding: 'utf8',
		});
		assert.equal(res.status, 0, res.stdout + res.stderr);

		const block = path.join(out, 'fixture-block');
		for (const file of ['block.json', 'index.js', 'index.asset.php', 'view.js', 'view.asset.php']) {
			assert.ok(fs.existsSync(path.join(block, file)), `falta ${file} en la salida`);
		}
		// view.js se compila como módulo: sus dependencias son ids de script module.
		assert.match(fs.readFileSync(path.join(block, 'view.asset.php'), 'utf8'), /@wordpress\/interactivity/);
		assert.equal(fs.existsSync(path.join(out, 'stale.txt')), false, 'la salida previa debe limpiarse');
	} finally {
		fs.rmSync(out, { recursive: true, force: true });
	}
});

test('one build emits blocks and editor', { timeout: 600_000 }, () => {
	const res = spawnSync('node', [script], { cwd: pluginRoot, encoding: 'utf8' });
	assert.equal(res.status, 0, res.stdout + res.stderr);
	for (const file of ['build/blocks/faq/view.js', 'build/editor/index.js', 'build/editor/index.asset.php']) {
		assert.ok(fs.existsSync(path.join(pluginRoot, file)), `falta ${file} tras un solo build`);
	}
	assert.equal(fs.existsSync(path.join(pluginRoot, 'build/editor/blocks')), false, 'la compilación del editor no duplica los bloques');
});

test('cleans output even without blocks', () => {
	const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-build-empty-'));
	try {
		const src = path.join(tmp, 'src');
		const out = path.join(tmp, 'blocks');
		fs.mkdirSync(src);
		fs.mkdirSync(out);
		fs.writeFileSync(path.join(out, 'old.txt'), 'viejo');
		const res = spawnSync('node', [script, `--src=${src}`, `--out=${out}`], { cwd: pluginRoot, encoding: 'utf8' });
		assert.equal(res.status, 0, res.stdout + res.stderr);
		assert.equal(fs.existsSync(path.join(out, 'old.txt')), false, 'old.txt debe borrarse');
	} finally {
		fs.rmSync(tmp, { recursive: true, force: true });
	}
});
