// Los `overrides` de la raíz fijan el tren de @wordpress/* (una sola versión por paquete): el lockfile no puede
// derivar de ellos ni traer un @wordpress/* sin override.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const lock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8'));
const overrides = pkg.overrides ?? {};

/** `{ "@wordpress/data": Set { "10.55.0" } }` con todas las copias instaladas en el lockfile. */
function installedVersions() {
	const found = {};
	for (const [location, entry] of Object.entries(lock.packages ?? {})) {
		const match = /(?:^|\/)node_modules\/(@wordpress\/[^/]+)$/.exec(location);
		if (match && !entry.link) (found[match[1]] ??= new Set()).add(entry.version);
	}
	return found;
}

test('every override is pinned to an exact version', () => {
	for (const [name, version] of Object.entries(overrides)) {
		assert.match(version, /^\d+\.\d+\.\d+$/, `${name}: el override debe ser una versión exacta, no "${version}"`);
	}
});

test('lockfile installs exactly the overridden version of each @wordpress package', () => {
	const installed = installedVersions();
	for (const [name, version] of Object.entries(overrides)) {
		assert.ok(installed[name], `${name}: override sin paquete en el lockfile (¿sobra?)`);
		assert.deepEqual([...installed[name]], [version], `${name}: el lockfile deriva del override`);
	}
});

test('no @wordpress package escapes the overrides', () => {
	const missing = Object.keys(installedVersions()).filter((name) => !(name in overrides));
	assert.deepEqual(missing, [], 'agrega un override en package.json para cada @wordpress/* nuevo');
});

test('overrides have no duplicate keys in the source file', () => {
	const source = fs.readFileSync(path.join(root, 'package.json'), 'utf8');
	const block = /"overrides"\s*:\s*\{([\s\S]*?)\n\s*\}/.exec(source)?.[1] ?? '';
	const keys = [...block.matchAll(/"(@[^"]+)"\s*:/g)].map((m) => m[1]);
	assert.equal(new Set(keys).size, keys.length, 'claves duplicadas en overrides');
	assert.equal(keys.length, Object.keys(overrides).length);
});
