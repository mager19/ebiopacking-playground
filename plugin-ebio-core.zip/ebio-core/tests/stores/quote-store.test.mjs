// Store `ebio/quote` (src/stores/quote/store.js) con un doble de la Interactivity API: cada bloque con
// viewScriptModule empaqueta su propia copia de store.js, así que se cargan dos bundles como en el sitio.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url));
const FAKE = path.join(here, 'fake-interactivity.mjs');
const STORE = path.resolve(here, '../../src/stores/quote/store.js');
const KEY = 'ebio-quote-v1';
const ids = (list) => list.map((item) => item.id);
const stored = (list) => JSON.stringify({ v: 1, items: list.map((id) => ({ id, quantity: '', dimensions: '', notes: '' })) });

// Navegador falso: localStorage en memoria, oyentes contados y temporizadores que no corren solos.
const data = new Map([[KEY, stored([1])]]);
const listeners = [];
globalThis.window = {
	localStorage: {
		getItem: (k) => (data.has(k) ? data.get(k) : null),
		setItem: (k, v) => data.set(k, String(v)),
		removeItem: (k) => data.delete(k),
	},
	addEventListener: (type, fn) => listeners.push({ type, fn }),
};
const timers = [];
globalThis.setTimeout = (fn) => timers.push(fn);
globalThis.clearTimeout = () => {};

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-quote-store-'));
after(() => fs.rmSync(dir, { recursive: true, force: true }));

async function bundle(name) {
	const outfile = path.join(dir, `${name}.mjs`);
	await build({
		entryPoints: [STORE],
		outfile,
		bundle: true,
		format: 'esm',
		platform: 'neutral',
		logLevel: 'silent',
		plugins: [{ name: 'fake-interactivity', setup: (b) => b.onResolve({ filter: /^@wordpress\/interactivity$/ }, () => ({ path: FAKE, external: true })) }],
	});
	return import(pathToFileURL(outfile).href);
}

const fake = await import(pathToFileURL(FAKE).href);
await bundle('site-header-view');
await bundle('product-grid-view');
const { state, actions } = fake.store('ebio/quote');
const storageListeners = () => listeners.filter((l) => l.type === 'storage');
const event = { preventDefault() {} };

test('store registers once across bundles', () => {
	assert.equal(fake.calls.definitions.filter((ns) => ns === 'ebio/quote').length, 1, 'una sola definición de ebio/quote');
	assert.equal(storageListeners().length, 1, 'un solo oyente de storage');
	assert.deepEqual(ids(state.items), [1], 'lista leída del almacenamiento al cargar');
});

test('addFromCard re-reads storage before writing (no lost update between tabs)', () => {
	// Otra pestaña agregó el 2; el evento storage aún no llegó.
	data.set(KEY, stored([1, 2]));
	fake.scope({ productId: 3, inList: false });
	actions.addFromCard(event);
	assert.deepEqual(ids(state.items), [1, 2, 3]);
	assert.deepEqual(ids(JSON.parse(data.get(KEY)).items), [1, 2, 3]);
	assert.equal(state.toastText, 'Agregado a tu cotización (3 productos)');
	assert.equal(state.toastVisible, true);
});

test('storage event syncs the list', () => {
	data.set(KEY, stored([4]));
	storageListeners()[0].fn({ key: KEY });
	assert.deepEqual(ids(state.items), [4]);
	assert.equal(state.count, 1);
	assert.equal(state.counterLabel, 'Mi cotización, 1 producto');
	state.quoteLabel = 'Mi lista';
	assert.equal(state.counterLabel, 'Mi lista, 1 producto', 'el nombre accesible empieza por quoteLabel');
	state.quoteLabel = 'Mi cotización';
});

test('cardDisabled is true only when the list is full, and full still shows the toast', () => {
	const thirty = Array.from({ length: 30 }, (_, i) => i + 1);
	data.set(KEY, stored(thirty));
	storageListeners()[0].fn({ key: KEY });
	state.toastVisible = false;

	fake.scope({ productId: 999, inList: false });
	assert.equal(state.cardState, 'full');
	assert.equal(state.cardDisabled, true);
	actions.addFromCard(event);
	assert.equal(state.items.length, 30, 'no agrega');
	assert.equal(state.toastVisible, true);
	assert.equal(state.toastText, 'Tu lista llegó al máximo de 30 productos');

	fake.scope({ productId: 5, inList: true });
	assert.equal(state.cardState, 'in-list');
	assert.equal(state.cardDisabled, null, 'nunca false (D8)');
	data.set(KEY, stored([1]));
	storageListeners()[0].fn({ key: KEY });
	fake.scope({ productId: 999, inList: false });
	assert.equal(state.cardState, 'idle');
	assert.equal(state.cardDisabled, null);
});
