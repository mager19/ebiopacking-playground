// Store `ebio/carousel` (src/stores/carousel/store.js) con un doble de la Interactivity API y una pista
// falsa: cada bloque con viewScriptModule empaqueta su propia copia, así que se cargan dos bundles.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url));
const FAKE = path.join(here, 'fake-interactivity.mjs');
const STORE = path.resolve(here, '../../src/stores/carousel/store.js');

let reduced = false;
globalThis.window = { matchMedia: () => ({ matches: reduced }) };

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-carousel-store-'));
after(() => fs.rmSync(dir, { recursive: true, force: true }));

async function bundle(name) {
	const outfile = path.join(dir, `${name}.mjs`);
	await build({
		entryPoints: [STORE],
		outfile,
		bundle: true,
		format: 'esm',
		platform: 'neutral',
		logLevel: 'silent',
		plugins: [{ name: 'fake-interactivity', setup: (b) => b.onResolve({ filter: /^@wordpress\/interactivity$/ }, () => ({ path: FAKE, external: true })) }],
	});
	return import(pathToFileURL(outfile).href);
}

/** Pista de 7 tarjetas de 280 px con 20 px de separación y 900 px visibles (3 caben). */
function makeTrack({ count = 7, scrollLeft = 0 } = {}) {
	const scrolls = [];
	const track = {
		children: Array.from({ length: count }, (_, i) => ({ offsetLeft: 10 + i * 300, offsetWidth: 280 })),
		clientWidth: 900,
		scrollWidth: count * 300,
		scrollLeft,
		scrolls,
		matches: (selector) => selector === '[id$="-track"]',
		scrollTo(options) {
			scrolls.push(options);
		},
	};
	return track;
}

/** Elemento (botón o raíz) cuya raíz contiene la pista. */
const within = (track) => ({ closest: () => ({ querySelector: () => track }) });

const fake = await import(pathToFileURL(FAKE).href);
await bundle('product-carousel-view');
await bundle('testimonials-view');
const { state, actions, callbacks } = fake.store('ebio/carousel');

test('store registers once across bundles', () => {
	assert.equal(fake.calls.definitions.filter((ns) => ns === 'ebio/carousel').length, 1);
});

test('isFirst and isLast follow the context and how many cards fit', () => {
	const track = makeTrack();
	fake.scope({ index: 0, count: 7, hydrated: true }, within(track));
	assert.equal(state.isFirst, true);
	assert.equal(state.isLast, false);
	fake.scope({ index: 4, count: 7, hydrated: true }, within(track));
	assert.equal(state.isFirst, false);
	assert.equal(state.isLast, true, 'con 3 por vista, el índice 4 es el último');
	fake.scope({ index: 0, count: 1, hydrated: true }, within(makeTrack({ count: 1 })));
	assert.equal(state.isLast, true, 'una sola tarjeta');
});

test('init shows the controls, counts real slides and never autoplays', () => {
	const track = makeTrack({ count: 5 });
	const context = { index: 0, count: 99, hydrated: false };
	fake.scope(context, track);
	callbacks.init();
	assert.equal(context.hydrated, true);
	assert.equal(context.count, 5);
	assert.equal(context.index, 0);
	assert.deepEqual(track.scrolls, [], 'no se desplaza solo');
});

test('next moves a page, prev moves back, both clamp at the ends', () => {
	const track = makeTrack();
	const context = { index: 0, count: 7, hydrated: true };
	fake.scope(context, within(track));
	actions.next();
	assert.equal(context.index, 3);
	assert.deepEqual(track.scrolls.at(-1), { left: 900, behavior: 'smooth' });
	track.scrollLeft = 900;
	actions.next();
	assert.equal(context.index, 4, 'se detiene en count - perView');
	track.scrollLeft = 1200;
	actions.prev();
	assert.equal(context.index, 1);
	track.scrollLeft = 300;
	actions.prev();
	assert.equal(context.index, 0);
});

test('prefers-reduced-motion scrolls without animation', () => {
	reduced = true;
	const track = makeTrack();
	fake.scope({ index: 0, count: 7, hydrated: true }, within(track));
	actions.next();
	assert.equal(track.scrolls.at(-1).behavior, 'auto');
	reduced = false;
});

test('syncIndex follows native scrolling, the end of the track included', () => {
	const track = makeTrack();
	const context = { index: 0, count: 7, hydrated: true };
	track.scrollLeft = 610;
	fake.scope(context, track);
	callbacks.syncIndex();
	assert.equal(context.index, 2);
	track.scrollLeft = track.scrollWidth - track.clientWidth;
	callbacks.syncIndex();
	assert.equal(context.index, 4, 'al final exacto: último índice posible');
	track.scrollLeft = 0;
	callbacks.syncIndex();
	assert.equal(context.index, 0);
});
