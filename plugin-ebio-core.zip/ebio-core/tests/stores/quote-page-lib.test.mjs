// Lógica pura de la página de cotización (`page-lib.js`): validación idéntica a la del servidor,
// cuerpo del POST, conciliación con el catálogo y errores de la respuesta REST.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import {
	buildListItems,
	countText,
	mapErrorResponse,
	PAYLOAD_KEYS,
	reconcile,
	submitCountText,
	summaryTitle,
	toPayload,
	validateForm,
} from '../../src/stores/quote/page-lib.js';

const here = (rel) => fileURLToPath(new URL(rel, import.meta.url));

/** Los textos salen de `ebio_quote_messages()`: una sola fuente para servidor y JS. */
function loadMessages() {
	const php = readFileSync(here('../../includes/quote/messages.php'), 'utf8');
	const body = php.slice(php.indexOf('return array('));
	const messages = {};
	for (const m of body.matchAll(/'([a-z_]+)'\s*=>\s*'((?:[^'\\]|\\.)*)'/g)) {
		messages[m[1]] = m[2].replace(/\\'/g, "'");
	}
	return messages;
}
const messages = loadMessages();

const cases = JSON.parse(readFileSync(here('../../../../tests/blocks/quote-validation-cases.json'), 'utf8'));

/** Expande los marcadores `{{N}}` del archivo de casos: N caracteres. */
const expand = (value) => (typeof value === 'string' && /^\{\{\d+\}\}$/.test(value) ? 'x'.repeat(Number(value.slice(2, -2))) : value);

const FIELDS = ['company', 'name', 'email', 'phone', 'city', 'sector', 'message'];

test('messages parse from the PHP source', () => {
	assert.equal(messages.email, 'Escribe un correo válido.');
	assert.equal(messages.consent, 'Debes aceptar el tratamiento de datos.');
	assert.ok(Object.keys(messages).length >= 18);
});

test('validateForm matches server cases', () => {
	const fieldCases = cases.filter((c) => !('items' in c.input));
	assert.ok(fieldCases.length >= 9, 'hay casos de campos compartidos');
	for (const c of fieldCases) {
		const values = {};
		for (const f of FIELDS) values[f] = expand(c.input[f] ?? '');
		const consent = c.input.consent === '1';
		const expected = Object.fromEntries(Object.entries(c.fields));
		assert.deepEqual(validateForm(values, consent, messages), expected, c.name);
	}
});

test('validateForm trims and counts code points', () => {
	const ok = { company: '  ACME  ', name: ' Ana ', email: ' ana@example.com ', phone: ' +57 300 123-4567 ', city: '', sector: '', message: '' };
	assert.deepEqual(validateForm(ok, true, messages), {});
	const emoji = { ...ok, company: '😀'.repeat(120) };
	assert.deepEqual(validateForm(emoji, true, messages), {}, '120 emojis = 120 caracteres');
	assert.equal(validateForm({ ...ok, company: '😀'.repeat(121) }, true, messages).company, messages.company_long);
	assert.deepEqual(validateForm(ok, 'true', messages), { consent: messages.consent }, 'consent debe ser true');
});

test('toPayload exact keys', () => {
	const items = [
		{ id: 7, quantity: '500', quantityUnit: 'pallets', length: '60,5', width: '40', height: '', dimensionUnit: 'mm', notes: 'n' },
		{ id: 8, quantity: '1e3', quantityUnit: 'unidades', length: '-2', width: '0', height: 'abc', dimensionUnit: 'cm', notes: '' },
	];
	const payload = toPayload(
		{ company: ' ACME ', name: 'Ana', email: 'a@b.co', phone: '3100000000', city: '', sector: 'otro', message: ' hola ', website: '' },
		items,
		'nonce123'
	);
	assert.deepEqual(Object.keys(payload), [...PAYLOAD_KEYS]);
	assert.equal(payload._ebio_nonce, 'nonce123');
	assert.equal(payload.company, 'ACME');
	assert.equal(payload.message, 'hola');
	assert.equal(payload.consent, '1');
	assert.equal(payload.website, '');
	assert.deepEqual(payload.items, [
		{ product_id: 7, quantity: '500', quantity_unit: 'pallets', length: '60.5', width: '40', height: '', dimension_unit: 'mm', notes: 'n' },
		{ product_id: 8, quantity: '', quantity_unit: 'unidades', length: '', width: '', height: '', dimension_unit: 'cm', notes: '' },
	], 'números normalizados; lo que no es un número positivo va vacío');
	assert.ok(!('name' in payload.items[0]), 'nunca viaja el nombre del producto');
});

test('toPayload tolerates missing input', () => {
	const payload = toPayload(undefined, undefined, '');
	assert.deepEqual(Object.keys(payload), [...PAYLOAD_KEYS]);
	assert.deepEqual(payload.items, []);
});

test('reconcile drops unknown ids', () => {
	const catalog = { 1: { name: 'A' }, 3: { name: 'C' } };
	const items = [
		{ id: 1, quantity: '', dimensions: '', notes: '' },
		{ id: 2, quantity: '', dimensions: '', notes: '' },
		{ id: 3, quantity: '', dimensions: '', notes: '' },
	];
	assert.deepEqual(reconcile(items, catalog).map((i) => i.id), [1, 3]);
	assert.deepEqual(reconcile(items, {}), []);
	assert.deepEqual(reconcile(items, null), []);
	assert.deepEqual(reconcile(null, catalog), []);
	assert.deepEqual(reconcile([{ id: 'toString' }], catalog), [], 'no usa el prototipo del catálogo');
});

test('buildListItems crosses the catalog', () => {
	const catalog = { 5: { name: 'Caja', url: '/p/caja/', category: 'Industriales', image: { src: '/i.jpg', width: 10, height: 10 } } };
	const base = { quantity: '9', quantityUnit: 'pallets', length: '1', width: '2', height: '3', dimensionUnit: 'mm' };
	const [row] = buildListItems([{ id: 5, ...base, notes: 'n' }, { id: 6, quantity: '', notes: '' }], catalog);
	assert.equal(row.name, 'Caja');
	assert.equal(row.removeLabel, ': Caja');
	assert.deepEqual(row.fieldIds, {
		quantity: 'ebio-quote-item-5-quantity',
		quantityUnit: 'ebio-quote-item-5-quantityUnit',
		length: 'ebio-quote-item-5-length',
		width: 'ebio-quote-item-5-width',
		height: 'ebio-quote-item-5-height',
		dimensionUnit: 'ebio-quote-item-5-dimensionUnit',
		notes: 'ebio-quote-item-5-notes',
	});
	assert.deepEqual([row.quantity, row.quantityUnit, row.length, row.width, row.height, row.dimensionUnit], ['9', 'pallets', '1', '2', '3', 'mm']);
	assert.equal(row.notesOpen, true, 'con nota: abierta');
	assert.equal(buildListItems([{ id: 6 }], catalog).length, 0);

	const closed = { 5: catalog[5] };
	assert.equal(buildListItems([{ id: 5, ...base, notes: '' }], closed)[0].notesOpen, false, 'sin nota: cerrada');
	assert.equal(buildListItems([{ id: 5, ...base, notes: '' }], closed, [5])[0].notesOpen, true, 'abierta con "+ Agregar nota"');
});

test('count texts', () => {
	assert.equal(countText(0), '');
	assert.equal(countText(1), ' · 1 producto');
	assert.equal(countText(3), ' · 3 productos');
	assert.equal(submitCountText(0), '');
	assert.equal(submitCountText(1), ' (1 producto)');
	assert.equal(submitCountText(2), ' (2 productos)');
	assert.equal(summaryTitle(0), '');
	assert.equal(summaryTitle(1), 'Revisa 1 campo para enviar tu solicitud:');
	assert.equal(summaryTitle(4), 'Revisa 4 campos para enviar tu solicitud:');
});

test('mapErrorResponse', () => {
	assert.deepEqual(mapErrorResponse(400, { code: 'ebio_invalid', data: { fields: { email: 'x' } } }, messages), { fields: { email: 'x' }, formError: '' });
	assert.equal(mapErrorResponse(403, { code: 'ebio_bad_nonce' }, messages).formError, messages.bad_nonce_js);
	assert.equal(mapErrorResponse(429, { code: 'ebio_rate_limited' }, messages).formError, messages.rate_limited);
	assert.equal(mapErrorResponse(400, { code: 'ebio_spam' }, messages).formError, messages.spam);
	assert.equal(mapErrorResponse(500, { code: 'ebio_save_failed' }, messages).formError, messages.save_failed);
	assert.equal(mapErrorResponse(500, null, messages).formError, messages.invalid);
	assert.equal(mapErrorResponse(400, { code: 'ebio_invalid' }, messages).formError, messages.invalid, 'sin campos: mensaje general');
});
