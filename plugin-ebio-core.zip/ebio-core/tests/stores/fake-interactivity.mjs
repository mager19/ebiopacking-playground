// Doble mínimo de `@wordpress/interactivity` para probar src/stores/quote/store.js en Node.
// Una sola instancia compartida por todos los bundles que la importan (como el runtime real).
export const calls = { definitions: [] };
const stores = new Map();
let context = {};
let element = { ref: null };

export function store(namespace, definition) {
	if (definition) {
		calls.definitions.push(namespace);
		if (!stores.has(namespace)) stores.set(namespace, { state: definition.state ?? {}, actions: {}, callbacks: {} });
		const target = stores.get(namespace);
		Object.assign(target.actions, definition.actions ?? {});
		Object.assign(target.callbacks, definition.callbacks ?? {});
	}
	if (!stores.has(namespace)) stores.set(namespace, { state: {}, actions: {}, callbacks: {} });
	return stores.get(namespace);
}

export const getContext = () => context;
export const getElement = () => element;

/** Fija el contexto y el elemento de la siguiente llamada a una acción o getter. */
export function scope(nextContext, ref = null) {
	context = nextContext;
	element = { ref };
}
