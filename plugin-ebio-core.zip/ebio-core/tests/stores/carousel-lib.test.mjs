// Lógica pura del store `ebio/carousel` (docs/blocks/product-carousel.md): límites del índice.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { canNext, canPrev, clampIndex, maxIndex } from '../../src/stores/carousel/lib.js';

test('clampIndex keeps the first visible card within [0, count - perView]', () => {
	assert.equal(clampIndex(9, 7, 3), 4);
	assert.equal(clampIndex(2, 7, 3), 2);
	assert.equal(clampIndex(-3, 7, 3), 0);
	assert.equal(clampIndex(5, 2, 3), 0, 'todo cabe: siempre 0');
	assert.equal(clampIndex(5, 0, 3), 0, 'sin tarjetas');
	assert.equal(clampIndex('x', 7, 3), 0, 'valor inválido');
});

test('canNext is false at the last position and canPrev at the first', () => {
	assert.equal(canNext(4, 7, 3), false);
	assert.equal(canNext(3, 7, 3), true);
	assert.equal(canNext(0, 1, 1), false, 'una sola tarjeta');
	assert.equal(canNext(0, 2, 3), false, 'todo cabe');
	assert.equal(canPrev(0), false);
	assert.equal(canPrev(1), true);
});

test('perView below 1 is treated as 1', () => {
	assert.equal(maxIndex(7, 0), 6);
	assert.equal(canNext(5, 7, 0), true);
	assert.equal(canNext(6, 7, 0), false);
});
