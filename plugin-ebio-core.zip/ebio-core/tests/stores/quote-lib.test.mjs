// Lógica pura del store `ebio/quote` (catalog §4, D11): almacenamiento, límites y textos.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
	addItem,
	counterLabel,
	createStorage,
	DIMENSION_UNITS,
	fromLegacy,
	ITEM_FIELDS,
	LIMITS,
	MAX_ITEMS,
	parseDimensions,
	parseQuantity,
	parseStored,
	payloadNumber,
	QUANTITY_UNITS,
	removeItem,
	serializeItems,
	STORAGE_KEY,
	toastText,
	updateItem,
} from '../../src/stores/quote/lib.js';

const item = (id, extra = {}) => ({ id, quantity: '', quantityUnit: 'unidades', length: '', width: '', height: '', dimensionUnit: 'cm', notes: '', ...extra });
const legacy = (id, extra = {}) => ({ id, quantity: '', dimensions: '', notes: '', ...extra });
const many = (n, from = 1) => Array.from({ length: n }, (_, i) => item(from + i));

/** `window` falso con un localStorage en memoria; `throwOn` hace fallar ese método. */
function fakeWindow({ initial = {}, throwOn = [] } = {}) {
	const data = new Map(Object.entries(initial));
	const guard = (name) => {
		if (throwOn.includes(name)) throw new Error(`${name} bloqueado`);
	};
	return {
		data,
		localStorage: {
			getItem: (k) => (guard('getItem'), data.has(k) ? data.get(k) : null),
			setItem: (k, v) => (guard('setItem'), data.set(k, String(v))),
			removeItem: (k) => (guard('removeItem'), data.delete(k)),
		},
	};
}

test('constants match the backend limits', () => {
	assert.equal(STORAGE_KEY, 'ebio-quote-v1');
	assert.equal(MAX_ITEMS, 30);
	assert.deepEqual(LIMITS, { quantity: 9, length: 9, width: 9, height: 9, notes: 500 });
	assert.deepEqual(QUANTITY_UNITS, ['unidades', 'pallets']);
	assert.deepEqual(DIMENSION_UNITS, ['cm', 'mm']);
	assert.deepEqual(ITEM_FIELDS, ['quantity', 'quantityUnit', 'length', 'width', 'height', 'dimensionUnit', 'notes']);
});

test('parseStored drops malformed data', () => {
	assert.deepEqual(parseStored(null), []);
	assert.deepEqual(parseStored('no-json'), []);
	assert.deepEqual(parseStored('null'), []);
	assert.deepEqual(parseStored('[]'), []);
	assert.deepEqual(parseStored('{"v":3,"items":[{"id":1}]}'), [], 'otra versión');
	assert.deepEqual(parseStored('{"v":2,"items":{}}'), [], 'items no es lista');

	const raw = JSON.stringify({
		v: 2,
		items: [
			item(101, { quantity: '500', length: '60', width: '40', height: '40', notes: 'urgente' }),
			{ id: '102' },
			{ id: 1.5 },
			{ id: 0 },
			{ id: -3 },
			{ quantity: '1' },
			'texto',
			null,
			{ id: 101, quantity: 'duplicado' },
			{ id: 103, quantity: 7, quantityUnit: 'cajas', length: null, dimensionUnit: 'pulgadas', notes: ['x'] },
		],
	});
	assert.deepEqual(parseStored(raw), [item(101, { quantity: '500', length: '60', width: '40', height: '40', notes: 'urgente' }), item(103)]);

	assert.equal(parseStored(JSON.stringify({ v: 2, items: many(31) })).length, 30);
	const long = JSON.stringify({ v: 2, items: [item(5, { notes: 'n'.repeat(600), quantity: '1'.repeat(12), length: '2'.repeat(12) })] });
	assert.deepEqual(parseStored(long), [item(5, { notes: 'n'.repeat(500), quantity: '1'.repeat(9), length: '2'.repeat(9) })]);
});

test('parseStored migrates v1 lists without losing text', () => {
	const raw = JSON.stringify({
		v: 1,
		items: [
			legacy(101, { quantity: '500 unidades', dimensions: '60 × 40 × 40 cm', notes: 'urgente' }),
			legacy(102, { quantity: '1.000', dimensions: '600x400x400 mm' }),
			legacy(103, { quantity: '3 pallets' }),
			legacy(104, { quantity: 'unos 500', dimensions: '60 × 40', notes: 'impresa' }),
			legacy(105),
		],
	});
	assert.deepEqual(parseStored(raw), [
		item(101, { quantity: '500', length: '60', width: '40', height: '40', notes: 'urgente' }),
		item(102, { quantity: '1000', length: '600', width: '400', height: '400', dimensionUnit: 'mm' }),
		item(103, { quantity: '3', quantityUnit: 'pallets' }),
		item(104, { notes: 'Cantidad: unos 500\nMedidas: 60 × 40\nimpresa' }),
		item(105),
	]);
});

test('fromLegacy, parseQuantity, parseDimensions and payloadNumber', () => {
	assert.deepEqual(parseQuantity('500'), { quantity: '500', quantityUnit: 'unidades' });
	assert.deepEqual(parseQuantity('2 estibas'), { quantity: '2', quantityUnit: 'pallets' });
	assert.equal(parseQuantity('1.5'), null, 'decimal no es cantidad');
	assert.equal(parseQuantity('500 cajas'), null);
	assert.deepEqual(parseDimensions('60,5 X 40 * 30'), { length: '60.5', width: '40', height: '30', dimensionUnit: 'cm' });
	assert.equal(parseDimensions('60 × 40'), null);
	assert.equal(fromLegacy(legacy(1, { notes: 'n'.repeat(500), quantity: 'muchas' })).notes.length, 500, 'las notas siguen limitadas');
	assert.equal(payloadNumber('500', true), '500');
	assert.equal(payloadNumber('2.6', true), '3');
	assert.equal(payloadNumber('12,345'), '12.35');
	assert.equal(payloadNumber('0'), '');
	assert.equal(payloadNumber('-4'), '');
	assert.equal(payloadNumber('1e5'), '');
	assert.equal(payloadNumber('1234567'), '', 'medida fuera del límite del backend');
	assert.equal(payloadNumber(''), '');
	assert.equal(payloadNumber(undefined), '');
});

test('serializeItems round-trips through parseStored', () => {
	const items = [item(7, { quantity: '10' }), item(8)];
	assert.equal(serializeItems(items), JSON.stringify({ v: 2, items }));
	assert.deepEqual(parseStored(serializeItems(items)), items);
});

test('createStorage reads and writes localStorage', () => {
	const win = fakeWindow({ initial: { [STORAGE_KEY]: JSON.stringify({ v: 2, items: [item(9)] }) } });
	const storage = createStorage(win);
	assert.equal(storage.persistent, true);
	assert.deepEqual(storage.read(), [item(9)]);
	storage.write([item(10)]);
	assert.equal(win.data.get(STORAGE_KEY), JSON.stringify({ v: 2, items: [item(10)] }));
	assert.equal([...win.data.keys()].length, 1, 'la prueba de escritura no deja claves');
});

test('createStorage falls back to memory', () => {
	const blocked = createStorage(fakeWindow({ throwOn: ['setItem'] }));
	assert.equal(blocked.persistent, false);
	assert.deepEqual(blocked.read(), []);
	assert.doesNotThrow(() => blocked.write([item(1)]));

	const noStorage = createStorage({});
	assert.equal(noStorage.persistent, false);
	assert.deepEqual(noStorage.read(), []);

	const getterThrows = {};
	Object.defineProperty(getterThrows, 'localStorage', {
		get() {
			throw new Error('SecurityError');
		},
	});
	assert.equal(createStorage(getterThrows).persistent, false);
	assert.equal(createStorage(undefined).persistent, false);

	const readFails = createStorage(fakeWindow({ throwOn: ['getItem'] }));
	assert.deepEqual(readFails.read(), [], 'getItem que lanza → lista vacía');
});

test('addItem dedupes and updates', () => {
	const first = addItem([], { id: 101 });
	assert.equal(first.status, 'added');
	assert.deepEqual(first.items, [item(101)]);

	const second = addItem(first.items, { id: 101, quantity: '500' });
	assert.equal(second.status, 'updated');
	assert.deepEqual(second.items, [item(101, { quantity: '500' })]);

	const third = addItem(second.items, { id: 101, quantity: '', dimensions: '60 × 40 × 40 cm' });
	assert.equal(third.status, 'updated');
	assert.deepEqual(third.items, [item(101, { quantity: '500', length: '60', width: '40', height: '40' })], 'quantity vacía no pisa');
	assert.deepEqual(first.items, [item(101)], 'no muta la lista recibida');

	const fourth = addItem(third.items, { id: 101, quantity: '2 pallets', dimensions: 'según muestra' });
	assert.deepEqual(fourth.items, [item(101, { quantity: '2', quantityUnit: 'pallets', length: '60', width: '40', height: '40', notes: 'Medidas: según muestra' })], 'texto ilegible a notas');
	assert.deepEqual(addItem(fourth.items, { id: 101, dimensions: 'según muestra' }).items, fourth.items, 'no repite la misma nota');

	assert.deepEqual(addItem([], { id: 4, quantity: 'q'.repeat(45) }).items, [item(4, { notes: `Cantidad: ${'q'.repeat(45)}` })]);
});

test('addItem full at 30', () => {
	const full = many(30);
	const result = addItem(full, { id: 999 });
	assert.equal(result.status, 'full');
	assert.equal(result.items.length, 30);
	assert.equal(addItem(full, { id: 3, quantity: '2' }).status, 'updated', 'un producto que ya está se actualiza aunque la lista esté llena');
});

test('addItem rejects ids that are not positive integers', () => {
	for (const id of ['101', 0, -1, 1.5, null, undefined]) {
		const result = addItem([item(1)], { id });
		assert.equal(result.status, 'invalid', String(id));
		assert.deepEqual(result.items, [item(1)]);
	}
});

test('updateItem truncates', () => {
	const items = [item(1), item(2)];
	const updated = updateItem(items, 2, 'notes', 'n'.repeat(600));
	assert.equal(updated[1].notes.length, 500);
	assert.deepEqual(updated[0], item(1));
	assert.equal(updateItem(items, 1, 'quantity', '1'.repeat(12))[0].quantity.length, 9);
	assert.equal(updateItem(items, 1, 'length', '60.5')[0].length, '60.5', 'guarda el valor del input tal cual');
	assert.equal(updateItem(items, 1, 'notes', 'ñ'.repeat(501))[0].notes, 'ñ'.repeat(500), 'cuenta caracteres, no bytes');
	assert.equal(updateItem(items, 1, 'quantityUnit', 'pallets')[0].quantityUnit, 'pallets');
	assert.equal(updateItem(items, 1, 'quantityUnit', 'cajas')[0].quantityUnit, 'unidades', 'unidad desconocida → por defecto');
	assert.equal(updateItem(items, 1, 'dimensionUnit', 'mm')[0].dimensionUnit, 'mm');
	assert.deepEqual(updateItem(items, 1, 'id', 5), items, 'solo campos del ítem');
	assert.deepEqual(updateItem(items, 1, 'dimensions', 'x'), items, 'el campo de texto libre ya no existe');
	assert.deepEqual(updateItem(items, 77, 'notes', 'x'), items, 'id inexistente');
	assert.deepEqual(items, [item(1), item(2)], 'no muta');
});

test('removeItem returns the removed item', () => {
	const { items, removed } = removeItem([item(1), item(2, { quantity: '3' })], 2);
	assert.deepEqual(items, [item(1)]);
	assert.deepEqual(removed, item(2, { quantity: '3' }));
	assert.deepEqual(removeItem([item(1)], 5), { items: [item(1)], removed: null });
});

test('counterLabel singular/plural', () => {
	assert.equal(counterLabel(1), 'Mi cotización, 1 producto');
	assert.equal(counterLabel(0), 'Mi cotización, 0 productos');
	assert.equal(counterLabel(3), 'Mi cotización, 3 productos');
	assert.equal(counterLabel(2, 'Mi lista de cotización'), 'Mi lista de cotización, 2 productos', 'empieza por el texto visible (WCAG 2.5.3)');
	assert.equal(counterLabel(1, '  '), 'Mi cotización, 1 producto', 'quoteLabel vacío → por defecto');
});

test('createStorage stops persisting after a failed write', () => {
	const win = fakeWindow();
	const storage = createStorage(win);
	assert.equal(storage.persistent, true);
	win.localStorage.setItem = () => {
		throw new Error('QuotaExceededError');
	};
	assert.doesNotThrow(() => storage.write([item(1)]));
	assert.equal(storage.persistent, false, 'la lista sigue solo en memoria');
	assert.deepEqual(storage.read(), [], 'sin persistencia no se relee lo viejo');
});

test('toastText for added, updated and full', () => {
	assert.equal(toastText('added', 1), 'Agregado a tu cotización (1 producto)');
	assert.equal(toastText('updated', 3), 'Agregado a tu cotización (3 productos)');
	assert.equal(toastText('full', 30), 'Tu lista llegó al máximo de 30 productos');
});
