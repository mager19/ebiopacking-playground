// Store `ebio/product-grid` (src/stores/product-grid/store.js) con un doble de la Interactivity API y una
// raíz falsa con ítems. No necesita la compilación.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { build } from 'esbuild';

const here = path.dirname(fileURLToPath(import.meta.url));
const FAKE = path.join(here, 'fake-interactivity.mjs');
const STORE = path.resolve(here, '../../src/stores/product-grid/store.js');

const replaced = [];
globalThis.window = {
	location: { pathname: '/productos/', hash: '' },
	history: { state: null, replaceState: (...args) => replaced.push(args) },
};

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-grid-store-'));
after(() => fs.rmSync(dir, { recursive: true, force: true }));
const outfile = path.join(dir, 'store.mjs');
await build({
	entryPoints: [STORE],
	outfile,
	bundle: true,
	format: 'esm',
	platform: 'neutral',
	logLevel: 'silent',
	plugins: [{ name: 'fake-interactivity', setup: (b) => b.onResolve({ filter: /^@wordpress\/interactivity$/ }, () => ({ path: FAKE, external: true })) }],
});
await import(pathToFileURL(outfile).href);
const fake = await import(pathToFileURL(FAKE).href);
const { state, actions, callbacks } = fake.store('ebio/product-grid');

const FACETS = [
	{ categories: ['empaques-industriales'], sectors: ['industria'], formats: ['gran-formato'], hidden: false },
	{ categories: ['empaques-agro-flores'], sectors: ['floricultura'], formats: ['exportacion'], hidden: false },
];
const checkbox = (name, value, checked) => ({ name, value, checked });
const makeRoot = (boxes) => {
	const root = {
		querySelectorAll: (selector) => (selector === '.ebio-product-grid__item' ? FACETS.map((f) => ({ getAttribute: () => JSON.stringify(f) })) : boxes),
	};
	const form = { matches: (s) => s === 'form', closest: () => root, querySelectorAll: () => boxes };
	return { root, form };
};

test('applyFilter updates the selection, texts and url without a request', () => {
	state.headingTemplate = '{count} {products}';
	const boxes = [checkbox('formato[]', 'gran-formato', true), checkbox('formato[]', 'a-medida', false), checkbox('sector[]', 'industria', false)];
	const { form } = makeRoot(boxes);
	const context = { categoria: [], sector: [], formato: [], panelOpen: false, hydrated: true };
	fake.scope(context, form);
	actions.applyFilter();
	assert.deepEqual(context.formato, ['gran-formato']);
	assert.equal(state.headingText, '1 producto');
	assert.equal(state.countText, '1 producto');
	assert.equal(state.liveText, '1 producto');
	assert.equal(state.isEmpty, false);
	assert.deepEqual(replaced.at(-1).slice(1), ['', '/productos/?formato=gran-formato']);
});

test('applyFilter with no matches marks the grid empty', () => {
	const boxes = [checkbox('formato[]', 'a-medida', true)];
	const { form } = makeRoot(boxes);
	fake.scope({ categoria: [], sector: [], formato: [], panelOpen: false, hydrated: true }, form);
	actions.applyFilter();
	assert.equal(state.headingText, '0 productos');
	assert.equal(state.isEmpty, true);
});

test('syncItem hides what does not match the root selection', () => {
	const context = { categoria: [], sector: [], formato: ['gran-formato'], categories: FACETS[0].categories, sectors: FACETS[0].sectors, formats: FACETS[0].formats, hidden: true };
	fake.scope(context);
	callbacks.syncItem();
	assert.equal(context.hidden, false);
	const other = { ...context, categories: FACETS[1].categories, sectors: FACETS[1].sectors, formats: FACETS[1].formats, hidden: false };
	fake.scope(other);
	callbacks.syncItem();
	assert.equal(other.hidden, true);
});

test('clear empties the selection, unchecks the boxes and restores the url', () => {
	const boxes = [checkbox('formato[]', 'gran-formato', true)];
	const { root } = makeRoot(boxes);
	const context = { categoria: [], sector: [], formato: ['gran-formato'], panelOpen: false, hydrated: true };
	let prevented = false;
	fake.scope(context, { closest: () => root });
	actions.clear({ preventDefault: () => (prevented = true) });
	assert.equal(prevented, true);
	assert.deepEqual(context.formato, []);
	assert.equal(boxes[0].checked, false);
	assert.equal(state.headingText, '2 productos');
	assert.equal(replaced.at(-1)[2], '/productos/');
});

test('init hydrates and togglePanel flips the panel', () => {
	const context = { panelOpen: false, hydrated: false };
	fake.scope(context);
	callbacks.init();
	assert.equal(context.hydrated, true);
	actions.togglePanel();
	assert.equal(context.panelOpen, true);
	actions.togglePanel();
	assert.equal(context.panelOpen, false);
});
