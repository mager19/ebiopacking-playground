<?php
/**
 * Renderiza un render.php con los atributos de un fixture y emite solo el HTML.
 *
 * Uso: bin/wp eval-file plugins/ebio-core/tests/parity/render-fixture.php <render.php> <attributes-json> [context-json]
 *
 * @package ebio-core
 */

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped

$ebio_render_path = $args[0] ?? '';
$attributes       = json_decode( $args[1] ?? '{}', true );
$attributes       = is_array( $attributes ) ? $attributes : array();
$content          = '';
$block            = null;

if ( isset( $args[2] ) ) {
	$ebio_context = json_decode( $args[2], true );
	$block        = (object) array(
		'context'    => is_array( $ebio_context ) ? $ebio_context : array(),
		'attributes' => $attributes,
	);
}

if ( '' === $ebio_render_path || ! is_readable( $ebio_render_path ) ) {
	fwrite( STDERR, "render-fixture: render.php no legible: {$ebio_render_path}\n" );
	exit( 1 );
}

ob_start();
include $ebio_render_path;
$ebio_html = ob_get_clean();

// Comprobación SSR (ssr-check.php): vuelca el estado que render.php publicó para cada namespace
// del HTML (`data-wp-interactive` y referencias `<namespace>::`).
$ebio_state_out = getenv( 'EBIO_PARITY_STATE_OUT' );
if ( is_string( $ebio_state_out ) && '' !== $ebio_state_out ) {
	$ebio_namespaces = array();
	preg_match_all( '/data-wp-interactive=(["\'])(.*?)\1/', $ebio_html, $ebio_matches );
	foreach ( $ebio_matches[2] as $ebio_value ) {
		$ebio_value   = html_entity_decode( $ebio_value, ENT_QUOTES );
		$ebio_decoded = json_decode( $ebio_value, true );
		$ebio_ns      = is_array( $ebio_decoded ) ? (string) ( $ebio_decoded['namespace'] ?? '' ) : $ebio_value;
		if ( '' !== $ebio_ns ) {
			$ebio_namespaces[ $ebio_ns ] = true;
		}
	}
	preg_match_all( '#([a-z0-9-]+/[a-z0-9-]+)::#', $ebio_html, $ebio_matches );
	foreach ( $ebio_matches[1] as $ebio_ns ) {
		$ebio_namespaces[ $ebio_ns ] = true;
	}
	$ebio_states = array();
	foreach ( array_keys( $ebio_namespaces ) as $ebio_ns ) {
		$ebio_states[ $ebio_ns ] = (object) wp_interactivity_state( $ebio_ns );
	}
	file_put_contents( $ebio_state_out, wp_json_encode( (object) $ebio_states ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
}

echo $ebio_html;
