import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { build } from 'esbuild';

const execFileAsync = promisify(execFile);
const here = path.dirname(fileURLToPath(import.meta.url));
// plugins/ebio-core/tests/parity -> wp-content
const WP_CONTENT = path.resolve(here, '../../../..');
const RENDER_FIXTURE = path.join(here, 'render-fixture.php');
const require = createRequire(import.meta.url);

const NAMED_ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
const VOID_ELEMENTS = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
const PRESERVE_WS = new Set(['pre', 'textarea']);
// Elements whose edges make adjacent whitespace unrendered (block-level and list/form containers).
const BLOCK_ELEMENTS = new Set([
	'address', 'article', 'aside', 'blockquote', 'body', 'caption', 'col', 'colgroup', 'datalist', 'dd', 'details',
	'dialog', 'div', 'dl', 'dt', 'fieldset', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5',
	'h6', 'head', 'header', 'hgroup', 'hr', 'html', 'legend', 'li', 'link', 'main', 'meta', 'nav', 'noscript', 'ol',
	'optgroup', 'option', 'p', 'pre', 'script', 'search', 'section', 'select', 'style', 'summary', 'table', 'tbody',
	'td', 'template', 'tfoot', 'th', 'thead', 'title', 'tr', 'ul',
]);

function decodeEntities(str) {
	return str.replace(/&(#x[0-9a-f]+|#[0-9]+|[a-z]+);/gi, (m, e) => {
		if (e[0] === '#') {
			const code = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
			return Number.isNaN(code) ? m : String.fromCodePoint(code);
		}
		return NAMED_ENTITIES[e.toLowerCase()] ?? m;
	});
}

const escapeText = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escapeAttr = (s) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
// HTML whitespace only: U+00A0 (&nbsp;) is content, not whitespace.
const collapseWs = (s) => s.replace(/[ \t\n\r\f]+/g, ' ');
const trimWs = (s) => s.replace(/^[ \t\n\r\f]+|[ \t\n\r\f]+$/g, '');

const ATTR_RE = /([^\s"'<>/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;

/** Returns the normalized tag plus what the walker needs to track nesting. */
function normalizeTag(raw, inSvg) {
	const m = /^<\s*(\/?)\s*([a-zA-Z][^\s/>]*)([\s\S]*?)(\/?)>$/.exec(raw);
	if (!m) return { text: raw, name: '', closing: false, selfClosing: false };
	const [, closingSlash, name, rest, selfSlash] = m;
	const lower = name.toLowerCase();
	const closing = closingSlash === '/';
	// svg elements and attributes are case-sensitive (viewBox, linearGradient).
	const svgContext = inSvg || lower === 'svg';
	const tag = svgContext ? name : lower;
	if (closing) return { text: `</${tag}>`, name: lower, closing, selfClosing: false };
	const attrs = [];
	for (const a of rest.matchAll(ATTR_RE)) {
		const key = svgContext ? a[1] : a[1].toLowerCase();
		const value = a[2] ?? a[3] ?? a[4];
		let decoded = value === undefined ? '' : decodeEntities(value);
		if (key.toLowerCase() === 'class') decoded = trimWs(collapseWs(decoded));
		// Boolean/empty attributes: `disabled`, `disabled=""` are equivalent.
		attrs.push(decoded === '' ? key : `${key}="${escapeAttr(decoded)}"`);
	}
	attrs.sort();
	const keepSlash = selfSlash === '/' && !VOID_ELEMENTS.has(lower) && !svgContext;
	const open = `<${tag}${attrs.length ? ' ' + attrs.join(' ') : ''}${keepSlash ? '/' : ''}>`;
	// In svg, `<x/>` and `<x></x>` are the same (empty) element; React emits the latter.
	const emptySvg = selfSlash === '/' && svgContext && !VOID_ELEMENTS.has(lower);
	return {
		text: emptySvg ? `${open}</${tag}>` : open,
		name: lower,
		closing,
		selfClosing: selfSlash === '/',
	};
}

/**
 * Normalize a text chunk. `dropBefore` / `dropAfter` say whether newline-bearing whitespace at the
 * start / end of the chunk is unrendered formatting: true next to a block-level tag (start or end
 * of a block element, or between a block and something else), at the document edges, and between
 * svg children. Next to text or an inline element a newline renders as a space, so it collapses
 * to ' ' like any other whitespace. A plain space is always content.
 */
function normalizeText(raw, preserve, dropBefore, dropAfter) {
	const decoded = escapeText(decodeEntities(raw));
	if (preserve) return decoded;
	if (/^[ \t\n\r\f]*$/.test(decoded)) {
		return decoded.includes('\n') && (dropBefore || dropAfter) ? '' : collapseWs(decoded);
	}
	let t = decoded;
	if (dropBefore) t = t.replace(/^[ \t\r\f]*\n[ \t\n\r\f]*/, '');
	if (dropAfter) t = t.replace(/[ \t\n\r\f]*\n[ \t\r\f]*$/, '');
	return collapseWs(t);
}

/**
 * Normalize an HTML string so that PHP- and React-produced markup can be compared:
 * strips comments, collapses HTML whitespace (keeping &nbsp; and <pre>/<textarea>),
 * drops newline-bearing whitespace next to tags, sorts attributes, and unifies entity
 * encoding, boolean attributes and void/svg self-closing slashes.
 */
export function normalizeHtml(html) {
	// Comentarios fuera de etiquetas: un `<!--` dentro de un valor de atributo es parte de la etiqueta.
	const src = html.replace(/<!--[\s\S]*?-->|<\/?[a-zA-Z](?:"[^"]*"|'[^']*'|[^'">])*>/g, (m) => (m.startsWith('<!--') ? '' : m));
	const out = [];
	const TAG = /<\/?[a-zA-Z](?:"[^"]*"|'[^']*'|[^'">])*>/g;
	let svgDepth = 0;
	let preDepth = 0;
	let last = 0;
	// Is whitespace on this side of a chunk droppable? Document start counts as a block edge.
	let prevBlock = true;
	const text = (chunk, nextBlock) => {
		if (!chunk) return;
		const inSvg = svgDepth > 0;
		out.push(normalizeText(chunk, preDepth > 0, prevBlock || inSvg, nextBlock || inSvg));
	};
	for (const m of src.matchAll(TAG)) {
		const t = normalizeTag(m[0], svgDepth > 0);
		text(src.slice(last, m.index), BLOCK_ELEMENTS.has(t.name));
		prevBlock = BLOCK_ELEMENTS.has(t.name);
		out.push(t.text);
		if (!t.selfClosing && !VOID_ELEMENTS.has(t.name)) {
			const delta = t.closing ? -1 : 1;
			if (t.name === 'svg') svgDepth = Math.max(0, svgDepth + delta);
			if (PRESERVE_WS.has(t.name)) preDepth = Math.max(0, preDepth + delta);
		}
		last = m.index + m[0].length;
	}
	text(src.slice(last), true);
	return trimWs(out.join(''));
}

function firstDiff(a, b) {
	let i = 0;
	while (i < a.length && i < b.length && a[i] === b[i]) i++;
	const ctx = 60;
	const slice = (s) => s.slice(Math.max(0, i - ctx), i + ctx);
	return `first difference at char ${i}\n  php:   ...${slice(a)}...\n  react: ...${slice(b)}...`;
}

// @wordpress/block-editor necesita DOM al importarse; RichField solo lo usa en save() (ver el shim).
const blockEditorShim = {
	name: 'ebio-block-editor-shim',
	setup(b) {
		b.onResolve({ filter: /^@wordpress\/block-editor$/ }, () => ({ path: path.join(here, 'block-editor-shim.js') }));
	},
};

async function renderReact(componentPath, attributes, context) {
	const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ebio-parity-'));
	try {
		const entry = path.join(dir, 'entry.mjs');
		const out = path.join(dir, 'bundle.mjs');
		await fs.writeFile(
			entry,
			`import React from 'react';\nimport { renderToStaticMarkup } from 'react-dom/server';\nimport Component from ${JSON.stringify(componentPath)};\nexport const render = (props) => renderToStaticMarkup(React.createElement(Component, props));\n`
		);
		await build({
			entryPoints: [entry],
			outfile: out,
			bundle: true,
			format: 'esm',
			platform: 'node',
			jsx: 'automatic',
			loader: { '.js': 'jsx' },
			external: ['react', 'react-dom', 'react/jsx-runtime', 'react-dom/server'],
			logLevel: 'silent',
			plugins: [blockEditorShim],
			// Dependencias CommonJS empaquetadas (p. ej. las de @wordpress/block-editor, que importa
			// RichField) llaman a require('react'): que resuelva la misma copia externa.
			banner: { js: `import { createRequire as __ebioCreateRequire } from 'node:module';\nconst require = __ebioCreateRequire(${JSON.stringify(import.meta.url)});` },
		});
		// Node resolves bare imports relative to the bundle, which lives in the temp dir:
		// link the repo's node_modules there so `react` stays external and shared.
		await fs.symlink(path.dirname(path.dirname(require.resolve('react/package.json'))), path.join(dir, 'node_modules'), 'dir');
		const mod = await import(pathToFileURL(out).href);
		return mod.render({ attributes, context });
	} finally {
		await fs.rm(dir, { recursive: true, force: true });
	}
}

async function renderPhp(renderPhpPath, attributes, context, stateOut) {
	const { stdout } = await execFileAsync(
		path.join(WP_CONTENT, 'bin/wp'),
		['eval-file', 'plugins/ebio-core/tests/parity/render-fixture.php', renderPhpPath, JSON.stringify(attributes ?? {}), ...(context ? [JSON.stringify(context)] : [])],
		{ cwd: WP_CONTENT, maxBuffer: 10 * 1024 * 1024, env: stateOut ? { ...process.env, EBIO_PARITY_STATE_OUT: stateOut } : process.env }
	);
	return stdout;
}

/**
 * Comprobación "SSR sin efecto" (D8): procesar las directivas en el servidor no cambia el HTML.
 * @param {string} html HTML de un bloque.
 * @param {Record<string, object>} [state] Estado por namespace (el que publica render.php).
 * @returns {Promise<{ ok: boolean, diff: string }>}
 */
export async function checkSsr(html, state) {
	const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ebio-ssr-'));
	try {
		const htmlFile = path.join(dir, 'block.html');
		await fs.writeFile(htmlFile, html);
		const args = ['eval-file', 'plugins/ebio-core/tests/parity/ssr-check.php', htmlFile];
		if (state) {
			const stateFile = path.join(dir, 'state.json');
			await fs.writeFile(stateFile, JSON.stringify(state));
			args.push(stateFile);
		}
		try {
			await execFileAsync(path.join(WP_CONTENT, 'bin/wp'), args, { cwd: WP_CONTENT, maxBuffer: 10 * 1024 * 1024 });
			return { ok: true, diff: '' };
		} catch (err) {
			if (err.code === 1 && /^ssr:/m.test(err.stdout ?? '')) return { ok: false, diff: err.stdout.trim() };
			throw err;
		}
	} finally {
		await fs.rm(dir, { recursive: true, force: true });
	}
}

/**
 * Compare PHP (render.php) and React (component) markup for each fixture.
 * With `ssr`, also checks that processing the PHP output's directives (with the state render.php
 * published) leaves it unchanged.
 * @returns {Promise<{name: string, ok: boolean, diff: string, ssr?: {ok: boolean, diff: string}}[]>}
 */
export async function comparePair({ componentPath, renderPhpPath, fixturesPath, ssr = false }) {
	let source;
	try {
		source = await fs.readFile(fixturesPath, 'utf8');
	} catch (err) {
		if (err.code === 'ENOENT') throw new Error(`falta fixtures.json: ${fixturesPath}`);
		throw err;
	}
	const fixtures = JSON.parse(source);
	const results = [];
	for (const fx of fixtures) {
		const dir = ssr ? await fs.mkdtemp(path.join(os.tmpdir(), 'ebio-state-')) : null;
		try {
			const stateOut = dir ? path.join(dir, 'state.json') : undefined;
			const [php, react] = await Promise.all([
				renderPhp(renderPhpPath, fx.attributes, fx.context, stateOut),
				renderReact(componentPath, fx.attributes ?? {}, fx.context ?? {}),
			]);
			const a = normalizeHtml(php);
			const b = normalizeHtml(react);
			const result = { name: fx.name, ok: a === b, diff: a === b ? '' : firstDiff(a, b) };
			if (ssr) result.ssr = await checkSsr(php, JSON.parse(await fs.readFile(stateOut, 'utf8')));
			results.push(result);
		} finally {
			if (dir) await fs.rm(dir, { recursive: true, force: true });
		}
	}
	return results;
}
