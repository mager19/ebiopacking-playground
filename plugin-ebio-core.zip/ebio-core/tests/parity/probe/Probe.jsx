export default function Probe({ attributes, context }) {
	const { title, text } = attributes;
	return (
		<section className="ebio-probe">
			{context?.label ? <span className="ebio-probe__label">{context.label}</span> : null}
			<h2 className="ebio-probe__title">{title}</h2>
			<p className="ebio-probe__text">{text}</p>
		</section>
	);
}
