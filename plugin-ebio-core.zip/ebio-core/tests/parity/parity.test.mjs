import { test } from 'node:test';
import fs from 'node:fs';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkSsr, comparePair, normalizeHtml } from './parity.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const pathsFor = (dir) => ({
  componentPath: path.join(here, 'probe', 'Probe.jsx'),
  renderPhpPath: path.join(here, dir, 'render.php'),
  fixturesPath: path.join(here, 'probe', 'fixtures.json'),
});

test('probe idéntico pasa', async () => {
  const r = await comparePair(pathsFor('probe'));
  assert.equal(r.length, 3);
  assert.ok(r.every((x) => x.ok), JSON.stringify(r));
});

test('probe con clase distinta falla y muestra diff', async () => {
  const r = await comparePair(pathsFor('probe-broken'));
  assert.equal(r[0].ok, false);
  assert.match(r[0].diff, /ebio-probe__title/);
});

test('normalizeHtml ignora espacios, comentarios y orden de atributos', () => {
  const a = '<div  id="x" class="a">\n  <!-- c --> <span>hi</span>\n</div>';
  const b = '<div class="a" id="x"><span>hi</span></div>';
  assert.equal(normalizeHtml(a), normalizeHtml(b));
});

test('normalizeHtml normaliza atributos booleanos', () => {
  assert.equal(normalizeHtml('<input disabled="">'), normalizeHtml('<input disabled>'));
});

const n = normalizeHtml;
const differ = (a, b, msg) => assert.notEqual(n(a), n(b), msg);
const same = (a, b, msg) => assert.equal(n(a), n(b), msg);

test('normalizeHtml distingue espacio entre inline tags', () => {
	differ('<p><b>a</b> <i>b</i></p>', '<p><b>a</b><i>b</i></p>');
});
test('normalizeHtml conserva nbsp', () => {
	differ('a&nbsp;b', 'a b');
	differ('a&#160;b', 'a b');
	same('a&nbsp;b', 'a&#160;b');
});
test('normalizeHtml colapsa espacios en class pero no en otros atributos', () => {
	differ('<p title="a   b">x</p>', '<p title="a b">x</p>');
	same('<p class=" a   b ">x</p>', '<p class="a b">x</p>');
});
test('normalizeHtml preserva espacios en pre y textarea', () => {
	differ('<pre>a   b\n c</pre>', '<pre>a b c</pre>');
	differ('<textarea>a   b</textarea>', '<textarea>a b</textarea>');
});
test('normalizeHtml respeta mayúsculas dentro de svg', () => {
	differ('<svg viewBox="0 0 1 1"></svg>', '<svg viewbox="0 0 1 1"></svg>');
	differ('<svg><linearGradient></linearGradient></svg>', '<svg><lineargradient></lineargradient></svg>');
});
test('normalizeHtml solo quita la barra final en void y svg', () => {
	differ('<div/>', '<div>');
	same('<br/>', '<br>');
	same('<svg><path d="M0"/></svg>', '<svg><path d="M0"></path></svg>');
	differ('<svg><path d="M0"/></svg>', '<svg><path d="M0"></svg>');
});
test('normalizeHtml mantiene equivalencias legítimas', () => {
	same('<a id="1" class="x">t</a>', '<a class="x" id="1">t</a>');
	same('a &amp; b', 'a &#038; b');
	same('<div>\n\t<p>x</p>\n</div>', '<div><p>x</p></div>');
	same('<div><!-- c --><p>x</p></div>', '<div><p>x</p></div>');
});

test('npm test ejecuta también la paridad de bloques reales', () => {
	const pkg = JSON.parse(fs.readFileSync(path.join(here, '../../package.json'), 'utf8'));
	assert.match(pkg.scripts.test, /run-all\.mjs/);
});

test('run-all falla con mensaje claro si fixtures.json está vacío', () => {
	const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-runall-'));
	try {
		const dir = path.join(root, 'src/blocks/vacio');
		fs.mkdirSync(dir, { recursive: true });
		fs.writeFileSync(path.join(dir, 'block.json'), JSON.stringify({ name: 'ebio/vacio', render: 'file:./render.php' }));
		fs.writeFileSync(path.join(dir, 'fixtures.json'), '[]');
		const res = spawnSync('node', [path.join(here, 'run-all.mjs'), '--root', root], { encoding: 'utf8' });
		assert.notEqual(res.status, 0);
		assert.match(res.stdout + res.stderr, /vacio.*fixtures\.json.*vac/is);
	} finally {
		fs.rmSync(root, { recursive: true, force: true });
	}
});

const rich = (component) => ({
	componentPath: path.join(here, 'probe-rich', component),
	renderPhpPath: path.join(here, 'probe-rich', 'render.php'),
	fixturesPath: path.join(here, 'probe-rich', 'fixtures.json'),
});

test('dangerouslySetInnerHTML en el <p> BEM coincide con <p>…</p> de PHP', async () => {
	const r = await comparePair(rich('RichProbe.jsx'));
	assert.equal(r.length, 1);
	assert.ok(r[0].ok, r[0].diff);
});

test('un componente con RichField (importa @wordpress/block-editor) pasa la paridad', async () => {
	const r = await comparePair(rich('RichFieldProbe.jsx'));
	assert.equal(r.length, 1);
	assert.ok(r[0].ok, r[0].diff);
});

test('RawHTML emite un <div> envoltorio bajo react-dom y rompe la paridad', async () => {
	const r = await comparePair(rich('RawHtmlProbe.jsx'));
	assert.equal(r[0].ok, false);
	assert.match(r[0].diff, /<div>/);
});

test('normalizeHtml: salto de línea junto a texto e inline cuenta como espacio', () => {
	differ('hello\n<b>x</b>', 'hello<b>x</b>');
	differ('<b>x</b>\nhello', '<b>x</b>hello');
	differ('<p>a\n<em>b</em></p>', '<p>a<em>b</em></p>');
	differ('<span>\n\t<b>a</b></span>', '<span><b>a</b></span>');
	same('hello\n<b>x</b>', 'hello <b>x</b>');
	same('<b>x</b>\n\thello', '<b>x</b> hello');
});

test('normalizeHtml: salto de línea junto a un bloque o al borde de un bloque se ignora', () => {
	same('<p>\n\thola\n</p>', '<p>hola</p>');
	same('<ul>\n\t<li>a</li>\n\t<li>b</li>\n</ul>', '<ul><li>a</li><li>b</li></ul>');
	same('<section>\n\t<span>a</span>\n</section>', '<section><span>a</span></section>');
	same('<div>texto\n</div>\n<p>x</p>', '<div>texto</div><p>x</p>');
	same('<svg viewBox="0 0 1 1">\n\t<path d="M0"/>\n</svg>', '<svg viewBox="0 0 1 1"><path d="M0"></path></svg>');
	differ('<p> hola</p>', '<p>hola</p>');
});

const runAll = (root) => spawnSync('node', [path.join(here, 'run-all.mjs'), '--root', root], { encoding: 'utf8' });

test('run-all falla si un componente o bloque importa RawHTML', () => {
	const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-runall-'));
	try {
		fs.mkdirSync(path.join(root, 'src/components'), { recursive: true });
		fs.writeFileSync(path.join(root, 'src/components/Foo.jsx'), "import { RawHTML } from '@wordpress/element';\nexport default () => null;\n");
		const res = runAll(root);
		assert.notEqual(res.status, 0);
		assert.match(res.stdout + res.stderr, /Foo\.jsx.*RawHTML/s);

		fs.writeFileSync(path.join(root, 'src/components/Foo.jsx'), 'export default () => null;\n');
		assert.equal(runAll(root).status, 0, 'sin RawHTML pasa');
	} finally {
		fs.rmSync(root, { recursive: true, force: true });
	}
});

test('run-all falla si un fixture no cubre todos los atributos de block.json', () => {
	const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-runall-'));
	try {
		const dir = path.join(root, 'src/blocks/incompleto');
		fs.mkdirSync(dir, { recursive: true });
		fs.writeFileSync(
			path.join(dir, 'block.json'),
			JSON.stringify({ name: 'ebio/incompleto', supports: { anchor: true }, attributes: { title: { type: 'string' }, count: { type: 'number' } } })
		);
		fs.writeFileSync(path.join(dir, 'fixtures.json'), JSON.stringify([{ name: 'default', attributes: { title: 'x' } }]));
		const res = runAll(root);
		assert.notEqual(res.status, 0);
		assert.match(res.stdout + res.stderr, /incompleto.*default.*count.*anchor/s);
	} finally {
		fs.rmSync(root, { recursive: true, force: true });
	}
});

test('ebio-core declara react y react-dom 18.3.1 exactos (React de WordPress)', () => {
	const pkg = JSON.parse(fs.readFileSync(path.join(here, '../../package.json'), 'utf8'));
	assert.equal(pkg.devDependencies.react, '18.3.1');
	assert.equal(pkg.devDependencies['react-dom'], '18.3.1');
});

const SSR_PROBE = '<div data-wp-interactive="ebio/probe">\n\t<span class="ebio-probe__t" data-wp-text="state.t">A</span>\n</div>';

test('ssr check passes for matching state', async () => {
	const r = await checkSsr(SSR_PROBE, { 'ebio/probe': { t: 'A' } });
	assert.equal(r.ok, true, r.diff);
});

test('ssr check fails when state differs', async () => {
	const r = await checkSsr(SSR_PROBE, { 'ebio/probe': { t: 'B' } });
	assert.equal(r.ok, false);
	assert.match(r.diff, /A/);
	assert.match(r.diff, /B/);
});

test('normalizeHtml no quita "<!--" dentro de valores de atributo', () => {
	differ('<p title="a <!-- b --> c">x</p>', '<p title="a  c">x</p>');
	same('<p title="a <!-- b -->">x<!-- c --></p>', '<p title="a <!-- b -->">x</p>');
});

test('run-all informa "falta fixtures.json" en vez de ENOENT', () => {
	const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-runall-'));
	try {
		const dir = path.join(root, 'src/blocks/sin-fixtures');
		fs.mkdirSync(dir, { recursive: true });
		fs.writeFileSync(path.join(dir, 'block.json'), JSON.stringify({ name: 'ebio/sin-fixtures', render: 'file:./render.php' }));
		const res = runAll(root);
		assert.notEqual(res.status, 0);
		assert.match(res.stdout, /FAIL sin-fixtures :: falta fixtures\.json/);
		assert.doesNotMatch(res.stdout + res.stderr, /ENOENT/);
	} finally {
		fs.rmSync(root, { recursive: true, force: true });
	}
});

test('comparePair con fixtures.json faltante lanza un error claro', async () => {
	await assert.rejects(
		comparePair({ ...pathsFor('probe'), fixturesPath: path.join(here, 'probe', 'no-existe.json') }),
		/falta fixtures\.json/
	);
});

test('run-all --block limita la corrida a un bloque', () => {
	const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-runall-'));
	try {
		for (const name of ['uno', 'dos']) {
			const dir = path.join(root, 'src/blocks', name);
			fs.mkdirSync(dir, { recursive: true });
			fs.writeFileSync(path.join(dir, 'block.json'), JSON.stringify({ name: `ebio/${name}`, render: 'file:./render.php' }));
		}
		const res = spawnSync('node', [path.join(here, 'run-all.mjs'), '--root', root, '--block', 'uno'], { encoding: 'utf8' });
		assert.notEqual(res.status, 0);
		assert.match(res.stdout, /FAIL uno :: falta fixtures\.json/);
		assert.doesNotMatch(res.stdout, /dos/);
		const unknown = spawnSync('node', [path.join(here, 'run-all.mjs'), '--root', root, '--block', 'tres'], { encoding: 'utf8' });
		assert.notEqual(unknown.status, 0);
		assert.match(unknown.stdout, /FAIL tres :: no existe src\/blocks\/tres\/block\.json/);
	} finally {
		fs.rmSync(root, { recursive: true, force: true });
	}
});

test('run-all aplica la comprobación SSR a los bloques con viewScriptModule', () => {
	const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ebio-runall-'));
	try {
		const dir = path.join(root, 'src/blocks/ssr-probe');
		fs.mkdirSync(dir, { recursive: true });
		fs.mkdirSync(path.join(root, 'src/components'), { recursive: true });
		fs.writeFileSync(
			path.join(dir, 'block.json'),
			JSON.stringify({ name: 'ebio/ssr-probe', render: 'file:./render.php', viewScriptModule: 'file:./view.js', attributes: { t: { type: 'string' } } })
		);
		fs.writeFileSync(path.join(dir, 'fixtures.json'), JSON.stringify([{ name: 'default', attributes: { t: 'A' } }]));
		const markup = '<div class="ebio-ssr-probe" data-wp-interactive="ebio/ssr-probe"><span data-wp-text="state.t">';
		const renderPhp = (state) =>
			`<?php\nwp_interactivity_state( 'ebio/ssr-probe', array( 't' => ${state} ) );\n?>\n${markup}<?php echo esc_html( $attributes['t'] ); ?></span></div>\n`;
		fs.writeFileSync(
			path.join(root, 'src/components/SsrProbe.jsx'),
			`export default ({ attributes }) => <div className="ebio-ssr-probe" data-wp-interactive="ebio/ssr-probe"><span data-wp-text="state.t">{attributes.t}</span></div>;\n`
		);

		fs.writeFileSync(path.join(dir, 'render.php'), renderPhp("$attributes['t']"));
		const ok = runAll(root);
		assert.equal(ok.status, 0, ok.stdout + ok.stderr);
		assert.match(ok.stdout, /ok\s+ssr-probe :: default\n/);
		assert.match(ok.stdout, /ok\s+ssr-probe :: default :: ssr/);

		fs.writeFileSync(path.join(dir, 'render.php'), renderPhp("'otro'"));
		const bad = runAll(root);
		assert.notEqual(bad.status, 0);
		assert.match(bad.stdout, /FAIL ssr-probe :: default :: ssr/);
		assert.match(bad.stdout, /otro/);
	} finally {
		fs.rmSync(root, { recursive: true, force: true });
	}
});
