<?php
/**
 * Comprobación "SSR sin efecto" (catalog §2.12, D8): procesar las directivas de la Interactivity API
 * en el servidor no debe cambiar el HTML.
 *
 * Uso: bin/wp eval-file plugins/ebio-core/tests/parity/ssr-check.php <html-file> [state-json-file]
 *
 * `state-json-file` (opcional): `{ "<namespace>": { …estado… } }`, el estado que publicó render.php
 * (lo vuelca render-fixture.php con EBIO_PARITY_STATE_OUT). Sale con 0 e imprime `ok` si el HTML
 * procesado, normalizado, es igual a la entrada; si no, sale con 1 e imprime la primera diferencia.
 *
 * @package ebio-core
 */

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions

$ebio_html_file  = $args[0] ?? '';
$ebio_state_file = $args[1] ?? '';

if ( '' === $ebio_html_file || ! is_readable( $ebio_html_file ) ) {
	fwrite( STDERR, "ssr-check: HTML no legible: {$ebio_html_file}\n" );
	exit( 2 );
}
$ebio_html = (string) file_get_contents( $ebio_html_file );

if ( function_exists( 'ebio_quote_init_state' ) ) {
	ebio_quote_init_state();
}
// Bloques estáticos con estado inicial propio (no pasan por render.php): ebio/product-gallery.
if ( function_exists( 'ebio_product_gallery_init_state' ) ) {
	ebio_product_gallery_init_state();
}
if ( '' !== $ebio_state_file ) {
	$ebio_states = json_decode( (string) file_get_contents( $ebio_state_file ), true );
	foreach ( is_array( $ebio_states ) ? $ebio_states : array() as $ebio_namespace => $ebio_state ) {
		wp_interactivity_state( (string) $ebio_namespace, is_array( $ebio_state ) ? $ebio_state : array() );
	}
}

// Estado derivado (closures): no sobrevive al volcado JSON del estado, así que se publica después.
if ( function_exists( 'ebio_carousel_init_state' ) ) {
	ebio_carousel_init_state();
}

$ebio_processed = wp_interactivity_process_directives( $ebio_html );

if ( ! function_exists( 'ebio_ssr_tokens' ) ) {
	/**
	 * Tokens normalizados: etiquetas con atributos ordenados y valores decodificados, texto decodificado
	 * con espacios colapsados; sin comentarios.
	 *
	 * @param string $html HTML.
	 * @return string[]
	 */
	function ebio_ssr_tokens( string $html ): array {
		$tokens    = array();
		$text      = '';
		$processor = new WP_HTML_Tag_Processor( $html );
		$flush     = static function () use ( &$text, &$tokens ) {
			$normalized = trim( (string) preg_replace( '/[ \t\n\r\f]+/', ' ', $text ) );
			if ( '' !== $normalized ) {
				$tokens[] = '#text ' . $normalized;
			}
			$text = '';
		};
		while ( $processor->next_token() ) {
			$type = $processor->get_token_type();
			if ( '#text' === $type ) {
				$text .= $processor->get_modifiable_text();
				continue;
			}
			if ( '#tag' !== $type ) {
				continue;
			}
			$flush();
			$tag = strtolower( (string) $processor->get_tag() );
			if ( $processor->is_tag_closer() ) {
				$tokens[] = "</{$tag}>";
				continue;
			}
			$names = $processor->get_attribute_names_with_prefix( '' ) ?? array();
			sort( $names );
			$attributes = array();
			foreach ( $names as $name ) {
				$value = $processor->get_attribute( $name );
				if ( true === $value || '' === $value ) {
					$attributes[] = $name;
					continue;
				}
				if ( 'class' === $name ) {
					$value = trim( (string) preg_replace( '/[ \t\n\r\f]+/', ' ', $value ) );
				}
				$attributes[] = $name . '="' . $value . '"';
			}
			$tokens[] = '<' . $tag . ( $attributes ? ' ' . implode( ' ', $attributes ) : '' ) . '>';
			$raw_text = $processor->get_modifiable_text();
			if ( '' !== $raw_text ) {
				$tokens[] = '#raw ' . $raw_text;
			}
		}
		$flush();
		return $tokens;
	}
}

$ebio_before = ebio_ssr_tokens( $ebio_html );
$ebio_after  = ebio_ssr_tokens( $ebio_processed );

if ( $ebio_before === $ebio_after ) {
	echo "ok\n";
	exit( 0 );
}

$ebio_count = max( count( $ebio_before ), count( $ebio_after ) );
for ( $ebio_i = 0; $ebio_i < $ebio_count; $ebio_i++ ) {
	if ( ( $ebio_before[ $ebio_i ] ?? null ) !== ( $ebio_after[ $ebio_i ] ?? null ) ) {
		echo "ssr: el procesamiento de directivas cambia el HTML (token {$ebio_i})\n";
		echo '  html:      ' . ( $ebio_before[ $ebio_i ] ?? '(fin)' ) . "\n";
		echo '  procesado: ' . ( $ebio_after[ $ebio_i ] ?? '(fin)' ) . "\n";
		break;
	}
}
exit( 1 );
