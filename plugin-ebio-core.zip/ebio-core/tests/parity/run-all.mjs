// Comprobaciones de bloques de ebio-core:
// 1. Lint: ningún archivo de src/components ni src/blocks usa RawHTML (catalog §2.9).
// 2. Cada bloque tiene fixtures.json y cada fixture lleva todos los atributos de su block.json.
// 3. Paridad PHP vs React de los bloques con "render" en block.json.
// 4. Bloques dinámicos con viewScriptModule: "SSR sin efecto" (D8) sobre la salida PHP de cada fixture.
//
// Uso: node tests/parity/run-all.mjs [--root <plugin>] [--block <nombre>]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { comparePair } from './parity.mjs';

const option = (name) => {
	const i = process.argv.indexOf(`--${name}`);
	return i > -1 ? process.argv[i + 1] : undefined;
};
const root = option('root') ? path.resolve(option('root')) : path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const only = option('block')?.replace(/^ebio\//, '');
const blocksDir = path.join(root, 'src/blocks');

let failed = false;
const fail = (msg) => {
	console.log(`FAIL ${msg}`);
	failed = true;
};

// 1. RawHTML: react-dom lo envuelve en un <div> que el HTML guardado no tiene.
const SOURCE = /\.(m?js|jsx|tsx?)$/;
const walk = (dir) =>
	fs.existsSync(dir)
		? fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => {
				const p = path.join(dir, d.name);
				return d.isDirectory() ? walk(p) : SOURCE.test(d.name) ? [p] : [];
			})
		: [];
for (const file of [...walk(path.join(root, 'src/components')), ...walk(blocksDir)]) {
	if (/\bRawHTML\b/.test(fs.readFileSync(file, 'utf8'))) {
		fail(`lint :: ${path.relative(root, file)} usa RawHTML; usa dangerouslySetInnerHTML en el elemento BEM o RichText.Content con tagName (catalog §2.9)`);
	}
}

let blockDirs = fs.existsSync(blocksDir)
	? fs
			.readdirSync(blocksDir, { withFileTypes: true })
			.filter((d) => d.isDirectory() && fs.existsSync(path.join(blocksDir, d.name, 'block.json')))
			.map((d) => d.name)
	: [];
if (only) {
	if (!blockDirs.includes(only)) fail(`${only} :: no existe src/blocks/${only}/block.json`);
	blockDirs = blockDirs.filter((name) => name === only);
}
const blockJson = (name) => JSON.parse(fs.readFileSync(path.join(blocksDir, name, 'block.json'), 'utf8'));

// 2. fixtures.json presente y con todos los atributos: el arnés no aplica los default de block.json.
const covered = new Set();
const fixturesOf = {};
for (const name of blockDirs) {
	const fixturesPath = path.join(blocksDir, name, 'fixtures.json');
	if (!fs.existsSync(fixturesPath)) {
		fail(`${name} :: falta fixtures.json`);
		continue;
	}
	const bj = blockJson(name);
	const required = [...Object.keys(bj.attributes ?? {}), ...(bj.supports?.anchor ? ['anchor'] : [])];
	const fixtures = JSON.parse(fs.readFileSync(fixturesPath, 'utf8'));
	fixturesOf[name] = fixtures;
	let ok = true;
	for (const fx of Array.isArray(fixtures) ? fixtures : []) {
		const missing = required.filter((k) => !Object.hasOwn(fx.attributes ?? {}, k));
		if (missing.length) {
			fail(`${name} :: fixture "${fx.name}" no cubre los atributos de block.json: ${missing.join(', ')}`);
			ok = false;
		}
	}
	if (ok) covered.add(name);
}

// 3 y 4. Paridad y SSR.
const dynamic = blockDirs.filter((name) => blockJson(name).render);
console.log(`${dynamic.length} dynamic blocks`);

for (const name of dynamic) {
	if (!(name in fixturesOf)) continue;
	const dir = path.join(blocksDir, name);
	// Convención: componente en src/components/<PascalCase>.jsx
	const pascal = name.split('-').map((p) => p.charAt(0).toUpperCase() + p.slice(1)).join('');
	const fixtures = fixturesOf[name];
	if (!Array.isArray(fixtures) || fixtures.length === 0) {
		fail(`${name} :: fixtures.json está vacío; un bloque dinámico necesita al menos un fixture`);
		continue;
	}
	if (!covered.has(name)) continue;
	const results = await comparePair({
		componentPath: path.join(root, 'src/components', `${pascal}.jsx`),
		renderPhpPath: path.join(dir, 'render.php'),
		fixturesPath: path.join(dir, 'fixtures.json'),
		ssr: Boolean(blockJson(name).viewScriptModule),
	});
	for (const r of results) {
		console.log(`${r.ok ? 'ok  ' : 'FAIL'} ${name} :: ${r.name}`);
		if (!r.ok) {
			failed = true;
			console.log(r.diff);
		}
		if (r.ssr) {
			console.log(`${r.ssr.ok ? 'ok  ' : 'FAIL'} ${name} :: ${r.name} :: ssr`);
			if (!r.ssr.ok) {
				failed = true;
				console.log(r.ssr.diff);
			}
		}
	}
}
process.exit(failed ? 1 : 0);
