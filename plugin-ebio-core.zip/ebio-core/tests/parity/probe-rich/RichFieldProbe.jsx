// Componente dinámico real con RichField (src/components/lib): la paridad debe poder empaquetarlo
// aunque RichField importe @wordpress/block-editor.
import RichField from '../../../src/components/lib/RichField.jsx';

export default function RichFieldProbe({ attributes }) {
	return (
		<section className="ebio-probe">
			<RichField tagName="p" className="ebio-probe__text" value={attributes.text} />
		</section>
	);
}
