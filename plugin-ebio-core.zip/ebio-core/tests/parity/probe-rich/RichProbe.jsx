// HTML de RichText en un componente dinámico: dangerouslySetInnerHTML sobre el elemento BEM,
// nunca RawHTML (que react-dom envuelve en un <div>). Ver docs/blocks/catalog.md §2.9.
export default function RichProbe({ attributes }) {
	return (
		<section className="ebio-probe">
			<p className="ebio-probe__text" dangerouslySetInnerHTML={{ __html: attributes.text }} />
		</section>
	);
}
