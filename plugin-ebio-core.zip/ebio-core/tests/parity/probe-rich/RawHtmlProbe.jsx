// Contraejemplo: RawHTML bajo react-dom emite un <div> envoltorio que el HTML guardado no tiene.
// Solo existe para la prueba que demuestra por qué los componentes no usan RawHTML.
import { RawHTML } from '@wordpress/element';

export default function RawHtmlProbe({ attributes }) {
	return (
		<section className="ebio-probe">
			<p className="ebio-probe__text">
				<RawHTML>{attributes.text}</RawHTML>
			</p>
		</section>
	);
}
