<?php
/**
 * Fixture de paridad para HTML de RichText.
 *
 * @var array $attributes
 */

?>
<section class="ebio-probe">
	<p class="ebio-probe__text"><?php echo wp_kses_post( $attributes['text'] ?? '' ); ?></p>
</section>
