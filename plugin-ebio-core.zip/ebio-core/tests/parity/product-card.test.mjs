// Paridad del componente compartido `ebio-product-card` (docs/blocks/product-card.md): el gemelo PHP
// `ebio_render_product_card()` y `<ProductCard card options />` producen el mismo HTML, y procesar sus
// directivas en el servidor no lo cambia (SSR sin efecto, catalog §2.12).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { comparePair } from './parity.mjs';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), 'product-card');

test('product-card: PHP and React render the same card for every fixture', async () => {
	const results = await comparePair({
		componentPath: path.join(dir, 'ProductCardFixture.jsx'),
		renderPhpPath: path.join(dir, 'render.php'),
		fixturesPath: path.join(dir, 'fixtures.json'),
		ssr: true,
	});
	assert.deepEqual(
		results.map((r) => r.name),
		['default', 'long-name', 'no-image', 'no-tags', 'formats']
	);
	for (const r of results) {
		assert.ok(r.ok, `${r.name}\n${r.diff}`);
		assert.ok(r.ssr.ok, `${r.name} :: ssr\n${r.ssr.diff}`);
	}
});
