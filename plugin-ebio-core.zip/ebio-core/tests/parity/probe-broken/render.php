<?php
/**
 * Fixture de la prueba de paridad con una clase distinta a propósito.
 *
 * @var array         $attributes
 * @var WP_Block|null $block
 */

$label = $block->context['label'] ?? '';
?>
<section class="ebio-probe">
	<?php if ( '' !== $label ) : ?>
		<span class="ebio-probe__label"><?php echo esc_html( $label ); ?></span>
	<?php endif; ?>
	<h2 class="ebio-probe__heading"><?php echo esc_html( $attributes['title'] ?? '' ); ?></h2>
	<p class="ebio-probe__text"><?php echo esc_html( $attributes['text'] ?? '' ); ?></p>
</section>
