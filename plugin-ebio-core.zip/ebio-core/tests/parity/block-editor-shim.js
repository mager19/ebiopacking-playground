// Sustituto de @wordpress/block-editor en el paquete de paridad (Node sin DOM).
//
// La paridad renderiza el componente como frontend (SaveMode en false): RichField usa
// dangerouslySetInnerHTML y nunca llega a RichText.Content, que solo existe para save(). Un componente
// que importe cualquier otra cosa de @wordpress/block-editor falla al empaquetar ("No matching export"):
// los componentes de src/components no deben depender del editor.
export const RichText = {
	Content() {
		throw new Error('RichText.Content solo se usa en save(); la paridad renderiza el componente con SaveMode en false');
	},
};
