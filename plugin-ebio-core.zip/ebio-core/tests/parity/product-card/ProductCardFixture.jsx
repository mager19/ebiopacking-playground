import ProductCard from '../../../src/components/ProductCard.jsx';

/** Adaptador de paridad: el arnés pasa `{ attributes, context }`; la tarjeta recibe `card` y `options`. */
export default function ProductCardFixture( { attributes = {} } ) {
	return <ProductCard card={ attributes.card } options={ attributes.options } />;
}
