<?php
/**
 * Paridad de `ebio-product-card` (no es bloque): el fixture trae `attributes.card` (`ProductCardView`)
 * y `attributes.options`, y se pinta con el gemelo PHP.
 *
 * @var array $attributes
 *
 * @package ebio-core
 */

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- el renderizador escapa.
echo ebio_render_product_card( is_array( $attributes['card'] ?? null ) ? $attributes['card'] : array(), is_array( $attributes['options'] ?? null ) ? $attributes['options'] : array() );
