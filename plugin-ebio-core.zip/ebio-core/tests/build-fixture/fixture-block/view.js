// Build fixture: viewScriptModule entry (script module).
import { store } from '@wordpress/interactivity';

store( 'ebio-test/fixture-block', {} );
