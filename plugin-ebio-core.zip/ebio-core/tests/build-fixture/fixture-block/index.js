// Build fixture: editor script entry (classic script).
export const fixtureEditor = 'fixture-block editor';
