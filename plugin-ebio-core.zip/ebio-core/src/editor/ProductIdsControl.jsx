import { __, sprintf } from '@wordpress/i18n';
import { useEffect, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { Button, Notice, TextControl } from '@wordpress/components';

/**
 * Título de un producto de la REST (`title.rendered` llega con entidades HTML).
 *
 * @param {Object} product Registro de `/wp/v2/ebio_product`.
 * @return {string} Título en texto plano.
 */
const plainTitle = ( product ) => {
	const node = document.createElement( 'textarea' );
	node.innerHTML = product?.title?.rendered ?? '';
	return node.value || `#${ product?.id }`;
};

/**
 * Selector ordenado de productos (`productIds`): buscador por nombre, y subir / bajar / quitar. Los IDs
 * no publicados se muestran como "no disponible" y el servidor los omite sin dejar hueco (C-M8).
 *
 * @param {Object}   props
 * @param {number[]} props.value    IDs elegidos, en orden.
 * @param {Function} props.onChange Recibe la nueva lista.
 * @param {number}   [props.max]    Máximo de productos (12).
 */
export default function ProductIdsControl( { value, onChange, max = 12 } ) {
	const ids = Array.isArray( value ) ? value : [];
	const [ names, setNames ] = useState( {} );
	const [ search, setSearch ] = useState( '' );
	const [ results, setResults ] = useState( [] );
	const key = ids.join( ',' );

	// Nombres de los IDs elegidos (los no publicados no vuelven en la lista: "no disponible").
	useEffect( () => {
		if ( ids.length === 0 ) {
			return undefined;
		}
		let active = true;
		apiFetch( { path: `/wp/v2/ebio_product?include=${ key }&per_page=${ max }&_fields=id,title` } ).then(
			( products ) => active && setNames( ( prev ) => ( { ...prev, ...Object.fromEntries( products.map( ( p ) => [ p.id, plainTitle( p ) ] ) ) } ) ),
			() => {}
		);
		return () => {
			active = false;
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [ key ] );

	useEffect( () => {
		if ( search.trim().length < 2 ) {
			setResults( [] );
			return undefined;
		}
		let active = true;
		const timer = setTimeout( () => {
			apiFetch( { path: `/wp/v2/ebio_product?search=${ encodeURIComponent( search.trim() ) }&per_page=8&_fields=id,title` } ).then(
				( products ) => active && setResults( products ),
				() => active && setResults( [] )
			);
		}, 250 );
		return () => {
			active = false;
			clearTimeout( timer );
		};
	}, [ search ] );

	const label = ( id ) => names[ id ] ?? sprintf( /* translators: %d: ID del producto. */ __( 'Producto %d (no disponible)', 'ebio-core' ), id );
	const move = ( index, delta ) => {
		const target = index + delta;
		if ( target < 0 || target >= ids.length ) {
			return;
		}
		const next = [ ...ids ];
		[ next[ index ], next[ target ] ] = [ next[ target ], next[ index ] ];
		onChange( next );
	};
	const add = ( product ) => {
		setNames( ( prev ) => ( { ...prev, [ product.id ]: plainTitle( product ) } ) );
		onChange( [ ...ids, product.id ] );
		setSearch( '' );
	};

	return (
		<div className="ebio-product-ids-control">
			{ ids.length === 0 ? (
				<Notice status="info" isDismissible={ false }>
					{ __( 'Sin productos elegidos: se muestran los primeros por orden del menú.', 'ebio-core' ) }
				</Notice>
			) : null }
			<ol>
				{ ids.map( ( id, index ) => (
					<li key={ id }>
						<span>{ label( id ) }</span>
						<Button size="small" icon="arrow-up-alt2" label={ sprintf( /* translators: %s: nombre. */ __( 'Subir %s', 'ebio-core' ), label( id ) ) } disabled={ index === 0 } onClick={ () => move( index, -1 ) } />
						<Button size="small" icon="arrow-down-alt2" label={ sprintf( /* translators: %s: nombre. */ __( 'Bajar %s', 'ebio-core' ), label( id ) ) } disabled={ index === ids.length - 1 } onClick={ () => move( index, 1 ) } />
						<Button size="small" icon="no-alt" isDestructive label={ sprintf( /* translators: %s: nombre. */ __( 'Quitar %s', 'ebio-core' ), label( id ) ) } onClick={ () => onChange( ids.filter( ( other ) => other !== id ) ) } />
					</li>
				) ) }
			</ol>
			{ ids.length < max ? (
				<>
					<TextControl label={ __( 'Buscar producto', 'ebio-core' ) } value={ search } onChange={ setSearch } __nextHasNoMarginBottom __next40pxDefaultSize />
					<ul>
						{ results
							.filter( ( product ) => ! ids.includes( product.id ) )
							.map( ( product ) => (
								<li key={ product.id }>
									<Button variant="secondary" size="small" onClick={ () => add( product ) }>
										{ sprintf( /* translators: %s: nombre. */ __( 'Agregar %s', 'ebio-core' ), plainTitle( product ) ) }
									</Button>
								</li>
							) ) }
					</ul>
				</>
			) : (
				<Notice status="warning" isDismissible={ false }>
					{ sprintf( /* translators: %d: máximo. */ __( 'Máximo %d productos.', 'ebio-core' ), max ) }
				</Notice>
			) }
		</div>
	);
}
