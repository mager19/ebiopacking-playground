import { __, sprintf } from '@wordpress/i18n';
import { Button, Notice } from '@wordpress/components';

/**
 * Lista editable del inspector: agregar, quitar y reordenar ítems dentro de los límites del contrato.
 * Fuera de rango muestra un aviso (el bloque sigue editable; el componente recorta al máximo).
 *
 * @param {Object}   props
 * @param {Array}    props.items      Ítems actuales.
 * @param {Function} props.onChange   Recibe la nueva lista.
 * @param {number}   props.min        Mínimo del contrato.
 * @param {number}   props.max        Máximo del contrato.
 * @param {Object}   props.emptyItem  Ítem nuevo.
 * @param {string}   props.itemLabel  Nombre del ítem para etiquetas (p. ej. `Paso`).
 * @param {Function} [props.renderItem] `( item, update, index ) => element` con los campos de texto plano del ítem. Los RichText se editan en el lienzo (EditContext).
 */
export default function ItemListControl( { items, onChange, min, max, emptyItem, itemLabel, renderItem } ) {
	const list = Array.isArray( items ) ? items : [];
	const update = ( index ) => ( patch ) => onChange( list.map( ( item, i ) => ( i === index ? { ...item, ...patch } : item ) ) );
	const remove = ( index ) => onChange( list.filter( ( _, i ) => i !== index ) );
	const move = ( index, delta ) => {
		const target = index + delta;
		if ( target < 0 || target >= list.length ) {
			return;
		}
		const next = [ ...list ];
		[ next[ index ], next[ target ] ] = [ next[ target ], next[ index ] ];
		onChange( next );
	};

	// «Subir paso 2»: acción + nombre del ítem + posición, para lectores de pantalla.
	const label = ( action, index ) => `${ action } ${ itemLabel.toLowerCase() } ${ index + 1 }`;

	return (
		<div className="ebio-item-list-control">
			{ list.length < min || list.length > max ? (
				<Notice status="warning" isDismissible={ false }>
					{ sprintf( /* translators: 1: mínimo, 2: máximo. */ __( 'Este bloque admite entre %1$d y %2$d elementos.', 'ebio-core' ), min, max ) }
				</Notice>
			) : null }
			{ list.map( ( item, index ) => (
				<fieldset key={ index }>
					<legend>{ sprintf( /* translators: 1: nombre del elemento, 2: posición. */ __( '%1$s %2$d', 'ebio-core' ), itemLabel, index + 1 ) }</legend>
					{ renderItem ? renderItem( item, update( index ), index ) : null }
					<Button variant="tertiary" size="small" disabled={ index === 0 } aria-label={ label( __( 'Subir', 'ebio-core' ), index ) } onClick={ () => move( index, -1 ) }>
						{ __( 'Subir', 'ebio-core' ) }
					</Button>
					<Button variant="tertiary" size="small" disabled={ index === list.length - 1 } aria-label={ label( __( 'Bajar', 'ebio-core' ), index ) } onClick={ () => move( index, 1 ) }>
						{ __( 'Bajar', 'ebio-core' ) }
					</Button>
					<Button variant="link" isDestructive aria-label={ label( __( 'Quitar', 'ebio-core' ), index ) } onClick={ () => remove( index ) }>
						{ __( 'Quitar', 'ebio-core' ) }
					</Button>
				</fieldset>
			) ) }
			{ list.length < max ? (
				<Button variant="secondary" onClick={ () => onChange( [ ...list, { ...emptyItem } ] ) }>
					{ sprintf( /* translators: %s: nombre del elemento. */ __( 'Añadir %s', 'ebio-core' ), itemLabel.toLowerCase() ) }
				</Button>
			) : null }
		</div>
	);
}
