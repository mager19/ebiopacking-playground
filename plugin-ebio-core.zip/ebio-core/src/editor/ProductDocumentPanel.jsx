import { __ } from '@wordpress/i18n';
import { useSelect } from '@wordpress/data';
import { useEntityProp } from '@wordpress/core-data';
import { PluginDocumentSettingPanel } from '@wordpress/editor';
import { FormTokenField, Notice, TextControl } from '@wordpress/components';

/**
 * Panel "Datos del producto" del documento (solo `ebio_product`): pedido mínimo y etiquetas del
 * producto (`ebio_min_order`, `ebio_tags`), y aviso si la imagen destacada no tiene texto alternativo.
 * El formato (`ebio_format`) usa el panel nativo de la taxonomía.
 */
export default function ProductDocumentPanel() {
	const postType = useSelect( ( select ) => select( 'core/editor' ).getCurrentPostType(), [] );
	const [ meta, setMeta ] = useEntityProp( 'postType', 'ebio_product', 'meta' );
	const [ featuredId ] = useEntityProp( 'postType', 'ebio_product', 'featured_media' );
	const media = useSelect( ( select ) => ( featuredId ? select( 'core' ).getMedia( featuredId ) : null ), [ featuredId ] );

	if ( postType !== 'ebio_product' ) {
		return null;
	}
	const tags = Array.isArray( meta?.ebio_tags ) ? meta.ebio_tags : [];
	const missingAlt = Boolean( featuredId ) && Boolean( media ) && String( media.alt_text ?? '' ).trim() === '';

	return (
		<PluginDocumentSettingPanel name="ebio-product-data" title={ __( 'Datos del producto', 'ebio-core' ) } className="ebio-product-data-panel">
			<TextControl
				label={ __( 'Pedido mínimo', 'ebio-core' ) }
				value={ meta?.ebio_min_order ?? '' }
				onChange={ ( next ) => setMeta( { ...meta, ebio_min_order: next } ) }
				help={ __( 'Se muestra en la ficha como dato clave. Vacío = no se muestra.', 'ebio-core' ) }
				__nextHasNoMarginBottom
				__next40pxDefaultSize
			/>
			<FormTokenField
				label={ __( 'Etiquetas', 'ebio-core' ) }
				value={ tags }
				onChange={ ( next ) => setMeta( { ...meta, ebio_tags: next.map( ( token ) => ( typeof token === 'string' ? token : token.value ) ) } ) }
				__nextHasNoMarginBottom
				__next40pxDefaultSize
			/>
			{ missingAlt ? (
				<Notice status="warning" isDismissible={ false }>
					{ __( 'Falta el texto alternativo (obligatorio)', 'ebio-core' ) }
				</Notice>
			) : null }
		</PluginDocumentSettingPanel>
	);
}
