/**
 * Copia de `value` con `newValue` en `path` (sin mutar). Ruta: clave o lista de claves/índices.
 *
 * @param {*}                       value    Atributo raíz.
 * @param {string|number|Array}     path     Ruta.
 * @param {*}                       newValue Valor nuevo.
 * @return {*} Copia actualizada.
 */
export function setIn( value, path, newValue ) {
	const keys = Array.isArray( path ) ? path : [ path ];
	if ( keys.length === 0 ) {
		return newValue;
	}
	const [ head, ...rest ] = keys;
	if ( Array.isArray( value ) ) {
		return value.map( ( item, i ) => ( i === head ? setIn( item, rest, newValue ) : item ) );
	}
	return { ...( value ?? {} ), [ head ]: setIn( value?.[ head ], rest, newValue ) };
}

/**
 * Valor del `EditContext` de un bloque: `onChange( path, value )` guarda el cambio en el atributo
 * raíz de la ruta (`path[0]`). Reutilizable por todos los bloques con RichText en línea.
 *
 * @param {Object}   attributes    Atributos del bloque.
 * @param {Function} setAttributes `setAttributes` del bloque.
 * @return {{ onChange: Function }} Valor del contexto.
 */
export function makeEditContext( attributes, setAttributes ) {
	return {
		onChange( path, value ) {
			const keys = Array.isArray( path ) ? path : [ path ];
			const [ root, ...rest ] = keys;
			setAttributes( { [ root ]: setIn( attributes?.[ root ], rest, value ) } );
		},
	};
}
