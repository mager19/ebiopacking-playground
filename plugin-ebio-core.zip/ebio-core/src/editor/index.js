/**
 * Entrada del editor de bloques (se compila aparte de los bloques: build/editor/index.js). Solo se
 * encola para `ebio_product` (includes/editor-assets.php).
 */
import { registerPlugin } from '@wordpress/plugins';
import ProductDocumentPanel from './ProductDocumentPanel.jsx';

registerPlugin( 'ebio-product-data', { render: ProductDocumentPanel } );
