import { useEffect } from '@wordpress/element';
import { useSelect } from '@wordpress/data';
import { store as blockEditorStore } from '@wordpress/block-editor';

const UID = /^[a-z0-9-]{1,32}$/;

/**
 * Nuevo `uid` `<prefix>-<6 caracteres>` que cumple `^[a-z0-9-]{1,32}$` (catalog §2.1).
 *
 * @param {string} prefix Prefijo (p. ej. `faq`).
 * @return {string} uid.
 */
export function createUid( prefix ) {
	const base = String( prefix ?? '' )
		.toLowerCase()
		.replace( /[^a-z0-9-]/g, '' )
		.slice( 0, 25 ) || 'ebio';
	let random = '';
	while ( random.length < 6 ) {
		random += Math.random().toString( 36 ).slice( 2 );
	}
	return `${ base }-${ random.slice( 0, 6 ) }`;
}

/**
 * `uid` de una instancia de bloque. Genera uno si falta o no es válido, y lo regenera si otro bloque
 * anterior del editor tiene el mismo (bloque copiado y pegado: los IDs de `aria-controls` chocarían).
 * El primer bloque con un `uid` lo conserva; los siguientes reciben uno nuevo.
 *
 * @param {string}   clientId      clientId del bloque.
 * @param {Object}   attributes    Atributos del bloque (usa `uid`).
 * @param {Function} setAttributes `setAttributes` del bloque.
 * @param {string}   prefix        Prefijo del uid (p. ej. `faq`).
 * @return {string} uid vigente.
 */
export default function useUid( clientId, attributes, setAttributes, prefix ) {
	const uid = typeof attributes?.uid === 'string' ? attributes.uid : '';
	const isDuplicate = useSelect(
		( select ) => {
			if ( ! uid ) {
				return false;
			}
			const { getClientIdsWithDescendants, getBlockAttributes } = select( blockEditorStore );
			const first = getClientIdsWithDescendants().find( ( id ) => getBlockAttributes( id )?.uid === uid );
			return first !== undefined && first !== clientId;
		},
		[ clientId, uid ]
	);
	const needsNew = ! UID.test( uid ) || isDuplicate;

	useEffect( () => {
		if ( needsNew ) {
			setAttributes( { uid: createUid( prefix ) } );
		}
		// setAttributes cambia de identidad en cada render del editor; solo importa needsNew.
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [ needsNew, uid ] );

	return uid;
}
