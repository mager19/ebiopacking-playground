import { __ } from '@wordpress/i18n';
import { MediaUpload, MediaUploadCheck } from '@wordpress/block-editor';
import { Button } from '@wordpress/components';
import { mediaToImage } from './ImageControl.jsx';

/**
 * Botón en el lienzo para elegir o cambiar la foto de una tarjeta.
 *
 * @param {Object}   props
 * @param {Object}   props.image    Atributo de imagen actual.
 * @param {Function} props.onChange Recibe el nuevo atributo de imagen.
 */
export default function CardImagePicker( { image, onChange } ) {
	return (
		<MediaUploadCheck>
			<MediaUpload
				allowedTypes={ [ 'image' ] }
				value={ image?.id || undefined }
				onSelect={ ( media ) => onChange( mediaToImage( media ) ) }
				render={ ( { open } ) => (
					<Button variant="secondary" size="small" onClick={ open }>
						{ image?.id ? __( 'Cambiar imagen', 'ebio-core' ) : __( 'Elegir imagen', 'ebio-core' ) }
					</Button>
				) }
			/>
		</MediaUploadCheck>
	);
}
