import { useEffect, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';

/**
 * Vista de un bloque dinámico en el editor (catalog §2.11): `GET /ebio/v1/view/<bloque>` ejecuta el
 * mismo constructor PHP que el frontend. En Storybook un middleware de `apiFetch` devuelve el
 * `ebio/view` del fixture.
 *
 * @param {string} name       Nombre del bloque (`ebio/faq`).
 * @param {Object} attributes Atributos del bloque.
 * @param {Object} context    Contexto del bloque (usa `postId`).
 * @return {{ view: Object|null, isLoading: boolean, error: string|null }} Estado de la vista.
 */
export default function useBlockView( name, attributes, context = {} ) {
	const block = String( name ).replace( /^ebio\//, '' );
	const postId = Number( context?.postId ) || 0;
	const query = new URLSearchParams( { attributes: JSON.stringify( attributes ?? {} ), postId: String( postId ) } ).toString();
	const path = `/ebio/v1/view/${ block }?${ query }`;
	const [ state, setState ] = useState( { view: null, isLoading: true, error: null } );

	useEffect( () => {
		let active = true;
		setState( ( prev ) => ( { ...prev, isLoading: true, error: null } ) );
		apiFetch( { path } ).then(
			( view ) => active && setState( { view, isLoading: false, error: null } ),
			( err ) => active && setState( { view: null, isLoading: false, error: err?.message || String( err ) } )
		);
		return () => {
			active = false;
		};
	}, [ path ] );

	return state;
}
