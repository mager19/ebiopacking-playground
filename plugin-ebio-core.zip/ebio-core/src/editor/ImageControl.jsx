import { __ } from '@wordpress/i18n';
import { MediaUpload, MediaUploadCheck } from '@wordpress/block-editor';
import { BaseControl, Button, Notice, TextControl } from '@wordpress/components';

export const EMPTY_IMAGE = { id: 0, url: '', alt: '', width: 0, height: 0 };

/**
 * Atributo de imagen (catalog §2.5) a partir de un objeto de la biblioteca de medios.
 *
 * @param {Object} media Objeto de `MediaUpload` / `MediaPlaceholder`.
 * @return {{ id: number, url: string, alt: string, width: number, height: number }} Atributo de imagen.
 */
export const mediaToImage = ( media ) => ( {
	id: media.id,
	url: media.url,
	alt: media.alt ?? '',
	width: media.width ?? 0,
	height: media.height ?? 0,
} );

/**
 * Imagen de un bloque estático `{ id, url, alt, width, height }` (catalog §2.5) con su texto
 * alternativo. Con `required`, una imagen sin alt muestra el aviso C-B3.
 *
 * @param {Object}   props
 * @param {string}   props.label    Etiqueta del control.
 * @param {Object}   props.value    Atributo de imagen.
 * @param {Function} props.onChange Recibe el nuevo atributo de imagen.
 * @param {boolean}  props.required El alt es obligatorio.
 */
export default function ImageControl( { label, value, onChange, required = false } ) {
	const image = { ...EMPTY_IMAGE, ...( value ?? {} ) };
	const select = ( media ) => onChange( mediaToImage( media ) );

	return (
		<BaseControl label={ label } __nextHasNoMarginBottom>
			<MediaUploadCheck>
				<MediaUpload
					allowedTypes={ [ 'image' ] }
					value={ image.id || undefined }
					onSelect={ select }
					render={ ( { open } ) => (
						<Button variant="secondary" onClick={ open }>
							{ image.id ? __( 'Reemplazar imagen', 'ebio-core' ) : __( 'Elegir imagen', 'ebio-core' ) }
						</Button>
					) }
				/>
			</MediaUploadCheck>
			{ image.id ? (
				<Button variant="link" isDestructive onClick={ () => onChange( { ...EMPTY_IMAGE } ) }>
					{ __( 'Quitar imagen', 'ebio-core' ) }
				</Button>
			) : null }
			{ image.id ? (
				<TextControl
					label={ required ? __( 'Texto alternativo (obligatorio)', 'ebio-core' ) : __( 'Texto alternativo', 'ebio-core' ) }
					value={ image.alt }
					onChange={ ( alt ) => onChange( { ...image, alt } ) }
					__nextHasNoMarginBottom
					__next40pxDefaultSize
				/>
			) : null }
			{ required && image.id && ! image.alt ? (
				<Notice status="warning" isDismissible={ false }>
					{ __( 'Falta el texto alternativo (obligatorio)', 'ebio-core' ) }
				</Notice>
			) : null }
		</BaseControl>
	);
}
