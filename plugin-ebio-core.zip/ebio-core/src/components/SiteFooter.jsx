import { rootProps } from './lib/root-props.js';
import DynamicImage from './lib/DynamicImage.jsx';

/**
 * `ebio/site-footer` (docs/blocks/site-footer.md): bloque dinámico sin InnerBlocks; contacto, logo,
 * año y columnas de enlaces llegan en la vista (`context['ebio/view']`, de `ebio_site_settings()`).
 * Gemelo de `render.php`. Un dato vacío no emite su elemento.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function SiteFooter( { attributes, context = {} } ) {
	const { description = '', ctaText = '', ctaUrl = '/cotizar/', copyright = '' } = attributes ?? {};
	const view = context?.[ 'ebio/view' ] ?? {};
	const logo = view.logo ?? null;
	const phones = ( Array.isArray( view.phones ) ? view.phones : [] ).filter( ( phone ) => phone?.label && phone?.href );
	const email = view.email?.label ? view.email : null;
	const address = view.address ?? '';
	const hours = view.hours ?? '';
	const hasContact = address !== '' || phones.length > 0 || email !== null || hours !== '';
	const columns = ( Array.isArray( view.columns ) ? view.columns : [] ).map( ( column ) => ( {
		title: column?.title ?? '',
		links: ( Array.isArray( column?.links ) ? column.links : [] ).filter( ( link ) => link?.label && link?.url ),
	} ) ).filter( ( column ) => column.title !== '' || column.links.length > 0 );
	const legalLinks = ( Array.isArray( attributes?.legalLinks ) ? attributes.legalLinks : [] ).filter( ( link ) => link?.label && link?.url );

	return (
		<div { ...rootProps( 'ebio-site-footer', [], attributes ?? {} ) }>
			<div className="ebio-site-footer__inner">
				<div className="ebio-site-footer__brand">
					<a className="ebio-site-footer__logo" href="/" aria-label="eBiopacking, ir al inicio">
						{ logo ? <DynamicImage className="ebio-site-footer__logo-image" image={ logo } /> : 'eBiopacking' }
					</a>
					{ description ? <p className="ebio-site-footer__description">{ description }</p> : null }
					{ hasContact ? (
						<address className="ebio-site-footer__contact">
							{ address ? <p className="ebio-site-footer__address">{ address }</p> : null }
							{ phones.length > 0 ? (
								<ul className="ebio-site-footer__phones">
									{ phones.map( ( phone, i ) => (
										<li className="ebio-site-footer__phone" key={ i }>
											<a className="ebio-site-footer__contact-link" href={ phone.href }>
												{ phone.label }
											</a>
										</li>
									) ) }
								</ul>
							) : null }
							{ email ? (
								<p className="ebio-site-footer__email">
									<a className="ebio-site-footer__contact-link" href={ email.href }>
										{ email.label }
									</a>
								</p>
							) : null }
							{ hours ? <p className="ebio-site-footer__hours">{ `Horario: ${ hours }` }</p> : null }
						</address>
					) : null }
					{ ctaText ? (
						<a className="ebio-site-footer__cta ebio-button ebio-button--secondary" href={ ctaUrl }>
							{ ctaText }
						</a>
					) : null }
				</div>
				{ columns.length > 0 ? (
					<div className="ebio-site-footer__columns">
						{ columns.map( ( column, i ) => (
							<div className="ebio-site-footer__column" key={ i }>
								{ column.title ? <h2 className="wp-block-heading">{ column.title }</h2> : null }
								{ column.links.length > 0 ? (
									<ul className="wp-block-list">
										{ column.links.map( ( link, j ) => (
											<li key={ j }>
												<a href={ link.url }>{ link.label }</a>
											</li>
										) ) }
									</ul>
								) : null }
							</div>
						) ) }
					</div>
				) : null }
				<div className="ebio-site-footer__legal">
					<p className="ebio-site-footer__copyright">
						©{ ' ' }
						<span className="ebio-site-footer__year">{ view.year ?? '' }</span>
						{ ' ' }
						{ copyright }
					</p>
					{ legalLinks.length > 0 ? (
						<ul className="ebio-site-footer__legal-links">
							{ legalLinks.map( ( link, i ) => (
								<li className="ebio-site-footer__legal-item" key={ i }>
									<a className="ebio-site-footer__legal-link" href={ link.url }>
										{ link.label }
									</a>
								</li>
							) ) }
						</ul>
					) : null }
				</div>
			</div>
		</div>
	);
}
