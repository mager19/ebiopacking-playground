import { rootProps } from './lib/root-props.js';
import DynamicImage from './lib/DynamicImage.jsx';
import { counterLabel } from '../stores/quote/lib.js';

/**
 * `ebio/site-header` (docs/blocks/site-header.md): bloque dinámico; logo y menú llegan en la vista
 * (`context['ebio/view']`, de `ebio_site_settings()`). Gemelo de `render.php`.
 *
 * `context['ebio/state']` (solo Storybook) traduce el estado de la Interactivity API a markup:
 * `{ hydrated, menuOpen, searchOpen }` de `ebio/site-header` y `{ count, toastVisible, toastText }`
 * de `ebio/quote`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`, `ebio/state`).
 */
export default function SiteHeader( { attributes, context = {} } ) {
	const {
		homeUrl = '/',
		searchAction = '/',
		searchPlaceholder = '',
		quoteUrl = '/cotizar/',
		quoteLabel = '',
		ctaText = '',
		ctaUrl = '/cotizar/',
	} = attributes ?? {};
	const view = context?.[ 'ebio/view' ] ?? {};
	const logo = view.logo ?? null;
	const nav = Array.isArray( view.nav ) ? view.nav : [];
	const state = context?.[ 'ebio/state' ] ?? {};
	const hydrated = state.hydrated === true;
	const menuOpen = state.menuOpen === true;
	const searchOpen = state.searchOpen === true;
	const count = Number( state.count ) || 0;
	const flag = ( value ) => ( value ? 'true' : 'false' );

	return (
		<div
			{ ...rootProps( 'ebio-site-header', [], attributes ?? {} ) }
			data-wp-interactive="ebio/site-header"
			data-wp-context={ JSON.stringify( { menuOpen: false, searchOpen: false, hydrated: false } ) }
			data-wp-init="callbacks.hydrate"
			data-wp-on-document--keydown="actions.closeOnEscape"
			data-hydrated={ flag( hydrated ) }
			data-wp-bind--data-hydrated="context.hydrated"
		>
			<div className="ebio-site-header__inner">
				<a className="ebio-site-header__logo" href={ homeUrl } rel="home" aria-label="eBiopacking, ir al inicio">
					{ logo ? <DynamicImage className="ebio-site-header__logo-image" image={ logo } /> : 'eBiopacking' }
				</a>
				{ nav.length > 0 && (
					<button
						type="button"
						className="ebio-site-header__menu-toggle ebio-button ebio-button--icon"
						aria-controls="ebio-site-header-nav"
						aria-expanded={ flag( menuOpen ) }
						hidden={ hydrated ? undefined : true }
						data-wp-bind--hidden="!context.hydrated"
						data-wp-bind--aria-expanded="context.menuOpen"
						data-wp-on--click="actions.toggleMenu"
					>
						<span className="ebio-icon ebio-icon--menu" aria-hidden="true"></span>
						<span className="ebio-visually-hidden">Menú</span>
					</button>
				) }
				{ nav.length > 0 && (
					<div className="ebio-site-header__nav" id="ebio-site-header-nav" data-open={ flag( menuOpen ) } data-wp-bind--data-open="context.menuOpen">
						<nav className="ebio-site-header__menu" aria-label="Principal">
							<ul className="ebio-site-header__menu-list">
								{ nav.map( ( item, i ) => (
									<li className="ebio-site-header__menu-item" key={ i }>
										<a className="ebio-site-header__menu-link" href={ item?.url ?? '' } aria-current={ item?.current === 'page' ? 'page' : undefined }>
											{ item?.label ?? '' }
										</a>
									</li>
								) ) }
							</ul>
						</nav>
					</div>
				) }
				<form
					className="ebio-site-header__search"
					id="ebio-site-header-search"
					role="search"
					action={ searchAction }
					method="get"
					data-open={ flag( searchOpen ) }
					data-wp-bind--data-open="context.searchOpen"
				>
					<label className="ebio-visually-hidden" htmlFor="ebio-site-header-search-input">
						Buscar empaques
					</label>
					<input
						className="ebio-site-header__search-input"
						id="ebio-site-header-search-input"
						type="search"
						name="s"
						placeholder={ searchPlaceholder }
						autoComplete="off"
					/>
					<button type="submit" className="ebio-site-header__search-submit ebio-button ebio-button--icon">
						<span className="ebio-icon ebio-icon--search" aria-hidden="true"></span>
						<span className="ebio-visually-hidden">Buscar</span>
					</button>
				</form>
				<button
					type="button"
					className="ebio-site-header__search-toggle ebio-button ebio-button--icon"
					aria-controls="ebio-site-header-search"
					aria-expanded={ flag( searchOpen ) }
					hidden={ hydrated ? undefined : true }
					data-wp-bind--hidden="!context.hydrated"
					data-wp-bind--aria-expanded="context.searchOpen"
					data-wp-on--click="actions.toggleSearch"
				>
					<span className="ebio-icon ebio-icon--search" aria-hidden="true"></span>
					<span className="ebio-visually-hidden">Mostrar buscador</span>
				</button>
				<a
					className="ebio-site-header__quote"
					href={ quoteUrl }
					data-wp-interactive="ebio/quote"
					aria-label={ counterLabel( count, quoteLabel ) }
					data-wp-bind--aria-label="state.counterLabel"
				>
					<span className="ebio-icon ebio-icon--list" aria-hidden="true"></span>
					<span className="ebio-site-header__quote-label">{ quoteLabel }</span>
					<span className="ebio-site-header__quote-count" aria-hidden="true" data-wp-text="state.count">
						{ String( count ) }
					</span>
				</a>
				<a className="ebio-site-header__cta ebio-button ebio-button--primary" href={ ctaUrl }>
					{ ctaText }
				</a>
			</div>
			<div className="ebio-site-header__toast" role="status" data-wp-interactive="ebio/quote">
				<p className="ebio-site-header__toast-body" hidden={ state.toastVisible ? undefined : true } data-wp-bind--hidden="!state.toastVisible">
					<span className="ebio-icon ebio-icon--check" aria-hidden="true"></span>
					<span className="ebio-site-header__toast-text" data-wp-text="state.toastText">
						{ state.toastText ?? '' }
					</span>
					<a className="ebio-site-header__toast-link" href={ quoteUrl }>
						Ver lista
					</a>
				</p>
			</div>
		</div>
	);
}
