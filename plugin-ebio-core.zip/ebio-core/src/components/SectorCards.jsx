import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';
import BlockImage from './lib/BlockImage.jsx';
import CardLink from './lib/CardLink.jsx';
import CardImageSlot from './lib/CardImageSlot.jsx';

const MAX_ITEMS = 6;

/**
 * `ebio/sector-cards` (docs/blocks/sector-cards.md): tarjetas de sectores con foto y una línea de uso.
 * La imagen va con `alt=""` dentro del enlace con título (D21). El título de cada tarjeta usa
 * `headingLevel + 1`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 */
export default function SectorCards( { attributes } ) {
	const { heading, headingLevel = 2, intro } = attributes ?? {};
	const CardTitle = `h${ headingLevel + 1 }`;
	const items = ( Array.isArray( attributes?.items ) ? attributes.items : [] ).slice( 0, MAX_ITEMS );

	return (
		<section { ...rootProps( 'ebio-sector-cards', [], attributes ?? {} ) }>
			<div className="ebio-sector-cards__inner">
				<div className="ebio-sector-cards__header">
					<RichField tagName={ `h${ headingLevel }` } className="ebio-sector-cards__heading" value={ heading } path="heading" />
					<RichField tagName="p" className="ebio-sector-cards__intro" value={ intro } path="intro" />
				</div>
				<ul className="ebio-sector-cards__list">
					{ items.map( ( item, i ) => (
						<li className="ebio-sector-cards__item" key={ i }>
							<CardLink className="ebio-sector-cards__card" href={ item?.url }>
								<CardImageSlot path={ [ 'items', i, 'image' ] } image={ item?.image } />
								<BlockImage className="ebio-sector-cards__image" image={ item?.image ? { ...item.image, alt: '' } : null } />
								<RichField tagName={ CardTitle } className="ebio-sector-cards__title" value={ item?.title } path={ [ 'items', i, 'title' ] } />
								<RichField tagName="p" className="ebio-sector-cards__text" value={ item?.text } path={ [ 'items', i, 'text' ] } />
							</CardLink>
						</li>
					) ) }
				</ul>
			</div>
		</section>
	);
}
