import { rootProps } from './lib/root-props.js';
import ProductCard from './ProductCard.jsx';

/**
 * `ebio/product-grid` (docs/blocks/product-grid.md): grilla de productos con filtros Categoría / Sector /
 * Formato. Bloque dinámico: los productos, los grupos y el texto llegan en la vista (`context['ebio/view']`).
 * Gemelo de `render.php`. Todo el conjunto de la fuente se emite; lo que no cumple va con `hidden`.
 * `status: hidden` no emite nada; búsqueda sin resultados (D23) solo emite el estado vacío con H2.
 *
 * `context['ebio/state']` (solo Storybook) traduce el estado de la Interactivity API a markup:
 * `{ hydrated, panelOpen }`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`, `ebio/state`).
 */
export default function ProductGrid( { attributes, context = {} } ) {
	const {
		variant = 'full-filters',
		source = 'all',
		headingLevel = 2,
		showCountLine = false,
		emptyText = '',
		emptyCtaText = '',
		emptyCtaUrl = '/cotizar/',
	} = attributes ?? {};
	const view = context?.[ 'ebio/view' ] ?? {};
	const status = view.status ?? 'results';
	if ( status === 'hidden' ) {
		return null;
	}
	const uid = view.uid ?? '';
	const headingId = `ebio-product-grid-${ uid }-heading`;
	const filtersId = `ebio-product-grid-${ uid }-filters`;
	const groups = Array.isArray( view.groups ) ? view.groups : [];
	const products = Array.isArray( view.products ) ? view.products : [];
	const visible = ( Array.isArray( view.visible ) ? view.visible : [] ).map( Number );
	const formAction = view.formAction ?? '/';
	const isEmpty = status === 'empty';
	const hasForm = variant !== 'plain';
	const Heading = `h${ headingLevel }`;
	// Resultados visibles: `data-count` y `--few` (1 a 3) dejan al CSS ensanchar las tarjetas cuando hay pocas.
	const count = visible.length;
	const isFew = count > 0 && count <= 3;
	const modifiers = [ variant === 'full-filters' ? '' : variant, isFew ? 'few' : '' ];
	const state = context?.[ 'ebio/state' ];
	const hydrated = state?.hydrated === true;
	const panelOpen = hydrated && state?.panelOpen === true;

	// Búsqueda sin ningún resultado (D23): solo el estado vacío, con H2, sin filtros ni barra.
	if ( isEmpty && source === 'search' ) {
		return (
			<section { ...rootProps( 'ebio-product-grid', modifiers, attributes ?? {} ) } aria-labelledby={ headingId }>
				<div className="ebio-product-grid__inner">
					<div className="ebio-product-grid__results">
						<div className="ebio-product-grid__empty">
							<h2 className="ebio-product-grid__empty-title" id={ headingId }>
								{ view.emptyTitle ?? '' }
							</h2>
							{ emptyText ? <p className="ebio-product-grid__empty-text">{ emptyText }</p> : null }
							<a className="ebio-product-grid__empty-cta ebio-button ebio-button--primary" href={ emptyCtaUrl }>
								{ emptyCtaText }
							</a>
						</div>
					</div>
				</div>
			</section>
		);
	}

	const selection = { categoria: [], sector: [], formato: [] };
	for ( const group of groups ) {
		if ( selection[ group?.key ] ) {
			for ( const option of group.options ?? [] ) {
				if ( option?.checked ) {
					selection[ group.key ].push( option.value );
				}
			}
		}
	}

	return (
		<section
			{ ...rootProps( 'ebio-product-grid', modifiers, attributes ?? {} ) }
			aria-labelledby={ headingId }
			data-count={ String( count ) }
			data-wp-interactive="ebio/product-grid"
			data-wp-context={ JSON.stringify( { ...selection, panelOpen: false, hydrated: false } ) }
			data-wp-init="callbacks.init"
			data-wp-on--keydown="actions.closePanelOnEscape"
			data-hydrated={ hydrated ? 'true' : 'false' }
			data-wp-bind--data-hydrated="context.hydrated"
			data-wp-bind--data-count="state.resultCount"
			data-wp-class--ebio-product-grid--few="state.isFew"
		>
			<div className="ebio-product-grid__inner">
				<div className="ebio-product-grid__toolbar">
					<Heading className="ebio-product-grid__heading" id={ headingId } data-wp-text="state.headingText">
						{ view.headingText ?? '' }
					</Heading>
					{ showCountLine ? (
						<p className="ebio-product-grid__count" data-wp-text="state.countText">
							{ view.countText ?? '' }
						</p>
					) : null }
					{ hasForm && (
						<button
							type="button"
							className="ebio-product-grid__filters-toggle ebio-button ebio-button--secondary ebio-button--small"
							aria-controls={ filtersId }
							aria-expanded={ panelOpen ? 'true' : 'false' }
							hidden={ hydrated ? undefined : true }
							data-wp-bind--hidden="!context.hydrated"
							data-wp-bind--aria-expanded="context.panelOpen"
							data-wp-on--click="actions.togglePanel"
						>
							Filtrar
						</button>
					) }
				</div>
				{ hasForm && (
					<form
						className="ebio-product-grid__filters"
						id={ filtersId }
						action={ formAction }
						method="get"
						aria-label="Filtros de productos"
						data-open={ panelOpen ? 'true' : 'false' }
						data-wp-bind--data-open="context.panelOpen"
						data-wp-on--change="actions.applyFilter"
					>
						{ groups.map( ( group ) => (
							<fieldset className="ebio-product-grid__group" key={ group?.key }>
								<legend className="ebio-product-grid__legend">{ group?.legend ?? '' }</legend>
								<ul className="ebio-product-grid__options">
									{ ( group?.options ?? [] ).map( ( option ) => (
										<li className="ebio-product-grid__option-item" key={ option?.value }>
											<label className="ebio-product-grid__option">
												<input
													className="ebio-product-grid__checkbox"
													type="checkbox"
													name={ `${ group?.key }[]` }
													value={ option?.value ?? '' }
													defaultChecked={ option?.checked ? true : undefined }
												/>
												<span className="ebio-product-grid__option-label">{ option?.label ?? '' }</span>
											</label>
										</li>
									) ) }
								</ul>
							</fieldset>
						) ) }
						<div className="ebio-product-grid__filter-actions">
							<button
								type="submit"
								className="ebio-product-grid__apply ebio-button ebio-button--secondary"
								hidden={ hydrated ? true : undefined }
								data-wp-bind--hidden="context.hydrated"
							>
								Aplicar filtros
							</button>
							<a className="ebio-product-grid__clear" href={ formAction } data-wp-on--click="actions.clear">
								Limpiar filtros
							</a>
						</div>
					</form>
				) }
				<div className="ebio-product-grid__results">
					<p className="ebio-product-grid__live ebio-visually-hidden" role="status" data-wp-text="state.liveText"></p>
					<ul className="ebio-product-grid__list" hidden={ isEmpty ? true : undefined } data-wp-bind--hidden="state.isEmpty">
						{ products.map( ( card, i ) => {
							const facets = card?.facets ?? {};
							const hidden = ! visible.includes( Number( card?.id ) );
							return (
								<li
									className="ebio-product-grid__item"
									key={ card?.id ?? i }
									hidden={ hidden ? true : undefined }
									data-wp-context={ JSON.stringify( {
										categories: facets.categories ?? [],
										sectors: facets.sectors ?? [],
										formats: facets.formats ?? [],
										hidden,
									} ) }
									data-wp-watch="callbacks.syncItem"
									data-wp-bind--hidden="context.hidden"
								>
									<ProductCard card={ card } options={ { headingLevel: 3, quoteUrl: view.quoteUrl, showAddToQuote: true } } />
								</li>
							);
						} ) }
					</ul>
					<div className="ebio-product-grid__empty" hidden={ isEmpty ? undefined : true } data-wp-bind--hidden="!state.isEmpty">
						<h3 className="ebio-product-grid__empty-title" data-wp-text="state.emptyTitle">
							{ view.emptyTitle ?? '' }
						</h3>
						{ emptyText ? <p className="ebio-product-grid__empty-text">{ emptyText }</p> : null }
						<a className="ebio-product-grid__empty-cta ebio-button ebio-button--primary" href={ emptyCtaUrl }>
							{ emptyCtaText }
						</a>
					</div>
				</div>
			</div>
		</section>
	);
}
