import { rootProps } from './lib/root-props.js';

/**
 * `ebio/breadcrumbs` (docs/blocks/breadcrumbs.md): bloque dinámico; la ruta llega en la vista
 * (`context['ebio/view']`: `items` y `current`). Gemelo de `render.php`. Sin `current` (solo "Inicio") no emite nada.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function Breadcrumbs( { attributes, context = {} } ) {
	const { ariaLabel = '' } = attributes ?? {};
	const view = context?.[ 'ebio/view' ] ?? {};
	const current = typeof view.current === 'string' ? view.current : '';
	const items = ( Array.isArray( view.items ) ? view.items : [] ).filter( ( item ) => item?.label && item?.url );
	if ( current === '' ) {
		return null;
	}

	return (
		<nav { ...rootProps( 'ebio-breadcrumbs', [], attributes ?? {} ) } aria-label={ ariaLabel }>
			<div className="ebio-breadcrumbs__inner">
				<ol className="ebio-breadcrumbs__list">
					{ items.map( ( item, i ) => (
						<li className="ebio-breadcrumbs__item" key={ i }>
							<a className="ebio-breadcrumbs__link" href={ item.url }>
								{ item.label }
							</a>
						</li>
					) ) }
					<li className="ebio-breadcrumbs__item">
						<span className="ebio-breadcrumbs__current" aria-current="page">
							{ current }
						</span>
					</li>
				</ol>
			</div>
		</nav>
	);
}
