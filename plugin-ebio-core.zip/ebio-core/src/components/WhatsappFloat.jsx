import { rootProps } from './lib/root-props.js';

/**
 * `ebio/whatsapp-float` (docs/blocks/whatsapp-float.md): botón fijo de WhatsApp; la URL y la variante
 * `raised` llegan en la vista (`context['ebio/view']`). Sin URL no emite nada. Gemelo de `render.php`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function WhatsappFloat( { attributes, context = {} } ) {
	const label = typeof attributes?.label === 'string' && attributes.label.trim() !== '' ? attributes.label : 'Escribir por WhatsApp';
	const view = context?.[ 'ebio/view' ] ?? {};
	if ( ! view.url ) {
		return null;
	}
	return (
		<a { ...rootProps( 'ebio-whatsapp-float', [ view.raised === true && 'raised' ], attributes ?? {} ) } href={ view.url } target="_blank" rel="noopener">
			<span className="ebio-icon ebio-icon--whatsapp" aria-hidden="true"></span>
			<span className="ebio-visually-hidden">{ `${ label } (abre WhatsApp en una pestaña nueva)` }</span>
		</a>
	);
}
