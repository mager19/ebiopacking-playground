import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';
import DynamicImage from './lib/DynamicImage.jsx';

/**
 * Cita con su autoría; `span` vacíos no se emiten. Sin hooks.
 *
 * @param {Object} props
 * @param {Object} props.item Ítem `quote` de la vista.
 */
function Quote( { item } ) {
	return (
		<figure className="ebio-testimonials__quote">
			<blockquote className="ebio-testimonials__text">
				<p>{ item?.quote ?? '' }</p>
			</blockquote>
			<figcaption className="ebio-testimonials__author">
				{ item?.name ? <span className="ebio-testimonials__name">{ item.name }</span> : null }
				{ item?.role ? <span className="ebio-testimonials__role">{ item.role }</span> : null }
				{ item?.company ? <span className="ebio-testimonials__company">{ item.company }</span> : null }
			</figcaption>
		</figure>
	);
}

/**
 * `ebio/testimonials` (docs/blocks/testimonials.md): carrusel mixto de fotos y citas, o caso único
 * (`single`). Bloque dinámico: la vista solo trae citas autorizadas y fotos con alt (C-B3, D22); sin
 * citas no emite nada. Gemelo de `render.php`. Sin autoplay; los controles (solo `default`) llevan
 * `hidden` hasta hidratar.
 *
 * `context['ebio/state']` (solo Storybook): `{ hydrated, index }`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`, `ebio/state`).
 */
export default function Testimonials( { attributes, context = {} } ) {
	const { variant = 'default', heading = '', headingLevel = 2, intro = '' } = attributes ?? {};
	const view = context?.[ 'ebio/view' ] ?? {};
	const items = Array.isArray( view.items ) ? view.items : [];
	if ( ! items.some( ( item ) => item?.type === 'quote' ) ) {
		return null;
	}
	const Heading = `h${ headingLevel }`;

	if ( variant === 'single' ) {
		const quote = items.find( ( item ) => item?.type === 'quote' );
		const photo = items.find( ( item ) => item?.type === 'photo' );
		return (
			<section { ...rootProps( 'ebio-testimonials', [ 'single' ], attributes ?? {} ) }>
				<div className="ebio-testimonials__inner">
					<Heading className="ebio-testimonials__heading">{ heading }</Heading>
					<div className="ebio-testimonials__case">
						<Quote item={ quote } />
						{ photo ? (
							<div className="ebio-testimonials__media">
								<DynamicImage className="ebio-testimonials__image" image={ photo.image ?? null } />
							</div>
						) : null }
					</div>
				</div>
			</section>
		);
	}

	const uid = view.uid ?? '';
	const count = items.length;
	const headingId = `ebio-testimonials-${ uid }-heading`;
	const trackId = `ebio-testimonials-${ uid }-track`;
	const state = context?.[ 'ebio/state' ];
	const hydrated = state?.hydrated === true;
	const index = hydrated ? Math.min( Math.max( Number.parseInt( state.index, 10 ) || 0, 0 ), count - 1 ) : 0;
	const isFirst = index <= 0;
	const isLast = index >= count - 1;

	return (
		<section
			{ ...rootProps( 'ebio-testimonials', [], attributes ?? {} ) }
			aria-labelledby={ headingId }
			data-wp-interactive="ebio/carousel"
			data-wp-context={ JSON.stringify( { index: 0, count, hydrated: false } ) }
			data-wp-init="callbacks.init"
			data-hydrated={ hydrated ? 'true' : 'false' }
			data-wp-bind--data-hydrated="context.hydrated"
		>
			<div className="ebio-testimonials__inner">
				<div className="ebio-testimonials__header">
					<Heading className="ebio-testimonials__heading" id={ headingId }>
						{ heading }
					</Heading>
					<RichField tagName="p" className="ebio-testimonials__intro" value={ intro } path="intro" allowedFormats={ [ 'core/link' ] } placeholder="Texto de ayuda (opcional)" />
					<div className="ebio-testimonials__controls" hidden={ hydrated ? undefined : true } data-wp-bind--hidden="!context.hydrated">
						<button
							type="button"
							className="ebio-testimonials__prev ebio-button ebio-button--icon"
							aria-controls={ trackId }
							disabled={ isFirst ? true : undefined }
							data-wp-bind--disabled="state.isFirst"
							data-wp-on--click="actions.prev"
						>
							<span className="ebio-icon ebio-icon--arrow-left" aria-hidden="true"></span>
							<span className="ebio-visually-hidden">Anterior</span>
						</button>
						<button
							type="button"
							className="ebio-testimonials__next ebio-button ebio-button--icon"
							aria-controls={ trackId }
							disabled={ isLast ? true : undefined }
							data-wp-bind--disabled="state.isLast"
							data-wp-on--click="actions.next"
						>
							<span className="ebio-icon ebio-icon--arrow-right" aria-hidden="true"></span>
							<span className="ebio-visually-hidden">Siguiente</span>
						</button>
					</div>
				</div>
				<ul className="ebio-testimonials__track" id={ trackId } data-wp-on--scroll="callbacks.syncIndex">
					{ items.map( ( item, i ) =>
						item?.type === 'photo' ? (
							<li className="ebio-testimonials__slide ebio-testimonials__slide--photo" key={ i }>
								<DynamicImage className="ebio-testimonials__image" image={ item.image ?? null } />
							</li>
						) : (
							<li className="ebio-testimonials__slide ebio-testimonials__slide--quote" key={ i }>
								<Quote item={ item } />
							</li>
						)
					) }
				</ul>
			</div>
		</section>
	);
}
