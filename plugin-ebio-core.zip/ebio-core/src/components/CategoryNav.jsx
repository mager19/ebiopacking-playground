import { rootProps } from './lib/root-props.js';

/**
 * `ebio/category-nav` (docs/blocks/category-nav.md): bloque dinámico; los ítems con su `current` llegan
 * en la vista (`context['ebio/view']`). Gemelo de `render.php`. `aria-current` solo se emite con `current`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function CategoryNav( { attributes, context = {} } ) {
	const { ariaLabel = '' } = attributes ?? {};
	const view = context?.[ 'ebio/view' ] ?? {};
	const items = ( Array.isArray( view.items ) ? view.items : [] ).filter( ( item ) => item?.label && item?.url );

	return (
		<nav { ...rootProps( 'ebio-category-nav', [], attributes ?? {} ) } aria-label={ ariaLabel }>
			<div className="ebio-category-nav__inner">
				<ul className="ebio-category-nav__list">
					{ items.map( ( item, i ) => (
						<li className="ebio-category-nav__item" key={ i }>
							<a className="ebio-category-nav__link" href={ item.url } aria-current={ item.current ? item.current : undefined }>
								{ item.icon ? <span className={ `ebio-icon ebio-icon--${ item.icon }` } aria-hidden="true"></span> : null }
								<span className="ebio-category-nav__label">{ item.label }</span>
							</a>
						</li>
					) ) }
				</ul>
			</div>
		</nav>
	);
}
