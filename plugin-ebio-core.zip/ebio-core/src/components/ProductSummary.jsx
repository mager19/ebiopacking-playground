import { rootProps } from './lib/root-props.js';

/**
 * `ebio/product-summary` (docs/blocks/product-summary.md): cabecera de la ficha. Bloque dinámico: los
 * datos del producto llegan en la vista (`context['ebio/view']`); `formats` e `impresión` son atributos.
 * Gemelo de `render.php`. Sin título (fuera de un producto) no emite nada.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function ProductSummary( { attributes, context = {} } ) {
	const view = context?.[ 'ebio/view' ] ?? {};
	const title = typeof view.title === 'string' ? view.title : '';
	if ( title === '' ) {
		return null;
	}
	const tags = Array.isArray( view.tags ) ? view.tags : [];
	const category = view.category && view.category.name ? view.category : null;
	const description = typeof view.description === 'string' ? view.description : '';
	const facts = [
		[ 'Formatos', attributes?.formats ],
		[ 'Pedido mínimo', view.minOrder ],
		[ 'Impresión', attributes?.printing ],
	].filter( ( [ , value ] ) => typeof value === 'string' && value !== '' );

	return (
		<div { ...rootProps( 'ebio-product-summary', [], attributes ?? {} ) }>
			{ tags.length > 0 && (
				<ul className="ebio-product-summary__tags" aria-label="Características">
					{ tags.map( ( tag, i ) => (
						<li className="ebio-product-summary__tag" data-format={ tag?.format ?? '' } key={ i }>
							{ tag?.label ?? '' }
						</li>
					) ) }
				</ul>
			) }
			{ category && (
				<p className="ebio-product-summary__category">
					<a className="ebio-product-summary__category-link" href={ category.url ?? '' }>
						{ category.name }
					</a>
				</p>
			) }
			<h1 className="ebio-product-summary__title">{ title }</h1>
			{ description !== '' && <p className="ebio-product-summary__description">{ description }</p> }
			{ facts.length > 0 && (
				<dl className="ebio-product-summary__facts">
					{ facts.map( ( [ label, value ] ) => (
						<div className="ebio-product-summary__fact" key={ label }>
							<dt className="ebio-product-summary__fact-label">{ label }</dt>
							<dd className="ebio-product-summary__fact-value">{ value }</dd>
						</div>
					) ) }
				</dl>
			) }
		</div>
	);
}
