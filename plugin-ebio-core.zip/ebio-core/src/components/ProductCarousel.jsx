import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';
import ProductCard from './ProductCard.jsx';

/**
 * `ebio/product-carousel` (docs/blocks/product-carousel.md): carrusel horizontal de tarjetas de producto.
 * Bloque dinámico: los productos llegan en la vista (`context['ebio/view']`). Gemelo de `render.php`.
 * Las tarjetas son el componente compartido `ProductCard` (encabezado H3). Sin productos no emite nada.
 * Sin autoplay; los controles llevan `hidden` hasta hidratar.
 *
 * `context['ebio/state']` (solo Storybook) traduce el estado de la Interactivity API a markup:
 * `{ hydrated, index, cards: { [id]: 'added' } }`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`, `ebio/state`).
 */
export default function ProductCarousel( { attributes, context = {} } ) {
	const { heading = '', headingLevel = 2, intro = '', showAddToQuote = true } = attributes ?? {};
	const view = context?.[ 'ebio/view' ] ?? {};
	const products = Array.isArray( view.products ) ? view.products : [];
	if ( products.length === 0 ) {
		return null;
	}
	const Heading = `h${ headingLevel }`;
	const uid = view.uid ?? '';
	const count = products.length;
	const headingId = `ebio-product-carousel-${ uid }-heading`;
	const trackId = `ebio-product-carousel-${ uid }-track`;
	const state = context?.[ 'ebio/state' ];
	const hydrated = state?.hydrated === true;
	const index = hydrated ? Math.min( Math.max( Number.parseInt( state.index, 10 ) || 0, 0 ), count - 1 ) : 0;
	const isFirst = index <= 0;
	const isLast = index >= count - 1;

	return (
		<section
			{ ...rootProps( 'ebio-product-carousel', [], attributes ?? {} ) }
			aria-labelledby={ headingId }
			data-wp-interactive="ebio/carousel"
			data-wp-context={ JSON.stringify( { index: 0, count, hydrated: false } ) }
			data-wp-init="callbacks.init"
			data-hydrated={ hydrated ? 'true' : 'false' }
			data-wp-bind--data-hydrated="context.hydrated"
		>
			<div className="ebio-product-carousel__inner">
				<div className="ebio-product-carousel__header">
					<Heading className="ebio-product-carousel__heading" id={ headingId }>
						{ heading }
					</Heading>
					<RichField tagName="p" className="ebio-product-carousel__intro" value={ intro } path="intro" allowedFormats={ [ 'core/link' ] } placeholder="Texto de ayuda (opcional)" />
					<div className="ebio-product-carousel__controls" hidden={ hydrated ? undefined : true } data-wp-bind--hidden="!context.hydrated">
						<button
							type="button"
							className="ebio-product-carousel__prev ebio-button ebio-button--icon"
							aria-controls={ trackId }
							disabled={ isFirst ? true : undefined }
							data-wp-bind--disabled="state.isFirst"
							data-wp-on--click="actions.prev"
						>
							<span className="ebio-icon ebio-icon--arrow-left" aria-hidden="true"></span>
							<span className="ebio-visually-hidden">Productos anteriores</span>
						</button>
						<button
							type="button"
							className="ebio-product-carousel__next ebio-button ebio-button--icon"
							aria-controls={ trackId }
							disabled={ isLast ? true : undefined }
							data-wp-bind--disabled="state.isLast"
							data-wp-on--click="actions.next"
						>
							<span className="ebio-icon ebio-icon--arrow-right" aria-hidden="true"></span>
							<span className="ebio-visually-hidden">Productos siguientes</span>
						</button>
					</div>
				</div>
				<ul className="ebio-product-carousel__track" id={ trackId } data-wp-on--scroll="callbacks.syncIndex">
					{ products.map( ( card, i ) => (
						<li className="ebio-product-carousel__slide" key={ card?.id ?? i }>
							<ProductCard
								card={ card }
								options={ { headingLevel: 3, quoteUrl: view.quoteUrl, showAddToQuote } }
								state={ state?.cards?.[ card?.id ] ? { cardState: state.cards[ card.id ] } : {} }
							/>
						</li>
					) ) }
				</ul>
				<div className="ebio-product-carousel__progress" aria-hidden="true">
					<span className="ebio-product-carousel__progress-bar"></span>
				</div>
			</div>
		</section>
	);
}
