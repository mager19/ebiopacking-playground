import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';
import DynamicImage from './lib/DynamicImage.jsx';

/**
 * Canal de la lista: ícono, nombre fijo y valores. Sin hooks.
 *
 * @param {Object} props
 * @param {string} props.id       Sufijo del modificador (`phone`, `whatsapp`…).
 * @param {string} props.icon     Ícono (`phone`, `whatsapp`, `mail`, `pin`, `clock`).
 * @param {string} props.name     Nombre fijo del canal.
 * @param {*}      props.children `li` de valores.
 */
function Channel( { id, icon, name, children } ) {
	return (
		<li className={ `ebio-contact-channels__channel ebio-contact-channels__channel--${ id }` }>
			<span className={ `ebio-icon ebio-icon--${ icon } ebio-contact-channels__icon` } aria-hidden="true"></span>
			<p className="ebio-contact-channels__name">{ name }</p>
			<ul className="ebio-contact-channels__values">{ children }</ul>
		</li>
	);
}

/**
 * `ebio/contact-channels` (docs/blocks/contact-channels.md): bloque dinámico; los datos llegan en la
 * vista (`context['ebio/view']`, de `ebio_site_settings()`). Gemelo de `render.php`. Un canal sin
 * dato no se emite; `compact` solo muestra celulares, WhatsApp y correo.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function ContactChannels( { attributes, context = {} } ) {
	const { variant = 'default', heading = '', headingLevel = 2 } = attributes ?? {};
	const view = context?.[ 'ebio/view' ] ?? {};
	const isDefault = variant !== 'compact';
	const phones = ( Array.isArray( view.phones ) ? view.phones : [] ).filter( ( phone ) => phone?.label && phone?.href );
	const whatsapp = view.whatsapp ?? null;
	const email = view.email ?? null;
	const address = view.address ?? '';
	const mapsUrl = view.mapsUrl ?? '';
	const hours = view.hours ?? '';
	const map = isDefault ? view.map ?? null : null;

	return (
		<section { ...rootProps( 'ebio-contact-channels', [ variant !== 'default' && variant ], attributes ?? {} ) }>
			<div className="ebio-contact-channels__inner">
				<RichField tagName={ `h${ headingLevel }` } className="ebio-contact-channels__heading" value={ heading } path="heading" placeholder="Título de la sección" />
				<ul className="ebio-contact-channels__list">
					{ phones.length > 0 && (
						<Channel id="phone" icon="phone" name="Celulares">
							{ phones.map( ( phone, i ) => (
								<li className="ebio-contact-channels__value" key={ i }>
									<a className="ebio-contact-channels__link" href={ phone.href }>
										{ phone.label }
									</a>
								</li>
							) ) }
						</Channel>
					) }
					{ whatsapp && whatsapp.url && (
						<Channel id="whatsapp" icon="whatsapp" name="WhatsApp comercial">
							<li className="ebio-contact-channels__value">
								<a className="ebio-contact-channels__link" href={ whatsapp.url } target="_blank" rel="noopener">
									Escribir por WhatsApp
									<span className="ebio-visually-hidden"> (abre WhatsApp en una pestaña nueva)</span>
								</a>
							</li>
							{ whatsapp.note ? <li className="ebio-contact-channels__value ebio-contact-channels__value--note">{ whatsapp.note }</li> : null }
						</Channel>
					) }
					{ email && email.label && (
						<Channel id="email" icon="mail" name="Correo">
							<li className="ebio-contact-channels__value">
								<a className="ebio-contact-channels__link" href={ email.href }>
									{ email.label }
								</a>
							</li>
						</Channel>
					) }
					{ isDefault && ( address || mapsUrl ) && (
						<Channel id="address" icon="pin" name="Planta">
							{ address ? <li className="ebio-contact-channels__value">{ address }</li> : null }
							{ mapsUrl ? (
								<li className="ebio-contact-channels__value">
									<a className="ebio-contact-channels__link" href={ mapsUrl } target="_blank" rel="noopener">
										Cómo llegar
										<span className="ebio-visually-hidden"> (abre Google Maps en una pestaña nueva)</span>
									</a>
								</li>
							) : null }
						</Channel>
					) }
					{ isDefault && hours && (
						<Channel id="hours" icon="clock" name="Horarios">
							<li className="ebio-contact-channels__value">{ hours }</li>
						</Channel>
					) }
				</ul>
				{ map && mapsUrl ? (
					<a className="ebio-contact-channels__map" href={ mapsUrl } target="_blank" rel="noopener">
						<DynamicImage className="ebio-contact-channels__map-image" image={ map } />
						<span className="ebio-visually-hidden"> (abre Google Maps en una pestaña nueva)</span>
					</a>
				) : null }
			</div>
		</section>
	);
}
