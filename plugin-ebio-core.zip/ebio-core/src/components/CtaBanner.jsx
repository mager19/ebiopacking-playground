import { rootProps } from './lib/root-props.js';

/**
 * `ebio/cta-banner` (docs/blocks/cta-banner.md): bloque dinámico con InnerBlocks; el enlace de
 * WhatsApp llega en la vista (`context['ebio/view'].whatsappUrl`, `''` sin número o con
 * `showWhatsapp` en `false`). Gemelo de `render.php`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 * @param {*}      props.children   Bloques internos (título, párrafo, botones).
 */
export default function CtaBanner( { attributes, context = {}, children } ) {
	const whatsappUrl = context?.[ 'ebio/view' ]?.whatsappUrl ?? '';
	const text = typeof attributes?.whatsappText === 'string' && attributes.whatsappText.trim() !== '' ? attributes.whatsappText : 'Escribir por WhatsApp';

	return (
		<section { ...rootProps( 'ebio-cta-banner', [], attributes ?? {} ) }>
			<div className="ebio-cta-banner__inner">
				<div className="ebio-cta-banner__content">{ children }</div>
				{ whatsappUrl ? (
					<a className="ebio-cta-banner__whatsapp ebio-button ebio-button--secondary" href={ whatsappUrl } target="_blank" rel="noopener">
						<span className="ebio-icon ebio-icon--whatsapp" aria-hidden="true"></span>
						{ text }
						<span className="ebio-visually-hidden"> (abre WhatsApp en una pestaña nueva)</span>
					</a>
				) : null }
			</div>
		</section>
	);
}
