import { rootProps } from './lib/root-props.js';

/**
 * Tres avisos de estado (`role="status"`), iguales en `default` y `sticky`. `status` solo existe en
 * Storybook (`context['ebio/state']`); en el servidor siempre es `idle` y los tres van con `hidden`.
 */
function Status( { quoteUrl, status, confirmationText } ) {
	const confirmed = status === 'added' || status === 'updated';
	return (
		<div className="ebio-add-to-quote__status" role="status">
			<p className="ebio-add-to-quote__confirmation" hidden={ confirmed ? undefined : true } data-wp-bind--hidden="!state.isConfirmationVisible">
				<span className="ebio-icon ebio-icon--check" aria-hidden="true"></span>
				<span className="ebio-add-to-quote__confirmation-text" data-wp-text="state.confirmationText">
					{ confirmed ? confirmationText : '' }
				</span>
				<a className="ebio-add-to-quote__view-list" href={ quoteUrl }>
					Ver lista
				</a>
			</p>
			<p className="ebio-add-to-quote__full" hidden={ status === 'full' ? undefined : true } data-wp-bind--hidden="!state.isFullVisible">
				Tu lista llegó al máximo de 30 productos.{ ' ' }
				<a className="ebio-add-to-quote__view-list" href={ quoteUrl }>
					Revisa tu lista
				</a>
			</p>
			<p className="ebio-add-to-quote__error" hidden={ status === 'storage-error' ? undefined : true } data-wp-bind--hidden="!state.isErrorVisible">
				No pudimos guardar tu lista en este navegador. La conservamos mientras sigas en el sitio.
			</p>
		</div>
	);
}

/**
 * `ebio/add-to-quote` (docs/blocks/add-to-quote.md): agrega el producto a la lista de cotización
 * (`ebio/quote`). Bloque dinámico: el producto llega en la vista (`context['ebio/view']`). Gemelo de
 * `render.php`. Sin producto no emite nada.
 *
 * `context['ebio/state']` (solo Storybook) traduce `context.status` a markup:
 * `{ status: 'added'|'updated'|'full'|'storage-error', confirmationText }`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`, `ebio/state`).
 */
export default function AddToQuote( { attributes, context = {} } ) {
	const view = context?.[ 'ebio/view' ] ?? {};
	const id = Number( view.productId ) || 0;
	if ( id <= 0 ) {
		return null;
	}
	const text = ( key, fallback = '' ) => ( typeof attributes?.[ key ] === 'string' ? attributes[ key ] : fallback );
	const sticky = attributes?.variant === 'sticky';
	const name = view.productName ?? '';
	const quoteUrl = view.quoteUrl ?? '/cotizar/';
	const howUrl = view.howUrl ?? '/cotizar/#como-funciona';
	const whatsappUrl = view.whatsappUrl ?? '';
	const state = context?.[ 'ebio/state' ] ?? {};
	const status = typeof state.status === 'string' ? state.status : 'idle';
	const prefix = `ebio-add-to-quote-${ id }`;
	const buttonText = text( 'buttonText', 'Agregar a cotización' );
	const interactive = {
		'data-state': status,
		'data-wp-interactive': 'ebio/quote',
		'data-wp-context': JSON.stringify( { productId: id, status: 'idle' } ),
		'data-wp-bind--data-state': 'context.status',
	};
	const statusProps = { quoteUrl, status, confirmationText: state.confirmationText ?? '' };

	if ( sticky ) {
		return (
			<div { ...rootProps( 'ebio-add-to-quote', [ 'sticky' ], attributes ?? {} ) } role="region" aria-label={ `Agregar ${ name } a tu cotización` } { ...interactive }>
				<p className="ebio-add-to-quote__product">{ name }</p>
				<form className="ebio-add-to-quote__form" action={ quoteUrl } method="get" data-wp-on--submit="actions.addFromForm">
					<input type="hidden" name="producto" value={ String( id ) } />
					<button type="submit" className="ebio-add-to-quote__submit ebio-button ebio-button--primary ebio-button--small">
						<span className="ebio-icon ebio-icon--plus" aria-hidden="true"></span>
						{ buttonText }
					</button>
				</form>
				<Status { ...statusProps } />
			</div>
		);
	}

	const Heading = `h${ attributes?.headingLevel ?? 2 }`;
	const hint = text( 'hint' );
	const whatsappText = text( 'whatsappText' );
	const howText = text( 'howText' );
	const showWhatsapp = whatsappText !== '' && whatsappUrl !== '';

	return (
		<section { ...rootProps( 'ebio-add-to-quote', [], attributes ?? {} ) } aria-labelledby={ `${ prefix }-heading` } { ...interactive }>
			<Heading className="ebio-add-to-quote__heading" id={ `${ prefix }-heading` }>
				{ text( 'heading' ) }
			</Heading>
			<form className="ebio-add-to-quote__form" action={ quoteUrl } method="get" data-wp-on--submit="actions.addFromForm">
				<input type="hidden" name="producto" value={ String( id ) } />
				<div className="ebio-add-to-quote__field">
					<label className="ebio-add-to-quote__label" htmlFor={ `${ prefix }-quantity` }>
						{ text( 'quantityLabel' ) }
					</label>
					<input
						className="ebio-add-to-quote__input"
						id={ `${ prefix }-quantity` }
						name="cantidad"
						type="text"
						maxLength={ 40 }
						placeholder={ text( 'quantityPlaceholder' ) }
						autoComplete="off"
					/>
				</div>
				<div className="ebio-add-to-quote__field">
					<label className="ebio-add-to-quote__label" htmlFor={ `${ prefix }-dimensions` }>
						{ text( 'dimensionsLabel' ) }
					</label>
					<input
						className="ebio-add-to-quote__input"
						id={ `${ prefix }-dimensions` }
						name="medidas"
						type="text"
						maxLength={ 120 }
						placeholder={ text( 'dimensionsPlaceholder' ) }
						autoComplete="off"
						aria-describedby={ hint !== '' ? `${ prefix }-hint` : undefined }
					/>
					{ hint !== '' && (
						<p className="ebio-add-to-quote__hint" id={ `${ prefix }-hint` }>
							{ hint }
						</p>
					) }
				</div>
				<button type="submit" className="ebio-add-to-quote__submit ebio-button ebio-button--primary ebio-button--block">
					<span className="ebio-icon ebio-icon--plus" aria-hidden="true"></span>
					{ buttonText }
				</button>
			</form>
			{ ( showWhatsapp || howText !== '' ) && (
				<p className="ebio-add-to-quote__links">
					{ showWhatsapp && (
						<a className="ebio-add-to-quote__whatsapp" href={ whatsappUrl } target="_blank" rel="noopener">
							{ whatsappText }
							<span className="ebio-visually-hidden"> (abre WhatsApp en una pestaña nueva)</span>
						</a>
					) }
					{ howText !== '' && (
						<a className="ebio-add-to-quote__how" href={ howUrl }>
							{ howText }
						</a>
					) }
				</p>
			) }
			<Status { ...statusProps } />
		</section>
	);
}
