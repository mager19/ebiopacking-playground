import { rootProps } from './lib/root-props.js';

const HIDDEN_LABEL = 'ebio-quote-list__label ebio-visually-hidden';
const SUB_LABEL = 'ebio-quote-list__sublabel';
const DIMENSIONS = [
	{ key: 'length', label: 'Largo' },
	{ key: 'width', label: 'Ancho' },
	{ key: 'height', label: 'Alto' },
];

/**
 * Campo numérico (cantidad o medida); gemelo de `$ebio_number` en `render.php`.
 *
 * @param {Object}  props
 * @param {string}  props.field      Campo (`data-field`).
 * @param {string}  props.label      Etiqueta.
 * @param {string}  props.labelClass Clase de la etiqueta.
 * @param {boolean} props.integer    Solo enteros (cantidad).
 */
function NumberField( { field, label, labelClass, integer } ) {
	return (
		<>
			<label className={ labelClass } data-wp-bind--for={ `context.item.fieldIds.${ field }` }>
				{ label }
			</label>
			<input
				className="ebio-quote-list__input ebio-quote-list__input--number"
				type="number"
				inputMode={ integer ? 'numeric' : 'decimal' }
				min={ integer ? '1' : '0' }
				step={ integer ? '1' : 'any' }
				autoComplete="off"
				data-field={ field }
				data-wp-bind--id={ `context.item.fieldIds.${ field }` }
				data-wp-bind--value={ `context.item.${ field }` }
				data-wp-on--input="actions.updateField"
			/>
		</>
	);
}

/**
 * Selector de unidad; gemelo de `$ebio_unit` en `render.php`.
 *
 * @param {Object}   props
 * @param {string}   props.field      Campo (`data-field`).
 * @param {string}   props.label      Etiqueta.
 * @param {string}   props.labelClass Clase de la etiqueta.
 * @param {string[]} props.options    Unidades.
 */
function UnitField( { field, label, labelClass, options } ) {
	return (
		<>
			<label className={ labelClass } data-wp-bind--for={ `context.item.fieldIds.${ field }` }>
				{ label }
			</label>
			<select
				className="ebio-quote-list__select"
				data-field={ field }
				data-wp-bind--id={ `context.item.fieldIds.${ field }` }
				data-wp-bind--value={ `context.item.${ field }` }
				data-wp-on--change="actions.updateField"
			>
				{ options.map( ( option ) => (
					<option value={ option } key={ option }>
						{ option }
					</option>
				) ) }
			</select>
		</>
	);
}

/**
 * `ebio/quote-list` (docs/blocks/quote-list.md): lista de cotización editable en `/cotizar/`. Bloque
 * dinámico: la lista la arma el navegador (`ebio/quote`); el servidor solo entrega los textos, el
 * enlace al catálogo y las categorías de la vista. Gemelo de `render.php`.
 *
 * `context['ebio/state']` (solo Storybook) no cambia este markup: el estado vive en el store.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function QuoteList( { attributes, context = {} } ) {
	const view = context?.[ 'ebio/view' ] ?? {};
	const text = ( key, fallback = '' ) => ( typeof attributes?.[ key ] === 'string' ? attributes[ key ] : fallback );
	const catalogUrl = view.catalogUrl ?? '/productos/';
	const formAnchor = view.formAnchor ?? '#ebio-quote-form';
	const categories = Array.isArray( view.categories ) ? view.categories : [];
	const addMoreText = text( 'addMoreText' );
	const Heading = `h${ attributes?.headingLevel ?? 2 }`;

	return (
		<section
			{ ...rootProps( 'ebio-quote-list', [], attributes ?? {} ) }
			aria-labelledby="ebio-quote-list-heading"
			data-state="loading"
			aria-busy="true"
			data-wp-interactive="ebio/quote"
			data-wp-init="callbacks.load"
			data-wp-bind--data-state="state.listStatus"
			data-wp-bind--aria-busy="state.isLoading"
		>
			<div className="ebio-quote-list__header">
				<Heading className="ebio-quote-list__heading" id="ebio-quote-list-heading">
					{ text( 'heading' ) }
					<span className="ebio-quote-list__count" hidden data-wp-bind--hidden="!state.hasItems" data-wp-text="state.countText"></span>
				</Heading>
				<button type="button" className="ebio-quote-list__clear" hidden data-wp-bind--hidden="!state.hasItems" data-wp-on--click="actions.clear">
					{ text( 'clearText' ) }
				</button>
			</div>

			<noscript>
				<p className="ebio-quote-list__noscript">{ text( 'noscriptText' ) }</p>
			</noscript>

			<div className="ebio-quote-list__undo" role="status">
				<p className="ebio-quote-list__undo-body" hidden data-wp-bind--hidden="!state.canUndo">
					<span className="ebio-quote-list__undo-text" data-wp-text="state.undoText"></span>
					<button type="button" className="ebio-quote-list__undo-button" data-wp-on--click="actions.undoRemove">
						Deshacer
					</button>
				</p>
			</div>

			<ul className="ebio-quote-list__items" hidden data-wp-bind--hidden="!state.hasItems">
				<template data-wp-each--item="state.listItems" data-wp-each-key="context.item.id">
					<li className="ebio-quote-list__item">
						<span className="ebio-quote-list__media">
							<img
								className="ebio-quote-list__image"
								alt=""
								data-wp-bind--hidden="!context.item.image"
								data-wp-bind--src="context.item.image.src"
								data-wp-bind--width="context.item.image.width"
								data-wp-bind--height="context.item.image.height"
								loading="lazy"
								decoding="async"
							/>
						</span>
						<div className="ebio-quote-list__body">
							<p className="ebio-quote-list__name">
								<a className="ebio-quote-list__name-link" data-wp-bind--href="context.item.url" data-wp-text="context.item.name"></a>
							</p>
							<p className="ebio-quote-list__category" data-wp-text="context.item.category"></p>
							<div className="ebio-quote-list__fields">
								<fieldset className="ebio-quote-list__group ebio-quote-list__group--quantity">
									<legend className="ebio-quote-list__legend">Cantidad aproximada</legend>
									<div className="ebio-quote-list__inputs">
										<NumberField field="quantity" label="Cantidad" labelClass={ HIDDEN_LABEL } integer />
										<UnitField field="quantityUnit" label="Unidad de la cantidad" labelClass={ HIDDEN_LABEL } options={ [ 'unidades', 'pallets' ] } />
									</div>
								</fieldset>
								<fieldset className="ebio-quote-list__group ebio-quote-list__group--dimensions">
									<legend className="ebio-quote-list__legend">Medidas aproximadas</legend>
									<div className="ebio-quote-list__inputs">
										{ DIMENSIONS.map( ( dimension ) => (
											<div className="ebio-quote-list__dimension" key={ dimension.key }>
												<NumberField field={ dimension.key } label={ dimension.label } labelClass={ SUB_LABEL } integer={ false } />
											</div>
										) ) }
										<div className="ebio-quote-list__dimension ebio-quote-list__dimension--unit">
											<UnitField field="dimensionUnit" label="Unidad" labelClass={ SUB_LABEL } options={ [ 'cm', 'mm' ] } />
										</div>
									</div>
								</fieldset>
								<div className="ebio-quote-list__note">
									<button type="button" className="ebio-quote-list__note-toggle" data-wp-bind--hidden="context.item.notesOpen" data-wp-on--click="actions.openNote">
										<span className="ebio-icon ebio-icon--plus" aria-hidden="true"></span>Agregar nota
									</button>
									<div className="ebio-quote-list__note-field" hidden data-wp-bind--hidden="!context.item.notesOpen">
										<label className="ebio-quote-list__label" data-wp-bind--for="context.item.fieldIds.notes">
											Notas (opcional)
										</label>
										<textarea
											className="ebio-quote-list__textarea"
											maxLength={ 500 }
											rows={ 2 }
											placeholder="Uso, impresión, peso a empacar…"
											data-field="notes"
											data-wp-bind--id="context.item.fieldIds.notes"
											data-wp-bind--value="context.item.notes"
											data-wp-on--input="actions.updateField"
										></textarea>
									</div>
								</div>
							</div>
						</div>
						<button type="button" className="ebio-quote-list__remove" data-wp-on--click="actions.remove">
							Quitar<span className="ebio-visually-hidden" data-wp-text="context.item.removeLabel"></span>
						</button>
					</li>
				</template>
			</ul>

			{ addMoreText !== '' && (
				<p className="ebio-quote-list__more" hidden data-wp-bind--hidden="!state.hasItems">
					<a className="ebio-quote-list__more-link ebio-button ebio-button--secondary ebio-button--small" href={ catalogUrl }>
						{ addMoreText }
					</a>
				</p>
			) }

			<div className="ebio-quote-list__empty" hidden data-wp-bind--hidden="!state.isEmpty">
				<h3 className="ebio-quote-list__empty-title">{ text( 'emptyTitle' ) }</h3>
				<p className="ebio-quote-list__empty-text">{ text( 'emptyText' ) }</p>
				<p className="ebio-quote-list__empty-actions">
					<a className="ebio-quote-list__empty-catalog ebio-button ebio-button--primary" href={ catalogUrl }>
						{ text( 'catalogText' ) }
					</a>
					<a className="ebio-quote-list__empty-free ebio-button ebio-button--secondary" href={ formAnchor }>
						{ text( 'freeRequestText' ) }
					</a>
				</p>
				{ categories.length > 0 && (
					<ul className="ebio-quote-list__categories">
						{ categories.map( ( category ) => (
							<li className="ebio-quote-list__category-item" key={ category.url }>
								<a className="ebio-quote-list__category-link" href={ category.url }>
									{ category.label }
								</a>
							</li>
						) ) }
					</ul>
				) }
			</div>
		</section>
	);
}
