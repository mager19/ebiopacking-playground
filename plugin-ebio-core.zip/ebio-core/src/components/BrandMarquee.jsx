import { Fragment } from '@wordpress/element';
import { rootProps } from './lib/root-props.js';

const MAX_PHRASES = 4;
const MIN_REPEAT = 2;
const MAX_REPEAT = 6;

/**
 * Límites del contrato: 1–4 frases, 2–6 repeticiones.
 *
 * @param {{ phrases?: string[], repeat?: number }} attributes Atributos del bloque.
 * @return {{ phrases: string[], repeat: number }} Valores aplicados.
 */
export function marqueeLimits( attributes ) {
	const phrases = ( Array.isArray( attributes?.phrases ) ? attributes.phrases : [] )
		.filter( ( phrase ) => typeof phrase === 'string' && phrase.trim() !== '' )
		.slice( 0, MAX_PHRASES );
	const repeat = Math.min( MAX_REPEAT, Math.max( MIN_REPEAT, Number.parseInt( attributes?.repeat, 10 ) || MIN_REPEAT ) );
	return { phrases, repeat };
}

/**
 * `ebio/brand-marquee` (docs/blocks/brand-marquee.md): franja decorativa, el grupo de frases se
 * repite `repeat` veces. La pista es `aria-hidden`; el botón de pausa (WCAG 2.2.2) queda fuera y solo aparece con JS.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 */
export default function BrandMarquee( { attributes } ) {
	const { phrases, repeat } = marqueeLimits( attributes );
	const group = ( key ) => (
		<span className="ebio-brand-marquee__group" key={ key }>
			{ phrases.map( ( phrase, i ) => (
				<Fragment key={ i }>
					<span className="ebio-brand-marquee__phrase">{ phrase }</span>
					<span className="ebio-icon ebio-icon--asterisk ebio-brand-marquee__separator"></span>
				</Fragment>
			) ) }
		</span>
	);

	return (
		<div
			{ ...rootProps( 'ebio-brand-marquee', [], attributes ) }
			data-wp-interactive="ebio/brand-marquee"
			data-wp-context={ JSON.stringify( { paused: false, hydrated: false } ) }
			data-wp-init="callbacks.init"
			data-wp-class--ebio-brand-marquee--paused="context.paused"
		>
			<div className="ebio-brand-marquee__track" aria-hidden="true">
				{ Array.from( { length: repeat }, ( _, i ) => group( i ) ) }
			</div>
			<button
				type="button"
				className="ebio-brand-marquee__toggle ebio-button ebio-button--secondary ebio-button--small"
				aria-pressed="false"
				hidden
				data-wp-bind--hidden="!context.hydrated"
				data-wp-bind--aria-pressed="context.paused"
				data-wp-on--click="actions.toggle"
			>
				<span className="ebio-brand-marquee__toggle-label ebio-brand-marquee__toggle-label--pause" data-wp-bind--hidden="context.paused">
					Pausar animación
				</span>
				<span className="ebio-brand-marquee__toggle-label ebio-brand-marquee__toggle-label--resume" hidden data-wp-bind--hidden="!context.paused">
					Reanudar animación
				</span>
			</button>
		</div>
	);
}
