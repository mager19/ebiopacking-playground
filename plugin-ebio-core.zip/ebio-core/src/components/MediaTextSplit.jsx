import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';
import BlockImage from './lib/BlockImage.jsx';

const MAX_STATS = 4;

/**
 * `ebio/media-text-split` (docs/blocks/media-text-split.md): imagen + texto (+ CTA); la variante `stat`
 * añade cifras destacadas antes o después del contenido. El orden en el DOM es siempre media → body;
 * `mediaPosition: end` solo añade el modificador `--media-end`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {*}      props.children   Bloques internos (párrafos, listas, botones).
 */
export default function MediaTextSplit( { attributes, children } ) {
	const { variant, heading, headingLevel = 2, image, mediaPosition, statsPosition } = attributes ?? {};
	const isStat = variant === 'stat';
	const stats = isStat ? ( Array.isArray( attributes?.stats ) ? attributes.stats : [] ).slice( 0, MAX_STATS ) : [];
	const statsList =
		stats.length > 0 ? (
			<ul className="ebio-media-text-split__stats">
				{ stats.map( ( stat, i ) => (
					<li className="ebio-media-text-split__stat" key={ i }>
						<RichField tagName="strong" className="ebio-media-text-split__stat-value" value={ stat?.value } path={ [ 'stats', i, 'value' ] } placeholder="Cifra" />
						<RichField tagName="span" className="ebio-media-text-split__stat-label" value={ stat?.label } path={ [ 'stats', i, 'label' ] } placeholder="Descripción de la cifra" />
					</li>
				) ) }
			</ul>
		) : null;
	const after = statsPosition === 'after-content';

	return (
		<section { ...rootProps( 'ebio-media-text-split', [ variant !== 'default' && variant, mediaPosition === 'end' && 'media-end' ], attributes ?? {} ) }>
			<div className="ebio-media-text-split__inner">
				{ image?.id ? (
					<div className="ebio-media-text-split__media">
						<BlockImage className="ebio-media-text-split__image" image={ image } />
					</div>
				) : null }
				<div className="ebio-media-text-split__body">
					<RichField tagName="p" className="ebio-media-text-split__eyebrow" value={ attributes?.eyebrow } path="eyebrow" placeholder="Sobretítulo" />
					<RichField tagName={ `h${ headingLevel }` } className="ebio-media-text-split__heading" value={ heading } path="heading" placeholder="Título de la sección" />
					{ after ? null : statsList }
					<div className="ebio-media-text-split__content">{ children }</div>
					{ after ? statsList : null }
				</div>
			</div>
		</section>
	);
}
