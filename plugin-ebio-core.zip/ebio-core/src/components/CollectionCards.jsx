import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';
import BlockImage from './lib/BlockImage.jsx';
import CardLink from './lib/CardLink.jsx';
import CardImageSlot from './lib/CardImageSlot.jsx';

const MAX_ITEMS = 4;

/**
 * `ebio/collection-cards` (docs/blocks/collection-cards.md): tarjetas grandes de foto con etiqueta
 * flotante. La imagen va con `alt=""`: el enlace ya contiene el título (catalog §2.5, D21). El título
 * de cada tarjeta usa `headingLevel + 1`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 */
export default function CollectionCards( { attributes } ) {
	const { heading, headingLevel = 2, ctaText, ctaUrl } = attributes ?? {};
	const CardTitle = `h${ headingLevel + 1 }`;
	const items = ( Array.isArray( attributes?.items ) ? attributes.items : [] ).slice( 0, MAX_ITEMS );

	return (
		<section { ...rootProps( 'ebio-collection-cards', [], attributes ?? {} ) }>
			<div className="ebio-collection-cards__inner">
				<div className="ebio-collection-cards__header">
					<RichField tagName={ `h${ headingLevel }` } className="ebio-collection-cards__heading" value={ heading } path="heading" placeholder="Título de la sección" />
					{ ctaText && ctaUrl ? (
						<a className="ebio-collection-cards__cta ebio-button ebio-button--secondary" href={ ctaUrl }>
							{ ctaText }
						</a>
					) : null }
				</div>
				<ul className="ebio-collection-cards__list">
					{ items.map( ( item, i ) => (
						<li className="ebio-collection-cards__item" key={ i }>
							<CardLink className="ebio-collection-cards__card" href={ item?.url }>
								<CardImageSlot path={ [ 'items', i, 'image' ] } image={ item?.image } />
								<BlockImage className="ebio-collection-cards__image" image={ item?.image ? { ...item.image, alt: '' } : null } />
								<span className="ebio-collection-cards__label">
									<RichField tagName="span" className="ebio-collection-cards__eyebrow" value={ item?.eyebrow } path={ [ 'items', i, 'eyebrow' ] } placeholder="Descripción corta" />
									<RichField tagName={ CardTitle } className="ebio-collection-cards__title" value={ item?.title } path={ [ 'items', i, 'title' ] } placeholder="Título de la tarjeta" />
								</span>
								<span className="ebio-icon ebio-icon--arrow-right ebio-collection-cards__arrow" aria-hidden="true"></span>
							</CardLink>
						</li>
					) ) }
				</ul>
			</div>
		</section>
	);
}
