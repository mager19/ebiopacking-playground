import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';
import DynamicImage from './lib/DynamicImage.jsx';

/**
 * `ebio/scale-range` (docs/blocks/scale-range.md): cuatro escalones a escala contra una figura humana.
 * Bloque dinámico: los escalones y la nota resueltos llegan en la vista (`context['ebio/view']`);
 * gemelo de `render.php`. Sin escalones no emite nada.
 *
 * La nota solo es editable en el lienzo en instancias con escalones propios (con el rango de planta
 * global sale de Ajustes › eBiopacking, C-B1).
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function ScaleRange( { attributes, context = {} } ) {
	const view = context?.[ 'ebio/view' ] ?? {};
	const steps = Array.isArray( view.steps ) ? view.steps : [];
	if ( steps.length === 0 ) {
		return null;
	}
	const { variant = 'plant', compact = false, heading = '', headingLevel = 2, intro = '', ctaText = '', ctaUrl = '', showPerson = true, personLabel = '' } = attributes ?? {};
	const Heading = `h${ headingLevel }`;
	const ownSteps = Array.isArray( attributes?.steps ) && attributes.steps.length > 0;

	return (
		<section { ...rootProps( 'ebio-scale-range', [ variant === 'product' && 'product', compact === true && 'compact' ], attributes ?? {} ) }>
			<div className="ebio-scale-range__inner">
				<div className="ebio-scale-range__header">
					<Heading className="ebio-scale-range__heading">{ heading }</Heading>
					<RichField tagName="p" className="ebio-scale-range__intro" value={ intro } path="intro" allowedFormats={ [ 'core/link', 'core/bold' ] } placeholder="Texto de ayuda (opcional)" />
					{ ctaText !== '' && (
						<a className="ebio-scale-range__cta ebio-button ebio-button--primary" href={ ctaUrl }>
							{ ctaText }
						</a>
					) }
				</div>
				<ol className="ebio-scale-range__steps">
					{ steps.map( ( step, i ) => {
						const scale = [ 1, 2, 3, 4 ].includes( Number( step?.scale ) ) ? Number( step.scale ) : i + 1;
						return (
							<li className="ebio-scale-range__step" data-scale={ String( scale ) } key={ i }>
								{ step?.image ? (
									<span className="ebio-scale-range__media">
										<DynamicImage className="ebio-scale-range__image" image={ step.image } />
									</span>
								) : (
									<span className="ebio-scale-range__box" aria-hidden="true"></span>
								) }
								<strong className="ebio-scale-range__name">{ step?.name ?? '' }</strong>
								<span className="ebio-scale-range__size">{ step?.size ?? '' }</span>
								<span className="ebio-scale-range__uses">{ step?.uses ?? '' }</span>
								{ step?.linkText && step?.linkUrl ? (
									<a className="ebio-scale-range__link" href={ step.linkUrl }>
										{ step.linkText }
										<span className="ebio-visually-hidden">{ ` · ${ step?.name ?? '' }` }</span>
									</a>
								) : null }
							</li>
						);
					} ) }
				</ol>
				{ showPerson && (
					<div className="ebio-scale-range__person" aria-hidden="true">
						<span className="ebio-scale-range__person-label">{ personLabel }</span>
					</div>
				) }
				<RichField tagName="p" className="ebio-scale-range__note" value={ view.note ?? '' } path={ ownSteps ? 'note' : undefined } allowedFormats={ [ 'core/link' ] } placeholder="Nota de las medidas" />
			</div>
		</section>
	);
}
