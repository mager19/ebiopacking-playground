import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';

const MAX_ITEMS = 8;

/**
 * `ebio/faq` (docs/blocks/faq.md): acordeón accesible. El servidor (y el editor) entregan todas las
 * respuestas desplegadas; al hidratar, `callbacks.collapseInitial` deja abierta solo la primera.
 * La pregunta es un `h3` (`headingLevel + 1`) que contiene el `button` (patrón de acordeón APG).
 *
 * `context['ebio/state']` (solo Storybook) traduce el estado de la Interactivity API a markup:
 * `{ hydrated: true, open: [ 0 ] }`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/state`).
 */
export default function Faq( { attributes, context = {} } ) {
	const { heading, headingLevel = 2, intro, uid = '' } = attributes ?? {};
	const Heading = `h${ headingLevel }`;
	const QuestionHeading = `h${ headingLevel + 1 }`;
	const headingId = `ebio-faq-${ uid }-heading`;
	const items = ( Array.isArray( attributes?.items ) ? attributes.items : [] ).slice( 0, MAX_ITEMS );
	const state = context?.[ 'ebio/state' ];
	const hydrated = state?.hydrated === true;
	const openList = hydrated ? ( Array.isArray( state.open ) ? state.open : [ 0 ] ) : null;

	return (
		<section
			{ ...rootProps( 'ebio-faq', [], attributes ?? {} ) }
			aria-labelledby={ headingId }
			data-wp-interactive="ebio/faq"
			data-wp-context={ JSON.stringify( { hydrated: false } ) }
			data-wp-init="callbacks.hydrate"
			data-hydrated={ hydrated ? 'true' : 'false' }
			data-wp-bind--data-hydrated="context.hydrated"
		>
			<div className="ebio-faq__inner">
				<div className="ebio-faq__header">
					<Heading className="ebio-faq__heading" id={ headingId }>
						{ heading }
					</Heading>
					<RichField tagName="p" className="ebio-faq__intro" value={ intro } path="intro" allowedFormats={ [ 'core/link' ] } placeholder="Texto de ayuda (opcional)" />
				</div>
				<div className="ebio-faq__list">
					{ items.map( ( item, i ) => {
						const open = openList ? openList.includes( i ) : true;
						const toggleId = `ebio-faq-${ uid }-q${ i }`;
						const answerId = `ebio-faq-${ uid }-a${ i }`;
						return (
							<div
								className="ebio-faq__item"
								key={ i }
								data-open={ open ? 'true' : 'false' }
								data-wp-context={ JSON.stringify( { index: i, open: true } ) }
								data-wp-init="callbacks.collapseInitial"
								data-wp-bind--data-open="context.open"
							>
								<QuestionHeading className="ebio-faq__question">
									<button
										type="button"
										className="ebio-faq__toggle"
										id={ toggleId }
										aria-expanded={ open ? 'true' : 'false' }
										aria-controls={ answerId }
										data-wp-bind--aria-expanded="context.open"
										data-wp-on--click="actions.toggle"
									>
										<span className="ebio-faq__question-text">{ item?.question }</span>
										<span className="ebio-icon ebio-icon--chevron-down ebio-faq__toggle-icon" aria-hidden="true"></span>
									</button>
								</QuestionHeading>
								<div className="ebio-faq__answer" id={ answerId } hidden={ open ? undefined : true } data-wp-bind--hidden="!context.open">
									<RichField
										tagName="p"
										className="ebio-faq__answer-text"
										value={ item?.answer }
										path={ [ 'items', i, 'answer' ] }
										allowedFormats={ [ 'core/link', 'core/bold' ] }
										placeholder="Respuesta"
									/>
								</div>
							</div>
						);
					} ) }
				</div>
			</div>
		</section>
	);
}
