import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';

const MAX_ITEMS = 6;

/**
 * `ebio/process-steps` (docs/blocks/process-steps.md): pasos numerados o línea de tiempo.
 * `default` emite `__number` (y `__when` si `showWhen`); `timeline` emite `__marker` y nunca
 * `__number` ni `__when`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 */
export default function ProcessSteps( { attributes } ) {
	const { variant, heading, headingLevel = 2, intro, ctaText, ctaUrl, showWhen } = attributes ?? {};
	const Heading = `h${ headingLevel }`;
	const StepHeading = `h${ headingLevel + 1 }`;
	const isTimeline = variant === 'timeline';
	const items = ( Array.isArray( attributes?.items ) ? attributes.items : [] ).slice( 0, MAX_ITEMS );

	return (
		<section { ...rootProps( 'ebio-process-steps', [ variant !== 'default' && variant ], attributes ?? {} ) }>
			<div className="ebio-process-steps__inner">
				<div className="ebio-process-steps__header">
					<Heading className="ebio-process-steps__heading">{ heading }</Heading>
					{ intro ? <p className="ebio-process-steps__intro">{ intro }</p> : null }
					{ ctaText && ctaUrl ? (
						<a className="ebio-process-steps__cta ebio-button ebio-button--primary" href={ ctaUrl }>
							{ ctaText }
						</a>
					) : null }
				</div>
				<ol className="ebio-process-steps__list">
					{ items.map( ( item, i ) => (
						<li className="ebio-process-steps__step" key={ i }>
							{ isTimeline ? (
								item?.marker ? <span className="ebio-process-steps__marker">{ item.marker }</span> : null
							) : (
								<span className="ebio-process-steps__number" aria-hidden="true">
									{ i + 1 }
								</span>
							) }
							{ ! isTimeline && showWhen && item?.when ? (
								<p className="ebio-process-steps__when">
									<span className="ebio-visually-hidden">Plazo: </span>
									{ item.when }
								</p>
							) : null }
							<StepHeading className="ebio-process-steps__title">{ item?.title }</StepHeading>
							<RichField tagName="p" className="ebio-process-steps__text" value={ item?.text } path={ [ 'items', i, 'text' ] } allowedFormats={ [ 'core/link' ] } />
						</li>
					) ) }
				</ol>
			</div>
		</section>
	);
}
