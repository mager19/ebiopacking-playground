import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';
import { EditContext, isEditing } from './lib/edit-context.js';

const MAX_ROWS = 15;

/**
 * `ebio/product-specs` (docs/blocks/product-specs.md): tabla etiqueta / valor. Las filas con valor
 * vacío no se emiten (salvo en el editor, donde se ven para poder llenarlas); se filtran antes de
 * recortar a 15. El encabezado nombra la tabla con un id derivado de `uid`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 */
export default function ProductSpecs( { attributes } ) {
	const { heading, headingLevel = 2, intro, uid = '' } = attributes ?? {};
	const Heading = `h${ headingLevel }`;
	const headingId = `ebio-product-specs-${ uid }-heading`;
	const all = ( Array.isArray( attributes?.rows ) ? attributes.rows : [] ).map( ( row, index ) => ( { row, index } ) );

	return (
		<EditContext.Consumer>
			{ ( edit ) => {
				const rows = ( isEditing( edit ) ? all : all.filter( ( { row } ) => typeof row?.value === 'string' && row.value.trim() !== '' ) ).slice( 0, MAX_ROWS );
				return (
					<section { ...rootProps( 'ebio-product-specs', [], attributes ?? {} ) }>
						<div className="ebio-product-specs__inner">
							<div className="ebio-product-specs__header">
								<Heading className="ebio-product-specs__heading" id={ headingId }>
									{ heading }
								</Heading>
								{ intro ? <p className="ebio-product-specs__intro">{ intro }</p> : null }
							</div>
							<table className="ebio-product-specs__table" aria-labelledby={ headingId }>
								<tbody>
									{ rows.map( ( { row, index } ) => (
										<tr className="ebio-product-specs__row" key={ index }>
											<th className="ebio-product-specs__label" scope="row">
												{ row?.label }
											</th>
											<RichField
												tagName="td"
												className="ebio-product-specs__value"
												value={ row?.value }
												path={ [ 'rows', index, 'value' ] }
												allowedFormats={ [ 'core/link' ] }
											/>
										</tr>
									) ) }
								</tbody>
							</table>
						</div>
					</section>
				);
			} }
		</EditContext.Consumer>
	);
}
