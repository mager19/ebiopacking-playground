import { rootProps } from './lib/root-props.js';

/** Campos de texto del contrato con `includes/quote/validate.php` (fijos en el código). */
const TEXT_FIELDS = [
	{ name: 'company', label: 'Empresa', type: 'text', max: 120, autocomplete: 'organization', required: true },
	{ name: 'name', label: 'Nombre', type: 'text', max: 120, autocomplete: 'name', required: true },
	{ name: 'email', label: 'Correo', type: 'email', max: 254, autocomplete: 'email', required: true },
	{ name: 'phone', label: 'Celular / WhatsApp', type: 'tel', max: 30, autocomplete: 'tel', required: true, hint: 'phoneHint' },
	{ name: 'city', label: 'Ciudad', type: 'text', max: 80, autocomplete: 'address-level2', required: false },
];

const SECTORS = [
	[ '', 'Selecciona…' ],
	[ 'floricultura', 'Floricultura' ],
	[ 'agro-frutas', 'Agro y frutas' ],
	[ 'industria', 'Industria' ],
	[ 'alimentos', 'Alimentos' ],
	[ 'retail-ecommerce', 'Retail y e-commerce' ],
	[ 'otro', 'Otro' ],
];

/** Campos del resumen, en el orden del formulario: etiqueta y destino del enlace. */
const SUMMARY = [
	[ 'company', 'Empresa:', '#ebio-quote-company' ],
	[ 'name', 'Nombre:', '#ebio-quote-name' ],
	[ 'email', 'Correo:', '#ebio-quote-email' ],
	[ 'phone', 'Celular / WhatsApp:', '#ebio-quote-phone' ],
	[ 'city', 'Ciudad:', '#ebio-quote-city' ],
	[ 'sector', 'Sector:', '#ebio-quote-sector' ],
	[ 'message', 'Mensaje:', '#ebio-quote-message' ],
	[ 'consent', 'Autorización:', '#ebio-quote-consent' ],
	[ 'items', 'Tu lista:', '#ebio-quote-list-heading' ],
];

const errorStatus = ( view ) => ( view.formError ? 'error' : Number( view.errorCount ) > 0 ? 'invalid' : 'idle' );

/**
 * `ebio/quote-form` (docs/blocks/quote-form.md): formulario de cotización. Con JS envía por REST
 * (`ebio/quote`); sin JS hace `POST` a `admin-post.php`. Bloque dinámico: nonce, valores y errores
 * llegan en la vista (`context['ebio/view']`). Gemelo de `render.php`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/view`).
 */
export default function QuoteForm( { attributes, context = {} } ) {
	const view = context?.[ 'ebio/view' ] ?? {};
	const values = view.values ?? {};
	const errors = view.errors ?? {};
	const text = ( key, fallback = '' ) => ( typeof attributes?.[ key ] === 'string' ? attributes[ key ] : fallback );
	const hasErrors = Number( view.errorCount ) > 0;
	const status = errorStatus( view );
	const invalid = ( field ) => ( errors[ field ] ? 'true' : 'false' );
	const Heading = `h${ attributes?.headingLevel ?? 2 }`;
	const messageHint = text( 'messageHint' );
	const phoneHint = text( 'phoneHint' );
	const consentUrl = text( 'consentUrl', '/proteccion-de-datos/' );
	const note = text( 'note' );

	const errorLine = ( field ) => (
		<p
			className="ebio-quote-form__error"
			id={ `ebio-quote-${ field }-error` }
			hidden={ errors[ field ] ? undefined : true }
			data-wp-bind--hidden={ `!state.form.errors.${ field }` }
			data-wp-text={ `state.form.errors.${ field }` }
		>
			{ errors[ field ] ?? '' }
		</p>
	);

	return (
		<section
			{ ...rootProps( 'ebio-quote-form', [], {} ) }
			id="ebio-quote-form"
			aria-labelledby="ebio-quote-form-heading"
			data-state={ status }
			data-wp-interactive="ebio/quote"
			data-wp-context='{"hydrated":false}'
			data-wp-init="callbacks.initForm"
			data-wp-bind--data-state="state.form.status"
		>
			<Heading className="ebio-quote-form__heading" id="ebio-quote-form-heading">
				{ text( 'heading' ) }
			</Heading>

			<div
				className="ebio-quote-form__summary"
				id="ebio-quote-form-summary"
				role="alert"
				tabIndex={ -1 }
				hidden={ hasErrors ? undefined : true }
				data-wp-bind--hidden="!state.form.hasErrors"
			>
				<p className="ebio-quote-form__summary-title" data-wp-text="state.form.summaryTitle">
					{ view.summaryTitle ?? '' }
				</p>
				<ul className="ebio-quote-form__summary-list">
					{ SUMMARY.map( ( [ field, label, href ] ) => (
						<li
							className="ebio-quote-form__summary-item"
							key={ field }
							hidden={ errors[ field ] ? undefined : true }
							data-wp-bind--hidden={ `!state.form.errors.${ field }` }
						>
							<a className="ebio-quote-form__summary-link" href={ href }>
								{ label }{ ' ' }
								<span data-wp-text={ `state.form.errors.${ field }` }>{ errors[ field ] ?? '' }</span>
							</a>
						</li>
					) ) }
				</ul>
			</div>

			<p
				className="ebio-quote-form__alert"
				role="alert"
				hidden={ view.formError ? undefined : true }
				data-wp-bind--hidden="!state.form.formError"
				data-wp-text="state.form.formError"
			>
				{ view.formError ?? '' }
			</p>

			<form
				className="ebio-quote-form__form"
				action={ view.actionUrl ?? '/wp-admin/admin-post.php?action=ebio_quote' }
				method="post"
				aria-describedby="ebio-quote-form-note"
				data-wp-on--submit="actions.submit"
				data-wp-bind--novalidate="context.hydrated"
			>
				<input type="hidden" name="_ebio_nonce" value={ view.nonce ?? '' } />

				<div className="ebio-quote-form__fields">
					{ TEXT_FIELDS.map( ( field ) => {
						const hint = field.hint ? text( field.hint ) : '';
						const describedBy = [ hint !== '' ? `ebio-quote-${ field.name }-hint` : '', `ebio-quote-${ field.name }-error` ].filter( Boolean ).join( ' ' );
						return (
							<div className="ebio-quote-form__field" data-field={ field.name } key={ field.name }>
								<label className="ebio-quote-form__label" htmlFor={ `ebio-quote-${ field.name }` }>
									{ field.label }
									{ field.required && (
										<>
											{ ' ' }
											<span className="ebio-quote-form__required" aria-hidden="true">
												*
											</span>
										</>
									) }
								</label>
								<input
									className="ebio-quote-form__input"
									id={ `ebio-quote-${ field.name }` }
									name={ field.name }
									type={ field.type }
									maxLength={ field.max }
									autoComplete={ field.autocomplete }
									inputMode={ field.type === 'tel' ? 'tel' : undefined }
									required={ field.required ? true : undefined }
									defaultValue={ values[ field.name ] ?? '' }
									aria-invalid={ invalid( field.name ) }
									aria-describedby={ describedBy }
									data-wp-bind--value={ `state.form.values.${ field.name }` }
									data-wp-bind--aria-invalid={ `state.form.invalid.${ field.name }` }
									data-wp-on--input="actions.setValue"
									data-wp-on--blur="actions.validateField"
								/>
								{ hint !== '' && (
									<p className="ebio-quote-form__hint" id={ `ebio-quote-${ field.name }-hint` }>
										{ hint }
									</p>
								) }
								{ errorLine( field.name ) }
							</div>
						);
					} ) }
					<div className="ebio-quote-form__field" data-field="sector">
						<label className="ebio-quote-form__label" htmlFor="ebio-quote-sector">
							Sector
						</label>
						<select
							className="ebio-quote-form__select"
							id="ebio-quote-sector"
							name="sector"
							defaultValue={ values.sector ?? '' }
							aria-invalid={ invalid( 'sector' ) }
							aria-describedby="ebio-quote-sector-error"
							data-wp-bind--aria-invalid="state.form.invalid.sector"
						>
							{ SECTORS.map( ( [ value, label ] ) => (
								<option value={ value } key={ value }>
									{ label }
								</option>
							) ) }
						</select>
						{ errorLine( 'sector' ) }
					</div>
					<div className="ebio-quote-form__field ebio-quote-form__field--full" data-field="message">
						<label className="ebio-quote-form__label" htmlFor="ebio-quote-message">
							Mensaje
						</label>
						<textarea
							className="ebio-quote-form__textarea"
							id="ebio-quote-message"
							name="message"
							maxLength={ 2000 }
							rows={ 5 }
							defaultValue={ values.message ?? '' }
							aria-invalid={ invalid( 'message' ) }
							aria-describedby={ [ messageHint !== '' ? 'ebio-quote-message-hint' : '', 'ebio-quote-message-error' ].filter( Boolean ).join( ' ' ) }
							data-wp-bind--aria-invalid="state.form.invalid.message"
						></textarea>
						{ messageHint !== '' && (
							<p className="ebio-quote-form__hint" id="ebio-quote-message-hint">
								{ messageHint }
							</p>
						) }
						{ errorLine( 'message' ) }
					</div>
				</div>

				<div className="ebio-quote-form__field ebio-quote-form__field--consent" data-field="consent">
					<input
						className="ebio-quote-form__checkbox"
						id="ebio-quote-consent"
						name="consent"
						type="checkbox"
						value="1"
						required
						aria-invalid={ invalid( 'consent' ) }
						aria-describedby="ebio-quote-consent-error"
						data-wp-bind--aria-invalid="state.form.invalid.consent"
					/>
					<label className="ebio-quote-form__consent-label" htmlFor="ebio-quote-consent">
						Acepto el <a href={ consentUrl }>{ text( 'consentLinkText' ) }</a>{ ' ' }
						<span className="ebio-quote-form__required" aria-hidden="true">
							*
						</span>
					</label>
					{ errorLine( 'consent' ) }
				</div>

				<div className="ebio-quote-form__trap" aria-hidden="true">
					<label className="ebio-quote-form__trap-label" htmlFor="ebio-quote-website">
						Sitio web (deja este campo vacío)
					</label>
					<input className="ebio-quote-form__trap-input" id="ebio-quote-website" name="website" type="text" defaultValue="" tabIndex={ -1 } autoComplete="off" />
				</div>

				{ /* La nota (qué pasa después de enviar) va justo antes del botón: se lee antes de enviar (modo Operate). */ }
				{ note !== '' && (
					<p className="ebio-quote-form__note" id="ebio-quote-form-note">
						{ note }
					</p>
				) }
				<button
					type="submit"
					className="ebio-quote-form__submit ebio-button ebio-button--primary ebio-button--block"
					aria-busy="false"
					data-wp-bind--disabled="state.form.isSubmitting"
					data-wp-bind--aria-busy="state.form.isSubmitting"
				>
					<span className="ebio-quote-form__submit-text">{ text( 'submitText' ) }</span>
					<span className="ebio-quote-form__submit-count" hidden data-wp-bind--hidden="!state.hasItems" data-wp-text="state.submitCountText"></span>
				</button>
			</form>
		</section>
	);
}
