import { rootProps } from './lib/root-props.js';
import BlockImage from './lib/BlockImage.jsx';

const MAX_IMAGES = 8;

/**
 * `ebio/product-gallery` (docs/blocks/product-gallery.md): foto principal, miniaturas y ampliación.
 * El servidor (y el editor) entregan todas las fotos una tras otra y los controles solo-JS con
 * `hidden`; al hidratar, la Interactivity API oculta las fotos no activas y muestra los controles.
 * Las miniaturas llevan `alt=""` porque su botón tiene texto ("Ver foto n de N").
 *
 * `context['ebio/state']` (solo Storybook) traduce el estado del store a markup:
 * `{ hydrated: true, active: 2, zoom: true }`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/state`).
 */
export default function ProductGallery( { attributes, context = {} } ) {
	const { label } = attributes ?? {};
	const images = ( Array.isArray( attributes?.images ) ? attributes.images : [] ).filter( ( image ) => image?.id ).slice( 0, MAX_IMAGES );
	const count = images.length;
	const state = context?.[ 'ebio/state' ];
	const hydrated = state?.hydrated === true;
	const active = hydrated ? Math.min( Math.max( Number.parseInt( state.active, 10 ) || 0, 0 ), Math.max( count - 1, 0 ) ) : 0;
	const zoom = hydrated && state.zoom === true;
	const zoomed = images[ active ];

	return (
		<div
			{ ...rootProps( 'ebio-product-gallery', [], attributes ?? {} ) }
			role="group"
			aria-label={ label }
			data-wp-interactive="ebio/product-gallery"
			data-wp-context={ JSON.stringify( { active: 0, count, hydrated: false } ) }
			data-wp-init="callbacks.init"
			data-hydrated={ hydrated ? 'true' : 'false' }
			data-wp-bind--data-hydrated="context.hydrated"
		>
			<ul className="ebio-product-gallery__slides">
				{ images.map( ( image, i ) => (
					<li
						className="ebio-product-gallery__slide"
						key={ i }
						data-wp-context={ JSON.stringify( { index: i, hidden: false } ) }
						data-wp-bind--hidden="context.hidden"
						data-wp-watch="callbacks.syncSlide"
						hidden={ hydrated && i !== active ? true : undefined }
					>
						<BlockImage className="ebio-product-gallery__image" image={ image } priority={ i === 0 } />
					</li>
				) ) }
			</ul>

			{ count > 1 ? (
				<ul className="ebio-product-gallery__thumbs" hidden={ hydrated ? undefined : true } data-wp-bind--hidden="!context.hydrated">
					{ images.map( ( image, i ) => (
						<li className="ebio-product-gallery__thumb-item" key={ i }>
							<button
								type="button"
								className="ebio-product-gallery__thumb"
								aria-pressed={ i === active ? 'true' : 'false' }
								data-wp-context={ JSON.stringify( { index: i, pressed: i === 0 } ) }
								data-wp-bind--aria-pressed="context.pressed"
								data-wp-watch="callbacks.syncThumb"
								data-wp-on--click="actions.select"
							>
								<BlockImage className="ebio-product-gallery__thumb-image" image={ { ...image, alt: '' } } />
								<span className="ebio-visually-hidden">{ `Ver foto ${ i + 1 } de ${ count }` }</span>
							</button>
						</li>
					) ) }
				</ul>
			) : null }

			<button
				type="button"
				className="ebio-product-gallery__zoom ebio-button ebio-button--icon"
				aria-haspopup="dialog"
				hidden={ hydrated ? undefined : true }
				data-wp-bind--hidden="!context.hydrated"
				data-wp-on--click="actions.openZoom"
			>
				<span className="ebio-icon ebio-icon--zoom" aria-hidden="true"></span>
				<span className="ebio-visually-hidden">Ampliar foto</span>
			</button>

			<dialog className="ebio-product-gallery__dialog" aria-label="Foto ampliada" open={ zoom || undefined } data-wp-on--close="actions.onZoomClose">
				<img
					className="ebio-product-gallery__dialog-image"
					src={ zoom ? zoomed?.url : undefined }
					alt={ zoom ? zoomed?.alt ?? '' : '' }
					data-wp-bind--src="state.activeSrc"
					data-wp-bind--alt="state.activeAlt"
				/>
				<button type="button" className="ebio-product-gallery__dialog-close ebio-button ebio-button--icon" data-wp-on--click="actions.closeZoom">
					<span className="ebio-icon ebio-icon--close" aria-hidden="true"></span>
					<span className="ebio-visually-hidden">Cerrar</span>
				</button>
			</dialog>
		</div>
	);
}
