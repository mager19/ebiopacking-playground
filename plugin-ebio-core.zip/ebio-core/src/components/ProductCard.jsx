import DynamicImage from './lib/DynamicImage.jsx';

/**
 * Opciones del contenedor con sus valores por defecto; gemelo de `ebio_product_card_options()`.
 *
 * @param {Object} [options]
 * @return {{ headingLevel: 3|4, quoteUrl: string, showAddToQuote: boolean }} Opciones normalizadas.
 */
export function productCardOptions( options = {} ) {
	return {
		headingLevel: Number( options?.headingLevel ) === 4 ? 4 : 3,
		quoteUrl: typeof options?.quoteUrl === 'string' ? options.quoteUrl : '/cotizar/',
		showAddToQuote: options?.showAddToQuote !== false,
	};
}

/**
 * Componente compartido `ebio-product-card` (docs/blocks/product-card.md; no es un bloque): gemelo de
 * `ebio_render_product_card()` (includes/blocks/product-card.php). Lo usan `product-carousel` y
 * `product-grid`.
 *
 * `state` (solo Storybook) traduce el estado de `ebio/quote` a markup: `{ inList: true }`,
 * `{ cardState: 'added' }`, `{ cardState: 'full' }` (con `aria-disabled="true"`, como `state.cardDisabled`).
 *
 * @param {Object} props
 * @param {Object} props.card      `ProductCardView`.
 * @param {Object} [props.options] `headingLevel` (3|4), `quoteUrl`, `showAddToQuote`.
 * @param {Object} [props.state]   Estado de la Interactivity API (Storybook).
 */
export default function ProductCard( { card = {}, options = {}, state = {} } ) {
	const { headingLevel, quoteUrl, showAddToQuote } = productCardOptions( options );
	const Heading = `h${ headingLevel }`;
	const id = Number( card?.id ) || 0;
	const name = card?.name ?? '';
	const url = card?.url ?? '';
	const tags = ( Array.isArray( card?.tags ) ? card.tags : [] ).slice( 0, 1 );
	const formats = Array.isArray( card?.formats ) ? card.formats : [];
	const inList = state?.inList ?? [ 'in-list', 'added' ].includes( state?.cardState );
	const cardState = state?.cardState ?? ( inList ? 'in-list' : 'idle' );

	return (
		<article className="ebio-product-card" data-product-id={ String( id ) }>
			<div className="ebio-product-card__media">
				<DynamicImage className="ebio-product-card__image" image={ card?.image ?? null } />
				{ tags.length > 0 && (
					<ul className="ebio-product-card__tags" aria-label="Etiquetas">
						{ tags.map( ( tag, i ) => (
							<li className="ebio-product-card__tag" data-format={ tag?.format ?? '' } key={ i }>
								{ tag?.label ?? '' }
							</li>
						) ) }
					</ul>
				) }
			</div>
			{ card?.category ? <p className="ebio-product-card__category">{ card.category }</p> : null }
			<Heading className="ebio-product-card__title">
				<a className="ebio-product-card__link" href={ url }>
					{ name }
				</a>
			</Heading>
			{ formats.length > 0 && (
				<ul className="ebio-product-card__formats" aria-label="Formato">
					{ formats.map( ( format, i ) => (
						<li className="ebio-product-card__format" data-format={ format?.slug ?? '' } key={ i }>
							{ format?.label ?? '' }
						</li>
					) ) }
				</ul>
			) }
			<div className="ebio-product-card__actions">
				{ showAddToQuote && (
					<form
						className="ebio-product-card__add-form"
						action={ quoteUrl }
						method="get"
						data-wp-interactive="ebio/quote"
						data-wp-context={ JSON.stringify( { productId: id, inList: false } ) }
						data-wp-watch="callbacks.syncCard"
						data-wp-on--submit="actions.addFromCard"
					>
						<input type="hidden" name="producto" value={ String( id ) } />
						<button
							type="submit"
							className="ebio-product-card__add ebio-button ebio-button--small"
							data-state={ cardState }
							aria-pressed={ inList ? 'true' : 'false' }
							data-wp-bind--data-state="state.cardState"
							data-wp-bind--aria-pressed="context.inList"
							aria-disabled={ cardState === 'full' ? 'true' : undefined }
							data-wp-bind--aria-disabled="state.cardDisabled"
						>
							<span className="ebio-icon ebio-icon--plus" aria-hidden="true"></span>
							<span className="ebio-product-card__add-text">Agregar a cotización</span>
							<span className="ebio-product-card__added-text" hidden={ inList ? undefined : true } data-wp-bind--hidden="!context.inList">
								En tu cotización
							</span>
							<span className="ebio-visually-hidden">: { name }</span>
						</button>
					</form>
				) }
				<a className="ebio-product-card__more" href={ url }>
					Ver ficha<span className="ebio-visually-hidden">: { name }</span>
				</a>
			</div>
		</article>
	);
}
