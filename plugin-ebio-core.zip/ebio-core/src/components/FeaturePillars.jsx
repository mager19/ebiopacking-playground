import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';

const MAX_ITEMS = 4;

/**
 * `ebio/feature-pillars` (docs/blocks/feature-pillars.md): 3–4 pilares con ícono. El título de cada
 * ítem usa `headingLevel + 1`.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 */
export default function FeaturePillars( { attributes } ) {
	const { variant, heading, headingLevel = 2 } = attributes ?? {};
	const Heading = `h${ headingLevel }`;
	const ItemHeading = `h${ headingLevel + 1 }`;
	const items = ( Array.isArray( attributes?.items ) ? attributes.items : [] ).slice( 0, MAX_ITEMS );

	return (
		<section { ...rootProps( 'ebio-feature-pillars', [ variant !== 'default' && variant ], attributes ?? {} ) }>
			<div className="ebio-feature-pillars__inner">
				<Heading className="ebio-feature-pillars__heading">{ heading }</Heading>
				<ul className="ebio-feature-pillars__list">
					{ items.map( ( item, i ) => (
						<li className="ebio-feature-pillars__item" key={ i }>
							{ item?.icon ? <span className={ `ebio-icon ebio-icon--${ item.icon } ebio-feature-pillars__icon` } aria-hidden="true"></span> : null }
							<ItemHeading className="ebio-feature-pillars__title">{ item?.title }</ItemHeading>
							<RichField tagName="p" className="ebio-feature-pillars__text" value={ item?.text } path={ [ 'items', i, 'text' ] } />
						</li>
					) ) }
				</ul>
			</div>
		</section>
	);
}
