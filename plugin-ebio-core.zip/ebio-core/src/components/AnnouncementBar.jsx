import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';

const KEY = /^[a-z0-9-]{1,20}$/;

/**
 * `ebio/announcement-bar` (docs/blocks/announcement-bar.md): barra superior con un mensaje y un
 * enlace; con `dismissible` se puede cerrar. La clave de descarte va en el contexto de la
 * Interactivity API, así que debe ser ASCII seguro (D8): una clave inválida cae en `v1`.
 *
 * `context['ebio/state'].dismissed` (solo Storybook) pinta la barra cerrada.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {Object} [props.context]  Contexto (`ebio/state`).
 */
export default function AnnouncementBar( { attributes, context = {} } ) {
	const { message, linkText, linkUrl, dismissible = true } = attributes ?? {};
	const key = KEY.test( attributes?.dismissKey ?? '' ) ? attributes.dismissKey : 'v1';
	const dismissed = context?.[ 'ebio/state' ]?.dismissed === true;

	return (
		<div
			{ ...rootProps( 'ebio-announcement-bar', [], attributes ?? {} ) }
			data-wp-interactive="ebio/announcement-bar"
			data-wp-context={ JSON.stringify( { key, dismissed: false } ) }
			data-wp-init="callbacks.restore"
			data-wp-bind--hidden="context.dismissed"
			hidden={ dismissed || undefined }
		>
			<div className="ebio-announcement-bar__inner">
				<p className="ebio-announcement-bar__text">
					<RichField tagName="span" className="ebio-announcement-bar__message" value={ message } path="message" allowedFormats={ [ 'core/bold' ] } placeholder="Mensaje del aviso" />
					{ linkText ? (
						<>
							{ ' ' }
							<a className="ebio-announcement-bar__link" href={ linkUrl }>
								{ linkText }
							</a>
						</>
					) : null }
				</p>
				{ dismissible ? (
					<button type="button" className="ebio-announcement-bar__close ebio-button ebio-button--icon" data-wp-on--click="actions.dismiss">
						<span className="ebio-icon ebio-icon--close" aria-hidden="true"></span>
						<span className="ebio-visually-hidden">Cerrar aviso</span>
					</button>
				) : null }
			</div>
		</div>
	);
}
