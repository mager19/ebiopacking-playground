import { rootProps } from './lib/root-props.js';
import RichField from './lib/RichField.jsx';

const MAX_ITEMS = 5;

/**
 * `ebio/trust-strip` (docs/blocks/trust-strip.md): franja de pruebas cortas de confianza. Sin
 * encabezado visible: la región se nombra con `aria-label`. La variante por defecto no emite modificador.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 */
export default function TrustStrip( { attributes } ) {
	const { variant, ariaLabel } = attributes ?? {};
	const items = ( Array.isArray( attributes?.items ) ? attributes.items : [] ).slice( 0, MAX_ITEMS );

	return (
		<section { ...rootProps( 'ebio-trust-strip', [ variant !== 'default' && variant ], attributes ?? {} ) } aria-label={ ariaLabel }>
			<div className="ebio-trust-strip__inner">
				<ul className="ebio-trust-strip__list">
					{ items.map( ( item, i ) => (
						<li className="ebio-trust-strip__item" key={ i }>
							{ item?.icon ? <span className={ `ebio-icon ebio-icon--${ item.icon } ebio-trust-strip__icon` } aria-hidden="true"></span> : null }
							<RichField tagName="strong" className="ebio-trust-strip__value" value={ item?.value } path={ [ 'items', i, 'value' ] } />
							<RichField tagName="span" className="ebio-trust-strip__label" value={ item?.label } path={ [ 'items', i, 'label' ] } />
						</li>
					) ) }
				</ul>
			</div>
		</section>
	);
}
