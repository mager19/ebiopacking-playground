import { rootProps } from './lib/root-props.js';
import BlockImage from './lib/BlockImage.jsx';

/**
 * `ebio/hero-split` (docs/blocks/hero-split.md): panel con el H1, texto y CTAs (los `children`, bloques
 * internos) junto a la foto protagonista. La imagen es el LCP (`fetchpriority="high"`); el sticker es
 * decorativo y solo existe en la variante por defecto.
 *
 * @param {Object} props
 * @param {Object} props.attributes Atributos del bloque.
 * @param {*}      props.children   Bloques internos (H1, párrafo, botones).
 */
export default function HeroSplit( { attributes, children } ) {
	const { variant, eyebrow, sticker, image } = attributes ?? {};

	return (
		<section { ...rootProps( 'ebio-hero-split', [ variant !== 'default' && variant ], attributes ?? {} ) }>
			<div className="ebio-hero-split__inner">
				<div className="ebio-hero-split__panel">
					{ ( variant ?? 'default' ) === 'default' && sticker ? (
						<span className="ebio-hero-split__sticker" aria-hidden="true">
							{ sticker }
						</span>
					) : null }
					{ eyebrow ? <p className="ebio-hero-split__eyebrow">{ eyebrow }</p> : null }
					<div className="ebio-hero-split__content">{ children }</div>
				</div>
				{ image?.id ? (
					<div className="ebio-hero-split__media">
						<BlockImage className="ebio-hero-split__image" image={ image } priority />
					</div>
				) : null }
			</div>
		</section>
	);
}
