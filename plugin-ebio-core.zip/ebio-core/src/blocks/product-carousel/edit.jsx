import { __ } from '@wordpress/i18n';
import { useEffect, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, RangeControl, SelectControl, TextControl, ToggleControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import ProductCarousel from '../../components/ProductCarousel.jsx';
import ProductIdsControl from '../../editor/ProductIdsControl.jsx';
import useBlockView from '../../editor/use-block-view.js';

/** Categorías de producto (slug y nombre) para el selector; vacío si la REST no responde. */
function useCategoryOptions() {
	const [ options, setOptions ] = useState( [] );
	useEffect( () => {
		let active = true;
		apiFetch( { path: '/wp/v2/ebio_product_category?per_page=100&_fields=slug,name' } ).then(
			( terms ) => active && Array.isArray( terms ) && setOptions( terms.filter( ( term ) => term?.slug ).map( ( term ) => ( { label: term.name, value: term.slug } ) ) ),
			() => {}
		);
		return () => {
			active = false;
		};
	}, [] );
	return options;
}

/**
 * Editor de `ebio/product-carousel`: las tarjetas vienen de la vista del servidor; el título y el texto de
 * ayuda se editan en el lienzo y la fuente, la cantidad y las tarjetas en el panel lateral.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view, isLoading } = useBlockView( 'ebio/product-carousel', attributes, context );
	const categories = useCategoryOptions();
	const { source, heading, productIds, category, limit, showAddToQuote } = attributes;
	const empty = ! isLoading && ( view?.products ?? [] ).length === 0;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Fuente', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Título', 'ebio-core' ) }
						value={ heading }
						onChange={ ( next ) => setAttributes( { heading: next } ) }
						help={ __( 'Recomendado: hasta 50 caracteres. El texto de ayuda se edita en el lienzo.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<SelectControl
						label={ __( 'Fuente de productos', 'ebio-core' ) }
						value={ source }
						options={ [
							{ label: __( 'Elegidos a mano', 'ebio-core' ), value: 'featured' },
							{ label: __( 'Relacionados (misma categoría)', 'ebio-core' ), value: 'related' },
							{ label: __( 'De una categoría', 'ebio-core' ), value: 'category' },
						] }
						onChange={ ( next ) => setAttributes( { source: next } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					{ source === 'featured' ? <ProductIdsControl value={ productIds } onChange={ ( next ) => setAttributes( { productIds: next } ) } /> : null }
					{ source === 'related' ? (
						<Notice status="info" isDismissible={ false }>
							{ __( 'Muestra los productos de la categoría principal del producto actual, sin él.', 'ebio-core' ) }
						</Notice>
					) : null }
					{ source === 'category' && categories.length > 0 ? (
						<SelectControl
							label={ __( 'Categoría', 'ebio-core' ) }
							value={ category }
							options={ [ { label: __( 'Elegir categoría…', 'ebio-core' ), value: '' }, ...categories ] }
							onChange={ ( next ) => setAttributes( { category: next } ) }
							__nextHasNoMarginBottom
							__next40pxDefaultSize
						/>
					) : null }
					{ source === 'category' && categories.length === 0 ? (
						<TextControl label={ __( 'Categoría (slug)', 'ebio-core' ) } value={ category } onChange={ ( next ) => setAttributes( { category: next } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
					) : null }
				</PanelBody>
				<PanelBody title={ __( 'Cantidad', 'ebio-core' ) }>
					<RangeControl label={ __( 'Máximo de productos', 'ebio-core' ) } value={ limit } min={ 1 } max={ 12 } onChange={ ( next ) => setAttributes( { limit: next ?? 8 } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
				</PanelBody>
				<PanelBody title={ __( 'Tarjetas', 'ebio-core' ) }>
					<ToggleControl label={ __( 'Mostrar "Agregar a cotización"', 'ebio-core' ) } checked={ showAddToQuote } onChange={ ( next ) => setAttributes( { showAddToQuote: next } ) } __nextHasNoMarginBottom />
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ empty ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'No hay productos publicados para esta fuente: el bloque no se muestra en el sitio.', 'ebio-core' ) }
					</Notice>
				) : null }
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<ProductCarousel attributes={ attributes } context={ { 'ebio/view': view ?? { uid: 'carousel-editor', quoteUrl: '/cotizar/', products: [] } } } />
				</EditContext.Provider>
			</div>
		</>
	);
}
