<?php
/**
 * `ebio/product-carousel` (docs/blocks/product-carousel.md). Gemelo de `src/components/ProductCarousel.jsx`.
 *
 * Las tarjetas las pinta el componente compartido `ebio_render_product_card()`. Sin productos no emite
 * nada. Cada elemento de bloque va en su línea (catalog §2.9).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_product_carousel_view( $attributes, $block ?? null );
	}
);

$ebio_products = is_array( $view['products'] ?? null ) ? array_values( $view['products'] ) : array();
if ( ! $ebio_products ) {
	return;
}

// Valores iniciales de `ebio/carousel` antes de procesar las directivas (catalog §2.12, SSR sin efecto).
ebio_carousel_init_state();

$ebio_uid      = (string) ( $view['uid'] ?? '' );
$ebio_level    = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );
$ebio_heading  = is_string( $attributes['heading'] ?? null ) ? $attributes['heading'] : '';
$ebio_intro    = is_string( $attributes['intro'] ?? null ) ? $attributes['intro'] : '';
$ebio_heading_id = 'ebio-product-carousel-' . $ebio_uid . '-heading';
$ebio_track_id   = 'ebio-product-carousel-' . $ebio_uid . '-track';
$ebio_count      = count( $ebio_products );
$ebio_options    = array(
	'headingLevel'   => 3,
	'quoteUrl'       => is_string( $view['quoteUrl'] ?? null ) ? $view['quoteUrl'] : '/cotizar/',
	'showAddToQuote' => false !== ( $attributes['showAddToQuote'] ?? true ),
);

$ebio_button = static function ( string $name, string $icon, string $label, string $track_id, bool $disabled ): string {
	return '<button type="button" class="ebio-product-carousel__' . $name . ' ebio-button ebio-button--icon" aria-controls="' . esc_attr( $track_id ) . '"'
		. ( $disabled ? ' disabled' : '' )
		. ' data-wp-bind--disabled="state.' . ( 'prev' === $name ? 'isFirst' : 'isLast' ) . '" data-wp-on--click="actions.' . $name . '">'
		. '<span class="ebio-icon ebio-icon--' . $icon . '" aria-hidden="true"></span><span class="ebio-visually-hidden">' . esc_html( $label ) . '</span></button>';
};

$ebio_lines   = array();
$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-product-carousel', array(), $attributes ) . ' aria-labelledby="' . esc_attr( $ebio_heading_id ) . '"'
	. ' data-wp-interactive="ebio/carousel" '
	. wp_interactivity_data_wp_context(
		array(
			'index'    => 0,
			'count'    => $ebio_count,
			'hydrated' => false,
		)
	)
	. ' data-wp-init="callbacks.init" data-hydrated="false" data-wp-bind--data-hydrated="context.hydrated">';
$ebio_lines[] = '<div class="ebio-product-carousel__inner">';
$ebio_lines[] = '<div class="ebio-product-carousel__header">';
$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-product-carousel__heading" id="' . esc_attr( $ebio_heading_id ) . '">' . esc_html( $ebio_heading ) . '</h' . $ebio_level . '>';
if ( '' !== $ebio_intro ) {
	$ebio_lines[] = '<p class="ebio-product-carousel__intro">' . wp_kses_post( $ebio_intro ) . '</p>';
}
$ebio_lines[] = '<div class="ebio-product-carousel__controls" hidden data-wp-bind--hidden="!context.hydrated">';
$ebio_lines[] = $ebio_button( 'prev', 'arrow-left', 'Productos anteriores', $ebio_track_id, true ) . $ebio_button( 'next', 'arrow-right', 'Productos siguientes', $ebio_track_id, $ebio_count <= 1 );
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '<ul class="ebio-product-carousel__track" id="' . esc_attr( $ebio_track_id ) . '" data-wp-on--scroll="callbacks.syncIndex">';
foreach ( $ebio_products as $ebio_card ) {
	$ebio_lines[] = '<li class="ebio-product-carousel__slide">';
	$ebio_lines[] = ebio_render_product_card( is_array( $ebio_card ) ? $ebio_card : array(), $ebio_options );
	$ebio_lines[] = '</li>';
}
$ebio_lines[] = '</ul>';
$ebio_lines[] = '<div class="ebio-product-carousel__progress" aria-hidden="true"><span class="ebio-product-carousel__progress-bar"></span></div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</section>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
