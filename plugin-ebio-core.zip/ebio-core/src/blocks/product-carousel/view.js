/**
 * Módulo de vista de `ebio/product-carousel` (docs/blocks/product-carousel.md): flechas del carrusel
 * (`ebio/carousel`) y botón "Agregar a cotización" de las tarjetas (`ebio/quote`). Los stores se
 * registran una sola vez por página aunque otros bloques los importen.
 */
import '../../stores/carousel/store.js';
import '../../stores/quote/store.js';
