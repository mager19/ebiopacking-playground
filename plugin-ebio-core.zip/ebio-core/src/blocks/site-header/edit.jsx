import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, TextControl } from '@wordpress/components';
import SiteHeader from '../../components/SiteHeader.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Editor de `ebio/site-header`: el logo y el menú vienen de la vista del servidor (Ajustes ›
 * eBiopacking); los textos y enlaces se editan en el panel lateral.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view } = useBlockView( 'ebio/site-header', attributes, context );
	const field = ( key, label, help ) => (
		<TextControl
			label={ label }
			value={ attributes[ key ] }
			onChange={ ( value ) => setAttributes( { [ key ]: value } ) }
			help={ help }
			__nextHasNoMarginBottom
			__next40pxDefaultSize
		/>
	);

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Logo y menú', 'ebio-core' ) }>
					<Notice status="info" isDismissible={ false }>
						{ __( 'El logo y el menú se editan en Ajustes › eBiopacking.', 'ebio-core' ) }
					</Notice>
				</PanelBody>
				<PanelBody title={ __( 'Buscador', 'ebio-core' ) }>
					{ field( 'searchPlaceholder', __( 'Texto de ejemplo del buscador', 'ebio-core' ), __( 'Recomendado: hasta 45 caracteres.', 'ebio-core' ) ) }
					{ field( 'searchAction', __( 'URL de búsqueda', 'ebio-core' ) ) }
				</PanelBody>
				<PanelBody title={ __( 'Cotización', 'ebio-core' ) }>
					{ field( 'quoteLabel', __( 'Texto del contador', 'ebio-core' ), __( 'Recomendado: hasta 20 caracteres.', 'ebio-core' ) ) }
					{ field( 'quoteUrl', __( 'URL de la lista', 'ebio-core' ) ) }
					{ field( 'ctaText', __( 'Texto del botón', 'ebio-core' ), __( 'Recomendado: hasta 25 caracteres.', 'ebio-core' ) ) }
					{ field( 'ctaUrl', __( 'URL del botón', 'ebio-core' ) ) }
					{ field( 'homeUrl', __( 'URL del inicio (logo)', 'ebio-core' ) ) }
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<SiteHeader attributes={ attributes } context={ { 'ebio/view': view ?? { logo: null, nav: [] } } } />
			</div>
		</>
	);
}
