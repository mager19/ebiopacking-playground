<?php
/**
 * `ebio/site-header` (docs/blocks/site-header.md). Gemelo de `src/components/SiteHeader.jsx`.
 *
 * Cada elemento de bloque va en su línea y los hermanos en línea (enlaces, botones, `span`) van
 * pegados, igual que en el componente (catalog §2.9, espacios en la paridad).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_site_header_view( $attributes, $block ?? null );
	}
);

// Valores iniciales de `ebio/quote` antes de procesar las directivas: en un tema de bloques la cabecera
// se renderiza antes de `wp_enqueue_scripts` (catalog §2.12, SSR sin efecto).
ebio_quote_init_state();

$ebio_text   = static function ( string $key, string $fallback ) use ( $attributes ): string {
	return is_string( $attributes[ $key ] ?? null ) ? $attributes[ $key ] : $fallback;
};
$ebio_logo   = is_array( $view['logo'] ?? null ) ? $view['logo'] : null;
$ebio_nav    = is_array( $view['nav'] ?? null ) ? array_values( $view['nav'] ) : array();
$ebio_quote  = $ebio_text( 'quoteUrl', '/cotizar/' );
$ebio_hidden = '<span class="ebio-visually-hidden">%s</span>';
$ebio_label  = $ebio_text( 'quoteLabel', '' );

// El nombre accesible del contador empieza por el texto visible `quoteLabel` (WCAG 2.5.3).
wp_interactivity_state(
	'ebio/quote',
	array(
		'quoteLabel'   => '' !== trim( $ebio_label ) ? $ebio_label : 'Mi cotización',
		'counterLabel' => ebio_quote_counter_label( 0, $ebio_label ),
	)
);

$ebio_lines   = array();
$ebio_lines[] = '<div ' . ebio_root_attributes( 'ebio-site-header', array(), $attributes )
	. ' data-wp-interactive="ebio/site-header" '
	. wp_interactivity_data_wp_context(
		array(
			'menuOpen'   => false,
			'searchOpen' => false,
			'hydrated'   => false,
		)
	)
	. ' data-wp-init="callbacks.hydrate" data-wp-on-document--keydown="actions.closeOnEscape" data-hydrated="false" data-wp-bind--data-hydrated="context.hydrated">';
$ebio_lines[] = '<div class="ebio-site-header__inner">';

$ebio_line = '<a class="ebio-site-header__logo" href="' . esc_url( $ebio_text( 'homeUrl', '/' ) ) . '" rel="home" aria-label="eBiopacking, ir al inicio">'
	. ( null !== $ebio_logo ? ebio_dynamic_image_html( 'ebio-site-header__logo-image', $ebio_logo ) : 'eBiopacking' )
	. '</a>';
if ( $ebio_nav ) {
	$ebio_line .= '<button type="button" class="ebio-site-header__menu-toggle ebio-button ebio-button--icon" aria-controls="ebio-site-header-nav" aria-expanded="false" hidden data-wp-bind--hidden="!context.hydrated" data-wp-bind--aria-expanded="context.menuOpen" data-wp-on--click="actions.toggleMenu">'
		. '<span class="ebio-icon ebio-icon--menu" aria-hidden="true"></span>' . sprintf( $ebio_hidden, 'Menú' ) . '</button>';
}
$ebio_lines[] = $ebio_line;

if ( $ebio_nav ) {
	$ebio_lines[] = '<div class="ebio-site-header__nav" id="ebio-site-header-nav" data-open="false" data-wp-bind--data-open="context.menuOpen">';
	$ebio_lines[] = '<nav class="ebio-site-header__menu" aria-label="Principal">';
	$ebio_lines[] = '<ul class="ebio-site-header__menu-list">';
	foreach ( $ebio_nav as $ebio_item ) {
		$ebio_current = 'page' === ( $ebio_item['current'] ?? '' ) ? ' aria-current="page"' : '';
		$ebio_lines[] = '<li class="ebio-site-header__menu-item"><a class="ebio-site-header__menu-link" href="' . esc_url( (string) ( $ebio_item['url'] ?? '' ) ) . '"' . $ebio_current . '>'
			. esc_html( (string) ( $ebio_item['label'] ?? '' ) ) . '</a></li>';
	}
	$ebio_lines[] = '</ul>';
	$ebio_lines[] = '</nav>';
	$ebio_lines[] = '</div>';
}

$ebio_lines[] = '<form class="ebio-site-header__search" id="ebio-site-header-search" role="search" action="' . esc_url( $ebio_text( 'searchAction', '/' ) ) . '" method="get" data-open="false" data-wp-bind--data-open="context.searchOpen">';
$ebio_lines[] = '<label class="ebio-visually-hidden" for="ebio-site-header-search-input">Buscar empaques</label>'
	. '<input class="ebio-site-header__search-input" id="ebio-site-header-search-input" type="search" name="s" placeholder="' . esc_attr( $ebio_text( 'searchPlaceholder', '' ) ) . '" autocomplete="off">'
	. '<button type="submit" class="ebio-site-header__search-submit ebio-button ebio-button--icon"><span class="ebio-icon ebio-icon--search" aria-hidden="true"></span>' . sprintf( $ebio_hidden, 'Buscar' ) . '</button>';
$ebio_lines[] = '</form>';

$ebio_lines[] = '<button type="button" class="ebio-site-header__search-toggle ebio-button ebio-button--icon" aria-controls="ebio-site-header-search" aria-expanded="false" hidden data-wp-bind--hidden="!context.hydrated" data-wp-bind--aria-expanded="context.searchOpen" data-wp-on--click="actions.toggleSearch">'
	. '<span class="ebio-icon ebio-icon--search" aria-hidden="true"></span>' . sprintf( $ebio_hidden, 'Mostrar buscador' ) . '</button>'
	. '<a class="ebio-site-header__quote" href="' . esc_url( $ebio_quote ) . '" data-wp-interactive="ebio/quote" aria-label="' . esc_attr( ebio_quote_counter_label( 0, $ebio_label ) ) . '" data-wp-bind--aria-label="state.counterLabel">'
	. '<span class="ebio-icon ebio-icon--list" aria-hidden="true"></span>'
	. '<span class="ebio-site-header__quote-label">' . esc_html( $ebio_label ) . '</span>'
	. '<span class="ebio-site-header__quote-count" aria-hidden="true" data-wp-text="state.count">0</span></a>'
	. '<a class="ebio-site-header__cta ebio-button ebio-button--primary" href="' . esc_url( $ebio_text( 'ctaUrl', '/cotizar/' ) ) . '">' . esc_html( $ebio_text( 'ctaText', '' ) ) . '</a>';
$ebio_lines[] = '</div>';

$ebio_lines[] = '<div class="ebio-site-header__toast" role="status" data-wp-interactive="ebio/quote">';
$ebio_lines[] = '<p class="ebio-site-header__toast-body" hidden data-wp-bind--hidden="!state.toastVisible">'
	. '<span class="ebio-icon ebio-icon--check" aria-hidden="true"></span>'
	. '<span class="ebio-site-header__toast-text" data-wp-text="state.toastText"></span>'
	. '<a class="ebio-site-header__toast-link" href="' . esc_url( $ebio_quote ) . '">Ver lista</a></p>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
