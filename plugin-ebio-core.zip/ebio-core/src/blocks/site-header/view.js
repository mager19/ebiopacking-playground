/**
 * Store `ebio/site-header` (docs/blocks/site-header.md): menú y buscador móviles. El header está en
 * todas las páginas, así que carga también el store compartido `ebio/quote` (contador y aviso).
 */
import { store, getContext, getElement } from '@wordpress/interactivity';
import '../../stores/quote/store.js';

const rootOf = ( element ) => element.closest( '.ebio-site-header' );

store( 'ebio/site-header', {
	actions: {
		toggleMenu() {
			const context = getContext();
			context.menuOpen = ! context.menuOpen;
		},
		toggleSearch() {
			const context = getContext();
			context.searchOpen = ! context.searchOpen;
			if ( context.searchOpen ) {
				const input = rootOf( getElement().ref )?.querySelector( '.ebio-site-header__search-input' );
				// El panel se muestra cuando se aplica data-open: se enfoca en el siguiente cuadro.
				window.requestAnimationFrame( () => input?.focus() );
			}
		},
		/** Escape cierra menú y buscador y devuelve el foco al botón que los abrió. */
		closeOnEscape( event ) {
			if ( event.key !== 'Escape' ) {
				return;
			}
			const context = getContext();
			const root = getElement().ref;
			const opener = context.searchOpen ? '.ebio-site-header__search-toggle' : context.menuOpen ? '.ebio-site-header__menu-toggle' : null;
			if ( ! opener ) {
				return;
			}
			context.menuOpen = false;
			context.searchOpen = false;
			root?.querySelector( opener )?.focus();
		},
	},
	callbacks: {
		hydrate() {
			getContext().hydrated = true;
		},
	},
} );
