<?php
/**
 * `ebio/quote-form` (docs/blocks/quote-form.md). Gemelo de `src/components/QuoteForm.jsx`.
 *
 * Sin JS el formulario hace `POST` a `admin-post.php`; con JS lo envía `stores/quote/form.js` por REST.
 * Los campos, límites y opciones son el contrato con `includes/quote/validate.php` y no se editan.
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_quote_form_view( $attributes, $block ?? null );
	}
);

ebio_quote_form_init_state( $view );

$ebio_text   = static function ( string $key, string $fallback = '' ) use ( $attributes ): string {
	return is_string( $attributes[ $key ] ?? null ) ? $attributes[ $key ] : $fallback;
};
$ebio_values = is_array( $view['values'] ?? null ) ? $view['values'] : array();
$ebio_errors = is_array( $view['errors'] ?? null ) ? $view['errors'] : array();
$ebio_value  = static function ( string $field ) use ( $ebio_values ): string {
	return is_string( $ebio_values[ $field ] ?? null ) ? $ebio_values[ $field ] : '';
};
$ebio_error  = static function ( string $field ) use ( $ebio_errors ): string {
	return is_string( $ebio_errors[ $field ] ?? null ) ? $ebio_errors[ $field ] : '';
};
$ebio_hidden = static function ( string $field ) use ( $ebio_error ): string {
	return '' === $ebio_error( $field ) ? ' hidden' : '';
};
$ebio_invalid = static function ( string $field ) use ( $ebio_error ): string {
	return '' === $ebio_error( $field ) ? 'false' : 'true';
};
$ebio_error_line = static function ( string $field ) use ( $ebio_error, $ebio_hidden ): string {
	return '<p class="ebio-quote-form__error" id="ebio-quote-' . $field . '-error"' . $ebio_hidden( $field )
		. ' data-wp-bind--hidden="!state.form.errors.' . $field . '" data-wp-text="state.form.errors.' . $field . '">' . esc_html( $ebio_error( $field ) ) . '</p>';
};

$ebio_level       = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );
$ebio_count       = (int) ( $view['errorCount'] ?? 0 );
$ebio_form_error  = is_string( $view['formError'] ?? null ) ? $view['formError'] : '';
$ebio_message_hint = $ebio_text( 'messageHint' );
$ebio_phone_hint  = $ebio_text( 'phoneHint' );
$ebio_note        = $ebio_text( 'note' );
$ebio_action      = is_string( $view['actionUrl'] ?? null ) ? $view['actionUrl'] : '/wp-admin/admin-post.php?action=ebio_quote';

$ebio_summary = array(
	array( 'company', 'Empresa:', '#ebio-quote-company' ),
	array( 'name', 'Nombre:', '#ebio-quote-name' ),
	array( 'email', 'Correo:', '#ebio-quote-email' ),
	array( 'phone', 'Celular / WhatsApp:', '#ebio-quote-phone' ),
	array( 'city', 'Ciudad:', '#ebio-quote-city' ),
	array( 'sector', 'Sector:', '#ebio-quote-sector' ),
	array( 'message', 'Mensaje:', '#ebio-quote-message' ),
	array( 'consent', 'Autorización:', '#ebio-quote-consent' ),
	array( 'items', 'Tu lista:', '#ebio-quote-list-heading' ),
);
$ebio_text_fields = array(
	array( 'company', 'Empresa', 'text', 120, 'organization', true, '' ),
	array( 'name', 'Nombre', 'text', 120, 'name', true, '' ),
	array( 'email', 'Correo', 'email', 254, 'email', true, '' ),
	array( 'phone', 'Celular / WhatsApp', 'tel', 30, 'tel', true, $ebio_phone_hint ),
	array( 'city', 'Ciudad', 'text', 80, 'address-level2', false, '' ),
);
$ebio_sectors     = array(
	''                 => 'Selecciona…',
	'floricultura'     => 'Floricultura',
	'agro-frutas'      => 'Agro y frutas',
	'industria'        => 'Industria',
	'alimentos'        => 'Alimentos',
	'retail-ecommerce' => 'Retail y e-commerce',
	'otro'             => 'Otro',
);
$ebio_star        = ' <span class="ebio-quote-form__required" aria-hidden="true">*</span>';

$ebio_lines   = array();
$ebio_lines[] = '<section class="ebio-quote-form" id="ebio-quote-form" aria-labelledby="ebio-quote-form-heading" data-state="' . esc_attr( ebio_quote_form_status( $view ) ) . '"'
	. ' data-wp-interactive="ebio/quote" ' . wp_interactivity_data_wp_context( array( 'hydrated' => false ) ) . ' data-wp-init="callbacks.initForm" data-wp-bind--data-state="state.form.status">';
$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-quote-form__heading" id="ebio-quote-form-heading">' . esc_html( $ebio_text( 'heading' ) ) . '</h' . $ebio_level . '>';
$ebio_lines[] = '<div class="ebio-quote-form__summary" id="ebio-quote-form-summary" role="alert" tabindex="-1"' . ( $ebio_count > 0 ? '' : ' hidden' ) . ' data-wp-bind--hidden="!state.form.hasErrors">';
$ebio_lines[] = '<p class="ebio-quote-form__summary-title" data-wp-text="state.form.summaryTitle">' . esc_html( (string) ( $view['summaryTitle'] ?? '' ) ) . '</p>';
$ebio_lines[] = '<ul class="ebio-quote-form__summary-list">';
foreach ( $ebio_summary as $ebio_row ) {
	$ebio_lines[] = '<li class="ebio-quote-form__summary-item"' . $ebio_hidden( $ebio_row[0] ) . ' data-wp-bind--hidden="!state.form.errors.' . $ebio_row[0] . '">';
	$ebio_lines[] = '<a class="ebio-quote-form__summary-link" href="' . esc_attr( $ebio_row[2] ) . '">' . esc_html( $ebio_row[1] ) . ' <span data-wp-text="state.form.errors.' . $ebio_row[0] . '">' . esc_html( $ebio_error( $ebio_row[0] ) ) . '</span></a>';
	$ebio_lines[] = '</li>';
}
$ebio_lines[] = '</ul>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '<p class="ebio-quote-form__alert" role="alert"' . ( '' === $ebio_form_error ? ' hidden' : '' ) . ' data-wp-bind--hidden="!state.form.formError" data-wp-text="state.form.formError">' . esc_html( $ebio_form_error ) . '</p>';
$ebio_lines[] = '<form class="ebio-quote-form__form" action="' . esc_url( $ebio_action ) . '" method="post" aria-describedby="ebio-quote-form-note" data-wp-on--submit="actions.submit" data-wp-bind--novalidate="context.hydrated">';
$ebio_lines[] = '<input type="hidden" name="_ebio_nonce" value="' . esc_attr( (string) ( $view['nonce'] ?? '' ) ) . '">';
$ebio_lines[] = '<div class="ebio-quote-form__fields">';

foreach ( $ebio_text_fields as $ebio_f ) {
	list( $ebio_name, $ebio_label, $ebio_type, $ebio_max, $ebio_auto, $ebio_required, $ebio_hint ) = $ebio_f;
	$ebio_id    = 'ebio-quote-' . $ebio_name;
	$ebio_desc  = ( '' !== $ebio_hint ? $ebio_id . '-hint ' : '' ) . $ebio_id . '-error';
	$ebio_lines[] = '<div class="ebio-quote-form__field" data-field="' . $ebio_name . '">';
	$ebio_lines[] = '<label class="ebio-quote-form__label" for="' . $ebio_id . '">' . esc_html( $ebio_label ) . ( $ebio_required ? $ebio_star : '' ) . '</label>';
	$ebio_lines[] = '<input class="ebio-quote-form__input" id="' . $ebio_id . '" name="' . $ebio_name . '" type="' . $ebio_type . '" maxlength="' . $ebio_max . '" autocomplete="' . $ebio_auto . '"'
		. ( 'tel' === $ebio_type ? ' inputmode="tel"' : '' ) . ( $ebio_required ? ' required' : '' ) . ' value="' . esc_attr( $ebio_value( $ebio_name ) ) . '"'
		. ' aria-invalid="' . $ebio_invalid( $ebio_name ) . '" aria-describedby="' . $ebio_desc . '" data-wp-bind--value="state.form.values.' . $ebio_name . '" data-wp-bind--aria-invalid="state.form.invalid.' . $ebio_name . '" data-wp-on--input="actions.setValue" data-wp-on--blur="actions.validateField">';
	if ( '' !== $ebio_hint ) {
		$ebio_lines[] = '<p class="ebio-quote-form__hint" id="' . $ebio_id . '-hint">' . esc_html( $ebio_hint ) . '</p>';
	}
	$ebio_lines[] = $ebio_error_line( $ebio_name );
	$ebio_lines[] = '</div>';
}

$ebio_lines[] = '<div class="ebio-quote-form__field" data-field="sector">';
$ebio_lines[] = '<label class="ebio-quote-form__label" for="ebio-quote-sector">Sector</label>';
$ebio_lines[] = '<select class="ebio-quote-form__select" id="ebio-quote-sector" name="sector" aria-invalid="' . $ebio_invalid( 'sector' ) . '" aria-describedby="ebio-quote-sector-error" data-wp-bind--aria-invalid="state.form.invalid.sector">';
foreach ( $ebio_sectors as $ebio_slug => $ebio_sector_label ) {
	$ebio_lines[] = '<option value="' . esc_attr( (string) $ebio_slug ) . '"' . ( $ebio_value( 'sector' ) === (string) $ebio_slug ? ' selected' : '' ) . '>' . esc_html( $ebio_sector_label ) . '</option>';
}
$ebio_lines[] = '</select>';
$ebio_lines[] = $ebio_error_line( 'sector' );
$ebio_lines[] = '</div>';

$ebio_lines[] = '<div class="ebio-quote-form__field ebio-quote-form__field--full" data-field="message">';
$ebio_lines[] = '<label class="ebio-quote-form__label" for="ebio-quote-message">Mensaje</label>';
$ebio_lines[] = '<textarea class="ebio-quote-form__textarea" id="ebio-quote-message" name="message" maxlength="2000" rows="5" aria-invalid="' . $ebio_invalid( 'message' ) . '" aria-describedby="'
	. ( '' !== $ebio_message_hint ? 'ebio-quote-message-hint ' : '' ) . 'ebio-quote-message-error" data-wp-bind--aria-invalid="state.form.invalid.message">' . esc_textarea( $ebio_value( 'message' ) ) . '</textarea>';
if ( '' !== $ebio_message_hint ) {
	$ebio_lines[] = '<p class="ebio-quote-form__hint" id="ebio-quote-message-hint">' . esc_html( $ebio_message_hint ) . '</p>';
}
$ebio_lines[] = $ebio_error_line( 'message' );
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';

$ebio_lines[] = '<div class="ebio-quote-form__field ebio-quote-form__field--consent" data-field="consent">';
$ebio_lines[] = '<input class="ebio-quote-form__checkbox" id="ebio-quote-consent" name="consent" type="checkbox" value="1" required aria-invalid="' . $ebio_invalid( 'consent' ) . '" aria-describedby="ebio-quote-consent-error" data-wp-bind--aria-invalid="state.form.invalid.consent">';
$ebio_lines[] = '<label class="ebio-quote-form__consent-label" for="ebio-quote-consent">Acepto el <a href="' . esc_url( $ebio_text( 'consentUrl', '/proteccion-de-datos/' ) ) . '">' . esc_html( $ebio_text( 'consentLinkText' ) ) . '</a>' . $ebio_star . '</label>';
$ebio_lines[] = $ebio_error_line( 'consent' );
$ebio_lines[] = '</div>';

$ebio_lines[] = '<div class="ebio-quote-form__trap" aria-hidden="true">';
$ebio_lines[] = '<label class="ebio-quote-form__trap-label" for="ebio-quote-website">Sitio web (deja este campo vacío)</label>';
$ebio_lines[] = '<input class="ebio-quote-form__trap-input" id="ebio-quote-website" name="website" type="text" value="" tabindex="-1" autocomplete="off">';
$ebio_lines[] = '</div>';

// La nota (qué pasa después de enviar) va justo antes del botón: se lee antes de enviar (modo Operate).
if ( '' !== $ebio_note ) {
	$ebio_lines[] = '<p class="ebio-quote-form__note" id="ebio-quote-form-note">' . esc_html( $ebio_note ) . '</p>';
}
$ebio_lines[] = '<button type="submit" class="ebio-quote-form__submit ebio-button ebio-button--primary ebio-button--block" aria-busy="false" data-wp-bind--disabled="state.form.isSubmitting" data-wp-bind--aria-busy="state.form.isSubmitting">';
$ebio_lines[] = '<span class="ebio-quote-form__submit-text">' . esc_html( $ebio_text( 'submitText' ) ) . '</span>';
$ebio_lines[] = '<span class="ebio-quote-form__submit-count" hidden data-wp-bind--hidden="!state.hasItems" data-wp-text="state.submitCountText"></span>';
$ebio_lines[] = '</button>';
$ebio_lines[] = '</form>';
$ebio_lines[] = '</section>';

echo implode( '', $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
