import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, TextControl, TextareaControl } from '@wordpress/components';
import QuoteForm from '../../components/QuoteForm.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Editor de `ebio/quote-form`: vista previa no enviable. Los campos son el contrato con el servidor
 * (`includes/quote/validate.php`) y no se editan; sí los textos y el enlace a la política de datos.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view } = useBlockView( 'ebio/quote-form', attributes, context );
	const field = ( key, label, help ) => (
		<TextControl
			label={ label }
			value={ attributes[ key ] }
			onChange={ ( next ) => setAttributes( { [ key ]: next } ) }
			help={ help }
			__nextHasNoMarginBottom
			__next40pxDefaultSize
		/>
	);

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Textos', 'ebio-core' ) }>
					{ field( 'heading', __( 'Encabezado', 'ebio-core' ), __( 'Recomendado: hasta 30 caracteres.', 'ebio-core' ) ) }
					{ field( 'submitText', __( 'Botón de envío', 'ebio-core' ), __( 'Recomendado: hasta 35 caracteres.', 'ebio-core' ) ) }
					<TextareaControl
						label={ __( 'Nota', 'ebio-core' ) }
						value={ attributes.note }
						onChange={ ( note ) => setAttributes( { note } ) }
						help={ __( 'Recomendado: hasta 200 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
					/>
					{ field( 'messageHint', __( 'Ayuda del mensaje', 'ebio-core' ), __( 'Recomendado: hasta 140 caracteres. Vacío = sin ayuda.', 'ebio-core' ) ) }
					{ field( 'phoneHint', __( 'Ayuda del celular', 'ebio-core' ), __( 'Recomendado: hasta 30 caracteres. Vacío = sin ayuda.', 'ebio-core' ) ) }
				</PanelBody>
				<PanelBody title={ __( 'Política de datos', 'ebio-core' ) } initialOpen={ false }>
					{ field( 'consentLinkText', __( 'Texto del enlace', 'ebio-core' ), __( 'Recomendado: hasta 50 caracteres.', 'ebio-core' ) ) }
					{ field( 'consentUrl', __( 'URL del enlace', 'ebio-core' ) ) }
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<Notice status="info" isDismissible={ false }>
					{ __( 'Los campos son fijos: contrato con el servidor.', 'ebio-core' ) }
				</Notice>
				<QuoteForm attributes={ attributes } context={ { 'ebio/view': view ?? {} } } />
			</div>
		</>
	);
}
