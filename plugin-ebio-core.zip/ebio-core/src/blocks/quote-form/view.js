/**
 * Vista de `ebio/quote-form`: extiende el store compartido `ebio/quote` (envío por REST de /cotizar/).
 */
import '../../stores/quote/form.js';
