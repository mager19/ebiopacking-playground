import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, SelectControl, TextControl } from '@wordpress/components';
import CategoryNav from '../../components/CategoryNav.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import { ICON_SLUGS } from '../../editor/icons.js';
import useBlockView from '../../editor/use-block-view.js';

const ICON_OPTIONS = ICON_SLUGS.map( ( slug ) => ( { label: slug, value: slug } ) );

/**
 * Editor de `ebio/category-nav`: la lista de ítems se edita en el panel "Ítems" (texto, URL y ícono de la
 * lista cerrada); el ítem actual lo calcula el servidor (vista).
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view } = useBlockView( 'ebio/category-nav', attributes, context );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Navegación', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Nombre accesible', 'ebio-core' ) }
						value={ attributes.ariaLabel }
						onChange={ ( ariaLabel ) => setAttributes( { ariaLabel } ) }
						help={ __( 'Recomendado: hasta 30 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Ítems', 'ebio-core' ) }>
					<ItemListControl
						items={ attributes.items }
						onChange={ ( items ) => setAttributes( { items } ) }
						min={ 3 }
						max={ 8 }
						emptyItem={ { label: '', url: '', icon: 'box' } }
						itemLabel={ __( 'Ítem', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<>
								<TextControl
									label={ __( 'Texto', 'ebio-core' ) }
									value={ item.label }
									onChange={ ( label ) => update( { label } ) }
									help={ __( 'Recomendado: hasta 24 caracteres.', 'ebio-core' ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
								<TextControl
									label={ __( 'URL', 'ebio-core' ) }
									value={ item.url }
									onChange={ ( url ) => update( { url } ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
								<SelectControl
									label={ __( 'Ícono', 'ebio-core' ) }
									value={ item.icon }
									options={ ICON_OPTIONS }
									onChange={ ( icon ) => update( { icon } ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
							</>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<CategoryNav attributes={ attributes } context={ { 'ebio/view': view ?? {} } } />
			</div>
		</>
	);
}
