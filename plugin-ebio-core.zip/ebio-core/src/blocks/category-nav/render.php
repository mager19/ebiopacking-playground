<?php
/**
 * `ebio/category-nav` (docs/blocks/category-nav.md). Gemelo de `src/components/CategoryNav.jsx`.
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_category_nav_view( $attributes, $block ?? null );
	}
);

$ebio_items = array();
foreach ( is_array( $view['items'] ?? null ) ? $view['items'] : array() as $ebio_item ) {
	if ( ! is_array( $ebio_item ) || empty( $ebio_item['label'] ) || empty( $ebio_item['url'] ) ) {
		continue;
	}
	$ebio_current = (string) ( $ebio_item['current'] ?? '' );
	$ebio_icon    = (string) ( $ebio_item['icon'] ?? '' );
	$ebio_items[] = '<li class="ebio-category-nav__item">'
		. '<a class="ebio-category-nav__link" href="' . esc_url( (string) $ebio_item['url'] ) . '"' . ( '' !== $ebio_current ? ' aria-current="' . esc_attr( $ebio_current ) . '"' : '' ) . '>'
		. ( '' !== $ebio_icon ? '<span class="ebio-icon ebio-icon--' . esc_attr( $ebio_icon ) . '" aria-hidden="true"></span>' : '' )
		. '<span class="ebio-category-nav__label">' . esc_html( (string) $ebio_item['label'] ) . '</span>'
		. '</a></li>';
}

$ebio_lines   = array();
$ebio_lines[] = '<nav ' . ebio_root_attributes( 'ebio-category-nav', array(), $attributes ) . ' aria-label="' . esc_attr( (string) ( $attributes['ariaLabel'] ?? '' ) ) . '">';
$ebio_lines[] = '<div class="ebio-category-nav__inner">';
$ebio_lines[] = '<ul class="ebio-category-nav__list">' . implode( '', $ebio_items ) . '</ul>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</nav>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
