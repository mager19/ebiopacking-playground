import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, TextControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import SectorCards from '../../components/SectorCards.jsx';
import ImageControl, { EMPTY_IMAGE } from '../../editor/ImageControl.jsx';
import CardImagePicker from '../../editor/CardImagePicker.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';

export default function Edit( { attributes, setAttributes } ) {
	const editContext = makeEditContext( attributes, setAttributes );
	editContext.imagePicker = ( path, image ) => <CardImagePicker image={ image } onChange={ ( next ) => editContext.onChange( path, next ) } />;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Tarjetas', 'ebio-core' ) }>
					<ItemListControl
						items={ attributes.items }
						onChange={ ( items ) => setAttributes( { items } ) }
						min={ 1 }
						max={ 6 }
						emptyItem={ { title: '', text: '', url: '', image: { ...EMPTY_IMAGE } } }
						itemLabel={ __( 'Tarjeta', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<>
								<TextControl
									label={ __( 'Enlace', 'ebio-core' ) }
									value={ item.url }
									onChange={ ( url ) => update( { url } ) }
									help={ ! item.url ? __( 'Falta el enlace de la tarjeta.', 'ebio-core' ) : undefined }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
								<ImageControl label={ __( 'Foto', 'ebio-core' ) } value={ item.image } onChange={ ( image ) => update( { image } ) } />
							</>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<EditContext.Provider value={ editContext }>
					<SectorCards attributes={ attributes } />
				</EditContext.Provider>
			</div>
		</>
	);
}
