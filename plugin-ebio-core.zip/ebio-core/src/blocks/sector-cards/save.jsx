import { SaveMode } from '../../components/lib/save-mode.js';
import SectorCards from '../../components/SectorCards.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<SectorCards attributes={ attributes } />
		</SaveMode.Provider>
	);
}
