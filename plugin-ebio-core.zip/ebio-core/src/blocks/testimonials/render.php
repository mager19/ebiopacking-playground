<?php
/**
 * `ebio/testimonials` (docs/blocks/testimonials.md). Gemelo de `src/components/Testimonials.jsx`.
 *
 * Sin citas autorizadas no emite nada (D22). Los `span` de la autoría van pegados y los vacíos no se
 * emiten (catalog §2.9). Solo la variante por defecto usa Interactivity API.
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_testimonials_view( $attributes, $block ?? null );
	}
);

$ebio_items = is_array( $view['items'] ?? null ) ? array_values( $view['items'] ) : array();
$ebio_quotes = array_values(
	array_filter(
		$ebio_items,
		static function ( $ebio_item ): bool {
			return is_array( $ebio_item ) && 'quote' === ( $ebio_item['type'] ?? '' );
		}
	)
);
if ( ! $ebio_quotes ) {
	return;
}

$ebio_single  = 'single' === ( $attributes['variant'] ?? 'default' );
$ebio_level   = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );
$ebio_heading = is_string( $attributes['heading'] ?? null ) ? $attributes['heading'] : '';
$ebio_intro   = is_string( $attributes['intro'] ?? null ) ? $attributes['intro'] : '';

$ebio_quote_html = static function ( array $item ): string {
	$author = '';
	foreach ( array( 'name', 'role', 'company' ) as $key ) {
		if ( ! empty( $item[ $key ] ) ) {
			$author .= '<span class="ebio-testimonials__' . $key . '">' . esc_html( (string) $item[ $key ] ) . '</span>';
		}
	}
	return '<figure class="ebio-testimonials__quote">'
		. '<blockquote class="ebio-testimonials__text"><p>' . esc_html( (string) ( $item['quote'] ?? '' ) ) . '</p></blockquote>'
		. '<figcaption class="ebio-testimonials__author">' . $author . '</figcaption>'
		. '</figure>';
};

$ebio_lines = array();

if ( $ebio_single ) {
	$ebio_photo = null;
	foreach ( $ebio_items as $ebio_item ) {
		if ( is_array( $ebio_item ) && 'photo' === ( $ebio_item['type'] ?? '' ) ) {
			$ebio_photo = $ebio_item;
			break;
		}
	}
	$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-testimonials', array( 'single' ), $attributes ) . '>';
	$ebio_lines[] = '<div class="ebio-testimonials__inner">';
	$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-testimonials__heading">' . esc_html( $ebio_heading ) . '</h' . $ebio_level . '>';
	$ebio_lines[] = '<div class="ebio-testimonials__case">';
	$ebio_lines[] = $ebio_quote_html( $ebio_quotes[0] );
	if ( null !== $ebio_photo && is_array( $ebio_photo['image'] ?? null ) ) {
		$ebio_lines[] = '<div class="ebio-testimonials__media">' . ebio_dynamic_image_html( 'ebio-testimonials__image', $ebio_photo['image'] ) . '</div>';
	}
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '</section>';
} else {
	// Valores iniciales de `ebio/carousel` antes de procesar las directivas (catalog §2.12, SSR sin efecto).
	ebio_carousel_init_state();

	$ebio_uid        = (string) ( $view['uid'] ?? '' );
	$ebio_count      = count( $ebio_items );
	$ebio_heading_id = 'ebio-testimonials-' . $ebio_uid . '-heading';
	$ebio_track_id   = 'ebio-testimonials-' . $ebio_uid . '-track';
	$ebio_button     = static function ( string $name, string $icon, string $label, string $track_id, bool $disabled ): string {
		return '<button type="button" class="ebio-testimonials__' . $name . ' ebio-button ebio-button--icon" aria-controls="' . esc_attr( $track_id ) . '"'
			. ( $disabled ? ' disabled' : '' )
			. ' data-wp-bind--disabled="state.' . ( 'prev' === $name ? 'isFirst' : 'isLast' ) . '" data-wp-on--click="actions.' . $name . '">'
			. '<span class="ebio-icon ebio-icon--' . $icon . '" aria-hidden="true"></span><span class="ebio-visually-hidden">' . esc_html( $label ) . '</span></button>';
	};

	$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-testimonials', array(), $attributes ) . ' aria-labelledby="' . esc_attr( $ebio_heading_id ) . '"'
		. ' data-wp-interactive="ebio/carousel" '
		. wp_interactivity_data_wp_context(
			array(
				'index'    => 0,
				'count'    => $ebio_count,
				'hydrated' => false,
			)
		)
		. ' data-wp-init="callbacks.init" data-hydrated="false" data-wp-bind--data-hydrated="context.hydrated">';
	$ebio_lines[] = '<div class="ebio-testimonials__inner">';
	$ebio_lines[] = '<div class="ebio-testimonials__header">';
	$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-testimonials__heading" id="' . esc_attr( $ebio_heading_id ) . '">' . esc_html( $ebio_heading ) . '</h' . $ebio_level . '>';
	if ( '' !== $ebio_intro ) {
		$ebio_lines[] = '<p class="ebio-testimonials__intro">' . wp_kses_post( $ebio_intro ) . '</p>';
	}
	$ebio_lines[] = '<div class="ebio-testimonials__controls" hidden data-wp-bind--hidden="!context.hydrated">';
	$ebio_lines[] = $ebio_button( 'prev', 'arrow-left', 'Anterior', $ebio_track_id, true ) . $ebio_button( 'next', 'arrow-right', 'Siguiente', $ebio_track_id, $ebio_count <= 1 );
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '<ul class="ebio-testimonials__track" id="' . esc_attr( $ebio_track_id ) . '" data-wp-on--scroll="callbacks.syncIndex">';
	foreach ( $ebio_items as $ebio_item ) {
		if ( ! is_array( $ebio_item ) ) {
			continue;
		}
		if ( 'photo' === ( $ebio_item['type'] ?? '' ) ) {
			$ebio_lines[] = '<li class="ebio-testimonials__slide ebio-testimonials__slide--photo">' . ebio_dynamic_image_html( 'ebio-testimonials__image', is_array( $ebio_item['image'] ?? null ) ? $ebio_item['image'] : null ) . '</li>';
		} else {
			$ebio_lines[] = '<li class="ebio-testimonials__slide ebio-testimonials__slide--quote">' . $ebio_quote_html( $ebio_item ) . '</li>';
		}
	}
	$ebio_lines[] = '</ul>';
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '</section>';
}

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
