import { __ } from '@wordpress/i18n';
import { useEffect, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { InspectorControls, MediaUpload, MediaUploadCheck, useBlockProps } from '@wordpress/block-editor';
import { BaseControl, Button, Notice, PanelBody, SelectControl, TextControl, TextareaControl, ToggleControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import Testimonials from '../../components/Testimonials.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Foto de un ítem: el alt vive en la biblioteca de medios; sin él la foto no se publica (C-B3).
 *
 * @param {Object}   props
 * @param {number}   props.imageId  ID del adjunto.
 * @param {Function} props.onChange Recibe el nuevo ID.
 */
function PhotoField( { imageId, onChange } ) {
	const [ alt, setAlt ] = useState( null );

	useEffect( () => {
		if ( ! imageId ) {
			setAlt( null );
			return undefined;
		}
		let active = true;
		apiFetch( { path: `/wp/v2/media/${ imageId }?_fields=alt_text` } ).then(
			( media ) => active && setAlt( String( media?.alt_text ?? '' ) ),
			() => active && setAlt( null )
		);
		return () => {
			active = false;
		};
	}, [ imageId ] );

	return (
		<BaseControl label={ __( 'Foto', 'ebio-core' ) } __nextHasNoMarginBottom>
			<MediaUploadCheck>
				<MediaUpload
					allowedTypes={ [ 'image' ] }
					value={ imageId || undefined }
					onSelect={ ( media ) => onChange( media.id ) }
					render={ ( { open } ) => (
						<Button variant="secondary" onClick={ open }>
							{ imageId ? __( 'Reemplazar foto', 'ebio-core' ) : __( 'Elegir foto', 'ebio-core' ) }
						</Button>
					) }
				/>
			</MediaUploadCheck>
			{ imageId ? (
				<Button variant="link" isDestructive onClick={ () => onChange( 0 ) }>
					{ __( 'Quitar foto', 'ebio-core' ) }
				</Button>
			) : null }
			{ imageId && alt === '' ? (
				<Notice status="warning" isDismissible={ false }>
					{ __( 'Falta el texto alternativo (obligatorio): complétalo en la biblioteca de medios o la foto no se publica.', 'ebio-core' ) }
				</Notice>
			) : null }
		</BaseControl>
	);
}

/**
 * Editor de `ebio/testimonials`: la vista del servidor solo trae las citas autorizadas y las fotos con
 * alt (lo que se publica); el título y la introducción se editan en el lienzo y la variante y los ítems,
 * en el panel lateral.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view, isLoading } = useBlockView( 'ebio/testimonials', attributes, context );
	const { variant, heading, items } = attributes;
	const single = variant === 'single';
	const pending = ( Array.isArray( items ) ? items : [] ).filter( ( item ) => item?.type === 'quote' && ! item?.authorized ).length;
	const nothingToShow = ! isLoading && ! ( view?.items ?? [] ).some( ( item ) => item?.type === 'quote' );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Variante', 'ebio-core' ) }
						value={ variant }
						options={ [
							{ label: __( 'Carrusel de fotos y citas', 'ebio-core' ), value: 'default' },
							{ label: __( 'Caso único (una cita y una foto)', 'ebio-core' ), value: 'single' },
						] }
						onChange={ ( next ) => setAttributes( { variant: next } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Título', 'ebio-core' ) }
						value={ heading }
						onChange={ ( next ) => setAttributes( { heading: next } ) }
						help={ __( 'Recomendado: hasta 60 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Ítems', 'ebio-core' ) }>
					<ItemListControl
						items={ items }
						onChange={ ( next ) => setAttributes( { items: next } ) }
						min={ single ? 1 : 2 }
						max={ single ? 2 : 8 }
						emptyItem={ { type: 'quote', quote: '', name: '', role: '', company: '', authorized: false, imageId: 0 } }
						itemLabel={ __( 'Ítem', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<>
								<SelectControl
									label={ __( 'Tipo', 'ebio-core' ) }
									value={ item.type }
									options={ [
										{ label: __( 'Cita', 'ebio-core' ), value: 'quote' },
										{ label: __( 'Foto', 'ebio-core' ), value: 'photo' },
									] }
									onChange={ ( type ) => update( { type } ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
								{ item.type === 'photo' ? (
									<PhotoField imageId={ item.imageId } onChange={ ( imageId ) => update( { imageId } ) } />
								) : (
									<>
										<TextareaControl label={ __( 'Cita textual', 'ebio-core' ) } value={ item.quote } onChange={ ( quote ) => update( { quote } ) } help={ __( 'Recomendado: hasta 280 caracteres.', 'ebio-core' ) } __nextHasNoMarginBottom />
										<TextControl label={ __( 'Nombre', 'ebio-core' ) } value={ item.name } onChange={ ( name ) => update( { name } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
										<TextControl label={ __( 'Cargo', 'ebio-core' ) } value={ item.role } onChange={ ( role ) => update( { role } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
										<TextControl label={ __( 'Empresa', 'ebio-core' ) } value={ item.company } onChange={ ( company ) => update( { company } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
										<ToggleControl
											label={ __( 'El cliente autorizó la cita por escrito', 'ebio-core' ) }
											checked={ Boolean( item.authorized ) }
											onChange={ ( authorized ) => update( { authorized } ) }
											help={ __( 'Sin autorización la cita no se publica.', 'ebio-core' ) }
											__nextHasNoMarginBottom
										/>
									</>
								) }
							</>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ pending > 0 ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'No se publica: falta autorización', 'ebio-core' ) } ({ pending })
					</Notice>
				) : null }
				{ nothingToShow ? (
					<Notice status="info" isDismissible={ false }>
						{ __( 'Sin citas autorizadas: la sección no se muestra en el sitio.', 'ebio-core' ) }
					</Notice>
				) : null }
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<Testimonials attributes={ attributes } context={ { 'ebio/view': view ?? { uid: 'testimonials-editor', items: [] } } } />
				</EditContext.Provider>
			</div>
		</>
	);
}
