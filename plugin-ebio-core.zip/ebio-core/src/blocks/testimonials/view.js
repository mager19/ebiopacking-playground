/**
 * Módulo de vista de `ebio/testimonials` (docs/blocks/testimonials.md): flechas del carrusel de la
 * variante por defecto (`ebio/carousel`, compartido con `ebio/product-carousel`). La variante `single`
 * no usa Interactivity API.
 */
import '../../stores/carousel/store.js';
