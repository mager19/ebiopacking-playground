import { SaveMode } from '../../components/lib/save-mode.js';
import TrustStrip from '../../components/TrustStrip.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<TrustStrip attributes={ attributes } />
		</SaveMode.Provider>
	);
}
