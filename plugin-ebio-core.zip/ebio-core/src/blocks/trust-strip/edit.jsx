import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, SelectControl, TextControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import TrustStrip from '../../components/TrustStrip.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import { ICON_SLUGS } from '../../editor/icons.js';

const ICON_OPTIONS = [ { label: __( 'Marca de verificación (por defecto)', 'ebio-core' ), value: '' }, ...ICON_SLUGS.map( ( slug ) => ( { label: slug, value: slug } ) ) ];

export default function Edit( { attributes, setAttributes } ) {
	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Variante', 'ebio-core' ) }
						value={ attributes.variant }
						options={ [
							{ label: __( 'Por defecto', 'ebio-core' ), value: 'default' },
							{ label: __( 'Compacta (ficha de producto)', 'ebio-core' ), value: 'compact' },
							{ label: __( 'Cifras', 'ebio-core' ), value: 'figures' },
						] }
						onChange={ ( variant ) => setAttributes( { variant } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Accesibilidad', 'ebio-core' ) } initialOpen={ false }>
					<TextControl
						label={ __( 'Nombre de la región', 'ebio-core' ) }
						value={ attributes.ariaLabel }
						onChange={ ( ariaLabel ) => setAttributes( { ariaLabel } ) }
						help={ __( 'Recomendado: hasta 40 caracteres. La franja no lleva encabezado visible.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Pruebas de confianza', 'ebio-core' ) }>
					<ItemListControl
						items={ attributes.items }
						onChange={ ( items ) => setAttributes( { items } ) }
						min={ 3 }
						max={ 5 }
						emptyItem={ { icon: '', value: '', label: '' } }
						itemLabel={ __( 'Prueba', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<SelectControl
								label={ __( 'Ícono', 'ebio-core' ) }
								value={ item.icon ?? '' }
								options={ ICON_OPTIONS }
								onChange={ ( icon ) => update( { icon } ) }
								__nextHasNoMarginBottom
								__next40pxDefaultSize
							/>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<TrustStrip attributes={ attributes } />
				</EditContext.Provider>
			</div>
		</>
	);
}
