/**
 * Store `ebio/brand-marquee` (docs/blocks/brand-marquee.md): botón de pausa de la animación (WCAG 2.2.2).
 *
 * `actions.toggle` alterna `context.paused`, que pone o quita `ebio-brand-marquee--paused` en la raíz y
 * cambia la etiqueta visible; `callbacks.init` muestra el botón (sin JS la franja sigue la animación del CSS
 * y no hay botón).
 */
import { store, getContext } from '@wordpress/interactivity';

store( 'ebio/brand-marquee', {
	actions: {
		toggle() {
			const context = getContext();
			context.paused = ! context.paused;
		},
	},
	callbacks: {
		init() {
			getContext().hydrated = true;
		},
	},
} );
