import { SaveMode } from '../../components/lib/save-mode.js';
import BrandMarquee from '../../components/BrandMarquee.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<BrandMarquee attributes={ attributes } />
		</SaveMode.Provider>
	);
}
