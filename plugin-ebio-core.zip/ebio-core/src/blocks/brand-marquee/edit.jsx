import { __, sprintf } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Button, PanelBody, RangeControl, TextControl } from '@wordpress/components';
import BrandMarquee from '../../components/BrandMarquee.jsx';

const MAX_PHRASES = 4;

export default function Edit( { attributes, setAttributes } ) {
	const phrases = Array.isArray( attributes.phrases ) ? attributes.phrases : [];
	const setPhrase = ( index, value ) => setAttributes( { phrases: phrases.map( ( p, i ) => ( i === index ? value : p ) ) } );
	const removePhrase = ( index ) => setAttributes( { phrases: phrases.filter( ( _, i ) => i !== index ) } );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Franja', 'ebio-core' ) }>
					{ phrases.map( ( phrase, index ) => (
						<div key={ index }>
							<TextControl
								label={ sprintf( /* translators: %d: número de frase. */ __( 'Frase %d', 'ebio-core' ), index + 1 ) }
								value={ phrase }
								onChange={ ( value ) => setPhrase( index, value ) }
								help={ __( 'Recomendado: hasta 30 caracteres.', 'ebio-core' ) }
								__nextHasNoMarginBottom
								__next40pxDefaultSize
							/>
							{ phrases.length > 1 ? (
								<Button variant="link" isDestructive onClick={ () => removePhrase( index ) }>
									{ __( 'Quitar frase', 'ebio-core' ) }
								</Button>
							) : null }
						</div>
					) ) }
					{ phrases.length < MAX_PHRASES ? (
						<Button variant="secondary" onClick={ () => setAttributes( { phrases: [ ...phrases, '' ] } ) }>
							{ __( 'Añadir frase', 'ebio-core' ) }
						</Button>
					) : null }
					<RangeControl
						label={ __( 'Repeticiones', 'ebio-core' ) }
						value={ attributes.repeat }
						onChange={ ( value ) => setAttributes( { repeat: value ?? 4 } ) }
						min={ 2 }
						max={ 6 }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<BrandMarquee attributes={ attributes } />
			</div>
		</>
	);
}
