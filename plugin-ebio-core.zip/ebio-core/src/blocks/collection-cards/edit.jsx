import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, TextControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import CollectionCards from '../../components/CollectionCards.jsx';
import ImageControl, { EMPTY_IMAGE } from '../../editor/ImageControl.jsx';
import CardImagePicker from '../../editor/CardImagePicker.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';

export default function Edit( { attributes, setAttributes } ) {
	const editContext = makeEditContext( attributes, setAttributes );
	editContext.imagePicker = ( path, image ) => <CardImagePicker image={ image } onChange={ ( next ) => editContext.onChange( path, next ) } />;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Llamado', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Texto del botón', 'ebio-core' ) }
						value={ attributes.ctaText }
						onChange={ ( ctaText ) => setAttributes( { ctaText } ) }
						help={ __( 'Opcional. Recomendado: hasta 30 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Enlace del botón', 'ebio-core' ) }
						value={ attributes.ctaUrl }
						onChange={ ( ctaUrl ) => setAttributes( { ctaUrl } ) }
						help={ attributes.ctaText && ! attributes.ctaUrl ? __( 'Falta el enlace del botón.', 'ebio-core' ) : undefined }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Tarjetas', 'ebio-core' ) }>
					<ItemListControl
						items={ attributes.items }
						onChange={ ( items ) => setAttributes( { items } ) }
						min={ 2 }
						max={ 4 }
						emptyItem={ { title: '', eyebrow: '', url: '', image: { ...EMPTY_IMAGE } } }
						itemLabel={ __( 'Tarjeta', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<>
								<TextControl
									label={ __( 'Enlace', 'ebio-core' ) }
									value={ item.url }
									onChange={ ( url ) => update( { url } ) }
									help={ ! item.url ? __( 'Falta el enlace de la tarjeta.', 'ebio-core' ) : undefined }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
								<ImageControl label={ __( 'Foto', 'ebio-core' ) } value={ item.image } onChange={ ( image ) => update( { image } ) } />
							</>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<EditContext.Provider value={ editContext }>
					<CollectionCards attributes={ attributes } />
				</EditContext.Provider>
			</div>
		</>
	);
}
