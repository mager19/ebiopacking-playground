import { SaveMode } from '../../components/lib/save-mode.js';
import CollectionCards from '../../components/CollectionCards.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<CollectionCards attributes={ attributes } />
		</SaveMode.Provider>
	);
}
