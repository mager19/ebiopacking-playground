import { SaveMode } from '../../components/lib/save-mode.js';
import ProductGallery from '../../components/ProductGallery.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<ProductGallery attributes={ attributes } />
		</SaveMode.Provider>
	);
}
