import { __ } from '@wordpress/i18n';
import { InspectorControls, MediaPlaceholder, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, TextControl } from '@wordpress/components';
import ProductGallery from '../../components/ProductGallery.jsx';
import ImageControl, { EMPTY_IMAGE, mediaToImage } from '../../editor/ImageControl.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import useUid from '../../editor/use-uid.js';

const MAX_IMAGES = 8;
// La galería siempre incluye una foto "a escala junto a una persona" (P4): se avisa si ningún alt la menciona.
const SCALE_ALT = /persona|escala/i;

export default function Edit( { clientId, attributes, setAttributes } ) {
	// Regenera el uid si falta o está duplicado (bloque copiado y pegado).
	useUid( clientId, attributes, setAttributes, 'gallery' );

	const images = Array.isArray( attributes.images ) ? attributes.images : [];
	const filled = images.filter( ( image ) => image?.id );
	const missingAlt = filled.some( ( image ) => ! image.alt );
	const missingScale = filled.length > 0 && ! filled.some( ( image ) => SCALE_ALT.test( image.alt ?? '' ) );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Galería', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Nombre accesible', 'ebio-core' ) }
						value={ attributes.label }
						onChange={ ( label ) => setAttributes( { label } ) }
						help={ __( 'Lo leen los lectores de pantalla. Recomendado: hasta 40 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<ItemListControl
						items={ images }
						onChange={ ( next ) => setAttributes( { images: next } ) }
						min={ 1 }
						max={ MAX_IMAGES }
						emptyItem={ EMPTY_IMAGE }
						itemLabel={ __( 'Foto', 'ebio-core' ) }
						renderItem={ ( image, update ) => <ImageControl label={ __( 'Imagen', 'ebio-core' ) } value={ image } onChange={ update } required /> }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ filled.length === 0 ? (
					<MediaPlaceholder
						icon="format-gallery"
						labels={ { title: __( 'Galería del producto', 'ebio-core' ), instructions: __( 'Elige de 3 a 5 fotos; incluye una a escala junto a una persona.', 'ebio-core' ) } }
						allowedTypes={ [ 'image' ] }
						multiple
						onSelect={ ( medias ) => setAttributes( { images: medias.slice( 0, MAX_IMAGES ).map( mediaToImage ) } ) }
					/>
				) : (
					<>
						<ProductGallery attributes={ attributes } />
						{ missingAlt ? (
							<Notice status="warning" isDismissible={ false }>
								{ __( 'Falta el texto alternativo (obligatorio)', 'ebio-core' ) }
							</Notice>
						) : null }
						{ missingScale ? (
							<Notice status="warning" isDismissible={ false }>
								{ __( 'Falta la foto a escala junto a una persona (menciónala en su texto alternativo).', 'ebio-core' ) }
							</Notice>
						) : null }
					</>
				) }
			</div>
		</>
	);
}
