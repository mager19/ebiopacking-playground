/**
 * Store `ebio/product-gallery` (docs/blocks/product-gallery.md). El servidor entrega todas las
 * fotos desplegadas; al hidratar se ocultan las no activas y aparecen miniaturas y ampliar.
 * La ampliación usa el `<dialog>` nativo (`showModal()`): foco atrapado y Escape nativos.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';

const rootOf = ( element ) => element.closest( '.ebio-product-gallery' );

const { state } = store( 'ebio/product-gallery', {
	state: {
		activeSrc: null,
		activeAlt: '',
	},
	actions: {
		select() {
			const context = getContext();
			context.active = context.index;
		},
		openZoom() {
			const context = getContext();
			const root = rootOf( getElement().ref );
			const image = root.querySelectorAll( '.ebio-product-gallery__image' )[ context.active ];
			if ( ! image ) {
				return;
			}
			state.activeSrc = image.currentSrc || image.src;
			state.activeAlt = image.alt;
			root.querySelector( 'dialog' ).showModal();
		},
		closeZoom() {
			getElement().ref.closest( 'dialog' ).close();
		},
		onZoomClose() {
			state.activeSrc = null;
			state.activeAlt = '';
		},
	},
	callbacks: {
		init() {
			getContext().hydrated = true;
		},
		syncSlide() {
			const context = getContext();
			context.hidden = context.index !== context.active;
		},
		syncThumb() {
			const context = getContext();
			context.pressed = context.index === context.active;
		},
	},
} );
