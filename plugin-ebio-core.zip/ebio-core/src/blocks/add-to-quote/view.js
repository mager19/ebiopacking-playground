/**
 * Getters de `ebio/quote` que usa `ebio/add-to-quote` (docs/blocks/add-to-quote.md): leen
 * `context.status` del propio bloque. El store compartido lo registra la primera copia que se
 * evalúa (`stores/quote/store.js`); estos getters se registran una sola vez por página.
 */
import { store, getContext } from '@wordpress/interactivity';
import '../../stores/quote/store.js';

const SHARED = Symbol.for( 'ebio/add-to-quote:getters' );

const products = ( count ) => `${ count } ${ count === 1 ? 'producto' : 'productos' }`;

globalThis[ SHARED ] ??= ( () => {
	const { state } = store( 'ebio/quote', {
		state: {
			get isConfirmationVisible() {
				const { status } = getContext();
				return status === 'added' || status === 'updated';
			},
			get isFullVisible() {
				return getContext().status === 'full';
			},
			get isErrorVisible() {
				return getContext().status === 'storage-error';
			},
			get confirmationText() {
				const { status } = getContext();
				if ( status !== 'added' && status !== 'updated' ) {
					return '';
				}
				return `${ status === 'added' ? 'Agregado a' : 'Actualizado en' } tu cotización (${ products( state.items.length ) })`;
			},
		},
	} );
	return true;
} )();
