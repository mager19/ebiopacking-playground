import { registerBlockType } from '@wordpress/blocks';
import metadata from './block.json';
import edit from './edit.jsx';

// Dinámico sin InnerBlocks: sin save() (render.php).
registerBlockType( metadata, { edit } );
