import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, SelectControl, TextControl } from '@wordpress/components';
import AddToQuote from '../../components/AddToQuote.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Editor de `ebio/add-to-quote`: el producto y el enlace de WhatsApp vienen de la vista del servidor;
 * variante, textos y enlaces se editan en el panel lateral.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view, isLoading } = useBlockView( 'ebio/add-to-quote', attributes, context );
	const empty = ! isLoading && ! view?.productId;
	const field = ( key, label, help ) => (
		<TextControl
			label={ label }
			value={ attributes[ key ] }
			onChange={ ( next ) => setAttributes( { [ key ]: next } ) }
			help={ help }
			__nextHasNoMarginBottom
			__next40pxDefaultSize
		/>
	);

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Variante', 'ebio-core' ) }
						value={ attributes.variant }
						options={ [
							{ label: __( 'Panel', 'ebio-core' ), value: 'default' },
							{ label: __( 'Barra fija móvil', 'ebio-core' ), value: 'sticky' },
						] }
						onChange={ ( variant ) => setAttributes( { variant } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Textos', 'ebio-core' ) } initialOpen={ false }>
					{ field( 'heading', __( 'Título', 'ebio-core' ), __( 'Recomendado: hasta 35 caracteres.', 'ebio-core' ) ) }
					{ field( 'quantityLabel', __( 'Etiqueta de cantidad', 'ebio-core' ) ) }
					{ field( 'quantityPlaceholder', __( 'Ejemplo de cantidad', 'ebio-core' ) ) }
					{ field( 'dimensionsLabel', __( 'Etiqueta de medidas', 'ebio-core' ) ) }
					{ field( 'dimensionsPlaceholder', __( 'Ejemplo de medidas', 'ebio-core' ) ) }
					{ field( 'hint', __( 'Ayuda', 'ebio-core' ), __( 'Recomendado: hasta 90 caracteres.', 'ebio-core' ) ) }
					{ field( 'buttonText', __( 'Botón', 'ebio-core' ), __( 'Recomendado: hasta 25 caracteres.', 'ebio-core' ) ) }
				</PanelBody>
				<PanelBody title={ __( 'Enlaces', 'ebio-core' ) } initialOpen={ false }>
					{ field( 'whatsappText', __( 'Texto de WhatsApp', 'ebio-core' ), __( 'Vacío = sin enlace. El número se edita en Ajustes › eBiopacking.', 'ebio-core' ) ) }
					{ field( 'howText', __( '¿Cómo funciona?', 'ebio-core' ), __( 'Vacío = sin enlace.', 'ebio-core' ) ) }
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ empty ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Fuera de un producto publicado el bloque no se muestra en el sitio.', 'ebio-core' ) }
					</Notice>
				) : (
					<AddToQuote attributes={ attributes } context={ { 'ebio/view': view ?? {} } } />
				) }
			</div>
		</>
	);
}
