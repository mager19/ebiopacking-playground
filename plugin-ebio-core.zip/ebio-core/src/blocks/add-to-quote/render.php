<?php
/**
 * `ebio/add-to-quote` (docs/blocks/add-to-quote.md). Gemelo de `src/components/AddToQuote.jsx`.
 *
 * Fuera de un producto publicado no emite nada. Cada elemento de bloque va en su línea y los
 * hermanos en línea van pegados (catalog §2.9).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_add_to_quote_view( $attributes, $block ?? null );
	}
);

$ebio_id = (int) ( $view['productId'] ?? 0 );
if ( $ebio_id <= 0 ) {
	return;
}

ebio_add_to_quote_init_state();

$ebio_text   = static function ( string $key, string $fallback = '' ) use ( $attributes ): string {
	return is_string( $attributes[ $key ] ?? null ) ? $attributes[ $key ] : $fallback;
};
$ebio_sticky = 'sticky' === ( $attributes['variant'] ?? 'default' );
$ebio_name   = is_string( $view['productName'] ?? null ) ? $view['productName'] : '';
$ebio_quote  = is_string( $view['quoteUrl'] ?? null ) ? $view['quoteUrl'] : '/cotizar/';
$ebio_how    = is_string( $view['howUrl'] ?? null ) ? $view['howUrl'] : '/cotizar/#como-funciona';
$ebio_wa     = is_string( $view['whatsappUrl'] ?? null ) ? $view['whatsappUrl'] : '';
$ebio_prefix = 'ebio-add-to-quote-' . $ebio_id;
$ebio_button = $ebio_text( 'buttonText', 'Agregar a cotización' );

$ebio_context = ' data-state="idle" data-wp-interactive="ebio/quote" '
	. wp_interactivity_data_wp_context(
		array(
			'productId' => $ebio_id,
			'status'    => 'idle',
		)
	)
	. ' data-wp-bind--data-state="context.status"';

$ebio_status = array(
	'<div class="ebio-add-to-quote__status" role="status">',
	'<p class="ebio-add-to-quote__confirmation" hidden data-wp-bind--hidden="!state.isConfirmationVisible">'
		. '<span class="ebio-icon ebio-icon--check" aria-hidden="true"></span>'
		. '<span class="ebio-add-to-quote__confirmation-text" data-wp-text="state.confirmationText"></span>'
		. '<a class="ebio-add-to-quote__view-list" href="' . esc_url( $ebio_quote ) . '">Ver lista</a></p>',
	'<p class="ebio-add-to-quote__full" hidden data-wp-bind--hidden="!state.isFullVisible">Tu lista llegó al máximo de 30 productos. <a class="ebio-add-to-quote__view-list" href="' . esc_url( $ebio_quote ) . '">Revisa tu lista</a></p>',
	'<p class="ebio-add-to-quote__error" hidden data-wp-bind--hidden="!state.isErrorVisible">No pudimos guardar tu lista en este navegador. La conservamos mientras sigas en el sitio.</p>',
	'</div>',
);

$ebio_lines = array();
if ( $ebio_sticky ) {
	$ebio_lines[] = '<div ' . ebio_root_attributes( 'ebio-add-to-quote', array( 'sticky' ), $attributes ) . ' role="region" aria-label="' . esc_attr( 'Agregar ' . $ebio_name . ' a tu cotización' ) . '"' . $ebio_context . '>';
	$ebio_lines[] = '<p class="ebio-add-to-quote__product">' . esc_html( $ebio_name ) . '</p>';
	$ebio_lines[] = '<form class="ebio-add-to-quote__form" action="' . esc_url( $ebio_quote ) . '" method="get" data-wp-on--submit="actions.addFromForm">';
	$ebio_lines[] = '<input type="hidden" name="producto" value="' . esc_attr( (string) $ebio_id ) . '">'
		. '<button type="submit" class="ebio-add-to-quote__submit ebio-button ebio-button--primary ebio-button--small">'
		. '<span class="ebio-icon ebio-icon--plus" aria-hidden="true"></span>' . esc_html( $ebio_button ) . '</button>';
	$ebio_lines[] = '</form>';
	$ebio_lines   = array_merge( $ebio_lines, $ebio_status );
	$ebio_lines[] = '</div>';
} else {
	$ebio_level   = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );
	$ebio_hint    = $ebio_text( 'hint' );
	$ebio_wa_text = $ebio_text( 'whatsappText' );
	$ebio_how_txt = $ebio_text( 'howText' );

	$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-add-to-quote', array(), $attributes ) . ' aria-labelledby="' . esc_attr( $ebio_prefix . '-heading' ) . '"' . $ebio_context . '>';
	$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-add-to-quote__heading" id="' . esc_attr( $ebio_prefix . '-heading' ) . '">' . esc_html( $ebio_text( 'heading' ) ) . '</h' . $ebio_level . '>';
	$ebio_lines[] = '<form class="ebio-add-to-quote__form" action="' . esc_url( $ebio_quote ) . '" method="get" data-wp-on--submit="actions.addFromForm">';
	$ebio_lines[] = '<input type="hidden" name="producto" value="' . esc_attr( (string) $ebio_id ) . '">';
	$ebio_lines[] = '<div class="ebio-add-to-quote__field">';
	$ebio_lines[] = '<label class="ebio-add-to-quote__label" for="' . esc_attr( $ebio_prefix . '-quantity' ) . '">' . esc_html( $ebio_text( 'quantityLabel' ) ) . '</label>'
		. '<input class="ebio-add-to-quote__input" id="' . esc_attr( $ebio_prefix . '-quantity' ) . '" name="cantidad" type="text" maxlength="40" placeholder="' . esc_attr( $ebio_text( 'quantityPlaceholder' ) ) . '" autocomplete="off">';
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '<div class="ebio-add-to-quote__field">';
	$ebio_lines[] = '<label class="ebio-add-to-quote__label" for="' . esc_attr( $ebio_prefix . '-dimensions' ) . '">' . esc_html( $ebio_text( 'dimensionsLabel' ) ) . '</label>'
		. '<input class="ebio-add-to-quote__input" id="' . esc_attr( $ebio_prefix . '-dimensions' ) . '" name="medidas" type="text" maxlength="120" placeholder="' . esc_attr( $ebio_text( 'dimensionsPlaceholder' ) ) . '" autocomplete="off"'
		. ( '' !== $ebio_hint ? ' aria-describedby="' . esc_attr( $ebio_prefix . '-hint' ) . '"' : '' ) . '>';
	if ( '' !== $ebio_hint ) {
		$ebio_lines[] = '<p class="ebio-add-to-quote__hint" id="' . esc_attr( $ebio_prefix . '-hint' ) . '">' . esc_html( $ebio_hint ) . '</p>';
	}
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '<button type="submit" class="ebio-add-to-quote__submit ebio-button ebio-button--primary ebio-button--block">'
		. '<span class="ebio-icon ebio-icon--plus" aria-hidden="true"></span>' . esc_html( $ebio_button ) . '</button>';
	$ebio_lines[] = '</form>';
	if ( ( '' !== $ebio_wa_text && '' !== $ebio_wa ) || '' !== $ebio_how_txt ) {
		$ebio_links = '';
		if ( '' !== $ebio_wa_text && '' !== $ebio_wa ) {
			$ebio_links .= '<a class="ebio-add-to-quote__whatsapp" href="' . esc_url( $ebio_wa ) . '" target="_blank" rel="noopener">' . esc_html( $ebio_wa_text )
				. '<span class="ebio-visually-hidden"> (abre WhatsApp en una pestaña nueva)</span></a>';
		}
		if ( '' !== $ebio_how_txt ) {
			$ebio_links .= '<a class="ebio-add-to-quote__how" href="' . esc_url( $ebio_how ) . '">' . esc_html( $ebio_how_txt ) . '</a>';
		}
		$ebio_lines[] = '<p class="ebio-add-to-quote__links">' . $ebio_links . '</p>';
	}
	$ebio_lines   = array_merge( $ebio_lines, $ebio_status );
	$ebio_lines[] = '</section>';
}

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
