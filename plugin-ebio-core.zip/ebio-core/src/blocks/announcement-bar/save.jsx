import { SaveMode } from '../../components/lib/save-mode.js';
import AnnouncementBar from '../../components/AnnouncementBar.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<AnnouncementBar attributes={ attributes } />
		</SaveMode.Provider>
	);
}
