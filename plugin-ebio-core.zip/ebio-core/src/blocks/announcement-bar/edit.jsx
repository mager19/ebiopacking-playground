import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, TextControl, ToggleControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import AnnouncementBar from '../../components/AnnouncementBar.jsx';

/** `^[a-z0-9-]{1,20}$` (docs/blocks/announcement-bar.md): minúsculas, números y guion. */
const cleanKey = ( value ) => value.toLowerCase().replace( /[^a-z0-9-]/g, '' ).slice( 0, 20 );

export default function Edit( { attributes, setAttributes } ) {
	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Aviso', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Texto del enlace', 'ebio-core' ) }
						value={ attributes.linkText }
						onChange={ ( linkText ) => setAttributes( { linkText } ) }
						help={ __( 'Recomendado: hasta 30 caracteres. Mensaje y enlace juntos, hasta 90. Sin texto no se muestra el enlace.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'URL del enlace', 'ebio-core' ) }
						value={ attributes.linkUrl }
						onChange={ ( linkUrl ) => setAttributes( { linkUrl } ) }
						type="url"
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<ToggleControl
						label={ __( 'Se puede cerrar', 'ebio-core' ) }
						checked={ attributes.dismissible }
						onChange={ ( dismissible ) => setAttributes( { dismissible } ) }
						__nextHasNoMarginBottom
					/>
					<TextControl
						label={ __( 'Clave del aviso', 'ebio-core' ) }
						value={ attributes.dismissKey }
						onChange={ ( value ) => setAttributes( { dismissKey: cleanKey( value ) } ) }
						help={ __( 'Solo minúsculas, números y guion (hasta 20). Cambiarla vuelve a mostrar la barra a quien ya la cerró.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<AnnouncementBar attributes={ attributes } />
				</EditContext.Provider>
			</div>
		</>
	);
}
