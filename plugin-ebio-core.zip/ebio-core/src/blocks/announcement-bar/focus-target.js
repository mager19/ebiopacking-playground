/**
 * Destino del foco al cerrar la barra de anuncio (WCAG 2.4.3 Orden del foco): el botón de cierre deja de
 * existir para el teclado, así que el foco pasa al siguiente elemento enfocable del documento que no esté
 * dentro de la barra. Sin ninguno, devuelve `null` (el foco queda donde el navegador lo deje).
 */
const FOCUSABLE = [
	'a[href]',
	'button:not([disabled])',
	'input:not([disabled]):not([type="hidden"])',
	'select:not([disabled])',
	'textarea:not([disabled])',
	'summary',
	'[tabindex]:not([tabindex="-1"])',
].join( ',' );

/**
 * @param {Element} bar Raíz de la barra (`.ebio-announcement-bar`).
 * @return {HTMLElement|null} Siguiente elemento enfocable fuera de la barra, o `null`.
 */
export function nextFocusTarget( bar ) {
	const doc = bar?.ownerDocument;
	if ( ! doc ) {
		return null;
	}
	const candidates = Array.from( doc.querySelectorAll( FOCUSABLE ) ).filter( ( el ) => {
		if ( bar.contains( el ) || ! ( bar.compareDocumentPosition( el ) & Node.DOCUMENT_POSITION_FOLLOWING ) ) {
			return false;
		}
		return ! el.closest( '[hidden], [inert]' ) && el.getAttribute( 'aria-hidden' ) !== 'true';
	} );
	return candidates[ 0 ] ?? null;
}
