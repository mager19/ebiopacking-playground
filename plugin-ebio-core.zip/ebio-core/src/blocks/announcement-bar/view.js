/**
 * Store `ebio/announcement-bar` (docs/blocks/announcement-bar.md).
 *
 * `actions.dismiss` guarda la clave en `localStorage['ebio-announcement']` y cierra la barra;
 * `callbacks.restore` la cierra al cargar si la clave guardada es la vigente. Sin JS o sin
 * almacenamiento (modo privado, bloqueado) la barra se ve siempre.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';
import { nextFocusTarget } from './focus-target.js';

const STORAGE_KEY = 'ebio-announcement';

store( 'ebio/announcement-bar', {
	actions: {
		dismiss() {
			const context = getContext();
			// El botón se oculta con la barra: el foco pasa al siguiente elemento enfocable (WCAG 2.4.3).
			const target = nextFocusTarget( getElement().ref?.closest( '.ebio-announcement-bar' ) );
			try {
				window.localStorage.setItem( STORAGE_KEY, context.key );
			} catch ( error ) {
				// Sin almacenamiento: se cierra solo en esta página.
			}
			context.dismissed = true;
			target?.focus();
		},
	},
	callbacks: {
		restore() {
			const context = getContext();
			const { ref } = getElement();
			// Una barra no descartable (sin botón) nunca se oculta.
			if ( ! ref?.querySelector( '.ebio-announcement-bar__close' ) ) {
				return;
			}
			try {
				if ( window.localStorage.getItem( STORAGE_KEY ) === context.key ) {
					context.dismissed = true;
				}
			} catch ( error ) {
				// Sin almacenamiento: la barra se ve.
			}
		},
	},
} );
