import { __ } from '@wordpress/i18n';
import { InnerBlocks, InspectorControls, MediaPlaceholder, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, SelectControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import MediaTextSplit from '../../components/MediaTextSplit.jsx';
import ImageControl, { mediaToImage } from '../../editor/ImageControl.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';

const ALLOWED_BLOCKS = [ 'core/paragraph', 'core/list', 'core/list-item', 'core/buttons', 'core/button' ];
const TEMPLATE = [ [ 'core/paragraph', { placeholder: __( 'Texto de la sección', 'ebio-core' ) } ] ];

export default function Edit( { attributes, setAttributes } ) {
	const { image } = attributes;
	const isStat = attributes.variant === 'stat';
	const missingAlt = Boolean( image?.id ) && ! image?.alt;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Variante', 'ebio-core' ) }
						value={ attributes.variant }
						options={ [
							{ label: __( 'Por defecto', 'ebio-core' ), value: 'default' },
							{ label: __( 'Dato destacado', 'ebio-core' ), value: 'stat' },
						] }
						onChange={ ( variant ) => setAttributes( { variant } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Imagen', 'ebio-core' ) }>
					<ImageControl label={ __( 'Imagen', 'ebio-core' ) } value={ image } onChange={ ( next ) => setAttributes( { image: next } ) } required />
					<SelectControl
						label={ __( 'Posición de la imagen', 'ebio-core' ) }
						value={ attributes.mediaPosition }
						options={ [
							{ label: __( 'Al inicio', 'ebio-core' ), value: 'start' },
							{ label: __( 'Al final', 'ebio-core' ), value: 'end' },
						] }
						onChange={ ( mediaPosition ) => setAttributes( { mediaPosition } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				{ isStat ? (
					<PanelBody title={ __( 'Cifras', 'ebio-core' ) }>
						<SelectControl
							label={ __( 'Posición de las cifras', 'ebio-core' ) }
							value={ attributes.statsPosition }
							options={ [
								{ label: __( 'Antes del texto', 'ebio-core' ), value: 'before-content' },
								{ label: __( 'Después del texto', 'ebio-core' ), value: 'after-content' },
							] }
							onChange={ ( statsPosition ) => setAttributes( { statsPosition } ) }
							__nextHasNoMarginBottom
							__next40pxDefaultSize
						/>
						<ItemListControl
							items={ attributes.stats }
							onChange={ ( stats ) => setAttributes( { stats } ) }
							min={ 1 }
							max={ 4 }
							emptyItem={ { value: '', label: '' } }
							itemLabel={ __( 'Cifra', 'ebio-core' ) }
						/>
					</PanelBody>
				) : null }
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ missingAlt ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Falta el texto alternativo (obligatorio)', 'ebio-core' ) }
					</Notice>
				) : null }
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<MediaTextSplit attributes={ attributes }>
						<InnerBlocks allowedBlocks={ ALLOWED_BLOCKS } template={ TEMPLATE } templateLock={ false } />
					</MediaTextSplit>
				</EditContext.Provider>
				{ image?.id ? null : (
					<MediaPlaceholder
						allowedTypes={ [ 'image' ] }
						labels={ { title: __( 'Imagen', 'ebio-core' ) } }
						onSelect={ ( media ) => setAttributes( { image: mediaToImage( media ) } ) }
					/>
				) }
			</div>
		</>
	);
}
