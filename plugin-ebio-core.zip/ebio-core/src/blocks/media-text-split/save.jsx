import { InnerBlocks } from '@wordpress/block-editor';
import { SaveMode } from '../../components/lib/save-mode.js';
import MediaTextSplit from '../../components/MediaTextSplit.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<MediaTextSplit attributes={ attributes }>
				<InnerBlocks.Content />
			</MediaTextSplit>
		</SaveMode.Provider>
	);
}
