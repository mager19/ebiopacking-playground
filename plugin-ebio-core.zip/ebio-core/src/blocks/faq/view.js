/**
 * Store `ebio/faq` (docs/blocks/faq.md). El servidor entrega todas las respuestas desplegadas;
 * al hidratar queda abierta solo la primera. Las preguntas se abren de a varias.
 */
import { store, getContext } from '@wordpress/interactivity';

store( 'ebio/faq', {
	actions: {
		toggle() {
			const context = getContext();
			context.open = ! context.open;
		},
	},
	callbacks: {
		hydrate() {
			getContext().hydrated = true;
		},
		collapseInitial() {
			const context = getContext();
			context.open = context.index === 0;
		},
	},
} );
