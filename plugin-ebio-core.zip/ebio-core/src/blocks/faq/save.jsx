import { SaveMode } from '../../components/lib/save-mode.js';
import Faq from '../../components/Faq.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<Faq attributes={ attributes } />
		</SaveMode.Provider>
	);
}
