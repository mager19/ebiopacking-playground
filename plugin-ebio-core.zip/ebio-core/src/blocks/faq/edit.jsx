import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, TextControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import Faq from '../../components/Faq.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import useUid from '../../editor/use-uid.js';

export default function Edit( { clientId, attributes, setAttributes } ) {
	// Regenera el uid si falta o está duplicado (bloque copiado y pegado): los aria-controls no deben chocar.
	useUid( clientId, attributes, setAttributes, 'faq' );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Encabezado', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Encabezado', 'ebio-core' ) }
						value={ attributes.heading }
						onChange={ ( heading ) => setAttributes( { heading } ) }
						help={ __( 'Recomendado: hasta 60 caracteres. La introducción se edita en el lienzo.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Preguntas', 'ebio-core' ) }>
					<ItemListControl
						items={ attributes.items }
						onChange={ ( items ) => setAttributes( { items } ) }
						min={ 1 }
						max={ 8 }
						emptyItem={ { question: '', answer: '' } }
						itemLabel={ __( 'Pregunta', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<TextControl
								label={ __( 'Pregunta', 'ebio-core' ) }
								value={ item.question }
								onChange={ ( question ) => update( { question } ) }
								help={ __( 'Recomendado: hasta 100 caracteres. La respuesta se edita en el lienzo.', 'ebio-core' ) }
								__nextHasNoMarginBottom
								__next40pxDefaultSize
							/>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<Faq attributes={ attributes } />
				</EditContext.Provider>
			</div>
		</>
	);
}
