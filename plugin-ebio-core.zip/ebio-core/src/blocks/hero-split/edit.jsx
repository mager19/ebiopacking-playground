import { __ } from '@wordpress/i18n';
import { InnerBlocks, InspectorControls, MediaPlaceholder, store as blockEditorStore, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, SelectControl, TextControl } from '@wordpress/components';
import { useSelect } from '@wordpress/data';
import HeroSplit from '../../components/HeroSplit.jsx';
import ImageControl, { mediaToImage } from '../../editor/ImageControl.jsx';
import { hasOtherH1 } from './h1.js';

const ALLOWED_BLOCKS = [ 'core/heading', 'core/paragraph', 'core/buttons', 'core/button', 'core/query-title', 'core/term-description' ];
const TEMPLATE = [
	[ 'core/heading', { level: 1, levelOptions: [ 1 ], placeholder: __( 'H1 de la página', 'ebio-core' ) } ],
	[ 'core/paragraph', { placeholder: __( 'Qué hacemos, para quién y en qué escala', 'ebio-core' ) } ],
	[
		'core/buttons',
		{},
		[
			[ 'core/button', { text: __( 'Solicitar cotización', 'ebio-core' ), url: '/cotizar/' } ],
			[ 'core/button', { className: 'is-style-outline', text: __( 'Ver productos', 'ebio-core' ), url: '/productos/' } ],
		],
	],
];

export default function Edit( { attributes, setAttributes, clientId } ) {
	const { image } = attributes;
	const otherH1 = useSelect( ( select ) => hasOtherH1( select( blockEditorStore ).getBlocks(), clientId ), [ clientId ] );
	const missingAlt = Boolean( image?.id ) && ! image?.alt;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Variante', 'ebio-core' ) }
						value={ attributes.variant }
						options={ [
							{ label: __( 'Por defecto (Inicio)', 'ebio-core' ), value: 'default' },
							{ label: __( 'Compacta (Categoría, Sostenibilidad, Nosotros)', 'ebio-core' ), value: 'compact' },
							{ label: __( 'Sector', 'ebio-core' ), value: 'sector' },
						] }
						onChange={ ( variant ) => setAttributes( { variant } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Imagen', 'ebio-core' ) }>
					<ImageControl label={ __( 'Foto protagonista', 'ebio-core' ) } value={ image } onChange={ ( next ) => setAttributes( { image: next } ) } required />
				</PanelBody>
				<PanelBody title={ __( 'Textos', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Sobretítulo', 'ebio-core' ) }
						value={ attributes.eyebrow }
						onChange={ ( eyebrow ) => setAttributes( { eyebrow } ) }
						help={ __( 'Opcional. Recomendado: hasta 50 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Sello', 'ebio-core' ) }
						value={ attributes.sticker }
						onChange={ ( sticker ) => setAttributes( { sticker } ) }
						help={ __( 'Opcional, solo en la variante por defecto. Recomendado: hasta 28 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ otherH1 ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Esta página ya tiene un H1; usa este bloque solo donde el contrato lo permite', 'ebio-core' ) }
					</Notice>
				) : null }
				{ missingAlt ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Falta el texto alternativo (obligatorio)', 'ebio-core' ) }
					</Notice>
				) : null }
				<HeroSplit attributes={ attributes }>
					<InnerBlocks allowedBlocks={ ALLOWED_BLOCKS } template={ TEMPLATE } templateLock={ false } />
				</HeroSplit>
				{ image?.id ? null : (
					<MediaPlaceholder
						allowedTypes={ [ 'image' ] }
						labels={ { title: __( 'Foto protagonista', 'ebio-core' ) } }
						onSelect={ ( media ) => setAttributes( { image: mediaToImage( media ) } ) }
					/>
				) }
			</div>
		</>
	);
}
