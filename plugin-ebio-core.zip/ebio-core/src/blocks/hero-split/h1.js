/**
 * ¿Hay en el contenido del editor un `core/heading` de nivel 1 fuera del bloque `clientId`?
 * Recorre `innerBlocks` y no entra en el propio bloque: su H1 interno es el que debe haber.
 * Solo avisa en el editor; el bloqueo real lo hacen las plantillas y patrones (catalog §2.4, C-B2).
 *
 * @param {Array<{ clientId: string, name: string, attributes?: { level?: number }, innerBlocks?: Array }>} blocks   Bloques del editor.
 * @param {string}                                                                                           clientId clientId del `hero-split`.
 * @return {boolean} `true` si otro bloque aporta un H1.
 */
export function hasOtherH1( blocks, clientId ) {
	if ( ! Array.isArray( blocks ) ) {
		return false;
	}
	return blocks.some( ( block ) => {
		if ( ! block || block.clientId === clientId ) {
			return false;
		}
		if ( block.name === 'core/heading' && block.attributes?.level === 1 ) {
			return true;
		}
		return hasOtherH1( block.innerBlocks, clientId );
	} );
}
