import { InnerBlocks } from '@wordpress/block-editor';
import { SaveMode } from '../../components/lib/save-mode.js';
import HeroSplit from '../../components/HeroSplit.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<HeroSplit attributes={ attributes }>
				<InnerBlocks.Content />
			</HeroSplit>
		</SaveMode.Provider>
	);
}
