/**
 * Vista de `ebio/quote-list`: extiende el store compartido `ebio/quote` (lista editable de /cotizar/).
 */
import '../../stores/quote/list.js';
