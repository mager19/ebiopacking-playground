import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, TextControl, TextareaControl } from '@wordpress/components';
import QuoteList from '../../components/QuoteList.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Editor de `ebio/quote-list`: la lista real la arma cada visitante en su navegador; aquí se ve el
 * armazón con los textos y las categorías de la vista del servidor.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view } = useBlockView( 'ebio/quote-list', attributes, context );
	const field = ( key, label, help ) => (
		<TextControl
			label={ label }
			value={ attributes[ key ] }
			onChange={ ( next ) => setAttributes( { [ key ]: next } ) }
			help={ help }
			__nextHasNoMarginBottom
			__next40pxDefaultSize
		/>
	);

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Textos', 'ebio-core' ) }>
					{ field( 'heading', __( 'Encabezado', 'ebio-core' ), __( 'Recomendado: hasta 30 caracteres.', 'ebio-core' ) ) }
					{ field( 'emptyTitle', __( 'Título del estado vacío', 'ebio-core' ), __( 'Recomendado: hasta 50 caracteres.', 'ebio-core' ) ) }
					<TextareaControl
						label={ __( 'Texto del estado vacío', 'ebio-core' ) }
						value={ attributes.emptyText }
						onChange={ ( emptyText ) => setAttributes( { emptyText } ) }
						help={ __( 'Recomendado: hasta 200 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
					/>
					{ field( 'catalogText', __( 'Botón: ver productos', 'ebio-core' ) ) }
					{ field( 'freeRequestText', __( 'Botón: solicitud libre', 'ebio-core' ) ) }
					{ field( 'addMoreText', __( 'Enlace: agregar más productos', 'ebio-core' ) ) }
					{ field( 'clearText', __( 'Botón: vaciar lista', 'ebio-core' ) ) }
					{ field( 'noscriptText', __( 'Aviso sin JavaScript', 'ebio-core' ), __( 'Recomendado: hasta 140 caracteres.', 'ebio-core' ) ) }
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<Notice status="info" isDismissible={ false }>
					{ __( 'La lista real la arma cada visitante.', 'ebio-core' ) }
				</Notice>
				<QuoteList attributes={ attributes } context={ { 'ebio/view': view ?? {} } } />
			</div>
		</>
	);
}
