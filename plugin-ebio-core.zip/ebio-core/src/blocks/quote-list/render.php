<?php
/**
 * `ebio/quote-list` (docs/blocks/quote-list.md). Gemelo de `src/components/QuoteList.jsx`.
 *
 * La lista la arma el navegador (`ebio/quote`); el servidor entrega los textos, el enlace al catálogo,
 * las categorías y el catálogo de productos publicados (estado del store).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_quote_list_view( $attributes, $block ?? null );
	}
);

ebio_quote_list_init_state();

$ebio_text       = static function ( string $key, string $fallback = '' ) use ( $attributes ): string {
	return is_string( $attributes[ $key ] ?? null ) ? $attributes[ $key ] : $fallback;
};
$ebio_catalog    = is_string( $view['catalogUrl'] ?? null ) ? $view['catalogUrl'] : '/productos/';
$ebio_anchor     = is_string( $view['formAnchor'] ?? null ) ? $view['formAnchor'] : '#ebio-quote-form';
$ebio_categories = is_array( $view['categories'] ?? null ) ? $view['categories'] : array();
$ebio_more       = $ebio_text( 'addMoreText' );
$ebio_level      = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );

// Campo numérico (cantidad o medida). El valor se guarda tal cual y se normaliza al enviar.
$ebio_number = static function ( string $key, string $label, string $label_class, bool $integer ): string {
	return '<label class="' . $label_class . '" data-wp-bind--for="context.item.fieldIds.' . $key . '">' . esc_html( $label ) . '</label>'
		. '<input class="ebio-quote-list__input ebio-quote-list__input--number" type="number" inputmode="' . ( $integer ? 'numeric' : 'decimal' ) . '" min="' . ( $integer ? '1' : '0' ) . '" step="' . ( $integer ? '1' : 'any' ) . '" autocomplete="off" data-field="' . $key . '"'
		. ' data-wp-bind--id="context.item.fieldIds.' . $key . '" data-wp-bind--value="context.item.' . $key . '" data-wp-on--input="actions.updateField">';
};
// Selector de unidad.
$ebio_unit = static function ( string $key, string $label, string $label_class, array $options ): string {
	$html = '<label class="' . $label_class . '" data-wp-bind--for="context.item.fieldIds.' . $key . '">' . esc_html( $label ) . '</label>'
		. '<select class="ebio-quote-list__select" data-field="' . $key . '" data-wp-bind--id="context.item.fieldIds.' . $key . '" data-wp-bind--value="context.item.' . $key . '" data-wp-on--change="actions.updateField">';
	foreach ( $options as $ebio_option ) {
		$html .= '<option value="' . esc_attr( $ebio_option ) . '">' . esc_html( $ebio_option ) . '</option>';
	}
	return $html . '</select>';
};
$ebio_hidden_label = 'ebio-quote-list__label ebio-visually-hidden';
$ebio_sub_label    = 'ebio-quote-list__sublabel';

$ebio_lines   = array();
$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-quote-list', array(), $attributes ) . ' aria-labelledby="ebio-quote-list-heading" data-state="loading" aria-busy="true"'
	. ' data-wp-interactive="ebio/quote" data-wp-init="callbacks.load" data-wp-bind--data-state="state.listStatus" data-wp-bind--aria-busy="state.isLoading">';
$ebio_lines[] = '<div class="ebio-quote-list__header">';
$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-quote-list__heading" id="ebio-quote-list-heading">' . esc_html( $ebio_text( 'heading' ) )
	. '<span class="ebio-quote-list__count" hidden data-wp-bind--hidden="!state.hasItems" data-wp-text="state.countText"></span></h' . $ebio_level . '>';
$ebio_lines[] = '<button type="button" class="ebio-quote-list__clear" hidden data-wp-bind--hidden="!state.hasItems" data-wp-on--click="actions.clear">' . esc_html( $ebio_text( 'clearText' ) ) . '</button>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '<noscript>';
$ebio_lines[] = '<p class="ebio-quote-list__noscript">' . esc_html( $ebio_text( 'noscriptText' ) ) . '</p>';
$ebio_lines[] = '</noscript>';
$ebio_lines[] = '<div class="ebio-quote-list__undo" role="status">';
$ebio_lines[] = '<p class="ebio-quote-list__undo-body" hidden data-wp-bind--hidden="!state.canUndo">';
$ebio_lines[] = '<span class="ebio-quote-list__undo-text" data-wp-text="state.undoText"></span>';
$ebio_lines[] = '<button type="button" class="ebio-quote-list__undo-button" data-wp-on--click="actions.undoRemove">Deshacer</button>';
$ebio_lines[] = '</p>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '<ul class="ebio-quote-list__items" hidden data-wp-bind--hidden="!state.hasItems">';
$ebio_lines[] = '<template data-wp-each--item="state.listItems" data-wp-each-key="context.item.id">';
$ebio_lines[] = '<li class="ebio-quote-list__item">';
$ebio_lines[] = '<span class="ebio-quote-list__media"><img class="ebio-quote-list__image" alt="" data-wp-bind--hidden="!context.item.image" data-wp-bind--src="context.item.image.src" data-wp-bind--width="context.item.image.width" data-wp-bind--height="context.item.image.height" loading="lazy" decoding="async"></span>';
$ebio_lines[] = '<div class="ebio-quote-list__body">';
$ebio_lines[] = '<p class="ebio-quote-list__name">';
$ebio_lines[] = '<a class="ebio-quote-list__name-link" data-wp-bind--href="context.item.url" data-wp-text="context.item.name"></a>';
$ebio_lines[] = '</p>';
$ebio_lines[] = '<p class="ebio-quote-list__category" data-wp-text="context.item.category"></p>';
$ebio_lines[] = '<div class="ebio-quote-list__fields">';
$ebio_lines[] = '<fieldset class="ebio-quote-list__group ebio-quote-list__group--quantity">';
$ebio_lines[] = '<legend class="ebio-quote-list__legend">Cantidad aproximada</legend>';
$ebio_lines[] = '<div class="ebio-quote-list__inputs">';
$ebio_lines[] = $ebio_number( 'quantity', 'Cantidad', $ebio_hidden_label, true );
$ebio_lines[] = $ebio_unit( 'quantityUnit', 'Unidad de la cantidad', $ebio_hidden_label, array( 'unidades', 'pallets' ) );
$ebio_lines[] = '</div>';
$ebio_lines[] = '</fieldset>';
$ebio_lines[] = '<fieldset class="ebio-quote-list__group ebio-quote-list__group--dimensions">';
$ebio_lines[] = '<legend class="ebio-quote-list__legend">Medidas aproximadas</legend>';
$ebio_lines[] = '<div class="ebio-quote-list__inputs">';
foreach ( array( 'length' => 'Largo', 'width' => 'Ancho', 'height' => 'Alto' ) as $ebio_key => $ebio_label ) {
	$ebio_lines[] = '<div class="ebio-quote-list__dimension">' . $ebio_number( $ebio_key, $ebio_label, $ebio_sub_label, false ) . '</div>';
}
$ebio_lines[] = '<div class="ebio-quote-list__dimension ebio-quote-list__dimension--unit">' . $ebio_unit( 'dimensionUnit', 'Unidad', $ebio_sub_label, array( 'cm', 'mm' ) ) . '</div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</fieldset>';
$ebio_lines[] = '<div class="ebio-quote-list__note">';
$ebio_lines[] = '<button type="button" class="ebio-quote-list__note-toggle" data-wp-bind--hidden="context.item.notesOpen" data-wp-on--click="actions.openNote"><span class="ebio-icon ebio-icon--plus" aria-hidden="true"></span>Agregar nota</button>';
$ebio_lines[] = '<div class="ebio-quote-list__note-field" hidden data-wp-bind--hidden="!context.item.notesOpen">';
$ebio_lines[] = '<label class="ebio-quote-list__label" data-wp-bind--for="context.item.fieldIds.notes">Notas (opcional)</label>';
$ebio_lines[] = '<textarea class="ebio-quote-list__textarea" maxlength="500" rows="2" placeholder="Uso, impresión, peso a empacar…" data-field="notes" data-wp-bind--id="context.item.fieldIds.notes" data-wp-bind--value="context.item.notes" data-wp-on--input="actions.updateField"></textarea>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '<button type="button" class="ebio-quote-list__remove" data-wp-on--click="actions.remove">Quitar<span class="ebio-visually-hidden" data-wp-text="context.item.removeLabel"></span></button>';
$ebio_lines[] = '</li>';
$ebio_lines[] = '</template>';
$ebio_lines[] = '</ul>';
if ( '' !== $ebio_more ) {
	$ebio_lines[] = '<p class="ebio-quote-list__more" hidden data-wp-bind--hidden="!state.hasItems">';
	$ebio_lines[] = '<a class="ebio-quote-list__more-link ebio-button ebio-button--secondary ebio-button--small" href="' . esc_url( $ebio_catalog ) . '">' . esc_html( $ebio_more ) . '</a>';
	$ebio_lines[] = '</p>';
}
$ebio_lines[] = '<div class="ebio-quote-list__empty" hidden data-wp-bind--hidden="!state.isEmpty">';
$ebio_lines[] = '<h3 class="ebio-quote-list__empty-title">' . esc_html( $ebio_text( 'emptyTitle' ) ) . '</h3>';
$ebio_lines[] = '<p class="ebio-quote-list__empty-text">' . esc_html( $ebio_text( 'emptyText' ) ) . '</p>';
$ebio_lines[] = '<p class="ebio-quote-list__empty-actions">';
$ebio_lines[] = '<a class="ebio-quote-list__empty-catalog ebio-button ebio-button--primary" href="' . esc_url( $ebio_catalog ) . '">' . esc_html( $ebio_text( 'catalogText' ) ) . '</a>';
$ebio_lines[] = '<a class="ebio-quote-list__empty-free ebio-button ebio-button--secondary" href="' . esc_attr( $ebio_anchor ) . '">' . esc_html( $ebio_text( 'freeRequestText' ) ) . '</a>';
$ebio_lines[] = '</p>';
if ( $ebio_categories ) {
	$ebio_lines[] = '<ul class="ebio-quote-list__categories">';
	foreach ( $ebio_categories as $ebio_category ) {
		if ( ! is_array( $ebio_category ) ) {
			continue;
		}
		$ebio_lines[] = '<li class="ebio-quote-list__category-item">';
		$ebio_lines[] = '<a class="ebio-quote-list__category-link" href="' . esc_url( (string) ( $ebio_category['url'] ?? '' ) ) . '">' . esc_html( (string) ( $ebio_category['label'] ?? '' ) ) . '</a>';
		$ebio_lines[] = '</li>';
	}
	$ebio_lines[] = '</ul>';
}
$ebio_lines[] = '</div>';
$ebio_lines[] = '</section>';

echo implode( '', $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
