import { InnerBlocks } from '@wordpress/block-editor';

/**
 * Dinámico con InnerBlocks: solo se guardan los bloques internos; `render.php` pinta el marco y recibe
 * los internos como `$content`.
 */
export default function save() {
	return <InnerBlocks.Content />;
}
