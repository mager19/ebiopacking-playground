import { __ } from '@wordpress/i18n';
import { InnerBlocks, InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, SelectControl, TextControl, ToggleControl } from '@wordpress/components';
import CtaBanner from '../../components/CtaBanner.jsx';
import useBlockView from '../../editor/use-block-view.js';

const ALLOWED_BLOCKS = [ 'core/heading', 'core/paragraph', 'core/buttons', 'core/button' ];
const TEMPLATE = [
	[ 'core/heading', { level: 2, levelOptions: [ 2 ], placeholder: __( '¿No encuentras tu empaque? Lo fabricamos a tu medida.', 'ebio-core' ) } ],
	[ 'core/paragraph', { placeholder: __( 'Qué datos tener a mano y qué pasa después', 'ebio-core' ) } ],
	[ 'core/buttons', {}, [ [ 'core/button', { text: __( 'Solicitar cotización', 'ebio-core' ), url: '/cotizar/' } ] ] ],
];

/**
 * Editor de `ebio/cta-banner`: título, párrafo y botón son bloques internos; el enlace de WhatsApp
 * viene de la vista del servidor (el número se edita en Ajustes › eBiopacking).
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view } = useBlockView( 'ebio/cta-banner', attributes, context );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'WhatsApp', 'ebio-core' ) }>
					<ToggleControl
						label={ __( 'Mostrar enlace de WhatsApp', 'ebio-core' ) }
						checked={ attributes.showWhatsapp }
						onChange={ ( showWhatsapp ) => setAttributes( { showWhatsapp } ) }
						__nextHasNoMarginBottom
					/>
					{ attributes.showWhatsapp ? (
						<>
							<TextControl
								label={ __( 'Texto del enlace', 'ebio-core' ) }
								value={ attributes.whatsappText }
								onChange={ ( whatsappText ) => setAttributes( { whatsappText } ) }
								help={ __( 'Recomendado: hasta 30 caracteres.', 'ebio-core' ) }
								__nextHasNoMarginBottom
								__next40pxDefaultSize
							/>
							<SelectControl
								label={ __( 'Mensaje precargado', 'ebio-core' ) }
								value={ attributes.whatsappMessage }
								options={ [
									{ label: __( 'General', 'ebio-core' ), value: 'general' },
									{ label: __( 'Del producto (en la ficha)', 'ebio-core' ), value: 'product' },
								] }
								onChange={ ( whatsappMessage ) => setAttributes( { whatsappMessage } ) }
								__nextHasNoMarginBottom
								__next40pxDefaultSize
							/>
						</>
					) : null }
					<Notice status="info" isDismissible={ false }>
						{ __( 'El número se edita en Ajustes › eBiopacking.', 'ebio-core' ) }
					</Notice>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<CtaBanner attributes={ attributes } context={ { 'ebio/view': view ?? { whatsappUrl: '' } } }>
					<InnerBlocks allowedBlocks={ ALLOWED_BLOCKS } template={ TEMPLATE } templateLock={ false } />
				</CtaBanner>
			</div>
		</>
	);
}
