<?php
/**
 * `ebio/cta-banner` (docs/blocks/cta-banner.md). Gemelo de `src/components/CtaBanner.jsx`.
 *
 * @var array         $attributes Atributos del bloque.
 * @var string        $content    Bloques internos ya renderizados.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_cta_banner_view( $attributes, $block ?? null );
	}
);

$ebio_url  = (string) ( $view['whatsappUrl'] ?? '' );
$ebio_text = is_string( $attributes['whatsappText'] ?? null ) && '' !== trim( $attributes['whatsappText'] ) ? $attributes['whatsappText'] : 'Escribir por WhatsApp';

$ebio_lines   = array();
$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-cta-banner', array(), $attributes ) . '>';
$ebio_lines[] = '<div class="ebio-cta-banner__inner">';
$ebio_lines[] = '<div class="ebio-cta-banner__content">' . ( $content ?? '' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- bloques internos ya renderizados por WordPress.
if ( '' !== $ebio_url ) {
	$ebio_lines[] = '<a class="ebio-cta-banner__whatsapp ebio-button ebio-button--secondary" href="' . esc_url( $ebio_url ) . '" target="_blank" rel="noopener">'
		. '<span class="ebio-icon ebio-icon--whatsapp" aria-hidden="true"></span>'
		. esc_html( $ebio_text )
		. '<span class="ebio-visually-hidden"> (abre WhatsApp en una pestaña nueva)</span></a>';
}
$ebio_lines[] = '</div>';
$ebio_lines[] = '</section>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
