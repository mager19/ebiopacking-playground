<?php
/**
 * `ebio/product-summary` (docs/blocks/product-summary.md). Gemelo de `src/components/ProductSummary.jsx`.
 *
 * Fuera de un producto no emite nada. Cada elemento de bloque va en su línea (catalog §2.9).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_product_summary_view( $attributes, $block ?? null );
	}
);

$ebio_title = is_string( $view['title'] ?? null ) ? $view['title'] : '';
if ( '' === $ebio_title ) {
	return;
}

$ebio_tags     = is_array( $view['tags'] ?? null ) ? array_values( $view['tags'] ) : array();
$ebio_category = is_array( $view['category'] ?? null ) ? $view['category'] : null;
$ebio_desc     = is_string( $view['description'] ?? null ) ? $view['description'] : '';
$ebio_facts    = array();
foreach (
	array(
		'Formatos'      => $attributes['formats'] ?? '',
		'Pedido mínimo' => $view['minOrder'] ?? '',
		'Impresión'     => $attributes['printing'] ?? '',
	) as $ebio_label => $ebio_value
) {
	if ( is_string( $ebio_value ) && '' !== $ebio_value ) {
		$ebio_facts[ $ebio_label ] = $ebio_value;
	}
}

$ebio_lines   = array();
$ebio_lines[] = '<div ' . ebio_root_attributes( 'ebio-product-summary', array(), $attributes ) . '>';
if ( $ebio_tags ) {
	$ebio_lines[] = '<ul class="ebio-product-summary__tags" aria-label="Características">';
	foreach ( $ebio_tags as $ebio_tag ) {
		$ebio_lines[] = '<li class="ebio-product-summary__tag" data-format="' . esc_attr( (string) ( $ebio_tag['format'] ?? '' ) ) . '">' . esc_html( (string) ( $ebio_tag['label'] ?? '' ) ) . '</li>';
	}
	$ebio_lines[] = '</ul>';
}
if ( null !== $ebio_category && ! empty( $ebio_category['name'] ) ) {
	$ebio_lines[] = '<p class="ebio-product-summary__category"><a class="ebio-product-summary__category-link" href="' . esc_url( (string) ( $ebio_category['url'] ?? '' ) ) . '">' . esc_html( (string) $ebio_category['name'] ) . '</a></p>';
}
$ebio_lines[] = '<h1 class="ebio-product-summary__title">' . esc_html( $ebio_title ) . '</h1>';
if ( '' !== $ebio_desc ) {
	$ebio_lines[] = '<p class="ebio-product-summary__description">' . esc_html( $ebio_desc ) . '</p>';
}
if ( $ebio_facts ) {
	$ebio_lines[] = '<dl class="ebio-product-summary__facts">';
	foreach ( $ebio_facts as $ebio_label => $ebio_value ) {
		$ebio_lines[] = '<div class="ebio-product-summary__fact">';
		$ebio_lines[] = '<dt class="ebio-product-summary__fact-label">' . esc_html( $ebio_label ) . '</dt>';
		$ebio_lines[] = '<dd class="ebio-product-summary__fact-value">' . esc_html( $ebio_value ) . '</dd>';
		$ebio_lines[] = '</div>';
	}
	$ebio_lines[] = '</dl>';
}
$ebio_lines[] = '</div>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
