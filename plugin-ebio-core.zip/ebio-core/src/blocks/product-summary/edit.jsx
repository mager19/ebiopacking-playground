import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, TextControl } from '@wordpress/components';
import ProductSummary from '../../components/ProductSummary.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Editor de `ebio/product-summary`: título, extracto, etiquetas y pedido mínimo salen del producto
 * (vista del servidor); formatos e impresión se editan en el panel lateral.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view, isLoading } = useBlockView( 'ebio/product-summary', attributes, context );
	const empty = ! isLoading && ! view?.title;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Datos clave', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Formatos', 'ebio-core' ) }
						value={ attributes.formats }
						onChange={ ( formats ) => setAttributes( { formats } ) }
						help={ __( 'Recomendado: hasta 120 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Impresión', 'ebio-core' ) }
						value={ attributes.printing }
						onChange={ ( printing ) => setAttributes( { printing } ) }
						help={ __( 'Recomendado: hasta 80 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<Notice status="info" isDismissible={ false }>
						{ __( 'Pedido mínimo: campo del producto (panel "Datos del producto").', 'ebio-core' ) }
					</Notice>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<Notice status="info" isDismissible={ false }>
					{ __( 'El título y el extracto se editan en el panel del documento.', 'ebio-core' ) }
				</Notice>
				{ empty ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Fuera de un producto el bloque no se muestra en el sitio.', 'ebio-core' ) }
					</Notice>
				) : (
					<ProductSummary attributes={ attributes } context={ { 'ebio/view': view ?? {} } } />
				) }
			</div>
		</>
	);
}
