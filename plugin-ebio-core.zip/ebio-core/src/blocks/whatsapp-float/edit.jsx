import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, TextControl } from '@wordpress/components';
import WhatsappFloat from '../../components/WhatsappFloat.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Editor de `ebio/whatsapp-float`: la URL y la elevación vienen de la vista del servidor; el texto
 * accesible se edita en el panel lateral. Sin número configurado el bloque no pinta nada, así que
 * se muestra un aviso.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view, isLoading } = useBlockView( 'ebio/whatsapp-float', attributes, context );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Botón', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Texto accesible', 'ebio-core' ) }
						value={ attributes.label }
						onChange={ ( label ) => setAttributes( { label } ) }
						help={ __( 'Recomendado: hasta 30 caracteres. Se lee con "(abre WhatsApp en una pestaña nueva)".', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<Notice status="info" isDismissible={ false }>
						{ __( 'El número se edita en Ajustes › eBiopacking.', 'ebio-core' ) }
					</Notice>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ ! isLoading && ! view?.url ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Sin número de WhatsApp configurado: el botón no se muestra.', 'ebio-core' ) }
					</Notice>
				) : (
					<WhatsappFloat attributes={ attributes } context={ { 'ebio/view': view ?? {} } } />
				) }
			</div>
		</>
	);
}
