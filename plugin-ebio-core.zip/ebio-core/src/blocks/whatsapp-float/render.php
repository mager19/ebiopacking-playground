<?php
/**
 * `ebio/whatsapp-float` (docs/blocks/whatsapp-float.md). Gemelo de `src/components/WhatsappFloat.jsx`.
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_whatsapp_float_view( $attributes, $block ?? null );
	}
);

// Sin número configurado el bloque no emite nada.
if ( empty( $view['url'] ) ) {
	return;
}

$ebio_label = is_string( $attributes['label'] ?? null ) && '' !== trim( $attributes['label'] ) ? $attributes['label'] : 'Escribir por WhatsApp';

echo '<a ' . ebio_root_attributes( 'ebio-whatsapp-float', array( true === ( $view['raised'] ?? false ) ? 'raised' : '' ), $attributes )
	. ' href="' . esc_url( (string) $view['url'] ) . '" target="_blank" rel="noopener">'
	. '<span class="ebio-icon ebio-icon--whatsapp" aria-hidden="true"></span>'
	. '<span class="ebio-visually-hidden">' . esc_html( $ebio_label . ' (abre WhatsApp en una pestaña nueva)' ) . '</span></a>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
