import { SaveMode } from '../../components/lib/save-mode.js';
import FeaturePillars from '../../components/FeaturePillars.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<FeaturePillars attributes={ attributes } />
		</SaveMode.Provider>
	);
}
