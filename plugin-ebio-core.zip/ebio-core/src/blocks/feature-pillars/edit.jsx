import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, SelectControl, TextControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import FeaturePillars from '../../components/FeaturePillars.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import { ICON_SLUGS } from '../../editor/icons.js';

const ICON_OPTIONS = [ { label: __( 'Sin ícono', 'ebio-core' ), value: '' }, ...ICON_SLUGS.map( ( slug ) => ( { label: slug, value: slug } ) ) ];

export default function Edit( { attributes, setAttributes } ) {
	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Variante', 'ebio-core' ) }
						value={ attributes.variant }
						options={ [
							{ label: __( 'Por defecto', 'ebio-core' ), value: 'default' },
							{ label: __( 'Valores', 'ebio-core' ), value: 'values' },
						] }
						onChange={ ( variant ) => setAttributes( { variant } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Encabezado', 'ebio-core' ) }
						value={ attributes.heading }
						onChange={ ( heading ) => setAttributes( { heading } ) }
						help={ __( 'Recomendado: hasta 50 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Pilares', 'ebio-core' ) }>
					<ItemListControl
						items={ attributes.items }
						onChange={ ( items ) => setAttributes( { items } ) }
						min={ 3 }
						max={ 4 }
						emptyItem={ { icon: '', title: '', text: '' } }
						itemLabel={ __( 'Pilar', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<>
								<SelectControl
									label={ __( 'Ícono', 'ebio-core' ) }
									value={ item.icon }
									options={ ICON_OPTIONS }
									onChange={ ( icon ) => update( { icon } ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
								<TextControl
									label={ __( 'Título', 'ebio-core' ) }
									value={ item.title }
									onChange={ ( title ) => update( { title } ) }
									help={ __( 'Recomendado: hasta 35 caracteres.', 'ebio-core' ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
							</>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<FeaturePillars attributes={ attributes } />
				</EditContext.Provider>
			</div>
		</>
	);
}
