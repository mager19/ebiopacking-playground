import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, TextControl } from '@wordpress/components';
import Breadcrumbs from '../../components/Breadcrumbs.jsx';
import useBlockView from '../../editor/use-block-view.js';

// En el editor la ruta real depende de la plantilla que se renderiza; se muestra una de ejemplo (Ficha).
const SAMPLE_VIEW = {
	items: [
		{ label: 'Inicio', url: '/' },
		{ label: 'Productos', url: '/productos/' },
		{ label: 'Empaques industriales', url: '/productos/empaques-industriales/' },
	],
	current: 'Caja telescópica',
};

/**
 * Editor de `ebio/breadcrumbs`: panel "Textos" (etiqueta de inicio y nombre accesible). Si el servidor no
 * devuelve ruta (la petición del editor no es una página del sitio), se pinta la ruta de ejemplo.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view } = useBlockView( 'ebio/breadcrumbs', attributes, context );
	const hasTrail = Boolean( view?.current );
	const shown = hasTrail
		? view
		: { ...SAMPLE_VIEW, items: SAMPLE_VIEW.items.map( ( item, i ) => ( i === 0 ? { ...item, label: attributes.homeLabel || item.label } : item ) ) };

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Textos', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Etiqueta de inicio', 'ebio-core' ) }
						value={ attributes.homeLabel }
						onChange={ ( homeLabel ) => setAttributes( { homeLabel } ) }
						help={ __( 'Recomendado: hasta 15 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Nombre accesible', 'ebio-core' ) }
						value={ attributes.ariaLabel }
						onChange={ ( ariaLabel ) => setAttributes( { ariaLabel } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<Breadcrumbs attributes={ attributes } context={ { 'ebio/view': shown } } />
			</div>
		</>
	);
}
