<?php
/**
 * `ebio/breadcrumbs` (docs/blocks/breadcrumbs.md). Gemelo de `src/components/Breadcrumbs.jsx`.
 * Sin `current` (solo "Inicio") no emite nada.
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_breadcrumbs_view( $attributes, $block ?? null );
	}
);

$ebio_current = is_string( $view['current'] ?? null ) ? $view['current'] : '';
if ( '' === $ebio_current ) {
	return;
}

$ebio_items = array();
foreach ( is_array( $view['items'] ?? null ) ? $view['items'] : array() as $ebio_item ) {
	if ( ! is_array( $ebio_item ) || empty( $ebio_item['label'] ) || empty( $ebio_item['url'] ) ) {
		continue;
	}
	$ebio_items[] = '<li class="ebio-breadcrumbs__item"><a class="ebio-breadcrumbs__link" href="' . esc_url( (string) $ebio_item['url'] ) . '">' . esc_html( (string) $ebio_item['label'] ) . '</a></li>';
}
$ebio_items[] = '<li class="ebio-breadcrumbs__item"><span class="ebio-breadcrumbs__current" aria-current="page">' . esc_html( $ebio_current ) . '</span></li>';

$ebio_lines   = array();
$ebio_lines[] = '<nav ' . ebio_root_attributes( 'ebio-breadcrumbs', array(), $attributes ) . ' aria-label="' . esc_attr( (string) ( $attributes['ariaLabel'] ?? '' ) ) . '">';
$ebio_lines[] = '<div class="ebio-breadcrumbs__inner">';
$ebio_lines[] = '<ol class="ebio-breadcrumbs__list">' . implode( '', $ebio_items ) . '</ol>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</nav>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
