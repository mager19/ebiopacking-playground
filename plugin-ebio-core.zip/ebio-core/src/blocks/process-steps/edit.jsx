import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, SelectControl, TextControl, ToggleControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import ProcessSteps from '../../components/ProcessSteps.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';

export default function Edit( { attributes, setAttributes } ) {
	const isTimeline = attributes.variant === 'timeline';

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Variante', 'ebio-core' ) }
						value={ attributes.variant }
						options={ [
							{ label: __( 'Pasos numerados', 'ebio-core' ), value: 'default' },
							{ label: __( 'Línea de tiempo', 'ebio-core' ), value: 'timeline' },
						] }
						onChange={ ( variant ) => setAttributes( { variant } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Encabezado', 'ebio-core' ) }
						value={ attributes.heading }
						onChange={ ( heading ) => setAttributes( { heading } ) }
						help={ __( 'Recomendado: hasta 50 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Introducción', 'ebio-core' ) }
						value={ attributes.intro }
						onChange={ ( intro ) => setAttributes( { intro } ) }
						help={ __( 'Opcional. Recomendado: hasta 140 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Plazos', 'ebio-core' ) } initialOpen={ false }>
					<ToggleControl
						label={ __( 'Mostrar plazo en cada paso', 'ebio-core' ) }
						checked={ attributes.showWhen }
						onChange={ ( showWhen ) => setAttributes( { showWhen } ) }
						help={ isTimeline ? __( 'La línea de tiempo no muestra plazos.', 'ebio-core' ) : undefined }
						__nextHasNoMarginBottom
					/>
				</PanelBody>
				<PanelBody title={ __( 'Llamado', 'ebio-core' ) } initialOpen={ false }>
					<TextControl
						label={ __( 'Texto del botón', 'ebio-core' ) }
						value={ attributes.ctaText }
						onChange={ ( ctaText ) => setAttributes( { ctaText } ) }
						help={ __( 'Opcional. Recomendado: hasta 25 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Enlace del botón', 'ebio-core' ) }
						value={ attributes.ctaUrl }
						onChange={ ( ctaUrl ) => setAttributes( { ctaUrl } ) }
						help={ attributes.ctaText && ! attributes.ctaUrl ? __( 'Falta el enlace del botón.', 'ebio-core' ) : undefined }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Pasos', 'ebio-core' ) }>
					<ItemListControl
						items={ attributes.items }
						onChange={ ( items ) => setAttributes( { items } ) }
						min={ 3 }
						max={ 6 }
						emptyItem={ { marker: '', when: '', title: '', text: '' } }
						itemLabel={ __( 'Paso', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<>
								{ isTimeline ? (
									<TextControl
										label={ __( 'Marcador (año)', 'ebio-core' ) }
										value={ item.marker }
										onChange={ ( marker ) => update( { marker } ) }
										help={ __( 'Recomendado: hasta 10 caracteres.', 'ebio-core' ) }
										__nextHasNoMarginBottom
										__next40pxDefaultSize
									/>
								) : (
									<TextControl
										label={ __( 'Plazo', 'ebio-core' ) }
										value={ item.when }
										onChange={ ( when ) => update( { when } ) }
										help={ __( 'Recomendado: hasta 20 caracteres.', 'ebio-core' ) }
										__nextHasNoMarginBottom
										__next40pxDefaultSize
									/>
								) }
								<TextControl
									label={ __( 'Título', 'ebio-core' ) }
									value={ item.title }
									onChange={ ( title ) => update( { title } ) }
									help={ __( 'Recomendado: hasta 40 caracteres.', 'ebio-core' ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
								
							</>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<ProcessSteps attributes={ attributes } />
				</EditContext.Provider>
			</div>
		</>
	);
}
