import { SaveMode } from '../../components/lib/save-mode.js';
import ProcessSteps from '../../components/ProcessSteps.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<ProcessSteps attributes={ attributes } />
		</SaveMode.Provider>
	);
}
