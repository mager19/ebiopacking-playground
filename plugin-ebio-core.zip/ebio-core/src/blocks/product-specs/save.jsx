import { SaveMode } from '../../components/lib/save-mode.js';
import ProductSpecs from '../../components/ProductSpecs.jsx';

export default function save( { attributes } ) {
	return (
		<SaveMode.Provider value={ true }>
			<ProductSpecs attributes={ attributes } />
		</SaveMode.Provider>
	);
}
