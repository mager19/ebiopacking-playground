import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, TextControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import ProductSpecs from '../../components/ProductSpecs.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import useUid from '../../editor/use-uid.js';

export default function Edit( { clientId, attributes, setAttributes } ) {
	// Regenera el uid si falta o está duplicado (bloque copiado y pegado).
	useUid( clientId, attributes, setAttributes, 'specs' );

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Encabezado', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Encabezado', 'ebio-core' ) }
						value={ attributes.heading }
						onChange={ ( heading ) => setAttributes( { heading } ) }
						help={ __( 'Recomendado: hasta 40 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl
						label={ __( 'Introducción', 'ebio-core' ) }
						value={ attributes.intro }
						onChange={ ( intro ) => setAttributes( { intro } ) }
						help={ __( 'Opcional. Recomendado: hasta 140 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Filas', 'ebio-core' ) }>
					<ItemListControl
						items={ attributes.rows }
						onChange={ ( rows ) => setAttributes( { rows } ) }
						min={ 3 }
						max={ 15 }
						emptyItem={ { label: '', value: '' } }
						itemLabel={ __( 'Fila', 'ebio-core' ) }
						renderItem={ ( row, update ) => (
							<>
								<TextControl
									label={ __( 'Etiqueta', 'ebio-core' ) }
									value={ row.label }
									onChange={ ( label ) => update( { label } ) }
									help={ __( 'Recomendado: hasta 30 caracteres.', 'ebio-core' ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
							</>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<ProductSpecs attributes={ attributes } />
				</EditContext.Provider>
			</div>
		</>
	);
}
