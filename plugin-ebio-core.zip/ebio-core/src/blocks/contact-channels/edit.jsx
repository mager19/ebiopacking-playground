import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, SelectControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import ContactChannels from '../../components/ContactChannels.jsx';
import ImageControl from '../../editor/ImageControl.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Editor de `ebio/contact-channels`: los datos de contacto vienen de la vista del servidor (Ajustes ›
 * eBiopacking); el título se edita en el lienzo y la variante y el mapa, en el panel lateral.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view } = useBlockView( 'ebio/contact-channels', attributes, context );
	const { mapImage } = attributes;
	const isDefault = attributes.variant !== 'compact';
	const missingAlt = isDefault && Boolean( mapImage?.id ) && ! mapImage?.alt;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Variante', 'ebio-core' ) }
						value={ attributes.variant }
						options={ [
							{ label: __( 'Completa (5 canales y mapa)', 'ebio-core' ), value: 'default' },
							{ label: __( 'Compacta (celulares, WhatsApp y correo)', 'ebio-core' ), value: 'compact' },
						] }
						onChange={ ( variant ) => setAttributes( { variant } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<Notice status="info" isDismissible={ false }>
						{ __( 'Teléfonos, WhatsApp, correo, dirección y horarios se editan en Ajustes › eBiopacking.', 'ebio-core' ) }
					</Notice>
				</PanelBody>
				{ isDefault ? (
					<PanelBody title={ __( 'Mapa', 'ebio-core' ) }>
						<ImageControl label={ __( 'Imagen del mapa', 'ebio-core' ) } value={ mapImage } onChange={ ( next ) => setAttributes( { mapImage: next } ) } required />
					</PanelBody>
				) : null }
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ missingAlt ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Falta el texto alternativo (obligatorio)', 'ebio-core' ) }
					</Notice>
				) : null }
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<ContactChannels attributes={ attributes } context={ { 'ebio/view': view ?? {} } } />
				</EditContext.Provider>
			</div>
		</>
	);
}
