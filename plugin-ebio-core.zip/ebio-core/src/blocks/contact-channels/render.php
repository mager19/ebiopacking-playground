<?php
/**
 * `ebio/contact-channels` (docs/blocks/contact-channels.md). Gemelo de `src/components/ContactChannels.jsx`.
 *
 * Los hermanos en línea (enlaces, `span`) van pegados, igual que en el componente (catalog §2.9).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_contact_channels_view( $attributes, $block ?? null );
	}
);

$ebio_variant = 'compact' === ( $attributes['variant'] ?? 'default' ) ? 'compact' : 'default';
$ebio_default = 'default' === $ebio_variant;
$ebio_level   = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );
$ebio_heading = is_string( $attributes['heading'] ?? null ) ? $attributes['heading'] : '';
$ebio_hidden  = static function ( string $text ): string {
	return '<span class="ebio-visually-hidden">' . esc_html( $text ) . '</span>';
};
$ebio_link    = static function ( string $href, string $text, bool $external, string $hidden = '' ) use ( $ebio_hidden ): string {
	return '<a class="ebio-contact-channels__link" href="' . esc_url( $href ) . '"' . ( $external ? ' target="_blank" rel="noopener"' : '' ) . '>'
		. esc_html( $text ) . ( '' !== $hidden ? $ebio_hidden( $hidden ) : '' ) . '</a>';
};
$ebio_value   = static function ( string $inner, string $modifier = '' ): string {
	return '<li class="ebio-contact-channels__value' . ( '' !== $modifier ? ' ebio-contact-channels__value--' . $modifier : '' ) . '">' . $inner . '</li>';
};
$ebio_channel = static function ( string $id, string $icon, string $name, array $values ): string {
	return '<li class="ebio-contact-channels__channel ebio-contact-channels__channel--' . $id . '">'
		. '<span class="ebio-icon ebio-icon--' . $icon . ' ebio-contact-channels__icon" aria-hidden="true"></span>'
		. '<p class="ebio-contact-channels__name">' . esc_html( $name ) . '</p>'
		. '<ul class="ebio-contact-channels__values">' . implode( '', $values ) . '</ul></li>';
};

$ebio_phones   = array();
foreach ( is_array( $view['phones'] ?? null ) ? $view['phones'] : array() as $ebio_phone ) {
	if ( ! empty( $ebio_phone['label'] ) && ! empty( $ebio_phone['href'] ) ) {
		$ebio_phones[] = $ebio_value( $ebio_link( (string) $ebio_phone['href'], (string) $ebio_phone['label'], false ) );
	}
}
$ebio_whatsapp = is_array( $view['whatsapp'] ?? null ) ? $view['whatsapp'] : null;
$ebio_email    = is_array( $view['email'] ?? null ) ? $view['email'] : null;
$ebio_address  = (string) ( $view['address'] ?? '' );
$ebio_maps_url = (string) ( $view['mapsUrl'] ?? '' );
$ebio_hours    = (string) ( $view['hours'] ?? '' );
$ebio_map      = $ebio_default && is_array( $view['map'] ?? null ) ? $view['map'] : null;

$ebio_channels = array();
if ( $ebio_phones ) {
	$ebio_channels[] = $ebio_channel( 'phone', 'phone', 'Celulares', $ebio_phones );
}
if ( null !== $ebio_whatsapp && ! empty( $ebio_whatsapp['url'] ) ) {
	$ebio_values = array( $ebio_value( $ebio_link( (string) $ebio_whatsapp['url'], 'Escribir por WhatsApp', true, ' (abre WhatsApp en una pestaña nueva)' ) ) );
	if ( ! empty( $ebio_whatsapp['note'] ) ) {
		$ebio_values[] = $ebio_value( esc_html( (string) $ebio_whatsapp['note'] ), 'note' );
	}
	$ebio_channels[] = $ebio_channel( 'whatsapp', 'whatsapp', 'WhatsApp comercial', $ebio_values );
}
if ( null !== $ebio_email && ! empty( $ebio_email['label'] ) ) {
	$ebio_channels[] = $ebio_channel( 'email', 'mail', 'Correo', array( $ebio_value( $ebio_link( (string) ( $ebio_email['href'] ?? '' ), (string) $ebio_email['label'], false ) ) ) );
}
if ( $ebio_default && ( '' !== $ebio_address || '' !== $ebio_maps_url ) ) {
	$ebio_values = array();
	if ( '' !== $ebio_address ) {
		$ebio_values[] = $ebio_value( esc_html( $ebio_address ) );
	}
	if ( '' !== $ebio_maps_url ) {
		$ebio_values[] = $ebio_value( $ebio_link( $ebio_maps_url, 'Cómo llegar', true, ' (abre Google Maps en una pestaña nueva)' ) );
	}
	$ebio_channels[] = $ebio_channel( 'address', 'pin', 'Planta', $ebio_values );
}
if ( $ebio_default && '' !== $ebio_hours ) {
	$ebio_channels[] = $ebio_channel( 'hours', 'clock', 'Horarios', array( $ebio_value( esc_html( $ebio_hours ) ) ) );
}

$ebio_lines   = array();
$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-contact-channels', array( 'default' !== $ebio_variant ? $ebio_variant : '' ), $attributes ) . '>';
$ebio_lines[] = '<div class="ebio-contact-channels__inner">';
if ( '' !== $ebio_heading ) {
	$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-contact-channels__heading">' . wp_kses_post( $ebio_heading ) . '</h' . $ebio_level . '>';
}
$ebio_lines[] = '<ul class="ebio-contact-channels__list">' . implode( '', $ebio_channels ) . '</ul>';
if ( null !== $ebio_map && '' !== $ebio_maps_url ) {
	$ebio_lines[] = '<a class="ebio-contact-channels__map" href="' . esc_url( $ebio_maps_url ) . '" target="_blank" rel="noopener">'
		. ebio_dynamic_image_html( 'ebio-contact-channels__map-image', $ebio_map )
		. $ebio_hidden( ' (abre Google Maps en una pestaña nueva)' ) . '</a>';
}
$ebio_lines[] = '</div>';
$ebio_lines[] = '</section>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
