<?php
/**
 * `ebio/site-footer` (docs/blocks/site-footer.md). Gemelo de `src/components/SiteFooter.jsx`.
 *
 * Los hermanos en línea (enlaces, `span`, texto) van pegados, igual que en el componente (catalog §2.9).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_site_footer_view( $attributes, $block ?? null );
	}
);

$ebio_text = static function ( string $key, string $fallback = '' ) use ( $attributes ): string {
	return is_string( $attributes[ $key ] ?? null ) ? $attributes[ $key ] : $fallback;
};
$ebio_logo = is_array( $view['logo'] ?? null ) ? $view['logo'] : null;
$ebio_year = (string) ( $view['year'] ?? '' );

$ebio_phones = array();
foreach ( is_array( $view['phones'] ?? null ) ? $view['phones'] : array() as $ebio_phone ) {
	if ( ! empty( $ebio_phone['label'] ) && ! empty( $ebio_phone['href'] ) ) {
		$ebio_phones[] = '<li class="ebio-site-footer__phone"><a class="ebio-site-footer__contact-link" href="' . esc_url( (string) $ebio_phone['href'] ) . '">' . esc_html( (string) $ebio_phone['label'] ) . '</a></li>';
	}
}
$ebio_email   = is_array( $view['email'] ?? null ) && ! empty( $view['email']['label'] ) ? $view['email'] : null;
$ebio_address = (string) ( $view['address'] ?? '' );
$ebio_hours   = (string) ( $view['hours'] ?? '' );

$ebio_columns = array();
foreach ( is_array( $view['columns'] ?? null ) ? $view['columns'] : array() as $ebio_column ) {
	$ebio_title = (string) ( $ebio_column['title'] ?? '' );
	$ebio_links = array();
	foreach ( is_array( $ebio_column['links'] ?? null ) ? $ebio_column['links'] : array() as $ebio_link ) {
		if ( ! empty( $ebio_link['label'] ) && ! empty( $ebio_link['url'] ) ) {
			$ebio_links[] = '<li><a href="' . esc_url( (string) $ebio_link['url'] ) . '">' . esc_html( (string) $ebio_link['label'] ) . '</a></li>';
		}
	}
	if ( '' === $ebio_title && ! $ebio_links ) {
		continue;
	}
	$ebio_columns[] = '<div class="ebio-site-footer__column">'
		. ( '' !== $ebio_title ? '<h2 class="wp-block-heading">' . esc_html( $ebio_title ) . '</h2>' : '' )
		. ( $ebio_links ? '<ul class="wp-block-list">' . implode( '', $ebio_links ) . '</ul>' : '' )
		. '</div>';
}

$ebio_legal = array();
foreach ( is_array( $attributes['legalLinks'] ?? null ) ? $attributes['legalLinks'] : array() as $ebio_link ) {
	if ( ! empty( $ebio_link['label'] ) && ! empty( $ebio_link['url'] ) ) {
		$ebio_legal[] = '<li class="ebio-site-footer__legal-item"><a class="ebio-site-footer__legal-link" href="' . esc_url( (string) $ebio_link['url'] ) . '">' . esc_html( (string) $ebio_link['label'] ) . '</a></li>';
	}
}

$ebio_lines   = array();
$ebio_lines[] = '<div ' . ebio_root_attributes( 'ebio-site-footer', array(), $attributes ) . '>';
$ebio_lines[] = '<div class="ebio-site-footer__inner">';
$ebio_lines[] = '<div class="ebio-site-footer__brand">';
$ebio_lines[] = '<a class="ebio-site-footer__logo" href="/" aria-label="eBiopacking, ir al inicio">'
	. ( null !== $ebio_logo ? ebio_dynamic_image_html( 'ebio-site-footer__logo-image', $ebio_logo ) : 'eBiopacking' ) . '</a>';
if ( '' !== $ebio_text( 'description' ) ) {
	$ebio_lines[] = '<p class="ebio-site-footer__description">' . esc_html( $ebio_text( 'description' ) ) . '</p>';
}
if ( '' !== $ebio_address || $ebio_phones || null !== $ebio_email || '' !== $ebio_hours ) {
	$ebio_lines[] = '<address class="ebio-site-footer__contact">';
	if ( '' !== $ebio_address ) {
		$ebio_lines[] = '<p class="ebio-site-footer__address">' . esc_html( $ebio_address ) . '</p>';
	}
	if ( $ebio_phones ) {
		$ebio_lines[] = '<ul class="ebio-site-footer__phones">' . implode( '', $ebio_phones ) . '</ul>';
	}
	if ( null !== $ebio_email ) {
		$ebio_lines[] = '<p class="ebio-site-footer__email"><a class="ebio-site-footer__contact-link" href="' . esc_url( (string) ( $ebio_email['href'] ?? '' ) ) . '">' . esc_html( (string) $ebio_email['label'] ) . '</a></p>';
	}
	if ( '' !== $ebio_hours ) {
		$ebio_lines[] = '<p class="ebio-site-footer__hours">' . esc_html( 'Horario: ' . $ebio_hours ) . '</p>';
	}
	$ebio_lines[] = '</address>';
}
if ( '' !== $ebio_text( 'ctaText' ) ) {
	$ebio_lines[] = '<a class="ebio-site-footer__cta ebio-button ebio-button--secondary" href="' . esc_url( $ebio_text( 'ctaUrl', '/cotizar/' ) ) . '">' . esc_html( $ebio_text( 'ctaText' ) ) . '</a>';
}
$ebio_lines[] = '</div>';
if ( $ebio_columns ) {
	$ebio_lines[] = '<div class="ebio-site-footer__columns">' . implode( '', $ebio_columns ) . '</div>';
}
$ebio_lines[] = '<div class="ebio-site-footer__legal">';
$ebio_lines[] = '<p class="ebio-site-footer__copyright">© <span class="ebio-site-footer__year">' . esc_html( $ebio_year ) . '</span> ' . esc_html( $ebio_text( 'copyright' ) ) . '</p>';
if ( $ebio_legal ) {
	$ebio_lines[] = '<ul class="ebio-site-footer__legal-links">' . implode( '', $ebio_legal ) . '</ul>';
}
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
