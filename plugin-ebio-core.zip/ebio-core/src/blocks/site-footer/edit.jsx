import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, TextControl, TextareaControl } from '@wordpress/components';
import SiteFooter from '../../components/SiteFooter.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import useBlockView from '../../editor/use-block-view.js';

/**
 * Editor de `ebio/site-footer`: logo, contacto y columnas de enlaces vienen de la vista del servidor
 * (Ajustes › eBiopacking); la descripción, el CTA y los legales se editan en el panel lateral.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view } = useBlockView( 'ebio/site-footer', attributes, context );
	const field = ( key, label, help ) => (
		<TextControl
			label={ label }
			value={ attributes[ key ] }
			onChange={ ( value ) => setAttributes( { [ key ]: value } ) }
			help={ help }
			__nextHasNoMarginBottom
			__next40pxDefaultSize
		/>
	);

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Marca', 'ebio-core' ) }>
					<TextareaControl
						label={ __( 'Descripción', 'ebio-core' ) }
						value={ attributes.description }
						onChange={ ( description ) => setAttributes( { description } ) }
						help={ __( 'Recomendado: hasta 160 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
					/>
					<Notice status="info" isDismissible={ false }>
						{ __( 'Logo, teléfonos, correo, horarios y columnas de enlaces se editan en Ajustes › eBiopacking.', 'ebio-core' ) }
					</Notice>
				</PanelBody>
				<PanelBody title={ __( 'CTA', 'ebio-core' ) }>
					{ field( 'ctaText', __( 'Texto del botón', 'ebio-core' ), __( 'Recomendado: hasta 25 caracteres.', 'ebio-core' ) ) }
					{ field( 'ctaUrl', __( 'URL del botón', 'ebio-core' ) ) }
				</PanelBody>
				<PanelBody title={ __( 'Legales', 'ebio-core' ) }>
					{ field( 'copyright', __( 'Texto de derechos', 'ebio-core' ), __( 'Recomendado: hasta 80 caracteres.', 'ebio-core' ) ) }
					<ItemListControl
						items={ attributes.legalLinks }
						onChange={ ( legalLinks ) => setAttributes( { legalLinks } ) }
						min={ 1 }
						max={ 4 }
						emptyItem={ { label: '', url: '' } }
						itemLabel={ __( 'Enlace legal', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<>
								<TextControl label={ __( 'Texto', 'ebio-core' ) } value={ item?.label ?? '' } onChange={ ( label ) => update( { label } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
								<TextControl label={ __( 'URL', 'ebio-core' ) } value={ item?.url ?? '' } onChange={ ( url ) => update( { url } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
							</>
						) }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<SiteFooter attributes={ attributes } context={ { 'ebio/view': view ?? {} } } />
			</div>
		</>
	);
}
