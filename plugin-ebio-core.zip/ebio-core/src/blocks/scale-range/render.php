<?php
/**
 * `ebio/scale-range` (docs/blocks/scale-range.md). Gemelo de `src/components/ScaleRange.jsx`.
 *
 * Sin escalones no emite nada. Cada elemento de bloque va en su línea (catalog §2.9).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_scale_range_view( $attributes, $block ?? null );
	}
);

$ebio_steps = is_array( $view['steps'] ?? null ) ? array_values( $view['steps'] ) : array();
if ( ! $ebio_steps ) {
	return;
}

$ebio_text    = static function ( string $key ) use ( $attributes ): string {
	return is_string( $attributes[ $key ] ?? null ) ? $attributes[ $key ] : '';
};
$ebio_level   = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );
$ebio_intro   = $ebio_text( 'intro' );
$ebio_cta     = $ebio_text( 'ctaText' );
$ebio_note    = is_string( $view['note'] ?? null ) ? $view['note'] : '';
$ebio_person  = true === ( $attributes['showPerson'] ?? true );
$ebio_product = 'product' === ( $attributes['variant'] ?? 'plant' );

$ebio_lines   = array();
$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-scale-range', array( $ebio_product ? 'product' : '', true === ( $attributes['compact'] ?? false ) ? 'compact' : '' ), $attributes ) . '>';
$ebio_lines[] = '<div class="ebio-scale-range__inner">';
$ebio_lines[] = '<div class="ebio-scale-range__header">';
$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-scale-range__heading">' . esc_html( $ebio_text( 'heading' ) ) . '</h' . $ebio_level . '>';
if ( '' !== $ebio_intro ) {
	$ebio_lines[] = '<p class="ebio-scale-range__intro">' . wp_kses_post( $ebio_intro ) . '</p>';
}
if ( '' !== $ebio_cta ) {
	$ebio_lines[] = '<a class="ebio-scale-range__cta ebio-button ebio-button--primary" href="' . esc_url( $ebio_text( 'ctaUrl' ) ) . '">' . esc_html( $ebio_cta ) . '</a>';
}
$ebio_lines[] = '</div>';
$ebio_lines[] = '<ol class="ebio-scale-range__steps">';
foreach ( $ebio_steps as $ebio_i => $ebio_step ) {
	$ebio_step  = is_array( $ebio_step ) ? $ebio_step : array();
	$ebio_name  = (string) ( $ebio_step['name'] ?? '' );
	$ebio_scale = (int) ( $ebio_step['scale'] ?? 0 );
	$ebio_lines[] = '<li class="ebio-scale-range__step" data-scale="' . esc_attr( (string) ( $ebio_scale >= 1 && $ebio_scale <= 4 ? $ebio_scale : $ebio_i + 1 ) ) . '">';
	$ebio_image   = is_array( $ebio_step['image'] ?? null ) ? $ebio_step['image'] : null;
	$ebio_inline  = ( null !== $ebio_image
		? '<span class="ebio-scale-range__media">' . ebio_dynamic_image_html( 'ebio-scale-range__image', $ebio_image ) . '</span>'
		: '<span class="ebio-scale-range__box" aria-hidden="true"></span>' )
		. '<strong class="ebio-scale-range__name">' . esc_html( $ebio_name ) . '</strong>'
		. '<span class="ebio-scale-range__size">' . esc_html( (string) ( $ebio_step['size'] ?? '' ) ) . '</span>'
		. '<span class="ebio-scale-range__uses">' . esc_html( (string) ( $ebio_step['uses'] ?? '' ) ) . '</span>';
	if ( ! empty( $ebio_step['linkText'] ) && ! empty( $ebio_step['linkUrl'] ) ) {
		$ebio_inline .= '<a class="ebio-scale-range__link" href="' . esc_url( (string) $ebio_step['linkUrl'] ) . '">' . esc_html( (string) $ebio_step['linkText'] )
			. '<span class="ebio-visually-hidden"> · ' . esc_html( $ebio_name ) . '</span></a>';
	}
	$ebio_lines[] = $ebio_inline;
	$ebio_lines[] = '</li>';
}
$ebio_lines[] = '</ol>';
if ( $ebio_person ) {
	$ebio_lines[] = '<div class="ebio-scale-range__person" aria-hidden="true">';
	$ebio_lines[] = '<span class="ebio-scale-range__person-label">' . esc_html( $ebio_text( 'personLabel' ) ) . '</span>';
	$ebio_lines[] = '</div>';
}
if ( '' !== $ebio_note ) {
	$ebio_lines[] = '<p class="ebio-scale-range__note">' . wp_kses_post( $ebio_note ) . '</p>';
}
$ebio_lines[] = '</div>';
$ebio_lines[] = '</section>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
