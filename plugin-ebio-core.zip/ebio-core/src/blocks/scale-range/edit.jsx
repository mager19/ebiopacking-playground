import { __ } from '@wordpress/i18n';
import { InspectorControls, MediaUpload, MediaUploadCheck, useBlockProps } from '@wordpress/block-editor';
import { BaseControl, Button, Notice, PanelBody, SelectControl, TextControl, ToggleControl } from '@wordpress/components';
import { EditContext } from '../../components/lib/edit-context.js';
import { makeEditContext } from '../../editor/edit-context.js';
import ScaleRange from '../../components/ScaleRange.jsx';
import ItemListControl from '../../editor/ItemListControl.jsx';
import useBlockView from '../../editor/use-block-view.js';

const EMPTY_STEP = { name: '', size: '', uses: '', linkText: '', linkUrl: '', scale: 1, imageId: 0 };

/**
 * Foto real de la caja de un escalón (`imageId`, adjunto de la biblioteca de medios). Sin foto se dibuja la caja de respaldo;
 * el texto alternativo sale de la biblioteca de medios.
 */
function StepImageControl( { imageId, onChange } ) {
	return (
		<BaseControl label={ __( 'Foto de la caja', 'ebio-core' ) } help={ __( 'Vacío = caja dibujada. El texto alternativo se edita en la biblioteca de medios.', 'ebio-core' ) } __nextHasNoMarginBottom>
			<MediaUploadCheck>
				<MediaUpload
					allowedTypes={ [ 'image' ] }
					value={ imageId || undefined }
					onSelect={ ( media ) => onChange( media.id ) }
					render={ ( { open } ) => (
						<Button variant="secondary" onClick={ open }>
							{ imageId ? __( 'Reemplazar foto', 'ebio-core' ) : __( 'Elegir foto', 'ebio-core' ) }
						</Button>
					) }
				/>
			</MediaUploadCheck>
			{ imageId ? (
				<Button variant="link" isDestructive onClick={ () => onChange( 0 ) }>
					{ __( 'Quitar foto', 'ebio-core' ) }
				</Button>
			) : null }
		</BaseControl>
	);
}

/**
 * Editor de `ebio/scale-range`: los escalones resueltos vienen de la vista del servidor (rango de
 * planta global o los de la instancia); título e intro se editan en el lienzo y el resto en el panel.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view, isLoading } = useBlockView( 'ebio/scale-range', attributes, context );
	const { variant, compact, heading, ctaText, ctaUrl, steps, note, showPerson, personLabel } = attributes;
	const empty = ! isLoading && ( view?.steps ?? [] ).length === 0;
	const text = ( key, label, help ) => (
		<TextControl label={ label } value={ attributes[ key ] } onChange={ ( next ) => setAttributes( { [ key ]: next } ) } help={ help } __nextHasNoMarginBottom __next40pxDefaultSize />
	);

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Rango', 'ebio-core' ) }
						value={ variant }
						options={ [
							{ label: __( 'Rango de planta', 'ebio-core' ), value: 'plant' },
							{ label: __( 'Rango del producto', 'ebio-core' ), value: 'product' },
						] }
						onChange={ ( next ) => setAttributes( { variant: next } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					{ text( 'heading', __( 'Título', 'ebio-core' ), __( 'Recomendado: hasta 50 caracteres. El texto de ayuda se edita en el lienzo.', 'ebio-core' ) ) }
				</PanelBody>
				<PanelBody title={ __( 'Compacta', 'ebio-core' ) } initialOpen={ false }>
					<ToggleControl label={ __( 'Versión compacta', 'ebio-core' ) } checked={ compact } onChange={ ( next ) => setAttributes( { compact: next } ) } __nextHasNoMarginBottom />
				</PanelBody>
				<PanelBody title={ __( 'Escalones', 'ebio-core' ) } initialOpen={ false }>
					<Notice status="info" isDismissible={ false }>
						{ __( 'Vacío = rango de planta de Ajustes › eBiopacking.', 'ebio-core' ) }
					</Notice>
					<ItemListControl
						items={ steps }
						onChange={ ( next ) => setAttributes( { steps: next } ) }
						min={ 0 }
						max={ 4 }
						emptyItem={ EMPTY_STEP }
						itemLabel={ __( 'Escalón', 'ebio-core' ) }
						renderItem={ ( item, update ) => (
							<>
								<TextControl label={ __( 'Nombre', 'ebio-core' ) } value={ item.name ?? '' } onChange={ ( next ) => update( { name: next } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
								<TextControl label={ __( 'Medida', 'ebio-core' ) } value={ item.size ?? '' } onChange={ ( next ) => update( { size: next } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
								<TextControl label={ __( 'Usos', 'ebio-core' ) } value={ item.uses ?? '' } onChange={ ( next ) => update( { uses: next } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
								<TextControl label={ __( 'Texto del enlace', 'ebio-core' ) } value={ item.linkText ?? '' } onChange={ ( next ) => update( { linkText: next } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
								<TextControl label={ __( 'URL del enlace', 'ebio-core' ) } value={ item.linkUrl ?? '' } onChange={ ( next ) => update( { linkUrl: next } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
								<StepImageControl imageId={ Number( item.imageId ?? 0 ) } onChange={ ( next ) => update( { imageId: next } ) } />
								<SelectControl
									label={ __( 'Tamaño del dibujo', 'ebio-core' ) }
									value={ String( item.scale ?? 1 ) }
									options={ [ '1', '2', '3', '4' ].map( ( value ) => ( { label: value, value } ) ) }
									onChange={ ( next ) => update( { scale: Number( next ) } ) }
									__nextHasNoMarginBottom
									__next40pxDefaultSize
								/>
							</>
						) }
					/>
					{ steps.length > 0 ? text( 'note', __( 'Nota', 'ebio-core' ), __( 'Solo con escalones propios. Recomendado: hasta 160 caracteres.', 'ebio-core' ) ) : null }
				</PanelBody>
				<PanelBody title={ __( 'Figura humana', 'ebio-core' ) } initialOpen={ false }>
					<ToggleControl label={ __( 'Mostrar figura humana', 'ebio-core' ) } checked={ showPerson } onChange={ ( next ) => setAttributes( { showPerson: next } ) } __nextHasNoMarginBottom />
					{ showPerson ? text( 'personLabel', __( 'Etiqueta de la figura', 'ebio-core' ) ) : null }
				</PanelBody>
				<PanelBody title={ __( 'Llamado', 'ebio-core' ) } initialOpen={ false }>
					{ text( 'ctaText', __( 'Texto del botón', 'ebio-core' ), __( 'Vacío = sin botón.', 'ebio-core' ) ) }
					{ ctaText !== '' ? text( 'ctaUrl', __( 'URL del botón', 'ebio-core' ) ) : null }
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ empty ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Sin escalones: en la variante de producto el bloque no se muestra. Añade escalones en el panel lateral.', 'ebio-core' ) }
					</Notice>
				) : null }
				<EditContext.Provider value={ makeEditContext( attributes, setAttributes ) }>
					<ScaleRange attributes={ attributes } context={ { 'ebio/view': view ?? { steps: [], note: '' } } } />
				</EditContext.Provider>
			</div>
		</>
	);
}
