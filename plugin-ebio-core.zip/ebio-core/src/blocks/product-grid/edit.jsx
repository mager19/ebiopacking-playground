import { __ } from '@wordpress/i18n';
import { useEffect, useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { Notice, PanelBody, RangeControl, SelectControl, TextControl, TextareaControl } from '@wordpress/components';
import ProductGrid from '../../components/ProductGrid.jsx';
import useBlockView from '../../editor/use-block-view.js';

/** Términos (slug y nombre) de una taxonomía REST para el selector; vacío si la REST no responde. */
function useTermOptions( restBase ) {
	const [ options, setOptions ] = useState( [] );
	useEffect( () => {
		let active = true;
		apiFetch( { path: `/wp/v2/${ restBase }?per_page=100&_fields=slug,name` } ).then(
			( terms ) => active && Array.isArray( terms ) && setOptions( terms.filter( ( term ) => term?.slug ).map( ( term ) => ( { label: term.name, value: term.slug } ) ) ),
			() => {}
		);
		return () => {
			active = false;
		};
	}, [ restBase ] );
	return options;
}

/** Selector de término con respaldo de texto (slug) si la lista no carga. */
function TermControl( { label, value, options, onChange } ) {
	if ( options.length === 0 ) {
		return <TextControl label={ `${ label } (slug)` } value={ value } onChange={ onChange } __nextHasNoMarginBottom __next40pxDefaultSize />;
	}
	return (
		<SelectControl
			label={ label }
			value={ value }
			options={ [ { label: __( 'De la página actual', 'ebio-core' ), value: '' }, ...options ] }
			onChange={ onChange }
			__nextHasNoMarginBottom
			__next40pxDefaultSize
		/>
	);
}

/**
 * Editor de `ebio/product-grid`: la grilla viene de la vista del servidor; variante, fuente, textos y
 * cantidad se editan en el panel lateral.
 */
export default function Edit( { attributes, setAttributes, context } ) {
	const { view, isLoading } = useBlockView( 'ebio/product-grid', attributes, context );
	const categories = useTermOptions( 'ebio_product_category' );
	const sectors = useTermOptions( 'ebio_sector' );
	const { variant, source, category, sector, heading, emptyTitle, emptyText, emptyCtaText, emptyCtaUrl, perPage, showCountLine } = attributes;
	const hidden = ! isLoading && view?.status === 'hidden';

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Variante', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Filtros', 'ebio-core' ) }
						value={ variant }
						options={ [
							{ label: __( 'Categoría, Sector y Formato', 'ebio-core' ), value: 'full-filters' },
							{ label: __( 'Sector y Formato', 'ebio-core' ), value: 'sector-format' },
							{ label: __( 'Sin filtros', 'ebio-core' ), value: 'plain' },
						] }
						onChange={ ( next ) => setAttributes( { variant: next } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
				</PanelBody>
				<PanelBody title={ __( 'Fuente', 'ebio-core' ) }>
					<SelectControl
						label={ __( 'Fuente de productos', 'ebio-core' ) }
						value={ source }
						options={ [
							{ label: __( 'Todo el catálogo', 'ebio-core' ), value: 'all' },
							{ label: __( 'De una categoría', 'ebio-core' ), value: 'category' },
							{ label: __( 'De un sector', 'ebio-core' ), value: 'sector' },
							{ label: __( 'Resultados de búsqueda', 'ebio-core' ), value: 'search' },
						] }
						onChange={ ( next ) => setAttributes( { source: next } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					{ source === 'category' ? <TermControl label={ __( 'Categoría', 'ebio-core' ) } value={ category } options={ categories } onChange={ ( next ) => setAttributes( { category: next } ) } /> : null }
					{ source === 'sector' ? <TermControl label={ __( 'Sector', 'ebio-core' ) } value={ sector } options={ sectors } onChange={ ( next ) => setAttributes( { sector: next } ) } /> : null }
				</PanelBody>
				<PanelBody title={ __( 'Textos', 'ebio-core' ) }>
					<TextControl
						label={ __( 'Encabezado', 'ebio-core' ) }
						value={ heading }
						onChange={ ( next ) => setAttributes( { heading: next } ) }
						help={ __( 'Marcadores: {count} número visible, {products} "producto" o "productos", {term} categoría o sector, {query} búsqueda. Recomendado: hasta 60 caracteres.', 'ebio-core' ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<SelectControl
						label={ __( 'Línea con el contador', 'ebio-core' ) }
						value={ showCountLine ? 'yes' : 'no' }
						options={ [
							{ label: __( 'No mostrar', 'ebio-core' ), value: 'no' },
							{ label: __( 'Mostrar bajo el encabezado', 'ebio-core' ), value: 'yes' },
						] }
						onChange={ ( next ) => setAttributes( { showCountLine: next === 'yes' } ) }
						__nextHasNoMarginBottom
						__next40pxDefaultSize
					/>
					<TextControl label={ __( 'Título del estado vacío', 'ebio-core' ) } value={ emptyTitle } onChange={ ( next ) => setAttributes( { emptyTitle: next } ) } help={ __( 'Admite {query}.', 'ebio-core' ) } __nextHasNoMarginBottom __next40pxDefaultSize />
					<TextareaControl label={ __( 'Texto del estado vacío', 'ebio-core' ) } value={ emptyText } onChange={ ( next ) => setAttributes( { emptyText: next } ) } __nextHasNoMarginBottom />
					<TextControl label={ __( 'Botón del estado vacío', 'ebio-core' ) } value={ emptyCtaText } onChange={ ( next ) => setAttributes( { emptyCtaText: next } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
					<TextControl label={ __( 'Enlace del botón', 'ebio-core' ) } value={ emptyCtaUrl } onChange={ ( next ) => setAttributes( { emptyCtaUrl: next } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
				</PanelBody>
				<PanelBody title={ __( 'Cantidad', 'ebio-core' ) }>
					<RangeControl label={ __( 'Máximo de productos', 'ebio-core' ) } value={ perPage } min={ 1 } max={ 100 } onChange={ ( next ) => setAttributes( { perPage: next ?? 60 } ) } __nextHasNoMarginBottom __next40pxDefaultSize />
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				{ hidden ? (
					<Notice status="warning" isDismissible={ false }>
						{ __( 'Hay páginas pero no productos para esta búsqueda: el bloque no se muestra en el sitio.', 'ebio-core' ) }
					</Notice>
				) : null }
				<ProductGrid attributes={ attributes } context={ { 'ebio/view': view ?? { uid: 'grid-editor', status: 'results', headingText: '', countText: '', emptyTitle: '', formAction: '/', quoteUrl: '/cotizar/', groups: [], products: [], visible: [] } } } />
			</div>
		</>
	);
}
