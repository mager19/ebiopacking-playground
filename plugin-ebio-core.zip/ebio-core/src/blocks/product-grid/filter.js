/**
 * Filtros de `ebio/product-grid` (docs/blocks/product-grid.md › Parámetros de URL). Funciones puras: gemelas de
 * `ebio_product_grid_selection()` y `ebio_product_grid_matches()` (includes/blocks/product-grid.php); ambas
 * se prueban con los mismos casos (tests/blocks/product-grid-cases.json).
 */

export const GROUPS = [ 'categoria', 'sector', 'formato' ];

/** Grupo de la selección → clave de las facetas de un producto. */
const FACET_KEY = { categoria: 'categories', sector: 'sectors', formato: 'formats' };

/** Como `sanitize_key()` de WordPress: minúsculas y solo `a-z 0-9 _ -`. */
const sanitizeKey = ( value ) => String( value ).toLowerCase().replace( /[^a-z0-9_-]/g, '' );

/**
 * Selección vacía.
 *
 * @return {{ categoria: string[], sector: string[], formato: string[] }} Selección.
 */
export function emptySelection() {
	return { categoria: [], sector: [], formato: [] };
}

/**
 * Valores de un grupo en una consulta, con la semántica de `$_GET` de PHP: `a=1,2` o `a[]=1&a[]=2`;
 * la última forma que aparece gana (`a[]=x&a=y` deja solo `y`).
 *
 * @param {URLSearchParams} params Consulta.
 * @param {string}          key    Grupo.
 * @return {string[]} Fragmentos sin normalizar.
 */
function rawValues( params, key ) {
	let values = [];
	for ( const [ name, value ] of params ) {
		if ( name === key ) {
			values = [ value ];
		} else if ( name === `${ key }[]` ) {
			const previous = values.fromArray ? values : Object.assign( [], { fromArray: true } );
			previous.push( value );
			values = previous;
		}
	}
	return values;
}

/**
 * Selección de la URL: acepta `?formato=a,b` y `?formato[]=a&formato[]=b`; normaliza con `sanitize_key`,
 * quita repetidos y, si se da `allowed`, descarta lo que no sea un término existente.
 *
 * @param {string}                                   search  `location.search` (con o sin `?`).
 * @param {Record<string, string[]>|null}            allowed Lista blanca por grupo (`null` = sin lista).
 * @return {{ categoria: string[], sector: string[], formato: string[] }} Selección, cada grupo ordenado.
 */
export function parseSelection( search, allowed = null ) {
	const params = new URLSearchParams( typeof search === 'string' ? search : '' );
	const selection = emptySelection();
	for ( const key of GROUPS ) {
		const found = new Set();
		for ( const raw of rawValues( params, key ) ) {
			for ( const piece of String( raw ).split( ',' ) ) {
				const slug = sanitizeKey( piece );
				if ( slug !== '' && ( ! allowed || ( allowed[ key ] ?? [] ).includes( slug ) ) ) {
					found.add( slug );
				}
			}
		}
		selection[ key ] = [ ...found ].sort();
	}
	return selection;
}

/**
 * ¿El producto cumple la selección? O dentro de un grupo, Y entre grupos; un grupo vacío no filtra.
 *
 * @param {{ categories?: string[], sectors?: string[], formats?: string[] }} facets    Facetas del producto.
 * @param {{ categoria?: string[], sector?: string[], formato?: string[] }}   selection Selección.
 * @return {boolean} Cumple.
 */
export function matches( facets, selection ) {
	for ( const key of GROUPS ) {
		const wanted = Array.isArray( selection?.[ key ] ) ? selection[ key ] : [];
		if ( wanted.length === 0 ) {
			continue;
		}
		const own = Array.isArray( facets?.[ FACET_KEY[ key ] ] ) ? facets[ FACET_KEY[ key ] ] : [];
		if ( ! wanted.some( ( slug ) => own.includes( slug ) ) ) {
			return false;
		}
	}
	return true;
}

/**
 * Consulta de la URL para una selección: `?formato=a,b` (grupos en orden; `''` si no hay nada).
 *
 * @param {{ categoria?: string[], sector?: string[], formato?: string[] }} selection Selección.
 * @return {string} `?categoria=a&formato=b,c` o `''`.
 */
export function toSearch( selection ) {
	const parts = [];
	for ( const key of GROUPS ) {
		const values = Array.isArray( selection?.[ key ] ) ? selection[ key ].filter( Boolean ) : [];
		if ( values.length > 0 ) {
			parts.push( `${ key }=${ values.join( ',' ) }` );
		}
	}
	return parts.length > 0 ? `?${ parts.join( '&' ) }` : '';
}
