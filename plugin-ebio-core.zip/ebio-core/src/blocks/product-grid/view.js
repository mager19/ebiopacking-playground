/**
 * Módulo de vista de `ebio/product-grid` (docs/blocks/product-grid.md): filtros de la grilla
 * (`ebio/product-grid`) y botón "Agregar a cotización" de las tarjetas (`ebio/quote`).
 */
import '../../stores/product-grid/store.js';
import '../../stores/quote/store.js';
