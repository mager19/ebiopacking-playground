<?php
/**
 * `ebio/product-grid` (docs/blocks/product-grid.md). Gemelo de `src/components/ProductGrid.jsx`.
 *
 * Las tarjetas las pinta el componente compartido `ebio_render_product_card()`. Todo el conjunto de la
 * fuente se emite; lo que no cumple los filtros va con `hidden`. Búsqueda sin productos pero con páginas:
 * no emite nada. Cada elemento de bloque va en su línea (catalog §2.9).
 *
 * @var array         $attributes Atributos del bloque.
 * @var WP_Block|null $block      Bloque (null en fixtures sin contexto).
 *
 * @package ebio-core
 */

defined( 'ABSPATH' ) || exit;

$view = ebio_block_view(
	$block ?? null,
	static function () use ( $attributes, $block ) {
		return ebio_product_grid_view( $attributes, $block ?? null );
	}
);

$ebio_status = is_string( $view['status'] ?? null ) ? $view['status'] : 'results';
if ( 'hidden' === $ebio_status ) {
	return;
}

$ebio_uid        = (string) ( $view['uid'] ?? '' );
$ebio_variant    = is_string( $attributes['variant'] ?? null ) ? $attributes['variant'] : 'full-filters';
$ebio_source     = is_string( $attributes['source'] ?? null ) ? $attributes['source'] : 'all';
$ebio_level      = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 2 ) ) );
$ebio_groups     = is_array( $view['groups'] ?? null ) ? array_values( $view['groups'] ) : array();
$ebio_products   = is_array( $view['products'] ?? null ) ? array_values( $view['products'] ) : array();
$ebio_visible    = array_map( 'intval', is_array( $view['visible'] ?? null ) ? $view['visible'] : array() );
$ebio_form_url   = is_string( $view['formAction'] ?? null ) ? $view['formAction'] : '/';
$ebio_heading_id = 'ebio-product-grid-' . $ebio_uid . '-heading';
$ebio_filters_id = 'ebio-product-grid-' . $ebio_uid . '-filters';
$ebio_is_empty   = 'empty' === $ebio_status;
$ebio_search_nil = $ebio_is_empty && 'search' === $ebio_source;
$ebio_has_form   = 'plain' !== $ebio_variant;
$ebio_empty_text = is_string( $attributes['emptyText'] ?? null ) ? $attributes['emptyText'] : '';
$ebio_cta_text   = is_string( $attributes['emptyCtaText'] ?? null ) ? $attributes['emptyCtaText'] : '';
$ebio_cta_url    = is_string( $attributes['emptyCtaUrl'] ?? null ) ? $attributes['emptyCtaUrl'] : '/cotizar/';
$ebio_options    = array(
	'headingLevel'   => 3,
	'quoteUrl'       => is_string( $view['quoteUrl'] ?? null ) ? $view['quoteUrl'] : '/cotizar/',
	'showAddToQuote' => true,
);
// Resultados visibles: `data-count` y `--few` (1 a 3) dejan al CSS ensanchar las tarjetas cuando hay pocas.
$ebio_count      = count( $ebio_visible );
$ebio_few        = $ebio_count > 0 && $ebio_count <= 3;
$ebio_modifiers  = array( 'full-filters' === $ebio_variant ? '' : $ebio_variant, $ebio_few ? 'few' : '' );

$ebio_lines = array();

// Búsqueda sin ningún resultado (D23): solo el estado vacío, con H2, sin filtros ni barra.
if ( $ebio_search_nil ) {
	$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-product-grid', $ebio_modifiers, $attributes ) . ' aria-labelledby="' . esc_attr( $ebio_heading_id ) . '">';
	$ebio_lines[] = '<div class="ebio-product-grid__inner">';
	$ebio_lines[] = '<div class="ebio-product-grid__results">';
	$ebio_lines[] = '<div class="ebio-product-grid__empty">';
	$ebio_lines[] = '<h2 class="ebio-product-grid__empty-title" id="' . esc_attr( $ebio_heading_id ) . '">' . esc_html( (string) ( $view['emptyTitle'] ?? '' ) ) . '</h2>';
	if ( '' !== $ebio_empty_text ) {
		$ebio_lines[] = '<p class="ebio-product-grid__empty-text">' . esc_html( $ebio_empty_text ) . '</p>';
	}
	$ebio_lines[] = '<a class="ebio-product-grid__empty-cta ebio-button ebio-button--primary" href="' . esc_url( $ebio_cta_url ) . '">' . esc_html( $ebio_cta_text ) . '</a>';
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '</section>';
	echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
	return;
}

// Estado inicial de `ebio/product-grid` derivado de la vista (SSR sin efecto, D8).
ebio_product_grid_init_state( $attributes, $view );

$ebio_selection = array(
	'categoria' => array(),
	'sector'    => array(),
	'formato'   => array(),
);
foreach ( $ebio_groups as $ebio_group ) {
	$ebio_key = is_string( $ebio_group['key'] ?? null ) ? $ebio_group['key'] : '';
	if ( ! isset( $ebio_selection[ $ebio_key ] ) ) {
		continue;
	}
	foreach ( is_array( $ebio_group['options'] ?? null ) ? $ebio_group['options'] : array() as $ebio_option ) {
		if ( ! empty( $ebio_option['checked'] ) ) {
			$ebio_selection[ $ebio_key ][] = (string) ( $ebio_option['value'] ?? '' );
		}
	}
}

$ebio_lines[] = '<section ' . ebio_root_attributes( 'ebio-product-grid', $ebio_modifiers, $attributes ) . ' aria-labelledby="' . esc_attr( $ebio_heading_id ) . '"'
	. ' data-count="' . esc_attr( (string) $ebio_count ) . '"'
	. ' data-wp-interactive="ebio/product-grid" '
	. wp_interactivity_data_wp_context(
		array(
			'categoria' => $ebio_selection['categoria'],
			'sector'    => $ebio_selection['sector'],
			'formato'   => $ebio_selection['formato'],
			'panelOpen' => false,
			'hydrated'  => false,
		)
	)
	. ' data-wp-init="callbacks.init" data-wp-on--keydown="actions.closePanelOnEscape" data-hydrated="false" data-wp-bind--data-hydrated="context.hydrated"'
	. ' data-wp-bind--data-count="state.resultCount" data-wp-class--ebio-product-grid--few="state.isFew">';
$ebio_lines[] = '<div class="ebio-product-grid__inner">';

// El botón "Filtrar" va antes del panel en el DOM (orden de foco: WCAG 2.4.3); el CSS fija el orden visual.
$ebio_lines[] = '<div class="ebio-product-grid__toolbar">';
$ebio_lines[] = '<h' . $ebio_level . ' class="ebio-product-grid__heading" id="' . esc_attr( $ebio_heading_id ) . '" data-wp-text="state.headingText">' . esc_html( (string) ( $view['headingText'] ?? '' ) ) . '</h' . $ebio_level . '>';
if ( ! empty( $attributes['showCountLine'] ) ) {
	$ebio_lines[] = '<p class="ebio-product-grid__count" data-wp-text="state.countText">' . esc_html( (string) ( $view['countText'] ?? '' ) ) . '</p>';
}
if ( $ebio_has_form ) {
	$ebio_lines[] = '<button type="button" class="ebio-product-grid__filters-toggle ebio-button ebio-button--secondary ebio-button--small" aria-controls="' . esc_attr( $ebio_filters_id ) . '" aria-expanded="false" hidden'
		. ' data-wp-bind--hidden="!context.hydrated" data-wp-bind--aria-expanded="context.panelOpen" data-wp-on--click="actions.togglePanel">Filtrar</button>';
}
$ebio_lines[] = '</div>';
if ( $ebio_has_form ) {
	$ebio_lines[] = '<form class="ebio-product-grid__filters" id="' . esc_attr( $ebio_filters_id ) . '" action="' . esc_url( $ebio_form_url ) . '" method="get" aria-label="Filtros de productos"'
		. ' data-open="false" data-wp-bind--data-open="context.panelOpen" data-wp-on--change="actions.applyFilter">';
	foreach ( $ebio_groups as $ebio_group ) {
		$ebio_key     = (string) ( $ebio_group['key'] ?? '' );
		$ebio_lines[] = '<fieldset class="ebio-product-grid__group">';
		$ebio_lines[] = '<legend class="ebio-product-grid__legend">' . esc_html( (string) ( $ebio_group['legend'] ?? '' ) ) . '</legend>';
		$ebio_lines[] = '<ul class="ebio-product-grid__options">';
		foreach ( is_array( $ebio_group['options'] ?? null ) ? $ebio_group['options'] : array() as $ebio_option ) {
			$ebio_lines[] = '<li class="ebio-product-grid__option-item">';
			$ebio_lines[] = '<label class="ebio-product-grid__option">'
				. '<input class="ebio-product-grid__checkbox" type="checkbox" name="' . esc_attr( $ebio_key ) . '[]" value="' . esc_attr( (string) ( $ebio_option['value'] ?? '' ) ) . '"' . ( ! empty( $ebio_option['checked'] ) ? ' checked' : '' ) . '>'
				. '<span class="ebio-product-grid__option-label">' . esc_html( (string) ( $ebio_option['label'] ?? '' ) ) . '</span></label>';
			$ebio_lines[] = '</li>';
		}
		$ebio_lines[] = '</ul>';
		$ebio_lines[] = '</fieldset>';
	}
	$ebio_lines[] = '<div class="ebio-product-grid__filter-actions">';
	$ebio_lines[] = '<button type="submit" class="ebio-product-grid__apply ebio-button ebio-button--secondary" data-wp-bind--hidden="context.hydrated">Aplicar filtros</button>'
		. '<a class="ebio-product-grid__clear" href="' . esc_url( $ebio_form_url ) . '" data-wp-on--click="actions.clear">Limpiar filtros</a>';
	$ebio_lines[] = '</div>';
	$ebio_lines[] = '</form>';
}

$ebio_lines[] = '<div class="ebio-product-grid__results">';
$ebio_lines[] = '<p class="ebio-product-grid__live ebio-visually-hidden" role="status" data-wp-text="state.liveText"></p>';

$ebio_lines[] = '<ul class="ebio-product-grid__list"' . ( $ebio_is_empty ? ' hidden' : '' ) . ' data-wp-bind--hidden="state.isEmpty">';
foreach ( $ebio_products as $ebio_card ) {
	$ebio_card   = is_array( $ebio_card ) ? $ebio_card : array();
	$ebio_facets = is_array( $ebio_card['facets'] ?? null ) ? $ebio_card['facets'] : array();
	$ebio_hidden = ! in_array( (int) ( $ebio_card['id'] ?? 0 ), $ebio_visible, true );
	$ebio_lines[] = '<li class="ebio-product-grid__item"' . ( $ebio_hidden ? ' hidden' : '' ) . ' '
		. wp_interactivity_data_wp_context(
			array(
				'categories' => array_values( (array) ( $ebio_facets['categories'] ?? array() ) ),
				'sectors'    => array_values( (array) ( $ebio_facets['sectors'] ?? array() ) ),
				'formats'    => array_values( (array) ( $ebio_facets['formats'] ?? array() ) ),
				'hidden'     => $ebio_hidden,
			)
		)
		. ' data-wp-watch="callbacks.syncItem" data-wp-bind--hidden="context.hidden">';
	$ebio_lines[] = ebio_render_product_card( $ebio_card, $ebio_options );
	$ebio_lines[] = '</li>';
}
$ebio_lines[] = '</ul>';

$ebio_lines[] = '<div class="ebio-product-grid__empty"' . ( $ebio_is_empty ? '' : ' hidden' ) . ' data-wp-bind--hidden="!state.isEmpty">';
$ebio_lines[] = '<h3 class="ebio-product-grid__empty-title" data-wp-text="state.emptyTitle">' . esc_html( (string) ( $view['emptyTitle'] ?? '' ) ) . '</h3>';
if ( '' !== $ebio_empty_text ) {
	$ebio_lines[] = '<p class="ebio-product-grid__empty-text">' . esc_html( $ebio_empty_text ) . '</p>';
}
$ebio_lines[] = '<a class="ebio-product-grid__empty-cta ebio-button ebio-button--primary" href="' . esc_url( $ebio_cta_url ) . '">' . esc_html( $ebio_cta_text ) . '</a>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</div>';
$ebio_lines[] = '</section>';

echo implode( "\n", $ebio_lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- cada pieza se escapó al armarla.
