/**
 * Store compartido `ebio/carousel` (docs/blocks/product-carousel.md y testimonials.md): flechas de los
 * carruseles. Sin autoplay: la posición solo cambia por una acción de la persona (flechas, teclado,
 * desplazamiento). Sin JS la pista se desplaza con scroll nativo y los controles siguen ocultos.
 *
 * Contexto de la raíz: `{ index, count, hydrated }`. `index` es la posición de la primera tarjeta
 * visible; cuántas caben (`perView`) se mide en la pista, así que no viaja en el markup.
 *
 * Cada bloque con `viewScriptModule` que importa este archivo empaqueta su propia copia; la primera que
 * se evalúa registra el store y las demás reutilizan el registrado (marca compartida en `globalThis`).
 *
 * Valores iniciales del servidor (`ebio_carousel_init_state()`): `isFirst` y `isLast` derivados del
 * contexto. Los getters de aquí los reemplazan al hidratar.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';
import { canNext, canPrev, clampIndex } from './lib.js';

const NAMESPACE = 'ebio/carousel';
const SHARED = Symbol.for( 'ebio/carousel:runtime' );
const ROOT = '[data-wp-interactive="ebio/carousel"]';
const TRACK = '[id$="-track"]';

/**
 * Pista de la raíz a la que pertenece un elemento (la propia pista, un control o la raíz).
 *
 * @param {Element} ref Elemento de la directiva.
 * @return {Element|null} Pista.
 */
const trackOf = ( ref ) => {
	if ( ! ref ) {
		return null;
	}
	if ( ref.matches?.( TRACK ) ) {
		return ref;
	}
	return ref.closest?.( ROOT )?.querySelector( TRACK ) ?? null;
};

/**
 * Medidas de la pista: paso entre tarjetas (ancho más separación) y cuántas caben.
 *
 * @param {Element|null} track Pista.
 * @return {{ slides: Element[], step: number, perView: number }} Medidas (`step` 0 si no hay tarjetas).
 */
const measure = ( track ) => {
	const slides = Array.from( track?.children ?? [] );
	if ( slides.length === 0 ) {
		return { slides, step: 0, perView: 1 };
	}
	const step = slides.length > 1 ? slides[ 1 ].offsetLeft - slides[ 0 ].offsetLeft : slides[ 0 ].offsetWidth;
	if ( ! ( step > 0 ) ) {
		return { slides, step: 0, perView: 1 };
	}
	return { slides, step, perView: Math.max( 1, Math.floor( ( track.clientWidth + 2 ) / step ) ) };
};

/**
 * Índice de la primera tarjeta visible según el desplazamiento; en los extremos exactos, el primero o
 * el último posible (una tarjeta parcial al final no deja el botón "Siguiente" activo).
 *
 * @param {Element|null} track Pista.
 * @return {number} Índice acotado.
 */
const indexFromScroll = ( track ) => {
	const { slides, step, perView } = measure( track );
	if ( step === 0 ) {
		return 0;
	}
	if ( track.scrollLeft + track.clientWidth >= track.scrollWidth - 1 ) {
		return clampIndex( slides.length, slides.length, perView );
	}
	return clampIndex( Math.round( track.scrollLeft / step ), slides.length, perView );
};

/**
 * Desplaza la pista hasta una tarjeta. Con "reducir movimiento" el salto es inmediato.
 *
 * @param {Element}  track Pista.
 * @param {number}   index Tarjeta destino.
 */
const scrollToIndex = ( track, index ) => {
	const { slides } = measure( track );
	if ( ! slides[ index ] ) {
		return;
	}
	const reduced = typeof window !== 'undefined' && window.matchMedia?.( '(prefers-reduced-motion: reduce)' )?.matches === true;
	track.scrollTo?.( { left: slides[ index ].offsetLeft - slides[ 0 ].offsetLeft, behavior: reduced ? 'auto' : 'smooth' } );
};

/**
 * Mueve la pista una "página" (tantas tarjetas como caben) y adelanta el índice del contexto.
 *
 * @param {number} direction -1 o 1.
 */
const move = ( direction ) => {
	const context = getContext();
	const track = trackOf( getElement().ref );
	const { slides, perView } = measure( track );
	const current = indexFromScroll( track );
	const target = clampIndex( Math.max( 0, current + direction * perView ), slides.length, perView );
	const root = getElement().ref?.closest?.( ROOT );
	const name = direction > 0 ? 'next' : 'prev';
	const pressed = root?.querySelector?.( `[data-wp-on--click="actions.${ name }"]` );
	const hadFocus = !! pressed && root.ownerDocument?.activeElement === pressed;
	context.index = target;
	scrollToIndex( track, target );
	// El botón pulsado se deshabilita al llegar al extremo: pasar el foco al contrario antes de perderlo.
	const reachedEnd = direction > 0 ? ! canNext( target, context.count, perView ) : ! canPrev( target );
	if ( hadFocus && reachedEnd ) {
		root.querySelector( `[data-wp-on--click="actions.${ direction > 0 ? 'prev' : 'next' }"]` )?.focus?.();
	}
};

/**
 * Registra el store una sola vez por página.
 */
function register() {
	store( NAMESPACE, {
		state: {
			get isFirst() {
				return ! canPrev( getContext().index );
			},
			get isLast() {
				const context = getContext();
				return ! canNext( context.index, context.count, measure( trackOf( getElement().ref ) ).perView );
			},
		},
		actions: {
			prev() {
				move( -1 );
			},
			next() {
				move( 1 );
			},
		},
		callbacks: {
			/** Hidrata: muestra los controles, cuenta las tarjetas reales y sigue los cambios de ancho. */
			init() {
				const context = getContext();
				const { ref } = getElement();
				const track = trackOf( ref );
				context.count = track?.children.length ?? context.count;
				context.index = indexFromScroll( track );
				context.hydrated = true;
				if ( track && typeof ResizeObserver !== 'undefined' ) {
					const observer = new ResizeObserver( () => {
						context.index = indexFromScroll( track );
					} );
					observer.observe( track );
					return () => observer.disconnect();
				}
				return undefined;
			},
			/** Mantiene `index` al desplazar con el dedo, la rueda o el teclado. */
			syncIndex() {
				const context = getContext();
				const next = indexFromScroll( trackOf( getElement().ref ) );
				if ( next !== context.index ) {
					context.index = next;
				}
			},
		},
	} );
	return true;
}

globalThis[ SHARED ] ??= register();

export const { state, actions, callbacks } = store( NAMESPACE );
