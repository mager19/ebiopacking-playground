/**
 * Funciones puras del store compartido `ebio/carousel` (docs/blocks/product-carousel.md y
 * testimonials.md). `index` es la posición de la primera tarjeta visible; `perView` cuántas caben a la
 * vez. Sin DOM: las usan el store y las pruebas de Node.
 */

/**
 * @param {*} value Valor a convertir.
 * @return {number} Entero mayor o igual que 0.
 */
const whole = ( value ) => {
	const number = Math.trunc( Number( value ) );
	return Number.isFinite( number ) && number > 0 ? number : 0;
};

/**
 * Último índice al que puede llegar la primera tarjeta visible sin dejar huecos al final.
 *
 * @param {number} count   Total de tarjetas.
 * @param {number} perView Tarjetas visibles a la vez (mínimo 1).
 * @return {number} Índice máximo (0 si todo cabe).
 */
export function maxIndex( count, perView ) {
	return Math.max( 0, whole( count ) - Math.max( 1, whole( perView ) ) );
}

/**
 * Limita `index` al rango válido `[0, count - perView]`.
 *
 * @param {number} index   Índice pedido.
 * @param {number} count   Total de tarjetas.
 * @param {number} perView Tarjetas visibles a la vez.
 * @return {number} Índice válido.
 */
export function clampIndex( index, count, perView ) {
	return Math.min( whole( index ), maxIndex( count, perView ) );
}

/**
 * @param {number} index Índice actual.
 * @return {boolean} `true` si hay tarjetas antes.
 */
export function canPrev( index ) {
	return whole( index ) > 0;
}

/**
 * @param {number} index   Índice actual.
 * @param {number} count   Total de tarjetas.
 * @param {number} perView Tarjetas visibles a la vez.
 * @return {boolean} `true` si hay tarjetas después de las visibles.
 */
export function canNext( index, count, perView ) {
	return whole( index ) < maxIndex( count, perView );
}
