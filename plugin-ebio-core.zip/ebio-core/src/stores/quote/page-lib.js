/**
 * Lógica pura de la página de cotización (`ebio/quote-list`, `ebio/quote-form`), sin la Interactivity
 * API: se prueba en Node. Los mensajes llegan de `ebio_quote_messages()` (estado `messages`), así que
 * servidor, JS y resumen dicen lo mismo (M19, C-B4).
 *
 * @typedef {import('./lib.js').Item} Item
 */
import { ITEM_FIELDS, payloadNumber } from './lib.js';

/** Orden de los campos del formulario (y del resumen de errores). */
export const FIELD_ORDER = Object.freeze( [ 'company', 'name', 'email', 'phone', 'city', 'sector', 'message', 'consent', 'items' ] );

/** Límites en caracteres (puntos de código, como `mb_strlen`); iguales a `includes/quote/validate.php`. */
export const FIELD_LIMITS = Object.freeze( { company: 120, name: 120, email: 254, phone: 30, city: 80, sector: 40, message: 2000 } );

export const SECTORS = Object.freeze( [ 'floricultura', 'agro-frutas', 'industria', 'alimentos', 'retail-ecommerce', 'otro' ] );

/** Claves del cuerpo del POST (catalog §4), en este orden. */
export const PAYLOAD_KEYS = Object.freeze( [ '_ebio_nonce', 'company', 'name', 'email', 'phone', 'city', 'sector', 'message', 'consent', 'website', 'items' ] );

const length = ( value ) => Array.from( value ).length;
const text = ( value ) => ( typeof value === 'string' ? value.trim() : '' );

/**
 * Descarta los ítems cuyo producto ya no está publicado (no está en el catálogo).
 *
 * @param {Item[]} items   Lista guardada.
 * @param {Object} catalog `{ "<id>": { name, … } }` de los productos publicados.
 * @return {Item[]} Ítems con producto publicado, en el mismo orden.
 */
export function reconcile( items, catalog ) {
	const known = catalog && typeof catalog === 'object' ? catalog : {};
	return ( Array.isArray( items ) ? items : [] ).filter( ( item ) => Object.prototype.hasOwnProperty.call( known, String( item?.id ) ) );
}

/**
 * Ítems de la lista cruzados con el catálogo, con lo que pinta cada `<li>`. La nota se muestra si tiene
 * texto o si se abrió con "+ Agregar nota" (`openNotes`).
 *
 * @param {Item[]}   items       Lista (ya reconciliada).
 * @param {Object}   catalog     Catálogo de productos publicados.
 * @param {number[]} [openNotes] Productos con la nota abierta.
 * @return {Object[]} `{ id, name, url, category, image, quantity, quantityUnit, length, width, height, dimensionUnit, notes, notesOpen, fieldIds, removeLabel }`.
 */
export function buildListItems( items, catalog, openNotes = [] ) {
	return reconcile( items, catalog ).map( ( item ) => {
		const product = catalog[ String( item.id ) ];
		const fieldIds = Object.fromEntries( ITEM_FIELDS.map( ( field ) => [ field, `ebio-quote-item-${ item.id }-${ field }` ] ) );
		return {
			id: item.id,
			name: product.name ?? '',
			url: product.url ?? '',
			category: product.category ?? '',
			image: product.image ?? null,
			...Object.fromEntries( ITEM_FIELDS.map( ( field ) => [ field, item[ field ] ?? '' ] ) ),
			notesOpen: ( item.notes ?? '' ) !== '' || ( Array.isArray( openNotes ) && openNotes.includes( item.id ) ),
			fieldIds,
			removeLabel: `: ${ product.name ?? '' }`,
		};
	} );
}

/**
 * @param {number} count Productos.
 * @return {string} " · 3 productos" (el H2 queda "Tu lista · 3 productos").
 */
export const countText = ( count ) => ( count > 0 ? ` · ${ count } ${ count === 1 ? 'producto' : 'productos' }` : '' );

/**
 * @param {number} count Productos.
 * @return {string} " (3 productos)" / " (1 producto)"; vacío sin productos.
 */
export const submitCountText = ( count ) => ( count > 0 ? ` (${ count } ${ count === 1 ? 'producto' : 'productos' })` : '' );

/**
 * @param {number} count Campos con error.
 * @return {string} Título del resumen de errores.
 */
export const summaryTitle = ( count ) => ( count > 0 ? `Revisa ${ count } ${ count === 1 ? 'campo' : 'campos' } para enviar tu solicitud:` : '' );

/**
 * Valida el formulario con las mismas reglas y textos que `ebio_quote_validate()`.
 *
 * @param {Object}  values   `{ company, name, email, phone, city, sector, message }`.
 * @param {boolean} consent  Casilla de tratamiento de datos.
 * @param {Object}  messages `ebio_quote_messages()`.
 * @return {Record<string,string>} Mensaje por campo con error (vacío si todo es válido).
 */
export function validateForm( values, consent, messages ) {
	const errors = {};
	const clean = {};
	for ( const field of Object.keys( FIELD_LIMITS ) ) {
		clean[ field ] = text( values?.[ field ] );
	}

	const rules = {
		company: [ messages.company_required, messages.company_long ],
		name: [ messages.name_required, messages.name_long ],
		email: [ messages.email, messages.email ],
		phone: [ messages.phone, messages.phone ],
		city: [ null, messages.city_long ],
		sector: [ null, messages.sector ],
		message: [ null, messages.message_long ],
	};
	for ( const [ field, [ required, long ] ] of Object.entries( rules ) ) {
		if ( required && clean[ field ] === '' ) {
			errors[ field ] = required;
		} else if ( length( clean[ field ] ) > FIELD_LIMITS[ field ] ) {
			errors[ field ] = long;
		}
	}

	if ( ! errors.email && ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( clean.email ) ) {
		errors.email = messages.email;
	}
	if ( ! errors.phone && ( ! /^[0-9 +()-]+$/.test( clean.phone ) || ( clean.phone.match( /\d/g ) ?? [] ).length < 7 ) ) {
		errors.phone = messages.phone;
	}
	if ( clean.sector !== '' && ! SECTORS.includes( clean.sector ) ) {
		errors.sector = messages.sector;
	}
	if ( consent !== true ) {
		errors.consent = messages.consent;
	}
	return errors;
}

/**
 * Cuerpo del POST a `ebio/v1/quote` (catalog §4). Sin cabecera `X-WP-Nonce`: el nonce va en el cuerpo.
 * Nunca viaja un nombre de producto: solo `product_id` y lo que escribió la persona. Cantidad y medidas
 * van como número normalizado (`payloadNumber`) o vacías, con sus unidades.
 *
 * @param {Object} values `{ company, name, email, phone, city, sector, message, website }` (`website` es la trampa: vacía salvo un bot).
 * @param {Item[]} items  Lista reconciliada.
 * @param {string} nonce  `ebio_quote_create_nonce()`.
 * @return {Object} Cuerpo con las claves exactas de `PAYLOAD_KEYS`.
 */
export function toPayload( values, items, nonce ) {
	return {
		_ebio_nonce: nonce,
		company: text( values?.company ),
		name: text( values?.name ),
		email: text( values?.email ),
		phone: text( values?.phone ),
		city: text( values?.city ),
		sector: text( values?.sector ),
		message: typeof values?.message === 'string' ? values.message.trim() : '',
		consent: '1',
		website: typeof values?.website === 'string' ? values.website : '',
		items: ( Array.isArray( items ) ? items : [] ).map( ( item ) => ( {
			product_id: item.id,
			quantity: payloadNumber( item.quantity, true ),
			quantity_unit: typeof item.quantityUnit === 'string' ? item.quantityUnit : '',
			length: payloadNumber( item.length ),
			width: payloadNumber( item.width ),
			height: payloadNumber( item.height ),
			dimension_unit: typeof item.dimensionUnit === 'string' ? item.dimensionUnit : '',
			notes: typeof item.notes === 'string' ? item.notes : '',
		} ) ),
	};
}

/**
 * Respuesta de error del servidor (`WP_Error` como JSON) → qué mostrar.
 *
 * @param {number} status   Código HTTP.
 * @param {Object} body     Cuerpo JSON (`{ code, data: { fields } }`).
 * @param {Object} messages `ebio_quote_messages()`.
 * @return {{ fields: Record<string,string>, formError: string }} Errores por campo o texto de formulario.
 */
export function mapErrorResponse( status, body, messages ) {
	const code = typeof body?.code === 'string' ? body.code : '';
	if ( status === 400 && code === 'ebio_invalid' && body?.data?.fields && typeof body.data.fields === 'object' ) {
		return { fields: body.data.fields, formError: '' };
	}
	const byCode = {
		ebio_bad_nonce: messages.bad_nonce_js,
		ebio_rate_limited: messages.rate_limited,
		ebio_spam: messages.spam,
		ebio_save_failed: messages.save_failed,
	};
	return { fields: {}, formError: byCode[ code ] ?? messages.invalid };
}
