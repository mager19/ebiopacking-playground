/**
 * Store compartido `ebio/quote` (catalog §4): lista de cotización del navegador.
 *
 * `state.items` es la fuente de verdad en ejecución: `localStorage['ebio-quote-v1']` solo la persiste.
 * Si el almacenamiento está bloqueado, la lista vive en el propio estado durante la visita.
 *
 * Cada bloque con `viewScriptModule` que importa este archivo empaqueta su propia copia; la primera
 * que se evalúa registra el store, el oyente de `storage` y el temporizador del aviso, y las demás
 * solo reutilizan el store registrado (marca compartida en `globalThis`).
 *
 * Valores iniciales del servidor (`ebio_quote_init_state()`): `count`, `quoteLabel`, `counterLabel`,
 * `cardState`, `cardDisabled`, `toastVisible`, `toastText`, `max`, `quoteUrl`, `restUrl`, `messages`.
 * Los getters de aquí reemplazan `count`, `counterLabel`, `cardState` y `cardDisabled` al hidratar.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';
import { addItem, counterLabel, createStorage, MAX_ITEMS, STORAGE_KEY, toastText } from './lib.js';

const NAMESPACE = 'ebio/quote';
const TOAST_MS = 5000;
const SHARED = Symbol.for( 'ebio/quote:runtime' );

/**
 * Registra el store una sola vez por página.
 *
 * @return {{ storage: ReturnType<typeof createStorage>, toastTimer: * }} Recursos compartidos.
 */
function register() {
	const runtime = { storage: createStorage( typeof window === 'undefined' ? undefined : window ), toastTimer: null };
	const { storage } = runtime;

	/**
	 * Agrega sobre la lista guardada más reciente (otra pestaña pudo cambiarla sin que llegara aún el
	 * evento `storage`), actualiza `state.items` y persiste.
	 *
	 * @param {{ id: number, quantity?: string, dimensions?: string }} entry Producto.
	 * @return {'added'|'updated'|'full'|'invalid'} Resultado.
	 */
	const save = ( entry ) => {
		const current = storage.persistent ? storage.read() : state.items;
		const { items, status } = addItem( current, entry );
		if ( status === 'added' || status === 'updated' ) {
			state.items = items;
			storage.write( items );
		} else {
			state.items = current;
		}
		return status;
	};

	/** @param {string} text Texto del aviso del header, visible unos segundos. */
	const showToast = ( text ) => {
		state.toastText = text;
		state.toastVisible = true;
		clearTimeout( runtime.toastTimer );
		runtime.toastTimer = setTimeout( () => {
			state.toastVisible = false;
			state.lastAddedId = 0;
		}, TOAST_MS );
	};

	const { state } = store( NAMESPACE, {
		state: {
			items: storage.read(),
			// Producto agregado desde una tarjeta mientras el aviso está visible (`cardState` "added").
			lastAddedId: 0,
			get count() {
				return state.items.length;
			},
			get counterLabel() {
				return counterLabel( state.items.length, state.quoteLabel );
			},
			/** `data-state` del botón de la tarjeta: idle | in-list | added | full. */
			get cardState() {
				const { productId, inList } = getContext();
				if ( inList ) {
					return state.toastVisible && state.lastAddedId === productId ? 'added' : 'in-list';
				}
				return state.items.length >= MAX_ITEMS ? 'full' : 'idle';
			},
			/** `aria-disabled` del botón: `true` con la lista llena; `null` (sin atributo), nunca `false` (D8). */
			get cardDisabled() {
				return state.cardState === 'full' ? true : null;
			},
		},
		actions: {
			/** Tarjeta de producto: agrega sin cantidad ni medidas y avisa en el `__toast` del header. */
			addFromCard( event ) {
				event?.preventDefault?.();
				const context = getContext();
				const result = save( { id: context.productId } );
				if ( result === 'invalid' ) {
					return;
				}
				if ( result !== 'full' ) {
					state.lastAddedId = context.productId;
				}
				showToast( toastText( result, state.items.length ) );
			},
			/**
			 * `add-to-quote`: agrega con `cantidad` y `medidas` del formulario y deja el resultado en
			 * `context.status` (added | updated | full | storage-error). No usa el aviso del header.
			 */
			addFromForm( event ) {
				event?.preventDefault?.();
				const context = getContext();
				const form = getElement().ref;
				const field = ( name ) => ( form?.elements?.namedItem?.( name )?.value ?? '' ).trim();
				const result = save( { id: context.productId, quantity: field( 'cantidad' ), dimensions: field( 'medidas' ) } );
				if ( result === 'invalid' ) {
					return;
				}
				context.status = result !== 'full' && ! storage.persistent ? 'storage-error' : result;
			},
		},
		callbacks: {
			/** `data-wp-watch` de la tarjeta: marca si su producto está en la lista (también da `aria-pressed`). */
			syncCard() {
				const context = getContext();
				context.inList = state.items.some( ( item ) => item.id === context.productId );
			},
		},
	} );

	/** Reemplaza la lista (edición, quitar, deshacer, vaciar, reconciliar) y la persiste. */
	runtime.commit = ( items ) => {
		state.items = items;
		storage.write( items );
	};

	// Otra pestaña cambió la lista: se relee (el evento no llega a la pestaña que escribió).
	if ( typeof window !== 'undefined' && typeof window.addEventListener === 'function' ) {
		window.addEventListener( 'storage', ( event ) => {
			if ( storage.persistent && ( event.key === STORAGE_KEY || event.key === null ) ) {
				state.items = storage.read();
			}
		} );
	}
	return runtime;
}

globalThis[ SHARED ] ??= register();

export const { state, actions, callbacks } = store( NAMESPACE );

/**
 * Página de cotización (`quote-list`, `quote-form`): reemplaza la lista del store compartido y la
 * persiste, sin crear otro store.
 *
 * @param {import('./lib.js').Item[]} items Lista nueva.
 */
export const commitItems = ( items ) => globalThis[ SHARED ].commit( items );
