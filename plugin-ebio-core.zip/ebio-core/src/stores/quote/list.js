/**
 * `ebio/quote-list` (docs/blocks/quote-list.md): extiende el store compartido `ebio/quote` con la lista
 * editable de `/cotizar/`. `state.items` sigue siendo la única fuente de verdad (la persiste
 * `commitItems`); aquí solo se cruza con `state.catalog` (productos publicados que publica el servidor).
 *
 * Valores iniciales del servidor (`ebio_quote_list_init_state()`): `catalog`, `listStatus: "loading"`,
 * `isLoading: true`, `hasItems: false`, `isEmpty: false`, `countText: ""`, `canUndo: false`,
 * `undoText: ""`, `listItems: []`. Los getters de aquí los reemplazan al hidratar. `openNotes` (ids con la
 * nota abierta) vive solo en el navegador.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';
import { commitItems } from './store.js';
import { removeItem, updateItem, ITEM_FIELDS, MAX_ITEMS } from './lib.js';
import { buildListItems, countText, reconcile } from './page-lib.js';

const UNDO_MS = 8000;
let undoTimer = null;
/** @type {Array<{ item: Object, index: number }>} */
let undoEntries = [];

/** @param {Object[]} items Ítems del store (proxies) → copias planas. */
const plain = ( items ) => items.map( ( item ) => Object.fromEntries( [ [ 'id', item.id ], ...ITEM_FIELDS.map( ( field ) => [ field, item[ field ] ] ) ] ) );

const { state } = store( 'ebio/quote', {
	state: {
		loaded: false,
		// Productos con la nota abierta con "+ Agregar nota" (solo durante la visita, no se guarda).
		openNotes: [],
		get isLoading() {
			return state.loaded === false;
		},
		get hasItems() {
			return state.loaded !== false && state.items.length > 0;
		},
		get isEmpty() {
			return state.loaded !== false && state.items.length === 0;
		},
		get listStatus() {
			if ( state.loaded === false ) {
				return 'loading';
			}
			return state.items.length > 0 ? 'list' : 'empty';
		},
		get countText() {
			return countText( state.items.length );
		},
		get listItems() {
			return state.loaded === false ? [] : buildListItems( state.items, state.catalog ?? {}, state.openNotes ?? [] );
		},
	},
	actions: {
		/** Cantidad, unidad, medidas o notas de un ítem (el campo va en `data-field`). */
		updateField( event ) {
			const { item } = getContext();
			const field = event?.target?.dataset?.field;
			commitItems( plain( updateItem( state.items, item.id, field, event?.target?.value ?? '' ) ) );
		},
		/** "+ Agregar nota": muestra el campo de notas del ítem y lo enfoca. */
		openNote() {
			const { item } = getContext();
			if ( ! state.openNotes.includes( item.id ) ) {
				state.openNotes = [ ...state.openNotes, item.id ];
			}
			const row = getElement().ref?.closest?.( 'li' );
			window.requestAnimationFrame( () => row?.querySelector?.( '.ebio-quote-list__textarea' )?.focus() );
		},
		/** Quita un ítem, ofrece "Deshacer" y mueve el foco al siguiente "Quitar" (o al H2). */
		remove() {
			const { item } = getContext();
			const index = state.items.findIndex( ( entry ) => entry.id === item.id );
			const { removed } = removeItem( state.items, item.id );
			if ( ! removed ) {
				return;
			}
			const row = getElement().ref?.closest?.( 'li' );
			const target = row?.nextElementSibling ?? row?.previousElementSibling;
			const next = target?.querySelector?.( '.ebio-quote-list__remove' );
			const remaining = plain( state.items.filter( ( entry ) => entry.id !== item.id ) );
			offerUndo( [ { item: plain( [ removed ] )[ 0 ], index } ], `Quitaste ${ item.name }.` );
			if ( next ) {
				next.focus();
			}
			commitItems( remaining );
			if ( ! next ) {
				focusHeading();
			}
		},
		/** "Vaciar lista": vacía y ofrece deshacer (sin `confirm()`). */
		clear() {
			const entries = plain( state.items ).map( ( item, index ) => ( { item, index } ) );
			if ( entries.length === 0 ) {
				return;
			}
			offerUndo( entries, 'Vaciaste tu lista.' );
			commitItems( [] );
			focusHeading();
		},
		undoRemove() {
			const items = plain( state.items );
			for ( const { item, index } of undoEntries ) {
				if ( items.length < MAX_ITEMS && ! items.some( ( entry ) => entry.id === item.id ) ) {
					items.splice( Math.min( index, items.length ), 0, item );
				}
			}
			clearUndo();
			commitItems( items );
		},
	},
	callbacks: {
		/** Al cargar: descarta los productos que ya no están publicados y muestra la lista. */
		load() {
			const clean = reconcile( state.items, state.catalog ?? {} );
			if ( clean.length !== state.items.length ) {
				commitItems( plain( clean ) );
			}
			state.loaded = true;
		},
	},
} );

/**
 * @param {Array<{ item: Object, index: number }>} entries Lo que "Deshacer" devuelve.
 * @param {string}                                   text    Aviso.
 */
function offerUndo( entries, text ) {
	undoEntries = entries;
	state.undoText = text;
	state.canUndo = true;
	clearTimeout( undoTimer );
	undoTimer = setTimeout( clearUndo, UNDO_MS );
}

function clearUndo() {
	clearTimeout( undoTimer );
	undoEntries = [];
	state.canUndo = false;
	state.undoText = '';
}

/** Foco al H2 de la lista (lista vacía): se vuelve enfocable solo para esto. */
function focusHeading() {
	const heading = document.getElementById( 'ebio-quote-list-heading' );
	if ( heading ) {
		heading.setAttribute( 'tabindex', '-1' );
		heading.focus();
	}
}
