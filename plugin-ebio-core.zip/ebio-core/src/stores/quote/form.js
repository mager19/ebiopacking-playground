/**
 * `ebio/quote-form` (docs/blocks/quote-form.md): extiende el store compartido `ebio/quote` con el
 * envío por REST. Sin JS el formulario hace `POST` a `admin-post.php` (progresivo, D9).
 *
 * Valores iniciales del servidor (`ebio_quote_form_init_state()`): `form` (`status`, `isSubmitting`,
 * `hasErrors`, `errorCount`, `summaryTitle`, `values`, `errors`, `invalid`, `formError`), `hasItems`,
 * `submitCountText`, `messages`, `restUrl`.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';
import { commitItems } from './store.js';
import { FIELD_ORDER, mapErrorResponse, reconcile, submitCountText, summaryTitle, toPayload, validateForm } from './page-lib.js';

const FIELDS = [ 'company', 'name', 'email', 'phone', 'city', 'sector', 'message' ];
let inFlight = false;
let attempted = false;

const { state } = store( 'ebio/quote', {
	state: {
		get hasItems() {
			return state.loaded !== false && state.items.length > 0;
		},
		get submitCountText() {
			return submitCountText( state.items.length );
		},
	},
	actions: {
		/** Valida en el cliente con los mismos textos del servidor y envía por REST (una sola vez). */
		async submit( event ) {
			event?.preventDefault?.();
			if ( inFlight ) {
				return;
			}
			const form = getElement().ref;
			const values = readValues( form );
			attempted = true;
			const errors = validateForm( values, form.elements.namedItem( 'consent' )?.checked === true, state.messages );
			if ( Object.keys( errors ).length > 0 ) {
				showFieldErrors( errors );
				return;
			}

			inFlight = true;
			state.form.isSubmitting = true;
			state.form.status = 'submitting';
			state.form.formError = '';
			try {
				const catalog = state.catalog && Object.keys( state.catalog ).length > 0 ? state.catalog : null;
				const items = ( catalog ? reconcile( state.items, catalog ) : state.items ).map( ( item ) => ( { ...item } ) );
				const payload = toPayload( values, items, form.elements.namedItem( '_ebio_nonce' )?.value ?? '' );
				const response = await fetch( state.restUrl, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
					body: JSON.stringify( payload ),
				} );
				const body = await response.json().catch( () => ( {} ) );
				if ( response.status === 201 && isLocalPath( body?.redirect ) ) {
					state.form.status = 'success';
					commitItems( [] );
					window.location.assign( body.redirect );
					return; // El botón queda deshabilitado mientras se navega.
				}
				const result = mapErrorResponse( response.status, body, state.messages );
				if ( Object.keys( result.fields ).length > 0 ) {
					showFieldErrors( result.fields );
				} else {
					showFormError( result.formError );
				}
			} catch ( error ) {
				showFormError( state.messages.network );
			}
			inFlight = false;
			state.form.isSubmitting = false;
		},
		/** Mantiene `state.form.values` al día: el `input` está enlazado a él y se repinta con ese valor. */
		setValue( event ) {
			const field = event?.target?.name;
			if ( FIELDS.includes( field ) ) {
				state.form.values[ field ] = event.target.value;
			}
		},
		/** Al salir de un campo: solo tras el primer intento de envío o si ya tenía error. */
		validateField( event ) {
			const input = event?.target;
			const field = input?.name;
			if ( ! FIELDS.includes( field ) || ( ! attempted && ! state.form.errors[ field ] ) ) {
				return;
			}
			const form = input.form;
			const errors = validateForm( readValues( form ), form.elements.namedItem( 'consent' )?.checked === true, state.messages );
			setErrors( { ...currentErrors(), [ field ]: errors[ field ] ?? '' } );
			state.form.status = state.form.hasErrors ? 'invalid' : 'idle';
		},
	},
	callbacks: {
		/** El formulario ya es interactivo: se activa la validación propia (`novalidate`). */
		initForm() {
			getContext().hydrated = true;
		},
	},
} );

/**
 * @param {HTMLFormElement} form Formulario.
 * @return {Object} Valores de los campos de texto y la trampa.
 */
function readValues( form ) {
	const values = {};
	for ( const field of FIELDS ) {
		values[ field ] = form.elements.namedItem( field )?.value ?? '';
	}
	values.website = form.elements.namedItem( 'website' )?.value ?? '';
	return values;
}

/** @param {*} path Valor de `redirect`. @return {boolean} Es una ruta del propio sitio. */
const isLocalPath = ( path ) => typeof path === 'string' && /^\/(?!\/)/.test( path );

function currentErrors() {
	return Object.fromEntries( FIELD_ORDER.map( ( field ) => [ field, state.form.errors[ field ] ?? '' ] ) );
}

/**
 * Publica los errores por campo y recalcula lo que dependen de ellos.
 *
 * @param {Record<string,string>} errors Mensaje por campo.
 */
function setErrors( errors ) {
	const next = {};
	const invalid = {};
	for ( const field of FIELD_ORDER ) {
		next[ field ] = typeof errors[ field ] === 'string' ? errors[ field ] : '';
		invalid[ field ] = next[ field ] !== '';
	}
	const count = FIELD_ORDER.filter( ( field ) => invalid[ field ] ).length;
	state.form.errors = next;
	state.form.invalid = invalid;
	state.form.errorCount = count;
	state.form.hasErrors = count > 0;
	state.form.summaryTitle = summaryTitle( count );
}

/** Errores de campo (cliente o servidor): resumen visible y foco en él. */
function showFieldErrors( errors ) {
	setErrors( errors );
	state.form.formError = '';
	state.form.status = 'invalid';
	focus( '#ebio-quote-form-summary' );
}

/** Error de formulario (nonce, frecuencia, guardado, red, trampa): `__alert` visible. */
function showFormError( message ) {
	setErrors( {} );
	state.form.formError = message;
	state.form.status = 'error';
}

function focus( selector ) {
	window.requestAnimationFrame( () => document.querySelector( selector )?.focus() );
}
