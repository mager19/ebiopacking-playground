/**
 * Lógica pura de la lista de cotización (catalog §4, D11), sin la Interactivity API: se prueba en Node.
 *
 * La lista guarda solo datos del producto (nunca datos personales), con campos estructurados (v2):
 * `{ id, quantity, quantityUnit, length, width, height, dimensionUnit, notes }`. Las cantidades y medidas
 * son texto numérico tal como lo da el `<input type="number">`; se normalizan al enviar (`payloadNumber`).
 * Las listas v1 (`quantity` y `dimensions` de texto libre) se migran al leerlas (`fromLegacy`): lo que no
 * se puede leer como número pasa a las notas, nunca se pierde.
 *
 * Límites iguales a `includes/quote/validate.php`: 30 productos; `quantity` 9, medidas 9 y `notes` 500
 * caracteres (puntos de código, como `mb_strlen`).
 *
 * @typedef {{ id: number, quantity: string, quantityUnit: string, length: string, width: string, height: string, dimensionUnit: string, notes: string }} Item
 */

export const STORAGE_KEY = 'ebio-quote-v1';
export const MAX_ITEMS = 30;
export const LIMITS = Object.freeze( { quantity: 9, length: 9, width: 9, height: 9, notes: 500 } );
export const QUANTITY_UNITS = Object.freeze( [ 'unidades', 'pallets' ] );
export const DIMENSION_UNITS = Object.freeze( [ 'cm', 'mm' ] );
export const UNITS = Object.freeze( { quantityUnit: QUANTITY_UNITS, dimensionUnit: DIMENSION_UNITS } );
/** Campos de un ítem, en orden (sin `id`). */
export const ITEM_FIELDS = Object.freeze( [ 'quantity', 'quantityUnit', 'length', 'width', 'height', 'dimensionUnit', 'notes' ] );
/** Campos de medida, en orden: largo × ancho × alto. */
export const DIMENSION_FIELDS = Object.freeze( [ 'length', 'width', 'height' ] );

const VERSION = 2;
// Igual que el backend: `product_id` entero positivo de hasta 9 dígitos.
const MAX_ID = 999999999;

/**
 * @param {*} id Valor recibido.
 * @return {boolean} Es un ID de producto válido.
 */
const isValidId = ( id ) => Number.isInteger( id ) && id > 0 && id <= MAX_ID;

/**
 * Texto recortado a `max` caracteres; lo que no es texto queda vacío.
 *
 * @param {*}      value Valor recibido.
 * @param {number} max   Límite en caracteres.
 * @return {string} Texto dentro del límite.
 */
const clip = ( value, max ) => ( typeof value === 'string' ? Array.from( value ).slice( 0, max ).join( '' ) : '' );

/**
 * @param {*}        value   Valor recibido.
 * @param {string[]} allowed Unidades válidas (la primera es la de por defecto).
 * @return {string} Unidad válida.
 */
const unit = ( value, allowed ) => ( allowed.includes( value ) ? value : allowed[ 0 ] );

/**
 * @param {Object} raw Ítem v2 de entrada con `id` válido.
 * @return {Item} Ítem normalizado.
 */
const normalize = ( raw ) => ( {
	id: raw.id,
	quantity: clip( raw.quantity, LIMITS.quantity ),
	quantityUnit: unit( raw.quantityUnit, QUANTITY_UNITS ),
	length: clip( raw.length, LIMITS.length ),
	width: clip( raw.width, LIMITS.width ),
	height: clip( raw.height, LIMITS.height ),
	dimensionUnit: unit( raw.dimensionUnit, DIMENSION_UNITS ),
	notes: clip( raw.notes, LIMITS.notes ),
} );

/**
 * Número de una medida o cantidad listo para enviar: entero (`integer`) o con hasta 2 decimales; acepta
 * coma decimal. Vacío si no es un número positivo dentro del límite del backend.
 *
 * @param {*}       value   Valor guardado.
 * @param {boolean} integer Solo enteros (cantidad).
 * @return {string} `"500"`, `"60.5"` o `""`.
 */
export function payloadNumber( value, integer = false ) {
	const text = typeof value === 'string' || typeof value === 'number' ? String( value ).trim().replace( ',', '.' ) : '';
	if ( text === '' || ! /^\d+(\.\d+)?$/.test( text ) ) {
		return '';
	}
	const number = Number( text );
	const rounded = integer ? Math.round( number ) : Math.round( number * 100 ) / 100;
	if ( ! Number.isFinite( rounded ) || rounded <= 0 || rounded > ( integer ? 999999999 : 999999 ) ) {
		return '';
	}
	return String( rounded );
}

/**
 * Cantidad de texto libre (v1 o el formulario de la ficha) → número y unidad. Acepta separador de miles
 * ("1.000") y las unidades "unidades/und/u" y "pallets/palets/estibas".
 *
 * @param {string} text Texto.
 * @return {{ quantity: string, quantityUnit: string }|null} `null` si no se puede leer.
 */
export function parseQuantity( text ) {
	const match = /^(\d{1,3}(?:[.,]\d{3})+|\d{1,9})\s*([a-záéíóúñ.]*)$/i.exec( String( text ?? '' ).trim() );
	if ( ! match ) {
		return null;
	}
	const word = match[ 2 ].toLowerCase().replace( /\.$/, '' );
	let quantityUnit = '';
	if ( [ '', 'u', 'un', 'und', 'unds', 'unid', 'unidad', 'unidades' ].includes( word ) ) {
		quantityUnit = 'unidades';
	} else if ( /^(pallets?|palets?|estibas?)$/.test( word ) ) {
		quantityUnit = 'pallets';
	} else {
		return null;
	}
	const quantity = payloadNumber( match[ 1 ].replace( /[.,]/g, '' ), true );
	return quantity === '' ? null : { quantity, quantityUnit };
}

/**
 * Medidas de texto libre ("60 × 40 × 40 cm", "600x400x400 mm") → largo, ancho, alto y unidad (cm por defecto).
 *
 * @param {string} text Texto.
 * @return {{ length: string, width: string, height: string, dimensionUnit: string }|null} `null` si no se puede leer.
 */
export function parseDimensions( text ) {
	const num = '(\\d{1,6}(?:[.,]\\d{1,2})?)';
	const sep = '\\s*[x×X*]\\s*';
	const match = new RegExp( `^${ num }${ sep }${ num }${ sep }${ num }\\s*(cm|mm)?\\.?$`, 'i' ).exec( String( text ?? '' ).trim() );
	if ( ! match ) {
		return null;
	}
	const [ length, width, height ] = [ match[ 1 ], match[ 2 ], match[ 3 ] ].map( ( value ) => payloadNumber( value ) );
	if ( ! length || ! width || ! height ) {
		return null;
	}
	return { length, width, height, dimensionUnit: ( match[ 4 ] ?? 'cm' ).toLowerCase() };
}

/**
 * Ítem con `quantity` / `dimensions` de texto libre (lista v1, formulario de la ficha) → ítem v2. Lo que no
 * se puede leer como número se conserva al inicio de las notas ("Cantidad: …", "Medidas: …").
 *
 * @param {{ id: number, quantity?: *, dimensions?: *, notes?: * }} raw Ítem con `id` válido.
 * @return {Item} Ítem v2.
 */
export function fromLegacy( raw ) {
	const quantityText = typeof raw.quantity === 'string' ? raw.quantity.trim() : '';
	const dimensionsText = typeof raw.dimensions === 'string' ? raw.dimensions.trim() : '';
	const quantity = quantityText === '' ? null : parseQuantity( quantityText );
	const dimensions = dimensionsText === '' ? null : parseDimensions( dimensionsText );
	const notes = [
		quantityText !== '' && ! quantity ? `Cantidad: ${ quantityText }` : '',
		dimensionsText !== '' && ! dimensions ? `Medidas: ${ dimensionsText }` : '',
		typeof raw.notes === 'string' ? raw.notes : '',
	].filter( ( line ) => line !== '' );
	return normalize( {
		id: raw.id,
		...( quantity ?? {} ),
		...( dimensions ?? {} ),
		notes: notes.join( '\n' ),
	} );
}

/**
 * Lista guardada → ítems válidos. JSON inválido, una versión desconocida o una forma inesperada dan `[]`;
 * la v1 se migra (`fromLegacy`). Se descartan ítems sin `id` entero positivo y duplicados (gana el
 * primero); máximo 30.
 *
 * @param {string|null} raw Valor de `localStorage[STORAGE_KEY]`.
 * @return {Item[]} Ítems válidos.
 */
export function parseStored( raw ) {
	if ( typeof raw !== 'string' ) {
		return [];
	}
	let data;
	try {
		data = JSON.parse( raw );
	} catch ( error ) {
		return [];
	}
	if ( ! data || typeof data !== 'object' || ( data.v !== 1 && data.v !== VERSION ) || ! Array.isArray( data.items ) ) {
		return [];
	}
	const read = data.v === 1 ? fromLegacy : normalize;
	const seen = new Set();
	const items = [];
	for ( const entry of data.items ) {
		if ( ! entry || typeof entry !== 'object' || ! isValidId( entry.id ) || seen.has( entry.id ) ) {
			continue;
		}
		seen.add( entry.id );
		items.push( read( entry ) );
		if ( items.length === MAX_ITEMS ) {
			break;
		}
	}
	return items;
}

/**
 * @param {Item[]} items Ítems.
 * @return {string} Valor para `localStorage[STORAGE_KEY]` (v2).
 */
export function serializeItems( items ) {
	return JSON.stringify( { v: VERSION, items: items.map( normalize ) } );
}

/**
 * Acceso a `localStorage` que nunca lanza. Si no existe o no deja escribir (modo privado, cuota,
 * bloqueado), `persistent` es `false`, `read()` devuelve `[]` y `write()` no hace nada: la lista
 * vive entonces solo en el estado del store durante la visita. Una escritura que falla a mitad de
 * la visita también apaga `persistent` (lo guardado ya no refleja la lista en memoria).
 *
 * @param {Window|Object|undefined} win Ventana (o un doble de pruebas).
 * @return {{ read: () => Item[], write: ( items: Item[] ) => void, persistent: boolean }} Almacenamiento.
 */
export function createStorage( win ) {
	let storage = null;
	try {
		storage = win?.localStorage ?? null;
		if ( storage ) {
			const probe = `${ STORAGE_KEY }-probe`;
			storage.setItem( probe, '1' );
			storage.removeItem( probe );
		}
	} catch ( error ) {
		storage = null;
	}
	return {
		get persistent() {
			return Boolean( storage );
		},
		read() {
			if ( ! storage ) {
				return [];
			}
			try {
				return parseStored( storage.getItem( STORAGE_KEY ) );
			} catch ( error ) {
				return [];
			}
		},
		write( items ) {
			if ( ! storage ) {
				return;
			}
			try {
				storage.setItem( STORAGE_KEY, serializeItems( items ) );
			} catch ( error ) {
				// Sin cuota o bloqueado a mitad de la visita: la lista sigue solo en memoria.
				storage = null;
			}
		},
	};
}

/**
 * Agrega un producto con la cantidad y las medidas de texto libre del formulario de la ficha (se leen con
 * `fromLegacy`). Si ya está, actualiza la cantidad o las medidas solo con valores no vacíos (no lo
 * duplica) y suma a las notas el texto que no se pudo leer. Con la lista llena, un producto nuevo no entra
 * (`full`). Un `id` que no es entero positivo no cambia nada (`invalid`). No muta `items`.
 *
 * @param {Item[]} items Lista actual.
 * @param {{ id: number, quantity?: string, dimensions?: string }} entry Producto.
 * @return {{ items: Item[], status: 'added'|'updated'|'full'|'invalid' }} Lista nueva y resultado.
 */
export function addItem( items, { id, quantity = '', dimensions = '' } ) {
	if ( ! isValidId( id ) ) {
		return { items, status: 'invalid' };
	}
	const next = fromLegacy( { id, quantity, dimensions, notes: '' } );
	const index = items.findIndex( ( item ) => item.id === id );
	if ( index > -1 ) {
		const current = items[ index ];
		const hasDimensions = DIMENSION_FIELDS.some( ( field ) => next[ field ] !== '' );
		const extra = next.notes !== '' && ! current.notes.includes( next.notes ) ? next.notes : '';
		const updated = normalize( {
			...current,
			...( next.quantity !== '' ? { quantity: next.quantity, quantityUnit: next.quantityUnit } : {} ),
			...( hasDimensions ? { length: next.length, width: next.width, height: next.height, dimensionUnit: next.dimensionUnit } : {} ),
			notes: [ current.notes, extra ].filter( ( line ) => line !== '' ).join( '\n' ),
		} );
		return { items: items.map( ( item, i ) => ( i === index ? updated : item ) ), status: 'updated' };
	}
	if ( items.length >= MAX_ITEMS ) {
		return { items, status: 'full' };
	}
	return { items: [ ...items, next ], status: 'added' };
}

/**
 * Cambia un campo de un ítem: los de texto se recortan a su límite y las unidades fuera de la lista vuelven
 * a la de por defecto. Otro campo o un `id` ausente devuelven la lista sin cambios. No muta `items`.
 *
 * @param {Item[]} items Lista actual.
 * @param {number} id    Producto.
 * @param {string} field Uno de `ITEM_FIELDS`.
 * @param {string} value Valor nuevo.
 * @return {Item[]} Lista nueva.
 */
export function updateItem( items, id, field, value ) {
	if ( ! ITEM_FIELDS.includes( field ) ) {
		return items;
	}
	const next = UNITS[ field ] ? unit( value, UNITS[ field ] ) : clip( value, LIMITS[ field ] );
	return items.map( ( item ) => ( item.id === id ? { ...item, [ field ]: next } : item ) );
}

/**
 * Quita un producto. No muta `items`.
 *
 * @param {Item[]} items Lista actual.
 * @param {number} id    Producto.
 * @return {{ items: Item[], removed: Item|null }} Lista nueva y el ítem quitado (para deshacer).
 */
export function removeItem( items, id ) {
	const removed = items.find( ( item ) => item.id === id ) ?? null;
	return { items: removed ? items.filter( ( item ) => item.id !== id ) : items, removed };
}

/**
 * @param {number} count Productos.
 * @return {string} "1 producto" / "N productos".
 */
const products = ( count ) => `${ count } ${ count === 1 ? 'producto' : 'productos' }`;

export const DEFAULT_QUOTE_LABEL = 'Mi cotización';

/**
 * Nombre accesible del contador del header: empieza por su texto visible (WCAG 2.5.3).
 * Gemelo de `ebio_quote_counter_label()`.
 *
 * @param {number} count   Productos en la lista.
 * @param {string} [label] `quoteLabel` del header; vacío → "Mi cotización".
 * @return {string} "<label>, N productos".
 */
export function counterLabel( count, label = DEFAULT_QUOTE_LABEL ) {
	const text = typeof label === 'string' && label.trim() !== '' ? label.trim() : DEFAULT_QUOTE_LABEL;
	return `${ text }, ${ products( count ) }`;
}

/**
 * Texto del aviso del header (`__toast`) tras agregar desde una tarjeta.
 *
 * @param {'added'|'updated'|'full'} status Resultado de `addItem`.
 * @param {number}                    count  Productos en la lista después de agregar.
 * @return {string} Texto del aviso.
 */
export function toastText( status, count ) {
	if ( status === 'full' ) {
		return `Tu lista llegó al máximo de ${ MAX_ITEMS } productos`;
	}
	return `Agregado a tu cotización (${ products( count ) })`;
}
