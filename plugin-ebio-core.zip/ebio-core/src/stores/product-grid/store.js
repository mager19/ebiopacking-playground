/**
 * Store `ebio/product-grid` (docs/blocks/product-grid.md): filtros de la grilla en el navegador, sin
 * petición al servidor.
 *
 * Contexto de la raíz: `{ categoria, sector, formato, panelOpen, hydrated }`. Cada ítem lleva su propio
 * contexto `{ categories, sectors, formats, hidden }` (hereda el de la raíz), así que `callbacks.syncItem`
 * se reevalúa solo cuando cambia la selección.
 *
 * Valores iniciales del servidor (`ebio_product_grid_init_state()`): `headingTemplate` (con `{count}` y
 * `{products}` por resolver), `headingText`, `countText`, `emptyTitle`, `liveText`, `isEmpty`, `resultCount`
 * (`data-count` de la raíz) e `isFew` (clase `--few`, de 1 a 3 resultados).
 */
import { store, getContext, getElement } from '@wordpress/interactivity';
import { GROUPS, matches, toSearch } from '../../blocks/product-grid/filter.js';

const NAMESPACE = 'ebio/product-grid';
const ROOT = '[data-wp-interactive="ebio/product-grid"]';
const ITEM = '.ebio-product-grid__item';

/**
 * Raíz de la grilla a la que pertenece un elemento.
 *
 * @param {Element|null} ref Elemento de la directiva.
 * @return {Element|null} Raíz.
 */
const rootOf = ( ref ) => ref?.closest?.( ROOT ) ?? null;

/**
 * Facetas de cada ítem, leídas de su contexto en el markup.
 *
 * @param {Element|null} root Raíz.
 * @return {Array<{ categories: string[], sectors: string[], formats: string[] }>} Facetas.
 */
function itemFacets( root ) {
	return Array.from( root?.querySelectorAll?.( ITEM ) ?? [] ).map( ( item ) => {
		try {
			return JSON.parse( item.getAttribute( 'data-wp-context' ) ?? '{}' ) ?? {};
		} catch ( error ) {
			return {};
		}
	} );
}

/**
 * Plantilla con `{count}` y `{products}` resueltos.
 *
 * @param {string} template Plantilla.
 * @param {number} count    Cantidad.
 * @return {string} Texto.
 */
const fill = ( template, count ) => String( template ?? '' ).replaceAll( '{count}', String( count ) ).replaceAll( '{products}', count === 1 ? 'producto' : 'productos' );

/**
 * Selección guardada en el contexto de la raíz.
 *
 * @param {Object} context Contexto.
 * @return {{ categoria: string[], sector: string[], formato: string[] }} Selección.
 */
const selectionOf = ( context ) => Object.fromEntries( GROUPS.map( ( key ) => [ key, Array.from( context?.[ key ] ?? [] ) ] ) );

/**
 * Recalcula los textos con la cantidad que cumple la selección y reemplaza la URL (sin recargar).
 *
 * @param {Element|null} root      Raíz.
 * @param {Object}       selection Selección.
 */
function refresh( root, selection ) {
	const count = itemFacets( root ).filter( ( facets ) => matches( facets, selection ) ).length;
	state.headingText = fill( state.headingTemplate, count );
	state.countText = fill( '{count} {products}', count );
	state.liveText = state.countText;
	state.isEmpty = count === 0;
	state.resultCount = count;
	state.isFew = count > 0 && count <= 3;
	try {
		window.history.replaceState( window.history.state, '', `${ window.location.pathname }${ toSearch( selection ) }${ window.location.hash }` );
	} catch ( error ) {
		// Sin historial (entornos restringidos): la grilla igual se filtra.
	}
}

export const { state, actions, callbacks } = store( NAMESPACE, {
	actions: {
		/** Lee las casillas del formulario, actualiza el contexto y los textos. */
		applyFilter() {
			const context = getContext();
			const { ref } = getElement();
			const form = ref?.matches?.( 'form' ) ? ref : ref?.closest?.( 'form' );
			const next = { categoria: [], sector: [], formato: [] };
			for ( const input of Array.from( form?.querySelectorAll?.( 'input[type="checkbox"]' ) ?? [] ) ) {
				const key = String( input.name ).replace( /\[\]$/, '' );
				if ( input.checked && next[ key ] ) {
					next[ key ].push( input.value );
				}
			}
			for ( const key of GROUPS ) {
				context[ key ] = next[ key ];
			}
			refresh( rootOf( form ), next );
		},
		/** Abre o cierra el panel de filtros del móvil. */
		togglePanel() {
			const context = getContext();
			context.panelOpen = ! context.panelOpen;
		},
		/** Escape cierra el panel abierto y devuelve el foco al botón "Filtrar" (igual que el menú y el buscador). */
		closePanelOnEscape( event ) {
			if ( event?.key !== 'Escape' ) {
				return;
			}
			const context = getContext();
			if ( ! context.panelOpen ) {
				return;
			}
			context.panelOpen = false;
			rootOf( getElement().ref )?.querySelector?.( '.ebio-product-grid__filters-toggle' )?.focus?.();
		},
		/** "Limpiar filtros": desmarca todo sin recargar. */
		clear( event ) {
			event?.preventDefault?.();
			const context = getContext();
			const root = rootOf( getElement().ref );
			for ( const input of Array.from( root?.querySelectorAll?.( '.ebio-product-grid__filters input[type="checkbox"]' ) ?? [] ) ) {
				input.checked = false;
			}
			for ( const key of GROUPS ) {
				context[ key ] = [];
			}
			refresh( root, { categoria: [], sector: [], formato: [] } );
		},
	},
	callbacks: {
		/** Hidrata: oculta "Aplicar filtros" y muestra el botón "Filtrar". */
		init() {
			getContext().hydrated = true;
		},
		/** Oculta o muestra un ítem según la selección de la raíz. */
		syncItem() {
			const context = getContext();
			const selection = selectionOf( context );
			context.hidden = ! matches( { categories: context.categories, sectors: context.sectors, formats: context.formats }, selection );
		},
	},
} );
